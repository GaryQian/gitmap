/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "tensorflow/core/platform/tensor_coding.h"

#include <climits>
#include <cstddef>
#include <vector>

#include "tensorflow/core/platform/coding.h"
#include "tensorflow/core/platform/logging.h"
#include "tensorflow/core/platform/protobuf.h"
#include "tensorflow/core/platform/strcat.h"
#include "tensorflow/core/platform/stringpiece.h"

#if defined(TENSORFLOW_PROTOBUF_USES_CORD)
#include "strings/cord_varint.h"
#include "third_party/gloop/strings/cord_bytestream.h"
#include "util/gtl/stl_util.h"
#endif  // defined(TENSORFLOW_PROTOBUF_USES_CORD)

namespace tensorflow {
namespace port {

void AssignRefCounted(absl::string_view src, core::RefCounted* obj,
                      std::string* out) {
  out->assign(src.data(), src.size());
}

void EncodeStringList(const tstring* strings, int64_t n, std::string* out) {
  int64_t tot = n * sizeof(size_t);
  for (int i = 0; i < n; ++i) {
    tot += strings[i].size();
  }
  if (tot > INT_MAX) {
    LOG(FATAL) << "EncodeStringList size too large: " << tot;  // Crash OK
  }
  out->clear();
  for (int i = 0; i < n; ++i) {
    core::PutVarint32(out, strings[i].size());
  }
  for (int i = 0; i < n; ++i) {
    out->append(strings[i]);
  }
}

bool DecodeStringList(const std::string& src, tstring* strings, int64_t n) {
  std::vector<uint32_t> sizes(n);
  absl::string_view reader(src);
  int64_t tot = 0;
  for (auto& v : sizes) {
    if (!core::GetVarint32(&reader, &v)) return false;
    tot += v;
  }
  if (tot != static_cast<int64_t>(reader.size())) {
    return false;
  }

  tstring* data = strings;
  for (int64_t i = 0; i < n; ++i, ++data) {
    auto size = sizes[i];
    if (size > reader.size()) {
      return false;
    }
    data->assign(reader.data(), size);
    reader.remove_prefix(size);
  }

  return true;
}

void CopyFromArray(std::string* s, const char* base, size_t bytes) {
  s->assign(base, bytes);
}

class StringListEncoderImpl : public StringListEncoder {
 public:
  explicit StringListEncoderImpl(std::string* out) : out_(out) {}
  ~StringListEncoderImpl() override = default;

  void Append(const protobuf::MessageLite& m) override {
    core::PutVarint32(out_, m.ByteSizeLong());
    std::string serialized_message;
    m.AppendToString(&serialized_message);
    absl::StrAppend(&rest_, serialized_message);
  }

  void Append(const std::string& s) override {
    core::PutVarint32(out_, s.length());
    absl::StrAppend(&rest_, s);
  }

  void Finalize() override { absl::StrAppend(out_, rest_); }

 private:
  std::string* out_;
  std::string rest_;
};

class StringListDecoderImpl : public StringListDecoder {
 public:
  explicit StringListDecoderImpl(const std::string& in) : reader_(in) {}
  ~StringListDecoderImpl() override = default;

  bool ReadSizes(std::vector<uint32_t>* sizes) override {
    int64_t total = 0;
    for (auto& size : *sizes) {
      if (!core::GetVarint32(&reader_, &size)) return false;
      total += size;
    }
    if (total != static_cast<int64_t>(reader_.size())) {
      return false;
    }
    return true;
  }

  const char* Data(uint32_t size) override {
    const char* data = reader_.data();
    reader_.remove_prefix(size);
    return data;
  }

 private:
  absl::string_view reader_;
};

std::unique_ptr<StringListEncoder> NewStringListEncoder(std::string* out) {
  return std::unique_ptr<StringListEncoder>(new StringListEncoderImpl(out));
}

std::unique_ptr<StringListDecoder> NewStringListDecoder(const std::string& in) {
  return std::unique_ptr<StringListDecoder>(new StringListDecoderImpl(in));
}

#if defined(TENSORFLOW_PROTOBUF_USES_CORD)
void AssignRefCounted(absl::string_view src, core::RefCounted* obj,
                      absl::Cord* out) {
  obj->Ref();
  *out = absl::MakeCordFromExternal(src, [obj] { obj->Unref(); });
}

void EncodeStringList(const tstring* strings, int64_t n, absl::Cord* out) {
  out->Clear();
  for (int i = 0; i < n; ++i) {
    ::strings::CordAppendVarint(strings[i].size(), out);
  }
  for (int i = 0; i < n; ++i) {
    out->Append(strings[i]);
  }
}

bool DecodeStringList(const absl::Cord& src, std::string* strings, int64_t n) {
  std::vector<uint32_t> sizes(n);
  ::strings::CordReader reader(src);
  int64_t tot = 0;
  for (auto& v : sizes) {
    if (!::strings::CordReaderReadVarint(&reader, &v)) return false;
    tot += v;
  }
  if (tot != reader.Available()) {
    return false;
  }
  std::string* data = strings;
  for (int i = 0; i < n; ++i, ++data) {
    auto size = sizes[i];
    if (size > reader.Available()) {
      return false;
    }
    gtl::STLStringResizeUninitialized(data, size);
    reader.ReadN(size, gtl::string_as_array(data));
  }
  return true;
}

bool DecodeStringList(const absl::Cord& src, tstring* strings, int64_t n) {
  std::vector<uint32_t> sizes(n);
  ::strings::CordReader reader(src);
  int64_t tot = 0;
  for (auto& v : sizes) {
    if (!::strings::CordReaderReadVarint(&reader, &v)) return false;
    tot += v;
  }
  if (tot != reader.Available()) {
    return false;
  }
  tstring* data = strings;
  for (int i = 0; i < n; ++i, ++data) {
    auto size = sizes[i];
    if (size > reader.Available()) {
      return false;
    }
    data->resize_uninitialized(size);
    reader.ReadN(size, data->data());
  }
  return true;
}

void CopyFromArray(absl::Cord* c, const char* base, size_t bytes) {
  *c = absl::string_view(base, bytes);
}

class CordStringListEncoderImpl : public StringListEncoder {
 public:
  explicit CordStringListEncoderImpl(absl::Cord* out) : out_(out) {}
  ~CordStringListEncoderImpl() override = default;

  void Append(const protobuf::MessageLite& m) override {
    ::strings::CordAppendVarint(m.ByteSizeLong(), out_);
    m.AppendToString(&rest_);
  }

  void Append(const std::string& s) override {
    ::strings::CordAppendVarint(s.length(), out_);
    rest_.append(s.data(), s.size());
  }

  void Finalize() override { out_->Append(rest_); }

 private:
  absl::Cord* out_;
  std::string rest_;
};

class CordStringListDecoderImpl : public StringListDecoder {
 public:
  explicit CordStringListDecoderImpl(const absl::Cord& in) : reader_(in) {}
  ~CordStringListDecoderImpl() override = default;

  bool ReadSizes(std::vector<uint32_t>* sizes) override {
    int64_t total = 0;
    for (auto& size : *sizes) {
      if (!::strings::CordReaderReadVarint(&reader_, &size)) return false;
      total += size;
    }
    if (total != static_cast<int64_t>(reader_.Available())) {
      return false;
    }
    return true;
  }

  const char* Data(uint32_t size) override {
    tmp_.resize(size);
    if (size > 0) {
      reader_.ReadN(size, tmp_.data());
    }
    return tmp_.data();
  }

 private:
  ::strings::CordReader reader_;
  std::vector<char> tmp_;
};

std::unique_ptr<StringListEncoder> NewStringListEncoder(absl::Cord* out) {
  return std::unique_ptr<StringListEncoder>(new CordStringListEncoderImpl(out));
}

std::unique_ptr<StringListDecoder> NewStringListDecoder(const absl::Cord& in) {
  return std::unique_ptr<StringListDecoder>(new CordStringListDecoderImpl(in));
}

#endif  // defined(TENSORFLOW_PROTOBUF_USES_CORD)

}  // namespace port
}  // namespace tensorflow
