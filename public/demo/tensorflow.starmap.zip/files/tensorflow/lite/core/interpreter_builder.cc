/* Copyright 2017 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/
#include "tensorflow/lite/core/interpreter_builder.h"

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "flatbuffers/buffer.h"  // from @flatbuffers
#include "flatbuffers/vector.h"  // from @flatbuffers
#include "tensorflow/compiler/mlir/lite/allocation.h"
#include "tensorflow/compiler/mlir/lite/schema/schema_utils.h"
#include "tensorflow/lite/core/api/error_reporter.h"
#include "tensorflow/lite/core/api/flatbuffer_conversions.h"
#include "tensorflow/lite/core/api/op_resolver.h"
#include "tensorflow/lite/core/c/c_api_types.h"
#include "tensorflow/lite/core/c/common.h"
#include "tensorflow/lite/core/interpreter.h"
#include "tensorflow/lite/core/macros.h"
#include "tensorflow/lite/core/model_builder.h"
#include "tensorflow/lite/core/subgraph.h"
#include "tensorflow/lite/internal/signature_def.h"
#include "tensorflow/lite/interpreter_options.h"
#include "tensorflow/lite/profiling/platform_profiler.h"
#include "tensorflow/lite/profiling/telemetry/c/telemetry_setting.h"
#include "tensorflow/lite/profiling/telemetry/c/telemetry_setting_internal.h"
#include "tensorflow/lite/schema/conversion_metadata_generated.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/shared_library.h"
#include "tensorflow/lite/stderr_reporter.h"
#include "tensorflow/lite/util.h"
#include "tensorflow/lite/version.h"

// aligned_alloc is available (via cstdlib/stdlib.h) with C++17/C11.
// (introduced in stdc11 but realized in C++17)
#if __cplusplus >= 201703L && __STDC_VERSION__ >= 201112L
#if !defined(__ANDROID__) || __ANDROID_API__ >= 28
// Neither Apple nor Windows provide aligned_alloc.
#if !defined(__APPLE__) && !defined(_WIN32)
#define TFLITE_USE_STD_ALIGNED_ALLOC
#endif
#endif
#endif

// TODO(b/139446230): Move to portable platform header.
#if defined(__ANDROID__)
#define TFLITE_IS_MOBILE_PLATFORM
#endif  // defined(__ANDROID__)

#if defined(__APPLE__)
#include "TargetConditionals.h"
#if TARGET_IPHONE_SIMULATOR
#define TFLITE_IS_MOBILE_PLATFORM
#elif TARGET_OS_IPHONE
#define TFLITE_IS_MOBILE_PLATFORM
#endif
#endif  // defined(__APPLE__)

namespace tflite {

namespace {

constexpr char kConversionMetadataKey[] = "CONVERSION_METADATA";
constexpr char kTelemetryBuilderEventName[] = "InterpreterBuilder::operator()";

// Ensure that ErrorReporter is non-null.
ErrorReporter* ValidateErrorReporter(ErrorReporter* e) {
  return e ? e : DefaultErrorReporter();
}

template <typename T>
TfLiteStatus Copy(const T* data_ptr, TfLiteIntArray** arr) {
  if (data_ptr->values() == nullptr) {
    return kTfLiteError;
  }

  int size = data_ptr->values()->size();
  *arr = TfLiteIntArrayCreate(size);
  for (int i = 0; i < size; i++) {
    (*arr)->data[i] = static_cast<int>(data_ptr->values()->Get(i));
  }
  return kTfLiteOk;
}

TfLiteStatus ParseSparseIndexVector(const DimensionMetadata* src,
                                    TfLiteDimensionMetadata* tgt) {
  if (src->array_segments() == nullptr || src->array_indices() == nullptr) {
    return kTfLiteError;
  }
  TfLiteStatus status = kTfLiteOk;
  switch (src->array_segments_type()) {
    case SparseIndexVector_Int32Vector:
      status = Copy(src->array_segments_as_Int32Vector(), &tgt->array_segments);
      break;
    case SparseIndexVector_Uint16Vector:
      status =
          Copy(src->array_segments_as_Uint16Vector(), &tgt->array_segments);
      break;
    case SparseIndexVector_Uint8Vector:
      status = Copy(src->array_segments_as_Uint8Vector(), &tgt->array_segments);
      break;
    default:
      status = kTfLiteError;
      break;
  }
  if (status != kTfLiteOk) return status;

  switch (src->array_indices_type()) {
    case SparseIndexVector_Int32Vector:
      return Copy(src->array_indices_as_Int32Vector(), &tgt->array_indices);
    case SparseIndexVector_Uint16Vector:
      return Copy(src->array_indices_as_Uint16Vector(), &tgt->array_indices);
    case SparseIndexVector_Uint8Vector:
      return Copy(src->array_indices_as_Uint8Vector(), &tgt->array_indices);
    default:
      break;
  }
  return kTfLiteError;
}

// Helper that returns std::map that corresponds to vector of TensorMap.
std::map<std::string, uint32_t> GetMapFromTensorMap(
    const flatbuffers::Vector<flatbuffers::Offset<tflite::TensorMap>>*
        tensor_map) {
  if (!tensor_map) return {};
  std::map<std::string, uint32_t> result;
  for (const auto tensor : *tensor_map) {
    if (tensor != nullptr && tensor->name() != nullptr) {
      result[tensor->name()->c_str()] = tensor->tensor_index();
    }
  }
  return result;
}

inline bool ShouldCreateLazyDelegateProviders(int num_fp32_tensors) {
#if defined(XNNPACK_DELEGATE_ENABLE_QS8) || defined(XNNPACK_DELEGATE_ENABLE_QU8)
  return true;
#else
  return num_fp32_tensors > 0;
#endif
}

}  // namespace

constexpr const char* kEmptyTensorName = "";

// Using weak symbols to create a delegate allows automatic injection of the
// delegate simply by adding it as a dependency.
// For flex delegate, see also the strong override in
// lite/delegates/flex/delegate.cc.
TFLITE_ATTRIBUTE_WEAK Interpreter::TfLiteDelegatePtr AcquireFlexDelegate() {
  // TF_AcquireFlexDelegate isn't defined on Android, and the following block of
  // code would have no effect if TF_AcquireFlexDelegate isn't defined, so we
  // only enable that block for non-Android platforms.  Also, on Android 4.4
  // (Kitkat), the dlsym() implementation has a bug where dlsym() of an unknown
  // name will result in a SIGFPE, which would crash the process, so it's
  // important that on Android 4.4 we *don't* call SharedLibrary::GetSymbol
  // unless the symbol is sure to exist.
#if !defined(__ANDROID__)
  auto acquire_flex_delegate_func =
      reinterpret_cast<Interpreter::TfLiteDelegatePtr (*)()>(
          SharedLibrary::GetSymbol("TF_AcquireFlexDelegate"));
  if (acquire_flex_delegate_func) {
    return acquire_flex_delegate_func();
  }
#endif

#if !defined(TFLITE_IS_MOBILE_PLATFORM)
  // Load TF_AcquireFlexDelegate() from _pywrap_tensorflow_internal.so if it is
  // available.
#if defined(_WIN32)
  const wchar_t* filename_pywrap_tensorflow_internal =
      L"_pywrap_tensorflow_internal.pyd";
#elif defined(__APPLE__)
  const char* filename_pywrap_tensorflow_internal =
      "python/_pywrap_tensorflow_internal.so";
#else
  const char* filename_pywrap_tensorflow_internal =
      "_pywrap_tensorflow_internal.so";
#endif
  void* lib_tf_internal =
      SharedLibrary::LoadLibrary(filename_pywrap_tensorflow_internal);
#if defined(_WIN32)
  if (lib_tf_internal == nullptr) {
    lib_tf_internal = SharedLibrary::LoadLibrary(
        L"_pywrap_tensorflow_interpreter_wrapper.pyd");
  }
#endif
  if (lib_tf_internal) {
    acquire_flex_delegate_func =
        reinterpret_cast<Interpreter::TfLiteDelegatePtr (*)()>(
            SharedLibrary::GetLibrarySymbol(lib_tf_internal,
                                            "TF_AcquireFlexDelegate"));
    if (acquire_flex_delegate_func) {
      return acquire_flex_delegate_func();
    }
  }
#endif  // !defined(TFLITE_IS_MOBILE_PLATFORM)

  return Interpreter::TfLiteDelegatePtr(nullptr, [](TfLiteDelegate*) {});
}

InterpreterBuilder::InterpreterBuilder(
    const FlatBufferModel& model, const OpResolver& op_resolver,
    const InterpreterOptions* options_experimental)
    : model_(model.GetModel()),
      op_resolver_(op_resolver),
      error_reporter_(ValidateErrorReporter(model.error_reporter())),
      metadata_(model.ReadAllMetadata()),
      allocation_(model.allocation()) {
  if (options_experimental) {
    options_ = *options_experimental;
  }
}

InterpreterBuilder::InterpreterBuilder(
    const ::tflite::Model* model, const OpResolver& op_resolver,
    ErrorReporter* error_reporter,
    const InterpreterOptions* options_experimental,
    const Allocation* allocation)
    : model_(model),
      op_resolver_(op_resolver),
      error_reporter_(ValidateErrorReporter(error_reporter)),
      metadata_(FlatBufferModel::ReadAllMetadata(model_)),
      allocation_(allocation) {
  if (options_experimental) {
    options_ = *options_experimental;
  }
}

InterpreterBuilder::~InterpreterBuilder() = default;

TfLiteStatus InterpreterBuilder::BuildLocalIndexToRegistrationMapping() {
  TfLiteStatus status = kTfLiteOk;
  // Reset state.
  flatbuffer_op_index_to_registration_.clear();
  unresolved_custom_ops_.clear();

  auto opcodes = model_->operator_codes();
  if (!opcodes) {
    return status;
  }
  int num_custom_ops = 0;
  for (const OperatorCode* opcode : *opcodes) {
    if (GetBuiltinCode(opcode) == BuiltinOperator_CUSTOM) {
      num_custom_ops++;
    }
  }
  unresolved_custom_ops_.reserve(num_custom_ops);
  for (const OperatorCode* opcode : *opcodes) {
    const TfLiteRegistration* registration = nullptr;
    status = GetRegistrationFromOpCode(opcode, op_resolver_, error_reporter_,
                                       &registration);
    if (status != kTfLiteOk) {
      if (GetBuiltinCode(opcode) != BuiltinOperator_CUSTOM) {
        return status;
      }
      // If it's an unresolved custom op, allow it for now. It might be resolved
      // by a delegate later.
      if (!opcode->custom_code()) {
        TF_LITE_REPORT_ERROR(
            error_reporter_,
            "Operator with CUSTOM builtin_code has no custom_code.\n");
        return status;
      }
      const auto* op_name = opcode->custom_code()->c_str();
      unresolved_custom_ops_.push_back(CreateUnresolvedCustomOp(op_name));
      registration = &unresolved_custom_ops_.back();
      has_flex_op_ |= IsFlexOp(op_name);
      status = kTfLiteOk;
    }
    flatbuffer_op_index_to_registration_.push_back(registration);
  }
  return status;
}

namespace {
template <class T>
std::vector<int> FlatBufferIntArrayToVector(T* flat_array) {
  // Initialize shape of tensors with null shape. Empty vectors are converted
  // to nullptr for models that are constructed via flatbuffers::Pack.
  if (flat_array == nullptr) {
    return {};
  }
  std::vector<int> ret(flat_array->size());
  for (int i = 0; i < flat_array->size(); i++) {
    ret[i] = flat_array->Get(i);
  }
  return ret;
}

// Used to determine how the op data parsing function creates its working space.
class MallocDataAllocator : public BuiltinDataAllocator {
 public:
  void* Allocate(size_t size, size_t alignment_hint) override {
#ifdef TFLITE_USE_STD_ALIGNED_ALLOC
    // Ensure that alignment is a power of two and a multiple of sizeof(void *)
    // and that size is an integral multiple of alignment.
    size_t used_alignment = std::max(alignment_hint, sizeof(void*));
    size_t used_size =
        ((size + used_alignment - 1) / used_alignment) * used_alignment;
    TFLITE_DCHECK(
        (used_alignment != 0) &&
        ((used_alignment & (used_alignment - 1)) == 0));  // is power-of-two
    return aligned_alloc(used_alignment, used_size);
#else
    return malloc(size);
#endif
  }
  void Deallocate(void* data) override { free(data); }
};

}  // namespace

TfLiteStatus InterpreterBuilder::ParseNodes(
    const flatbuffers::Vector<flatbuffers::Offset<Operator>>* operators,
    Subgraph* subgraph) {
  TfLiteStatus status = kTfLiteOk;

  // Reduce the number of redundant allocations
  subgraph->ReserveNodes(operators->size());

  for (int i = 0; i < operators->size(); ++i) {
    const auto* op = operators->Get(i);
    int index = op->opcode_index();
    if (index < 0 || index >= flatbuffer_op_index_to_registration_.size()) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Missing registration for opcode_index %d\n", index);
      status = kTfLiteError;
      continue;
    }

    const TfLiteRegistration* registration =
        flatbuffer_op_index_to_registration_[index];
    if (registration == nullptr) {
      TF_LITE_REPORT_ERROR(error_reporter_, "Skipping op for opcode_index %d\n",
                           index);
      status = kTfLiteError;
      continue;
    }

    BuiltinOperator op_type =
        static_cast<BuiltinOperator>(registration->builtin_code);

    if (op_type != BuiltinOperator_CUSTOM && op->custom_options()) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Found builtin operator %s with custom options.\n",
                           EnumNameBuiltinOperator(op_type));
    }

    void* builtin_data = nullptr;
    const char* init_data = nullptr;
    size_t init_data_size = 0;
    if (op_type == BuiltinOperator_CUSTOM) {
      if (op->custom_options()) {
        init_data = reinterpret_cast<const char*>(op->custom_options()->data());
        init_data_size = op->custom_options()->size();
      } else if (allocation_) {
        const uint64_t offset = op->large_custom_options_offset();
        if (offset > 1) {
          const size_t alloc_bytes = allocation_->bytes();
          const uint64_t size = op->large_custom_options_size();
          if (offset > alloc_bytes || size > alloc_bytes - offset) {
            TF_LITE_REPORT_ERROR(
                error_reporter_,
                "Custom Option Offset for opcode_index %d is out of bound\n",
                index);
            return kTfLiteError;
          }
          // If the custom op is storing payloads outside of flatbuffers
          init_data =
              reinterpret_cast<const char*>(allocation_->base()) + offset;
          init_data_size = size;
        }
      }
    } else {
      MallocDataAllocator malloc_allocator;
      TF_LITE_ENSURE_STATUS(ParseOpData(op, op_type, error_reporter_,
                                        &malloc_allocator, &builtin_data));
    }
    subgraph->AddNodeWithParameters(
        FlatBufferIntArrayToVector(op->inputs()),
        FlatBufferIntArrayToVector(op->outputs()),
        FlatBufferIntArrayToVector(op->intermediates()), init_data,
        init_data_size, builtin_data, registration);
  }

  return status;
}

TfLiteStatus InterpreterBuilder::ParseQuantization(
    const QuantizationParameters* src_quantization,
    TfLiteQuantization* quantization, const std::vector<int>& dims,
    size_t num_tensors) {
  quantization->type = kTfLiteNoQuantization;
  quantization->params = nullptr;
  if (!src_quantization) {
    return kTfLiteOk;
  }

  auto validate_tensor_index = [&](int32_t tensor_index, const char* name,
                                   bool optional) {
    if (optional && tensor_index == -1) {
      return kTfLiteOk;
    }
    if (tensor_index < 0 || static_cast<size_t>(tensor_index) >= num_tensors) {
      TF_LITE_REPORT_ERROR(
          error_reporter_,
          "MultiAxisQuantization %s tensor index must be in range [0, %d)%s. "
          "Was %d.",
          name, static_cast<int>(num_tensors),
          optional ? ", or -1 if optional" : "", tensor_index);
      return kTfLiteError;
    }
    return kTfLiteOk;
  };

  // Multi-axis quantization.
  if (src_quantization->details_type() ==
      QuantizationDetails_MultiAxisQuantization) {
    auto* src_quant = src_quantization->details_as_MultiAxisQuantization();
    if (!src_quant || !src_quant->quantized_dimensions()) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Invalid MultiAxisQuantization parameters.");
      return kTfLiteError;
    }
    TF_LITE_ENSURE_STATUS(
        validate_tensor_index(src_quant->scales(), "scales", false));
    TF_LITE_ENSURE_STATUS(
        validate_tensor_index(src_quant->zero_points(), "zero_points", true));
    if (src_quant->block_size() < 0) {
      TF_LITE_REPORT_ERROR(
          error_reporter_,
          "MultiAxisQuantization block_size must be non-negative. Was %d.",
          src_quant->block_size());
      return kTfLiteError;
    }

    const auto* quantized_dimensions = src_quant->quantized_dimensions();
    if (quantized_dimensions->empty()) {
      TF_LITE_REPORT_ERROR(
          error_reporter_,
          "MultiAxisQuantization must have at least one quantized dimension.");
      return kTfLiteError;
    }
    for (int i = 0; i < quantized_dimensions->size(); ++i) {
      const int32_t quantized_dimension = quantized_dimensions->Get(i);
      if (quantized_dimension < 0 ||
          (!dims.empty() &&
           static_cast<size_t>(quantized_dimension) >= dims.size())) {
        TF_LITE_REPORT_ERROR(
            error_reporter_,
            "MultiAxisQuantization quantized_dimensions must be in range [0, "
            "%d). Value %d at index %d is invalid.",
            static_cast<int>(dims.size()), quantized_dimension, i);
        return kTfLiteError;
      }
    }

    auto* multi_axis_quantization =
        reinterpret_cast<TfLiteMultiAxisQuantization*>(
            malloc(sizeof(TfLiteMultiAxisQuantization)));
    if (!multi_axis_quantization) {
      return kTfLiteError;
    }
    multi_axis_quantization->scales = src_quant->scales();
    multi_axis_quantization->zero_points = src_quant->zero_points();
    multi_axis_quantization->blocksize = src_quant->block_size();
    multi_axis_quantization->quantized_dimensions =
        TfLiteIntArrayCreate(static_cast<int>(quantized_dimensions->size()));
    if (!multi_axis_quantization->quantized_dimensions) {
      free(multi_axis_quantization);
      return kTfLiteError;
    }
    for (int i = 0; i < quantized_dimensions->size(); ++i) {
      multi_axis_quantization->quantized_dimensions->data[i] =
          quantized_dimensions->Get(i);
    }
    quantization->type = kTfLiteMultiAxisQuantization;
    quantization->params = reinterpret_cast<void*>(multi_axis_quantization);
    return kTfLiteOk;
  }

  // Blockwise quantization.
  if (src_quantization->details_type() ==
      QuantizationDetails_BlockwiseQuantization) {
    auto* src_quant = src_quantization->details_as_BlockwiseQuantization();
    if (!src_quant) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Blockwise quantization details are missing.");
      return kTfLiteError;
    }
    // `block_shape` supersedes `block_size`. It is only meaningful if it has
    // exactly one entry per dimension of the tensor, so reject anything else
    // rather than silently falling back to `block_size`, which would produce
    // wrong values.
    const auto* block_shape = src_quant->block_shape();
    if (block_shape && !block_shape->empty()) {
      if (!dims.empty() &&
          static_cast<size_t>(block_shape->size()) != dims.size()) {
        TF_LITE_REPORT_ERROR(
            error_reporter_,
            "BlockwiseQuantization block_shape must have one entry per "
            "dimension. Expected %d entries, got %d.",
            static_cast<int>(dims.size()), block_shape->size());
        return kTfLiteError;
      }
      for (int i = 0; i < block_shape->size(); ++i) {
        if (block_shape->Get(i) <= 0) {
          TF_LITE_REPORT_ERROR(error_reporter_,
                               "BlockwiseQuantization block_shape entries must "
                               "be positive. Value %d at index %d is invalid.",
                               block_shape->Get(i), i);
          return kTfLiteError;
        }
      }
      auto* blockwise_quantization_v2 =
          reinterpret_cast<TfLiteBlockwiseQuantizationV2*>(
              malloc(sizeof(TfLiteBlockwiseQuantizationV2)));
      if (!blockwise_quantization_v2) {
        return kTfLiteError;
      }
      blockwise_quantization_v2->scale = src_quant->scales();
      blockwise_quantization_v2->zero_point = src_quant->zero_points();
      blockwise_quantization_v2->quantized_dimension =
          src_quantization->quantized_dimension();
      blockwise_quantization_v2->blocksize = src_quant->block_size();
      blockwise_quantization_v2->block_shape =
          TfLiteIntArrayCreate(static_cast<int>(block_shape->size()));
      if (!blockwise_quantization_v2->block_shape) {
        free(blockwise_quantization_v2);
        return kTfLiteError;
      }
      for (int i = 0; i < block_shape->size(); ++i) {
        blockwise_quantization_v2->block_shape->data[i] = block_shape->Get(i);
      }
      quantization->type = kTfLiteBlockwiseQuantizationV2;
      quantization->params = reinterpret_cast<void*>(blockwise_quantization_v2);
      return kTfLiteOk;
    }
    auto* blockwise_quantization_v1 =
        reinterpret_cast<TfLiteBlockwiseQuantization*>(
            malloc(sizeof(TfLiteBlockwiseQuantization)));
    if (!blockwise_quantization_v1) {
      return kTfLiteError;
    }
    blockwise_quantization_v1->scale = src_quant->scales();
    blockwise_quantization_v1->zero_point = src_quant->zero_points();
    blockwise_quantization_v1->quantized_dimension =
        src_quantization->quantized_dimension();
    blockwise_quantization_v1->blocksize = src_quant->block_size();
    quantization->type = kTfLiteBlockwiseQuantization;
    quantization->params = reinterpret_cast<void*>(blockwise_quantization_v1);
    return kTfLiteOk;
  }
  if (!src_quantization->scale() || src_quantization->scale()->empty()) {
    return kTfLiteOk;
  }
  if (!src_quantization->zero_point()) {
    TF_LITE_REPORT_ERROR(
        error_reporter_,
        "Quantization parameters has non-null scale but null zero_point.");
    return kTfLiteError;
  }

  // Ensure that the number of scales matches the number of zero_points.
  if (src_quantization->scale()->size() !=
      src_quantization->zero_point()->size()) {
    TF_LITE_REPORT_ERROR(
        error_reporter_,
        "QuantizationParam has %d zero_point values and %d scale values. "
        "Must "
        "have same number.",
        src_quantization->zero_point()->size(),
        src_quantization->scale()->size());
    return kTfLiteError;
  }

  const size_t num_scales = src_quantization->scale()->size();
  const size_t num_zero_points = src_quantization->zero_point()->size();
  // If all of the zero points are the same, we can store a single value to
  // avoid large, redundant allocations. This is guarded by an experimental
  // option for compatibility with external delegates that may assume
  // per-change zero-point arrays.
  bool all_zero_points_same = false;
  int32_t zero_point = 0;
  if (options_.GetCompressQuantizationZeroPoints() && num_zero_points > 0) {
    all_zero_points_same = true;
    zero_point = src_quantization->zero_point()->data()[0];
    for (int i = 1; i < num_zero_points && all_zero_points_same; ++i) {
      all_zero_points_same &=
          (src_quantization->zero_point()->data()[i] == zero_point);
    }
  }

  // Ensure that the quantization dimension is valid.
  if (src_quantization->quantized_dimension() < 0 ||
      (!dims.empty() &&
       src_quantization->quantized_dimension() >= dims.size())) {
    TF_LITE_REPORT_ERROR(
        error_reporter_,
        "quantized_dimension must be in range [0, %d). Was %d.", dims.size(),
        src_quantization->quantized_dimension());
    return kTfLiteError;
  }

  // Ensure that the number of scales is 1 for per-layer quantization, and
  // matches number of quantization dimensions for per-axis quantization.
  if (num_scales != 1 &&
      (!dims.empty() &&
       num_scales != dims[src_quantization->quantized_dimension()])) {
    TF_LITE_REPORT_ERROR(
        error_reporter_,
        "num_scales must be 1 for per-layer quantization, or %d for per-axis "
        "quantization, but got %d.",
        dims[src_quantization->quantized_dimension()], num_scales);
    return kTfLiteError;
  }

  // Affine-quantization.
  quantization->type = kTfLiteAffineQuantization;
  auto* affine_quantization = reinterpret_cast<TfLiteAffineQuantization*>(
      malloc(sizeof(TfLiteAffineQuantization)));
  affine_quantization->scale = TfLiteFloatArrayCreate(num_scales);
  for (size_t i = 0; i < num_scales; ++i) {
    affine_quantization->scale->data[i] = src_quantization->scale()->Get(i);
  }
  if (all_zero_points_same) {
    affine_quantization->zero_point = TfLiteIntArrayCreate(1);
    affine_quantization->zero_point->data[0] = zero_point;
  } else {
    affine_quantization->zero_point = TfLiteIntArrayCreate(num_scales);
    for (size_t i = 0; i < num_scales; ++i) {
      affine_quantization->zero_point->data[i] =
          src_quantization->zero_point()->Get(i);
    }
  }
  affine_quantization->quantized_dimension =
      src_quantization->quantized_dimension();
  quantization->params = reinterpret_cast<void*>(affine_quantization);
  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::ParseSparsity(
    const SparsityParameters* src_sparsity, TfLiteSparsity** sparsity_ptr) {
  if (!src_sparsity) {
    return kTfLiteOk;
  }

  if (src_sparsity->traversal_order() == nullptr ||
      src_sparsity->dim_metadata() == nullptr) {
    TF_LITE_REPORT_ERROR(error_reporter_, "Invalid sparsity parameter.");
    return kTfLiteError;
  }

  auto* sparsity =
      reinterpret_cast<TfLiteSparsity*>(malloc(sizeof(TfLiteSparsity)));
  memset(sparsity, 0, sizeof(TfLiteSparsity));
  *sparsity_ptr = sparsity;

  const size_t traversal_order_size = src_sparsity->traversal_order()->size();
  sparsity->traversal_order = TfLiteIntArrayCreate(traversal_order_size);
  for (int i = 0; i < traversal_order_size; i++) {
    sparsity->traversal_order->data[i] =
        src_sparsity->traversal_order()->Get(i);
  }

  if (src_sparsity->block_map()) {
    const size_t block_map_size = src_sparsity->block_map()->size();
    sparsity->block_map = TfLiteIntArrayCreate(block_map_size);
    for (int i = 0; i < block_map_size; i++) {
      sparsity->block_map->data[i] = src_sparsity->block_map()->Get(i);
    }
  }

  const size_t dim_metadata_size = src_sparsity->dim_metadata()->size();
  sparsity->dim_metadata_size = dim_metadata_size;
  sparsity->dim_metadata = reinterpret_cast<TfLiteDimensionMetadata*>(
      malloc(dim_metadata_size * sizeof(TfLiteDimensionMetadata)));
  memset(sparsity->dim_metadata, 0,
         dim_metadata_size * sizeof(TfLiteDimensionMetadata));

  for (int i = 0; i < dim_metadata_size; i++) {
    const auto* src_metadata = src_sparsity->dim_metadata()->Get(i);
    if (src_metadata->format() != DimensionType_DENSE &&
        src_metadata->format() != DimensionType_SPARSE_CSR) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "The %dth dimension has unknown type: %d.", i,
                           src_metadata->format());
      return kTfLiteError;
    }
    auto* tgt_metadata = &sparsity->dim_metadata[i];

    tgt_metadata->format =
        static_cast<TfLiteDimensionType>(src_metadata->format());

    if (tgt_metadata->format == kTfLiteDimDense) {
      tgt_metadata->dense_size = src_metadata->dense_size();
    } else {
      if (ParseSparseIndexVector(src_metadata, tgt_metadata) != kTfLiteOk) {
        TF_LITE_REPORT_ERROR(
            error_reporter_,
            "The %dth sparse dimension has invalid parameters.", i);
        return kTfLiteError;
      }
    }
  }

  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::ParseSignatureDefs(
    const flatbuffers::Vector<flatbuffers::Offset<SignatureDef>>*
        signature_def_list,
    Interpreter* interpreter) {
  if (signature_def_list == nullptr || signature_def_list->empty()) {
    return kTfLiteOk;
  }
  std::vector<internal::SignatureDef> signature_defs;
  signature_defs.reserve(signature_def_list->size());
  for (const auto fb_signature_def : *signature_def_list) {
    if (fb_signature_def == nullptr) {
      TF_LITE_REPORT_ERROR(error_reporter_, "NULL SignatureDef in the model.");
      return kTfLiteError;
    }
    if (fb_signature_def->signature_key() == nullptr) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Missing exported method name for SignatureDef");
      return kTfLiteError;
    }
    signature_defs.resize(signature_defs.size() + 1);
    auto& signature_def = signature_defs.back();
    signature_def.signature_key = fb_signature_def->signature_key()->c_str();
    signature_def.subgraph_index = fb_signature_def->subgraph_index();
    if (fb_signature_def->inputs()) {
      signature_def.inputs = GetMapFromTensorMap(fb_signature_def->inputs());
    }
    if (fb_signature_def->outputs()) {
      signature_def.outputs = GetMapFromTensorMap(fb_signature_def->outputs());
    }
  }
  interpreter->SetSignatureDef(std::move(signature_defs));
  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::ParseTensors(
    const flatbuffers::Vector<flatbuffers::Offset<Buffer>>* buffers,
    const flatbuffers::Vector<flatbuffers::Offset<Tensor>>* tensors,
    Subgraph* subgraph, TfLiteTelemetrySubgraphInfo* subgraph_info) {
  TfLiteStatus status = kTfLiteOk;

  // A little helper to get the names of inputs and outputs. Note that they
  // must outlive the subgraph.
  auto get_name = [](const tflite::Tensor* t) -> const char* {
    auto name = t->name();
    if (name) return name->c_str();
    return kEmptyTensorName;
  };

  if (subgraph_info) {
    subgraph_info->quantizations.resize(tensors->size());
  }

  num_fp32_tensors_ = 0;
  for (int i = 0; i < tensors->size(); ++i) {
    const auto* tensor = tensors->Get(i);
    std::vector<int> dims = FlatBufferIntArrayToVector(tensor->shape());

    TfLiteType type;
    if (ConvertTensorType(tensor->type(), &type, error_reporter_) !=
        kTfLiteOk) {
      status = kTfLiteError;
      continue;
    }
    if (type == kTfLiteFloat32) {
      ++num_fp32_tensors_;
    }
    auto get_readonly_data = [&](const char** buffer_data,
                                 size_t* buffer_size) {
      // TODO(aselle): Check what happens if we have an unspecified size
      // constant.
      *buffer_data = nullptr;
      if (tensor->buffer() == 0) return kTfLiteOk;
      if (tensor->buffer() >= buffers->size()) {
        TF_LITE_REPORT_ERROR(
            error_reporter_,
            "Tensor %d specifies out of range buffer %d (only %d buffers).\n",
            i, tensor->buffer(), buffers->size());
        return kTfLiteError;
      }
      if (auto* buffer = (*buffers)[tensor->buffer()]) {
        auto offset = buffer->offset();
        if (auto* array = buffer->data()) {
          *buffer_size = array->size();
          *buffer_data = reinterpret_cast<const char*>(array->data());
          return kTfLiteOk;
        } else if (offset > 1 && allocation_) {
          const size_t alloc_bytes = allocation_->bytes();
          const uint64_t size = buffer->size();
          if (offset > alloc_bytes || size > alloc_bytes - offset) {
            TF_LITE_REPORT_ERROR(
                error_reporter_,
                "Constant buffer %d specified an out of range offset.\n",
                tensor->buffer());
            return kTfLiteError;
          }
          *buffer_size = size;
          *buffer_data =
              reinterpret_cast<const char*>(allocation_->base()) + offset;
          return kTfLiteOk;
        }
      }
      return kTfLiteOk;
    };
    size_t buffer_size = 0;
    const char* buffer_ptr = nullptr;
    TF_LITE_ENSURE_STATUS(get_readonly_data(&buffer_ptr, &buffer_size));

    const auto* src_quantization = tensor->quantization();
    TfLiteQuantization quantization{};
    if (ParseQuantization(src_quantization, &quantization, dims,
                          tensors->size()) != kTfLiteOk) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Tensor %d has invalid quantization parameters.", i);
      status = kTfLiteError;
    }
    if (subgraph_info) subgraph_info->quantizations[i] = quantization;

    std::vector<int> dims_signature = {};
    if (tensor->shape_signature()) {
      dims_signature = FlatBufferIntArrayToVector(tensor->shape_signature());
    }

    bool is_variable = tensor->is_variable();
    if (buffer_ptr) {
      if (is_variable || tensor->external_buffer() != 0) {
        TF_LITE_REPORT_ERROR(
            error_reporter_,
            "Tensor %d is a variable tensor with buffer or external buffer. "
            "It's not supported now.\n",
            i);
        status = kTfLiteError;
      }

      // TODO(b/144999664): Only constant sparse tensor is supported now.
      const auto* src_sparsity = tensor->sparsity();
      TfLiteSparsity* sparsity = nullptr;
      if (ParseSparsity(src_sparsity, &sparsity) != kTfLiteOk) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Tensor %d has invalid sparsity parameters.", i);
        status = kTfLiteError;
      }

      if (subgraph->SetTensorParametersReadOnly(
              i, type, get_name(tensor), dims, quantization, buffer_ptr,
              buffer_size, allocation_, sparsity,
              /*buffer_identifier=*/tensor->buffer(),
              /*external_buffer_id=*/tensor->external_buffer()) != kTfLiteOk) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Tensor %d is invalidly specified in schema.\n",
                             i);
        status = kTfLiteError;
      }
    } else {
      if (subgraph->SetTensorParametersReadWrite(
              i, type, get_name(tensor), dims, quantization, is_variable,
              dims_signature, tensor->external_buffer()) != kTfLiteOk) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Tensor %d is invalidly specified in schema.\n",
                             i);
        status = kTfLiteError;
      }
    }
  }

  return status;
}

TfLiteStatus InterpreterBuilder::ApplyDelegates(Interpreter* interpreter) {
  // Apply Flex delegate if applicable.
  if (has_flex_op_) {
    if (Interpreter::TfLiteDelegatePtr flex_delegate = AcquireFlexDelegate()) {
      TF_LITE_ENSURE_STATUS(interpreter->ModifyGraphWithDelegateImpl(
          // Transfers ownership of flex_delegate to the interpreter.
          std::move(flex_delegate)));
    }
  }
  for (TfLiteDelegate* delegate : delegates_) {
    // Note that we DON'T transfer ownership of the delegate to the
    // interpreter. (Doing that would cause problems if operator() was invoked
    // twice.)
    TF_LITE_ENSURE_STATUS(interpreter->ModifyGraphWithDelegateImpl(delegate));
  }
  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::SetNumThreads(int num_threads) {
  if (num_threads < -1) {
    TF_LITE_REPORT_ERROR(
        error_reporter_,
        "num_threads should be >= 0 or just -1 to let TFLite runtime set the "
        "value.");
    return kTfLiteError;
  }
  num_threads_ = num_threads;
  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::operator()(
    std::unique_ptr<Interpreter>* interpreter, int num_threads) {
  TfLiteStatus status = SetNumThreads(num_threads);
  if (status != kTfLiteOk) {
    if (interpreter) {
      interpreter->reset();
    }
    return status;
  }
  return (*this)(interpreter);
}

TfLiteStatus InterpreterBuilder::operator()(
    std::unique_ptr<Interpreter>* interpreter) {
  if (!interpreter) {
    TF_LITE_REPORT_ERROR(error_reporter_,
                         "Null output pointer passed to InterpreterBuilder.");
    return kTfLiteError;
  }
  interpreter->reset();

  if (!model_) {
    TF_LITE_REPORT_ERROR(error_reporter_, "Null pointer passed in as model.");
    return kTfLiteError;
  }

  if (model_->version() != TFLITE_SCHEMA_VERSION) {
    TF_LITE_REPORT_ERROR(error_reporter_,
                         "Model provided is schema version %d not equal "
                         "to supported version %d.\n",
                         model_->version(), TFLITE_SCHEMA_VERSION);
    return kTfLiteError;
  }

  if (BuildLocalIndexToRegistrationMapping() != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter_, "Registration failed.\n");
    return kTfLiteError;
  }

  // Flatbuffer model schemas define a list of opcodes independent of the
  // graph. We first map those to registrations. This reduces string lookups
  // for custom ops since we only do it once per custom op rather than once
  // per custom op invocation in the model graph. Construct interpreter with
  // correct number of tensors and operators.
  auto* subgraphs = model_->subgraphs();
  auto* buffers = model_->buffers();

  if (subgraphs->empty()) {
    TF_LITE_REPORT_ERROR(error_reporter_, "No subgraph in the model.\n");
    return kTfLiteError;
  }

  if (!buffers) {
    TF_LITE_REPORT_ERROR(error_reporter_, "No buffers in the model.\n");
    return kTfLiteError;
  }

  int num_add_specializations = 0;
  for (const auto& spec : subgraph_specializations_) {
    if (!spec.signature_key.empty()) ++num_add_specializations;
  }

  auto tmp_interpreter = std::make_unique<Interpreter>(error_reporter_);
  if (subgraphs->size() + num_add_specializations > 1) {
    tmp_interpreter->AddSubgraphs(subgraphs->size() + num_add_specializations -
                                  1);
  }

  // Set num threads after all the subgraphs are added.
  tmp_interpreter->SetNumThreads(num_threads_);

  // Set Interpreter options
  tmp_interpreter->ApplyOptionsImpl(&options_);

  tmp_interpreter->SetProfilerImpl(
      tflite::profiling::MaybeCreatePlatformProfiler());

  bool telemetry_registered = telemetry_profiler_ != nullptr;
  std::unique_ptr<TfLiteTelemetryInterpreterSettings> telemetry_settings;
  if (telemetry_registered) {
    tmp_interpreter->AddProfiler(std::move(telemetry_profiler_));
    telemetry_settings = std::make_unique<TfLiteTelemetryInterpreterSettings>();
    telemetry_settings->subgraph_infos.resize(subgraphs->size());
  }

  for (int subgraph_index = 0; subgraph_index < subgraphs->size();
       ++subgraph_index) {
    auto* subgraph_info =
        telemetry_registered
            ? &telemetry_settings->subgraph_infos[subgraph_index]
            : nullptr;
    if (BuildSubgraph((*subgraphs)[subgraph_index], buffers,
                      tmp_interpreter->subgraph(subgraph_index), subgraph_info,
                      subgraph_index) != kTfLiteOk) {
      return kTfLiteError;
    }
  }

  if (ParseSignatureDefs(model_->signature_defs(), tmp_interpreter.get()) !=
      kTfLiteOk) {
    return kTfLiteError;
  }

  if (!subgraph_specializations_.empty() &&
      ApplySubgraphSpecializations(tmp_interpreter.get(), subgraphs->size()) !=
          kTfLiteOk) {
    return kTfLiteError;
  }

  if (options_.GetUseSignatureTensorNames()) {
    for (const auto& signature_def : tmp_interpreter->signature_defs_) {
      Subgraph* subgraph =
          tmp_interpreter->subgraph(signature_def.subgraph_index);
      if (subgraph == nullptr) {
        continue;
      }
      for (const auto& [name, tensor_index] : signature_def.inputs) {
        TfLiteTensor* tensor = subgraph->tensor(tensor_index);
        if (tensor != nullptr) {
          tensor->name = name.c_str();
        }
      }
      for (const auto& [name, tensor_index] : signature_def.outputs) {
        TfLiteTensor* tensor = subgraph->tensor(tensor_index);
        if (tensor != nullptr) {
          tensor->name = name.c_str();
        }
      }
    }
  }

  if (tmp_interpreter->SetMetadata(metadata_) != kTfLiteOk) {
    return kTfLiteError;
  }

  if (ShouldCreateLazyDelegateProviders(num_fp32_tensors_)) {
    tmp_interpreter->lazy_delegate_providers_ =
        op_resolver_.GetDelegateCreators();
  }

  if (telemetry_registered) {
    ParseConversionMetadata(telemetry_settings.get());
    tmp_interpreter->SetTelemetrySettings(std::move(telemetry_settings));
    // Reports model and interpreter settings if telemetry is applied.
    tmp_interpreter->ReportTelemetrySettings(kTelemetryBuilderEventName);
  }

  if (TfLiteStatus status = ApplyDelegates(tmp_interpreter.get());
      status != kTfLiteOk) {
    TF_LITE_REPORT_ERROR(error_reporter_, "Failed to apply delegates.\n");
    return status;
  }

  // Apply Interpreter options again for dynamic allocation.
  if (options_.GetDynamicAllocationForLargeTensors()) {
    tmp_interpreter->ApplyOptionsImpl(&options_);
  }

  *interpreter = std::move(tmp_interpreter);
  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::BuildSubgraph(
    const ::tflite::SubGraph* subgraph,
    const flatbuffers::Vector<flatbuffers::Offset<Buffer>>* buffers,
    Subgraph* modified_subgraph, TfLiteTelemetrySubgraphInfo* subgraph_info,
    int subgraph_index) {
  modified_subgraph->allocation_ = allocation_;
  auto operators = subgraph->operators();
  auto tensors = subgraph->tensors();
  if (!tensors) {
    TF_LITE_REPORT_ERROR(error_reporter_,
                         "Did not get tensors in subgraph %d.\n",
                         subgraph_index);
    return kTfLiteError;
  }
  if (modified_subgraph->AddTensors(tensors->size()) != kTfLiteOk) {
    return kTfLiteError;
  }
  // Parse inputs/outputs
  modified_subgraph->SetInputs(FlatBufferIntArrayToVector(subgraph->inputs()));
  modified_subgraph->SetOutputs(
      FlatBufferIntArrayToVector(subgraph->outputs()));

  // Finally setup nodes and tensors
  // Parse tensors before nodes as ParseNodes checks input tensors for the
  // nodes.
  if (ParseTensors(buffers, tensors, modified_subgraph, subgraph_info) !=
      kTfLiteOk)
    return kTfLiteError;
  if (operators && ParseNodes(operators, modified_subgraph) != kTfLiteOk)
    return kTfLiteError;

  std::vector<int> variables;
  for (int i = 0; i < modified_subgraph->tensors_size(); ++i) {
    auto* tensor = modified_subgraph->tensor(i);
    if (tensor->is_variable) {
      variables.push_back(i);
    }
  }
  modified_subgraph->SetVariables(std::move(variables));
  if (subgraph->name()) {
    modified_subgraph->SetName(subgraph->name()->c_str());
  }
  return kTfLiteOk;
}

TfLiteStatus InterpreterBuilder::ApplySubgraphSpecializations(
    Interpreter* interpreter, int num_model_subgraphs) {
  auto* subgraphs = model_->subgraphs();
  auto* buffers = model_->buffers();
  int next_subgraph_index = num_model_subgraphs;

  // Keys must not collide with each other or with the model's own signatures.
  for (size_t i = 0; i < subgraph_specializations_.size(); ++i) {
    const auto& key = subgraph_specializations_[i].signature_key;
    if (key.empty()) continue;
    for (const auto& existing : interpreter->signature_defs_) {
      if (existing.signature_key == key) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization key '%s' collides with "
                             "an existing signature.\n",
                             key.c_str());
        return kTfLiteError;
      }
    }
    for (size_t j = 0; j < i; ++j) {
      if (subgraph_specializations_[j].signature_key == key) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization key '%s' is used more "
                             "than once.\n",
                             key.c_str());
        return kTfLiteError;
      }
    }
  }

  for (const auto& spec : subgraph_specializations_) {
    const int source_index = spec.source_subgraph_index;
    if (source_index < 0 || source_index >= num_model_subgraphs) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Subgraph specialization source index %d is out "
                           "of range [0, %d).\n",
                           source_index, num_model_subgraphs);
      return kTfLiteError;
    }
    const ::tflite::SubGraph* fb_subgraph = (*subgraphs)[source_index];
    const bool is_add = !spec.signature_key.empty();

    Subgraph* target = nullptr;
    int target_index = source_index;
    if (is_add) {
      target_index = next_subgraph_index++;
      target = interpreter->subgraph(target_index);
      if (BuildSubgraph(fb_subgraph, buffers, target, /*subgraph_info=*/nullptr,
                        source_index) != kTfLiteOk) {
        return kTfLiteError;
      }
    } else {
      target = interpreter->subgraph(source_index);
    }

    const int num_tensors = static_cast<int>(target->tensors_size());

    // Constant contents first: an entry may also change the tensor's dims
    // (taken from `tensor_dims`), which resizing a read-only tensor cannot do.
    for (const auto& [tensor_index, bytes] : spec.constant_overrides) {
      if (tensor_index < 0 || tensor_index >= num_tensors) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization tensor index %d is out "
                             "of range for subgraph %d.\n",
                             tensor_index, source_index);
        return kTfLiteError;
      }
      TfLiteTensor* tensor = target->tensor(tensor_index);
      // A constant stored in an external buffer has no data yet and is not
      // read-only at this point; it is only known by its external buffer id.
      const bool is_external_constant =
          target->tensor_external_buffer_ids_.count(tensor_index) > 0;
      if ((tensor->allocation_type != kTfLiteMmapRo && !is_external_constant) ||
          tensor->is_variable || tensor->sparsity != nullptr ||
          tensor->type == kTfLiteString || tensor->type == kTfLiteResource ||
          tensor->type == kTfLiteVariant) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization cannot override tensor "
                             "%d of subgraph %d: not a dense constant.\n",
                             tensor_index, source_index);
        return kTfLiteError;
      }
      std::vector<int> dims;
      if (tensor->dims != nullptr) {
        dims.assign(tensor->dims->data,
                    tensor->dims->data + tensor->dims->size);
      }
      for (const auto& [dims_index, new_dims] : spec.tensor_dims) {
        if (dims_index == tensor_index) dims = new_dims;
      }
      // The copy is owned by the subgraph. The padding matches what
      // SetTensorParametersReadOnly reserves for its own aligned copies.
      constexpr size_t kExtraAllocationBytes = 16;
      std::unique_ptr<char, Subgraph::FreeDeleter> buffer(
          static_cast<char*>(malloc(bytes.size() + kExtraAllocationBytes)));
      if (buffer == nullptr) return kTfLiteError;
      if (!bytes.empty()) {
        memcpy(buffer.get(), bytes.data(), bytes.size());
      }
      memset(buffer.get() + bytes.size(), 0, kExtraAllocationBytes);
      const char* data = buffer.get();
      target->aligned_ro_buffers_.push_back(std::move(buffer));
      if (target->SetTensorParametersReadOnly(
              tensor_index, tensor->type, tensor->name, dims,
              TfLiteQuantizationClone(tensor->quantization), data,
              bytes.size()) != kTfLiteOk) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization failed to override "
                             "constant tensor %d of subgraph %d.\n",
                             tensor_index, source_index);
        return kTfLiteError;
      }
      // SetTensorParametersReadOnly keeps the previous size when the type and
      // dims are unchanged, which can be larger than the new buffer (e.g. a
      // padded model buffer).
      tensor->bytes = bytes.size();
      // The tensor no longer aliases the model buffer, so delegates must not
      // share it with other tensors that do, and its contents must not be
      // loaded from the external buffer later.
      target->tensor_buffer_identifiers_.erase(tensor_index);
      target->tensor_external_buffer_ids_.erase(tensor_index);
    }

    for (const auto& [tensor_index, dims] : spec.tensor_dims) {
      if (tensor_index < 0 || tensor_index >= num_tensors) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization tensor index %d is out "
                             "of range for subgraph %d.\n",
                             tensor_index, source_index);
        return kTfLiteError;
      }
      const TfLiteTensor* tensor = target->tensor(tensor_index);
      // A constant whose contents were not overridden above, including one
      // that is still to be loaded from an external buffer of a fixed size.
      if (tensor->allocation_type == kTfLiteMmapRo ||
          target->tensor_external_buffer_ids_.count(tensor_index) > 0) {
        if (!EqualArrayAndTfLiteIntArray(tensor->dims, dims.size(),
                                         dims.data())) {
          TF_LITE_REPORT_ERROR(error_reporter_,
                               "Subgraph specialization cannot reshape "
                               "constant tensor %d of subgraph %d without new "
                               "contents.\n",
                               tensor_index, source_index);
          return kTfLiteError;
        }
        continue;
      }
      // Despite its name, ResizeInputTensor only records the new dims of this
      // one tensor; it does not propagate them. Propagation is what the
      // kernels' Prepare does, and `tensor_dims` exists for the case where that
      // pass does not run, so every listed tensor is set individually.
      if (target->ResizeInputTensor(tensor_index, dims) != kTfLiteOk) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization failed to resize tensor "
                             "%d of subgraph %d.\n",
                             tensor_index, source_index);
        return kTfLiteError;
      }
    }

    const std::vector<int>& input_tensors = target->inputs();
    for (const auto& [input_position, dims] : spec.input_dims) {
      if (input_position < 0 ||
          input_position >= static_cast<int>(input_tensors.size())) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization input position %d is "
                             "out of range for subgraph %d with %zu inputs.\n",
                             input_position, source_index,
                             input_tensors.size());
        return kTfLiteError;
      }
      if (target->ResizeInputTensor(input_tensors[input_position], dims) !=
          kTfLiteOk) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization failed to resize input "
                             "%d of subgraph %d.\n",
                             input_position, source_index);
        return kTfLiteError;
      }
    }

    if (!is_add) continue;

    // Mirror the source signature's aliases. Tensor indices are identical in
    // the clone because it was parsed from the same flatbuffer subgraph.
    internal::SignatureDef new_def;
    new_def.signature_key = spec.signature_key;
    new_def.subgraph_index = target_index;
    const internal::SignatureDef* source_def = nullptr;
    for (const auto& existing : interpreter->signature_defs_) {
      if (!spec.source_signature_key.empty()) {
        if (existing.signature_key == spec.source_signature_key) {
          source_def = &existing;
          break;
        }
      } else if (static_cast<int>(existing.subgraph_index) == source_index) {
        source_def = &existing;
        break;
      }
    }
    if (!spec.source_signature_key.empty() && source_def == nullptr) {
      TF_LITE_REPORT_ERROR(error_reporter_,
                           "Subgraph specialization source signature '%s' "
                           "not found.\n",
                           spec.source_signature_key.c_str());
      return kTfLiteError;
    }
    if (source_def != nullptr) {
      if (static_cast<int>(source_def->subgraph_index) != source_index) {
        TF_LITE_REPORT_ERROR(error_reporter_,
                             "Subgraph specialization source signature '%s' "
                             "does not refer to subgraph %d.\n",
                             source_def->signature_key.c_str(), source_index);
        return kTfLiteError;
      }
      new_def.inputs = source_def->inputs;
      new_def.outputs = source_def->outputs;
    } else {
      // No SignatureDef to mirror: name the aliases like
      // Interpreter::CreatePlaceholderSignatureDef does, so a model without
      // signatures exposes the same names on the clone as on its default
      // runner. ParseTensors stores "" (not nullptr) for unnamed tensors, and
      // optional (-1) I/O entries have no tensor at all.
      auto add_aliases = [target](const std::vector<int>& tensor_indices,
                                  const char* prefix,
                                  std::map<std::string, uint32_t>* aliases) {
        for (size_t i = 0; i < tensor_indices.size(); ++i) {
          const int tensor_index = tensor_indices[i];
          const TfLiteTensor* tensor = target->tensor(tensor_index);
          if (tensor == nullptr) continue;
          const bool named = tensor->name != nullptr && *tensor->name != '\0';
          (*aliases)[named ? std::string(tensor->name)
                           : prefix + std::to_string(i)] = tensor_index;
        }
      };
      add_aliases(target->inputs(), "input", &new_def.inputs);
      add_aliases(target->outputs(), "output", &new_def.outputs);
    }
    interpreter->signature_defs_.push_back(std::move(new_def));
  }
  return kTfLiteOk;
}

void InterpreterBuilder::AddDelegate(TfLiteDelegate* delegate) {
  if (delegate == nullptr) {
    TF_LITE_REPORT_ERROR(error_reporter_, "Null delegate.");
  } else {
    delegates_.push_back(delegate);
  }
}

void InterpreterBuilder::AddDelegate(
    TfLiteOpaqueDelegateStruct* opaque_delegate) {
  // The following cast is safe only because this code is part of the TF Lite
  // runtime code.  Apps using TF Lite should not rely on
  // TfLiteOpaqueDelegateStruct and TfLiteDelegate being equivalent.
  AddDelegate(reinterpret_cast<TfLiteDelegate*>(opaque_delegate));
}

void InterpreterBuilder::ParseConversionMetadata(
    TfLiteTelemetryInterpreterSettings* settings) {
  if (settings == nullptr) return;
  auto it = metadata_.find(kConversionMetadataKey);
  if (it == metadata_.end()) {
    // No conversion metadata embeded.
    return;
  }
  auto* conversion_meta = GetConversionMetadata(it->second.data());
  if (conversion_meta == nullptr || conversion_meta->options() == nullptr) {
    // Empty conversion metadata.
    return;
  }
  settings->conversion_metadata =
      std::make_unique<TfLiteTelemetryConversionMetadata>();
  settings->conversion_metadata->model_optimization_modes =
      FlatBufferIntArrayToVector(
          conversion_meta->options()->model_optimization_modes());
}

}  // namespace tflite
