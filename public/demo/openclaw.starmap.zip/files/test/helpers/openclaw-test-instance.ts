// OpenClaw test instance helper spawns isolated OpenClaw processes.
import { type ChildProcess, type ChildProcessByStdio, spawnSync } from "node:child_process";
import { randomUUID } from "node:crypto";
import { once } from "node:events";
import fs from "node:fs/promises";
import net from "node:net";
import path from "node:path";
import type { Readable } from "node:stream";
import { StringDecoder } from "node:string_decoder";
import { isRecord } from "@openclaw/normalization-core/record-coerce";
import {
  BUILD_STAMP_FILE,
  RUNTIME_POSTBUILD_STAMP_FILE,
} from "../../scripts/lib/local-build-metadata-paths.mts";
import {
  hasUnjoinedWork,
  finalizeManagedChild,
  runManagedCommand,
  loadManagedChildSpawner,
} from "../../scripts/lib/managed-child-process.mts";
import { formatCliCommand } from "../../src/cli/command-format.js";
import { hasErrnoCode } from "../../src/infra/errno.js";
import {
  appendCapturedOutput,
  createCapturedOutputBuffers,
  finalizeCapturedOutput,
  resolveMaxOutputBytes,
} from "../../src/process/exec-output.js";
import type { ProcessExtinctionResult } from "../../src/process/supervisor/types.js";
import {
  createOpenClawTestState,
  type OpenClawTestState,
} from "../../src/test-utils/openclaw-test-state.js";
import { reserveTestPortListener } from "../../src/test-utils/port-claims.js";
import { cleanupSessionStateForTest } from "../../src/test-utils/session-state-cleanup.js";
import { sleep } from "../../src/utils.js";
import { decodeUtf8Tail } from "./bounded-child-output.js";
import { createOpenClawTestProcess, type OpenClawTestProcess } from "./openclaw-test-process.js";
import { runQaGatewayFixture } from "./qa-gateway-cleanup.js";
import { beginUiE2ePhase } from "./ui-e2e-phase.js";

type OpenClawTestStateOptions = NonNullable<Parameters<typeof createOpenClawTestState>[0]>;

type OpenClawTestInstanceOptions = {
  name: string;
  cwd?: string;
  entrypoint?: string[];
  port?: number;
  /** Set false for absent-Gateway diagnostics; cooperative port claims remain held. */
  reserveIdlePort?: boolean;
  gatewayToken?: string;
  hookToken?: string;
  config?: Record<string, unknown>;
  env?: Record<string, string | undefined>;
  state?: Omit<OpenClawTestStateOptions, "applyEnv" | "gateway" | "env" | "verifyCleanup">;
  gatewayArgs?: string[];
  gatewayCommandPrefix?: string[];
  startTimeoutMs?: number;
  stopTimeoutMs?: number;
  gracefulShutdownTimeoutMs?: number;
  signal?: AbortSignal;
  verifyCleanup?: (cleanup: () => Promise<void>) => Promise<void>;
};

type OpenClawTestInstanceCommandResult = {
  code: number | null;
  signal: NodeJS.Signals | null;
  stdout: string;
  stderr: string;
};

type RawGatewayProcess = ChildProcessByStdio<null, Readable, Readable>;

export class GatewayStartupRefusedError extends Error {
  readonly reason = "legacy-migration-required";
  readonly exitCode = 78;
  readonly signalCode = null;
  readonly legacyStorePath: string;
  readonly stderr: string;

  constructor(legacyStorePath: string, stderr: string, cause: unknown) {
    super(`gateway refused startup: legacy migration required (code=78 signal=null)\n${stderr}`, {
      cause,
    });
    this.name = "GatewayStartupRefusedError";
    this.legacyStorePath = legacyStorePath;
    this.stderr = stderr;
  }
}

export type OpenClawTestInstance = {
  name: string;
  port: number;
  url: string;
  hookToken: string;
  gatewayToken: string;
  homeDir: string;
  stateDir: string;
  configPath: string;
  state: OpenClawTestState;
  stdout: string[];
  stderr: string[];
  readonly readiness: readonly GatewayReadinessDiagnostic[];
  child?: OpenClawTestProcess;
  env: NodeJS.ProcessEnv;
  entrypoint: () => Promise<string[]>;
  cli: (
    args: string[],
    options?: { timeoutMs?: number; execPath?: string },
  ) => Promise<OpenClawTestInstanceCommandResult>;
  startGateway: () => Promise<void>;
  /** Crash only the command; retain descendant custody until stop/cleanup. */
  crashGateway: () => Promise<void>;
  stopGateway: () => Promise<void>;
  logs: () => string;
  /** Bounded owner/readiness/listener facts for a failure after startup. */
  diagnose: () => Promise<string>;
  cleanup: () => Promise<void>;
};

type ReadinessProbe = {
  attempt: number;
  phase: "headers" | "body" | "complete";
  elapsedMs: number;
  status?: number;
  ready?: boolean;
  endpoint?: "/startupz";
  startupStatus?: "starting" | "started" | "draining";
  failing?: string[];
  omittedFailing?: number;
  /** Responder's reported server uptime; binds the answer to a process started after spawn. */
  uptimeMs?: number;
  error?: "timeout" | "child-exit" | "fetch-failed" | "invalid-json" | "body-failed" | "aborted";
};

export type GatewayReadinessDiagnostic = {
  probe: "GET /readyz";
  settlementProbe?: "GET /startupz";
  startedAtMs: number;
  deadlineMs: number;
  elapsedMs: number;
  outcome: "ready" | "timeout" | "child-exit" | "aborted" | "agent-refused";
  attempts: number;
  probes: Array<ReadinessProbe & { startedAtMs: number; deadlineMs: number }>;
  omittedProbes: number;
  lastProbe: ReadinessProbe | null;
  lastFailedResponse: Pick<
    ReadinessProbe,
    "attempt" | "phase" | "elapsedMs" | "status" | "ready" | "endpoint" | "startupStatus" | "error"
  > | null;
  child: { pid: number | null; exitCode: number | null; signalCode: NodeJS.Signals | null };
  logs: { stdout: string; stderr: string } | null;
};

const GATEWAY_START_TIMEOUT_MS = 60_000;
const GATEWAY_STOP_TIMEOUT_MS = 1_500;
const GATEWAY_ENTRYPOINT_PREPARE_TIMEOUT_MS = 120_000;
const COMMAND_TIMEOUT_MS = 30_000;
const LOG_TAIL_MAX_BYTES = 256 * 1024;
const GATEWAY_MIGRATION_CONVERGENCE_MAX_RESTARTS = 1;
const GATEWAY_MIGRATION_CONVERGENCE_REFUSAL_PREFIX =
  "OpenClaw plugin migration inputs changed during startup convergence;";
const GATEWAY_MIGRATION_CONVERGENCE_RESTART_MARKER =
  "[openclaw-test-instance] restarting gateway after migration convergence refusal\n";
const entrypointPromises = new Map<string, Promise<string[]>>();

type BoundedStringLog = string[] & {
  maxBytes?: number;
  byteLength?: number;
  truncated?: boolean;
};

type OpenClawTestProcessReadiness = Pick<OpenClawTestProcess, "pid" | "exitCode" | "signalCode"> & {
  once: (event: "exit", listener: () => void) => unknown;
  off: (event: "exit", listener: () => void) => unknown;
};
type GatewayProcessStopOptions = {
  runTaskkill?: NonNullable<Parameters<typeof finalizeManagedChild>[2]>["runTaskkill"];
  forceWindowsTree?: boolean;
};
type TaskkillResult = Exclude<
  ReturnType<NonNullable<GatewayProcessStopOptions["runTaskkill"]>>,
  undefined
> & {
  signal?: NodeJS.Signals | null;
};

function createBoundedStringLog(maxBytes = LOG_TAIL_MAX_BYTES): string[] {
  const log = [] as BoundedStringLog;
  log.maxBytes = Math.max(1, maxBytes);
  log.byteLength = 0;
  log.truncated = false;
  return log;
}

function appendLogChunk(log: string[], chunk: unknown): void {
  const chunks = log as BoundedStringLog;
  const limit = chunks.maxBytes ?? LOG_TAIL_MAX_BYTES;
  const text = String(chunk);
  const textBytes = Buffer.byteLength(text);
  if (textBytes > limit) {
    const buffer = Buffer.from(text);
    const tail = decodeUtf8Tail(buffer.subarray(buffer.length - limit));
    chunks.splice(0, chunks.length, tail);
    chunks.byteLength = Buffer.byteLength(tail);
    chunks.truncated = true;
    return;
  }

  chunks.push(text);
  chunks.byteLength = (chunks.byteLength ?? 0) + textBytes;
  while ((chunks.byteLength ?? 0) > limit && chunks.length > 0) {
    const first = chunks[0] ?? "";
    const firstBytes = Buffer.byteLength(first);
    const overflow = (chunks.byteLength ?? 0) - limit;
    if (firstBytes <= overflow) {
      chunks.shift();
      chunks.byteLength = (chunks.byteLength ?? 0) - firstBytes;
      chunks.truncated = true;
      continue;
    }

    const buffer = Buffer.from(first);
    // Drop a split prefix instead of expanding it into replacement bytes that can stall trimming.
    const tail = decodeUtf8Tail(buffer.subarray(overflow));
    chunks[0] = tail;
    chunks.byteLength = chunks.reduce((total, entry) => total + Buffer.byteLength(entry), 0);
    chunks.truncated = true;
  }
}

function readLogBuffer(log: string[]): string {
  const text = log.join("");
  return (log as BoundedStringLog).truncated
    ? `[output truncated to last ${(log as BoundedStringLog).maxBytes ?? LOG_TAIL_MAX_BYTES} bytes]\n${text}`
    : text;
}

function isGatewayMigrationConvergenceRefusal(
  code: number | null,
  signal: NodeJS.Signals | null,
  stderr: string,
): boolean {
  return (
    code === 1 &&
    signal === null &&
    stderr
      .split(/\r?\n/u)
      .some((line) => line.startsWith(GATEWAY_MIGRATION_CONVERGENCE_REFUSAL_PREFIX))
  );
}

async function resolveBuiltGatewayEntrypoint(cwd: string): Promise<string[] | null> {
  const buildStampPath = path.join(cwd, "dist", BUILD_STAMP_FILE);
  const runtimePostBuildStampPath = path.join(cwd, "dist", RUNTIME_POSTBUILD_STAMP_FILE);
  for (const entrypoint of ["dist/index.js", "dist/index.mjs"]) {
    try {
      await Promise.all([
        fs.access(path.join(cwd, entrypoint)),
        fs.access(buildStampPath),
        fs.access(runtimePostBuildStampPath),
      ]);
      return [entrypoint];
    } catch {
      // try the next built entrypoint
    }
  }
  return null;
}

async function prepareGatewayEntrypoint(cwd: string): Promise<string[]> {
  const builtEntrypoint = await resolveBuiltGatewayEntrypoint(cwd);
  if (builtEntrypoint) {
    return builtEntrypoint;
  }

  // Share command ownership so successful preparation cannot retain its deadline.
  const completed = await runCommand({
    args: ["node", "scripts/run-node.mjs", "--help"],
    cwd,
    env: { ...process.env, VITEST: "1" },
    timeoutMs: GATEWAY_ENTRYPOINT_PREPARE_TIMEOUT_MS,
  });
  if (completed.code !== 0) {
    throw new Error(
      `failed preparing gateway entrypoint (code=${String(completed.code)} signal=${String(
        completed.signal,
      )})\n${formatLogs([completed.stdout], [completed.stderr])}`,
    );
  }

  return (await resolveBuiltGatewayEntrypoint(cwd)) ?? ["scripts/run-node.mjs"];
}

async function resolveGatewayEntrypoint(cwd: string): Promise<string[]> {
  let promise = entrypointPromises.get(cwd);
  if (!promise) {
    promise = prepareGatewayEntrypoint(cwd);
    entrypointPromises.set(cwd, promise);
  }
  return await promise;
}

async function reserveGatewayPort(
  port: number,
  verifyCleanup?: OpenClawTestInstanceOptions["verifyCleanup"],
) {
  // A probe must not retain a connection that can delay release before spawn.
  const server = net.createServer((socket) => socket.destroy());
  const release = () =>
    new Promise<void>((resolve, reject) => {
      server.close((error) => (error ? reject(error) : resolve()));
    });
  try {
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject);
      server.listen(port, "127.0.0.1", () => {
        server.off("error", reject);
        resolve();
      });
    });
    return { release };
  } catch (error) {
    return await runQaGatewayFixture(
      async (): Promise<never> => {
        throw error;
      },
      () => (server.listening ? (verifyCleanup ? verifyCleanup(release) : release()) : undefined),
    );
  }
}

export function formatGatewayReadinessDiagnostic(
  diagnostic: Pick<
    GatewayReadinessDiagnostic,
    "attempts" | "elapsedMs" | "lastProbe" | "lastFailedResponse" | "child"
  >,
): string {
  const { attempts, elapsedMs, lastProbe, lastFailedResponse, child } = diagnostic;
  return `[openclaw-test-instance] readiness ${JSON.stringify({
    attempts,
    elapsedMs,
    lastProbe,
    lastFailedResponse,
    child,
  })}`;
}

class GatewayReadinessError extends Error {}

export class GatewayAgentAdmissionError extends GatewayReadinessError {
  override readonly name = "GatewayAgentAdmissionError";

  constructor(
    readonly refusals: readonly Record<string, unknown>[],
    diagnostic: string,
  ) {
    const details = refusals
      .map((refusal) =>
        typeof refusal.reason === "string" && typeof refusal.repairHint === "string"
          ? `${refusal.reason}\n${refusal.repairHint}`
          : JSON.stringify(refusal),
      )
      .join("\n");
    super(`gateway agent database admission refused:\n${details}\n${diagnostic}`);
  }
}

async function waitForGatewayReady(
  proc: OpenClawTestProcessReadiness,
  chunksOut: string[],
  chunksErr: string[],
  port: number,
  timeoutMs: number,
  fetchImpl: typeof fetch = fetch,
  signal?: AbortSignal,
  record?: (diagnostic: GatewayReadinessDiagnostic) => void,
) {
  const finishPhase = beginUiE2ePhase("gateway-readiness");
  const startedAt = Date.now();
  const probes: GatewayReadinessDiagnostic["probes"] = [];
  let outcome: GatewayReadinessDiagnostic["outcome"] = "timeout";
  let attempts = 0;
  let lastProbe: ReadinessProbe | undefined;
  let lastFailedResponse: GatewayReadinessDiagnostic["lastFailedResponse"] = null;
  const startupError = (message: string, probe = lastProbe) =>
    new GatewayReadinessError(
      `${message}\n${formatGatewayReadinessDiagnostic({
        attempts,
        elapsedMs: Date.now() - startedAt,
        lastProbe: probe ?? null,
        lastFailedResponse,
        child: { pid: proc.pid ?? null, exitCode: proc.exitCode, signalCode: proc.signalCode },
      })}`,
    );
  const exitedBeforeReadinessError = (probe = lastProbe) =>
    startupError(
      `gateway exited before readiness (code=${String(proc.exitCode)} signal=${String(
        proc.signalCode,
      )})`,
      probe,
    );
  try {
    while (Date.now() - startedAt < timeoutMs) {
      signal?.throwIfAborted();
      if (hasChildExited(proc)) {
        throw exitedBeforeReadinessError();
      }

      const attemptStartedAt = Date.now();
      const remainingMs = timeoutMs - (attemptStartedAt - startedAt);
      if (remainingMs <= 0) {
        break;
      }
      const attemptTimeoutMs = Math.min(1_000, Math.max(1, remainingMs));
      const probe: ReadinessProbe = { attempt: ++attempts, phase: "headers", elapsedMs: 0 };
      const probeAbort = new AbortController();
      const abortProbe = () => probeAbort.abort(signal?.reason);
      signal?.addEventListener("abort", abortProbe, { once: true });
      if (signal?.aborted) {
        abortProbe();
      }
      let attemptTimeout: ReturnType<typeof setTimeout> | undefined;
      let handleExit = () => {};
      const exitPromise = new Promise<never>((_resolve, reject) => {
        handleExit = () => {
          probe.error = "child-exit";
          probe.elapsedMs = Date.now() - attemptStartedAt;
          const error = exitedBeforeReadinessError(probe);
          probeAbort.abort(error);
          reject(error);
        };
        proc.once("exit", handleExit);
      });
      const timeoutPromise = new Promise<never>((_resolve, reject) => {
        attemptTimeout = setTimeout(() => {
          probe.error = "timeout";
          const error = new Error("gateway readiness probe timed out");
          probeAbort.abort(error);
          reject(error);
        }, attemptTimeoutMs);
        attemptTimeout.unref?.();
      });
      try {
        // A dead child cannot complete readiness. Race the owner lifecycle against
        // both HTTP headers and body parsing so a stuck probe never hides its exit.
        const ready = await Promise.race([
          (async () => {
            const response = await fetchImpl(`http://127.0.0.1:${port}/readyz`, {
              signal: probeAbort.signal,
            });
            probe.status = response.status;
            probe.phase = "body";
            const readiness: unknown = await response.json();
            probe.phase = "complete";
            if (isRecord(readiness)) {
              if (typeof readiness.ready === "boolean") {
                probe.ready = readiness.ready;
              }
              if (typeof readiness.uptimeMs === "number" && Number.isFinite(readiness.uptimeMs)) {
                probe.uptimeMs = readiness.uptimeMs;
              }
              if (Array.isArray(readiness.failing)) {
                // Channel IDs and arbitrary startup reasons are private; retain only core categories.
                probe.failing = readiness.failing.slice(0, 8).map((reason) => {
                  switch (reason) {
                    case "startup-sidecars":
                    case "gateway-draining":
                    case "state-database":
                    case "internal":
                      return reason;
                    default:
                      return "other";
                  }
                });
                probe.omittedFailing = Math.max(0, readiness.failing.length - 8);
              }
            }
            const agentDatabases =
              isRecord(readiness) && Array.isArray(readiness.agentDatabases)
                ? readiness.agentDatabases
                : [];
            const refused = agentDatabases.filter(
              (entry): entry is Record<string, unknown> =>
                isRecord(entry) &&
                typeof entry.code === "string" &&
                entry.code !== "agent-database-inspection-pending",
            );
            if (refused.length) {
              outcome = "agent-refused";
              throw new GatewayAgentAdmissionError(
                refused,
                formatGatewayReadinessDiagnostic({
                  attempts,
                  elapsedMs: Date.now() - startedAt,
                  lastProbe: probe,
                  lastFailedResponse,
                  child: {
                    pid: proc.pid ?? null,
                    exitCode: proc.exitCode,
                    signalCode: proc.signalCode,
                  },
                }),
              );
            }
            if (
              !response.ok ||
              !isRecord(readiness) ||
              readiness.ready !== true ||
              agentDatabases.length > 0
            ) {
              return false;
            }
            // All configured agents are admitted; also join the startup sidecars.
            probeAbort.signal.throwIfAborted();
            probe.endpoint = "/startupz";
            probe.phase = "headers";
            delete probe.status;
            const startupResponse = await fetchImpl(`http://127.0.0.1:${port}/startupz`, {
              signal: probeAbort.signal,
            });
            probe.status = startupResponse.status;
            probe.phase = "body";
            const startup: unknown = await startupResponse.json();
            probe.phase = "complete";
            if (
              isRecord(startup) &&
              (startup.status === "starting" ||
                startup.status === "started" ||
                startup.status === "draining")
            ) {
              probe.startupStatus = startup.status;
            }
            return (
              startupResponse.ok &&
              isRecord(startup) &&
              startup.ok === true &&
              startup.status === "started"
            );
          })(),
          exitPromise,
          timeoutPromise,
        ]);
        signal?.throwIfAborted();
        if (ready) {
          outcome = "ready";
          return;
        }
      } catch (error) {
        signal?.throwIfAborted();
        if (error instanceof GatewayAgentAdmissionError) {
          throw error;
        }
        probe.elapsedMs = Date.now() - attemptStartedAt;
        if (hasChildExited(proc)) {
          probe.error ??= "child-exit";
          throw exitedBeforeReadinessError(probe);
        }
        probe.error ??=
          probe.phase === "headers"
            ? "fetch-failed"
            : error instanceof SyntaxError
              ? "invalid-json"
              : "body-failed";
        // keep polling
      } finally {
        // A fetch that ignores abort may finish later; keep its mutations out of the retained receipt.
        if (signal?.aborted) {
          probe.error ??= "aborted";
        }
        lastProbe = { ...probe, elapsedMs: Date.now() - attemptStartedAt };
        // Preserve a completed failure when the budget's final probe stalls. Keep
        // only scalar categories, never response bodies, headers, or error text.
        if (
          lastProbe.status !== undefined &&
          outcome !== "ready" &&
          (!lastProbe.error ||
            lastProbe.error === "invalid-json" ||
            lastProbe.error === "body-failed")
        ) {
          const { attempt, phase, elapsedMs, status, ready, endpoint, startupStatus, error } =
            lastProbe;
          lastFailedResponse = {
            attempt,
            phase,
            elapsedMs,
            status,
            ready,
            endpoint,
            startupStatus,
            error,
          };
        }
        // Bound retained diagnostics even when callers extend the startup budget.
        if (probes.length < 8192) {
          probes.push({
            ...lastProbe,
            startedAtMs: attemptStartedAt,
            deadlineMs: attemptStartedAt + attemptTimeoutMs,
          });
        }
        if (attemptTimeout) {
          clearTimeout(attemptTimeout);
        }
        proc.off("exit", handleExit);
        signal?.removeEventListener("abort", abortProbe);
      }

      // Agent-launched fixtures can inherit the secret proxy: a closed listener
      // must not produce a stream of proxied refusals at a fixed 10ms cadence.
      const delayMs = Math.min(
        10 * 2 ** Math.min(attempts - 1, 6),
        500,
        timeoutMs - (Date.now() - startedAt),
      );
      if (delayMs > 0) {
        await sleep(delayMs, signal);
      }
    }
    signal?.throwIfAborted();
    if (hasChildExited(proc)) {
      throw exitedBeforeReadinessError();
    }
    throw startupError(`timeout waiting for gateway readiness on port ${port}`);
  } catch (error) {
    signal?.throwIfAborted();
    throw error;
  } finally {
    finishPhase();
    record?.({
      probe: "GET /readyz",
      settlementProbe: "GET /startupz",
      startedAtMs: startedAt,
      deadlineMs: startedAt + timeoutMs,
      elapsedMs: Date.now() - startedAt,
      outcome: signal?.aborted ? "aborted" : hasChildExited(proc) ? "child-exit" : outcome,
      attempts,
      probes,
      omittedProbes: attempts - probes.length,
      lastProbe: lastProbe ?? null,
      lastFailedResponse,
      child: { pid: proc.pid ?? null, exitCode: proc.exitCode, signalCode: proc.signalCode },
      logs: outcome === "ready" ? null : { stdout: chunksOut.join(""), stderr: chunksErr.join("") },
    });
  }
}

async function stopWindowsGatewayProcess(
  child: RawGatewayProcess,
  deadline: number,
  stopTimeoutMs: number,
  options: GatewayProcessStopOptions = {},
  stopLog: string[] = [],
): Promise<boolean> {
  const platform = "win32";
  const startedAt = Date.now();
  const taskkill: Array<{
    force: boolean;
    elapsedMs: number;
    status?: number | null;
    signal?: NodeJS.Signals | null;
    errorCode?: string;
    threw?: boolean;
  }> = [];
  // At most the owner's TERM and force attempts; never retain command output or error text.
  const runTaskkill: NonNullable<GatewayProcessStopOptions["runTaskkill"]> = (...args) => {
    const attemptStartedAt = Date.now();
    let result: TaskkillResult | undefined;
    let threw = false;
    let error: unknown;
    try {
      result = (options.runTaskkill ?? spawnSync)(...args);
      return result;
    } catch (cause) {
      threw = true;
      error = cause;
      throw cause;
    } finally {
      taskkill.push({
        force: args[1].includes("/F"),
        elapsedMs: Date.now() - attemptStartedAt,
        status: result?.status,
        signal: result?.signal,
        errorCode: shutdownErrorCode(result?.error ?? error),
        ...(threw ? { threw } : {}),
      });
    }
  };
  const failed = (
    reason: "termination-indeterminate" | "close-incomplete" | "exception",
    error?: unknown,
  ) => {
    const diagnostic = {
      reason,
      pid: child.pid,
      exitCode: child.exitCode,
      signalCode: child.signalCode,
      stdoutClosed: child.stdout.closed,
      stderrClosed: child.stderr.closed,
      elapsedMs: Date.now() - startedAt,
      taskkill,
      errorCode: shutdownErrorCode(error),
    };
    appendLogChunk(
      stopLog,
      `[openclaw-test-instance] Windows shutdown ${JSON.stringify(diagnostic)}\n`,
    );
    return false;
  };
  if (Date.now() >= deadline) {
    return failed("close-incomplete");
  }
  // Taskkill owns its bounded synchronous TERM/force sequence. Node cannot observe
  // exit or pipe closure until it returns, so charge the existing close allowance afterward.
  try {
    const signal =
      hasChildExited(child) && !options.forceWindowsTree
        ? undefined
        : options.forceWindowsTree
          ? "SIGKILL"
          : "SIGTERM";
    await finalizeManagedChild(child, signal, {
      platform,
      runTaskkill,
      forceKillDelayMs: 0,
      drainTimeoutMs: stopTimeoutMs,
      retainOutputOnFailure: true,
    });
    return true;
  } catch (error) {
    failed("exception", error);
    throw error;
  }
}

function shutdownErrorCode(error: unknown): string | undefined {
  return isRecord(error) && typeof error.code === "string" ? error.code.slice(0, 128) : undefined;
}

function hasChildExited(child: Pick<OpenClawTestProcess, "exitCode" | "signalCode">) {
  return child.exitCode !== null || child.signalCode !== null;
}

function mergeConfig(
  base: Record<string, unknown>,
  override: Record<string, unknown> | undefined,
): Record<string, unknown> {
  if (!override) {
    return base;
  }
  const result: Record<string, unknown> = { ...base };
  for (const [key, value] of Object.entries(override)) {
    const existing = result[key];
    result[key] = isRecord(existing) && isRecord(value) ? mergeConfig(existing, value) : value;
  }
  return result;
}

function formatLogs(stdout: string[], stderr: string[], maxBytes = LOG_TAIL_MAX_BYTES): string {
  const diagnosticTail = (log: string[]): string => {
    const tail = createBoundedStringLog(
      Math.min((log as BoundedStringLog).maxBytes ?? LOG_TAIL_MAX_BYTES, maxBytes),
    ) as BoundedStringLog;
    for (const chunk of log) {
      appendLogChunk(tail, chunk);
    }
    tail.truncated ||= (log as BoundedStringLog).truncated;
    return readLogBuffer(tail);
  };
  return `--- stdout ---\n${diagnosticTail(stdout)}\n--- stderr ---\n${diagnosticTail(stderr)}`;
}

type PortListenerOwner = { pid: number; pgid: number | null; comm: string | null };
type PortListenerScan = { owners: PortListenerOwner[]; complete: boolean } | "unsupported";

// Failure diagnostics must not consume the test deadline before teardown.
const PORT_LISTENER_SCAN_BUDGET_MS = 1_000;

/** Linux only: which processes hold a LISTEN socket on the loopback port. */
async function inspectPortListeners(port: number): Promise<PortListenerScan> {
  if (process.platform !== "linux") {
    return "unsupported";
  }
  const deadline = Date.now() + PORT_LISTENER_SCAN_BUDGET_MS;
  const inodes = new Set<string>();
  for (const table of ["/proc/net/tcp", "/proc/net/tcp6"]) {
    const rows = await fs.readFile(table, "utf8").catch(() => "");
    for (const row of rows.split("\n").slice(1)) {
      // sl local_address rem_address st ... inode; state 0A is LISTEN.
      const fields = row.trim().split(/\s+/u);
      const localPort = Number.parseInt(fields[1]?.split(":").at(-1) ?? "", 16);
      if (localPort === port && fields[3] === "0A" && fields[9]) {
        inodes.add(fields[9]);
      }
    }
  }
  const owners: PortListenerOwner[] = [];
  if (inodes.size === 0) {
    return { owners, complete: true };
  }
  for (const pid of await fs.readdir("/proc")) {
    if (owners.length >= 8 || Date.now() > deadline) {
      return { owners, complete: false };
    }
    if (!/^\d+$/u.test(pid)) {
      continue;
    }
    const fds = await fs.readdir(`/proc/${pid}/fd`).catch(() => []);
    for (const fd of fds) {
      if (Date.now() > deadline) {
        return { owners, complete: false };
      }
      const target = await fs.readlink(`/proc/${pid}/fd/${fd}`).catch(() => "");
      if (inodes.has(/^socket:\[(\d+)\]$/u.exec(target)?.[1] ?? "")) {
        const stat = await fs.readFile(`/proc/${pid}/stat`, "utf8").catch(() => "");
        // comm may contain spaces; pgrp is the third field after its closing paren.
        const pgid = Number(stat.slice(stat.lastIndexOf(")") + 2).split(" ")[2]);
        owners.push({
          pid: Number(pid),
          pgid: Number.isInteger(pgid) ? pgid : null,
          comm: /\((.*)\)/su.exec(stat)?.[1]?.slice(0, 32) ?? null,
        });
        break;
      }
    }
  }
  return { owners, complete: true };
}

function createInstanceEnv(params: {
  stateEnv: NodeJS.ProcessEnv;
  extraEnv: Record<string, string | undefined>;
}): NodeJS.ProcessEnv {
  const env: NodeJS.ProcessEnv = {
    ...params.stateEnv,
    OPENCLAW_GATEWAY_TOKEN: "",
    OPENCLAW_GATEWAY_PASSWORD: "",
    OPENCLAW_GATEWAY_PORT: "",
    OPENCLAW_GATEWAY_URL: "",
    OPENCLAW_SKIP_CHANNELS: "1",
    OPENCLAW_SKIP_PROVIDERS: "1",
    OPENCLAW_SKIP_GMAIL_WATCHER: "1",
    OPENCLAW_SKIP_CRON: "1",
    OPENCLAW_SKIP_BROWSER_CONTROL_SERVER: "1",
    OPENCLAW_SKIP_CANVAS_HOST: "1",
    OPENCLAW_TEST_MINIMAL_GATEWAY: "1",
    VITEST: "1",
  };
  for (const [key, value] of Object.entries(params.extraEnv)) {
    if (value === undefined) {
      delete env[key];
    } else {
      env[key] = value;
    }
  }
  return env;
}

export async function createOpenClawTestInstance(
  options: OpenClawTestInstanceOptions,
): Promise<OpenClawTestInstance> {
  const cwd = options.cwd ?? process.cwd();
  const signal = options.signal;
  const verifyCleanup = options.verifyCleanup ?? ((cleanup: () => Promise<void>) => cleanup());
  let acceptingWork = !signal?.aborted;
  const closeAdmission = () => {
    acceptingWork = false;
  };
  const entrypoint = async () => {
    signal?.throwIfAborted();
    // Shared preparation remains joined for every borrower; one instance's
    // cancellation only refuses its own handoff and subsequent spawn.
    const prepared = options.entrypoint ?? (await resolveGatewayEntrypoint(cwd));
    signal?.throwIfAborted();
    return prepared;
  };
  let reservation: Awaited<ReturnType<typeof reserveGatewayPort>> | undefined;
  const releasePort = async () => {
    if (reservation) {
      await reservation.release();
      reservation = undefined;
    }
  };
  let releasePortClaims: (() => Promise<void>) | undefined;
  let port: number;
  const gatewayToken = options.gatewayToken ?? `gateway-${options.name}-${randomUUID()}`;
  const hookToken = options.hookToken ?? `token-${options.name}-${randomUUID()}`;
  let state: OpenClawTestState | undefined;
  signal?.addEventListener("abort", closeAdmission, { once: true });
  try {
    signal?.throwIfAborted();
    // The lazy sandbox uses port + 1; keep both listeners out of Linux's client-port pool.
    if (options.port !== undefined) {
      port = options.port;
    } else {
      const reserved = await reserveTestPortListener({
        offsets: [0, 1],
        signal,
        createListener: () => net.createServer((socket) => socket.destroy()),
        verifyCleanup: options.verifyCleanup,
      });
      port = reserved.claim.port;
      releasePortClaims = reserved.claim.release;
      reservation = { release: reserved.releaseListener };
    }
    signal?.throwIfAborted();
    state = await createOpenClawTestState({
      label: options.name,
      layout: "home",
      ...options.state,
      applyEnv: false,
      env: options.env,
      verifyCleanup: options.verifyCleanup,
    });
    signal?.throwIfAborted();
    await state.writeConfig(
      mergeConfig(
        {
          gateway: {
            port,
            auth: { mode: "token", token: gatewayToken },
            controlUi: { enabled: false },
          },
          hooks: { enabled: true, token: hookToken, path: "/hooks" },
        },
        options.config,
      ),
    );
    if (options.reserveIdlePort === false) {
      await verifyCleanup(releasePort);
    }
    signal?.throwIfAborted();
  } catch (error) {
    // Neither owner is exposed until configuration succeeds; roll both back,
    // retaining the acquisition error even when a cleanup phase also fails.
    const acquiredState = state;
    try {
      return await runQaGatewayFixture(
        async (): Promise<never> => {
          throw error;
        },
        () => (acquiredState ? verifyCleanup(() => acquiredState.cleanup()) : undefined),
        () => (reservation ? verifyCleanup(releasePort) : undefined),
        () => (releasePortClaims ? verifyCleanup(releasePortClaims) : undefined),
      );
    } finally {
      signal?.removeEventListener("abort", closeAdmission);
    }
  }

  const stdout = createBoundedStringLog();
  const stderr = createBoundedStringLog();
  const readiness: GatewayReadinessDiagnostic[] = [];
  const env = createInstanceEnv({
    stateEnv: state.env,
    extraEnv: options.env ?? {},
  });
  let child:
    | {
        process: OpenClawTestProcess;
        ready: boolean;
        spawnedAtMs: number;
        started: Promise<void>;
        stop: (deadline: number, stopOptions: GatewayProcessStopOptions) => Promise<boolean>;
      }
    | undefined;
  let constructionCleanup: Promise<ProcessExtinctionResult> | undefined;
  const crashedChildren = new Set<NonNullable<typeof child>>();
  const commands = new Set<Promise<OpenClawTestInstanceCommandResult>>();
  const reserveIdlePort = async () => {
    if (
      options.reserveIdlePort !== false &&
      options.port === undefined &&
      acceptingWork &&
      !reservation
    ) {
      reservation = await reserveGatewayPort(port, options.verifyCleanup);
    }
  };
  let cleanupPromise: Promise<void> | undefined;
  let operation:
    | { kind: "start" | "stop" | "crash" | "cleanup"; promise: Promise<void> }
    | undefined;
  const enqueue = (kind: NonNullable<typeof operation>["kind"], action: () => Promise<void>) => {
    if (operation?.kind === kind) {
      return operation.promise;
    }
    // Claim ordering before preparation can yield. Teardown joins pending startup,
    // and another start cannot borrow readiness from a child being stopped.
    const finishQueue = beginUiE2ePhase(kind === "start" ? "gateway-start-queue" : undefined);
    const next = {
      kind,
      promise: Promise.resolve(operation?.promise)
        .catch(() => undefined)
        .then(() => {
          finishQueue();
          const finishPhase = beginUiE2ePhase(
            kind === "start"
              ? "gateway-start"
              : kind === "stop"
                ? "gateway-stop"
                : kind === "cleanup"
                  ? "gateway-cleanup"
                  : undefined,
          );
          return action().finally(finishPhase);
        }),
    };
    operation = next;
    const release = () => {
      if (operation === next) {
        operation = undefined;
      }
    };
    void next.promise.then(release, release);
    return next.promise;
  };
  const stopTimeoutMs = options.stopTimeoutMs ?? GATEWAY_STOP_TIMEOUT_MS;
  const spawnGatewayProcess = async (
    spawnManagedChild: Awaited<ReturnType<typeof loadManagedChildSpawner>>,
    args: string[],
    attemptStderr: string[],
  ) => {
    const [command = process.execPath, ...prefixArgs] = options.gatewayCommandPrefix ?? [];
    signal?.throwIfAborted();
    const onError = (error: Error) =>
      appendLogChunk(stderr, `gateway child startup error: ${error.message}\n`);
    let owned: {
      process: OpenClawTestProcess;
      started: Promise<void>;
      stop: (deadline: number, stopOptions: GatewayProcessStopOptions) => Promise<boolean>;
    };
    if (process.platform === "win32") {
      const process = spawnManagedChild(command, [...prefixArgs, ...args], {
        cwd,
        env,
        stdio: ["ignore", "pipe", "pipe"],
        detached: false,
      });
      process.once("error", onError);
      owned = {
        process,
        started: Promise.resolve(),
        stop: (deadline, stopOptions) =>
          stopWindowsGatewayProcess(process, deadline, stopTimeoutMs, stopOptions, stderr),
      };
    } else {
      const process = await createOpenClawTestProcess({
        argv: [command, ...prefixArgs, ...args],
        cwd,
        env,
        signal,
        gracefulShutdownTimeoutMs: options.gracefulShutdownTimeoutMs,
        onError,
        onSpawnCleanup: (cleanup) => {
          constructionCleanup = cleanup;
          void cleanup.catch(() => {
            acceptingWork = false;
          });
        },
      });
      owned = {
        ...process,
        stop: (deadline) =>
          process.stop(deadline, (message) => appendLogChunk(stderr, `${message}\n`)),
      };
    }
    const next = owned.process;
    next.stdout.setEncoding("utf8");
    next.stderr.setEncoding("utf8");
    next.stdout.on("data", (chunk) => appendLogChunk(stdout, chunk));
    next.stderr.on("data", (chunk) => {
      appendLogChunk(stderr, chunk);
      appendLogChunk(attemptStderr, chunk);
    });
    return owned;
  };
  const releaseGatewayChild = async (
    target: OpenClawTestProcess,
    deadline: number,
    stopOptions: GatewayProcessStopOptions = {},
  ): Promise<boolean> => {
    if (child?.process !== target) {
      throw new Error("Gateway cleanup lost its process owner");
    }
    const closed = await child.stop(deadline, stopOptions);
    if (closed && child?.process === target) {
      child = undefined;
    }
    return closed;
  };
  const stopGatewayChild = async (stopOptions: GatewayProcessStopOptions = {}) => {
    const target = child;
    if (!target) {
      await constructionCleanup;
      constructionCleanup = undefined;
      await reserveIdlePort();
      return;
    }
    // A failed stop retains ownership, never the old readiness observation.
    target.ready = false;
    const closed = await releaseGatewayChild(
      target.process,
      Date.now() + stopTimeoutMs * 2,
      stopOptions,
    );
    if (!closed) {
      throw new Error(
        `gateway process cleanup could not verify termination and output closure\n${formatLogs(stdout, stderr)}`,
      );
    }
    await reserveIdlePort();
  };
  const stopAllGatewayChildren = async (stopOptions: GatewayProcessStopOptions = {}) => {
    await runQaGatewayFixture(
      () => stopGatewayChild(stopOptions),
      ...[...crashedChildren].map((target) => async () => {
        if (!(await target.stop(Date.now() + stopTimeoutMs * 2, stopOptions))) {
          throw new Error("crashed Gateway process cleanup could not verify termination");
        }
        crashedChildren.delete(target);
      }),
    );
  };

  const instance: OpenClawTestInstance = {
    name: options.name,
    port,
    url: `ws://127.0.0.1:${port}`,
    hookToken,
    gatewayToken,
    homeDir: state.home,
    stateDir: state.stateDir,
    configPath: state.configPath,
    state,
    stdout,
    stderr,
    readiness,
    get child() {
      return child?.process;
    },
    env,
    entrypoint,
    cli: (args, commandOptions = {}) => {
      if (!acceptingWork) {
        return Promise.reject(new Error("test instance no longer accepts CLI commands"));
      }
      // Admit the whole operation before preparation yields. Failed process cleanup
      // retains its completion and closes admission until the instance is retired.
      const command = Promise.resolve().then(async () => {
        signal?.throwIfAborted();
        const commandEntrypoint = await entrypoint();
        signal?.throwIfAborted();
        return await runCommand({
          args: [commandOptions.execPath ?? process.execPath, ...commandEntrypoint, ...args],
          cwd,
          env,
          timeoutMs: commandOptions.timeoutMs ?? COMMAND_TIMEOUT_MS,
          signal,
        });
      });
      commands.add(command);
      void command.then(
        () => commands.delete(command),
        (error: unknown) => {
          if (hasUnjoinedWork(error)) {
            acceptingWork = false;
          } else {
            commands.delete(command);
          }
        },
      );
      return command;
    },
    startGateway: () => {
      if (!acceptingWork) {
        return Promise.reject(new Error("test instance no longer accepts Gateway starts"));
      }
      return enqueue("start", async () => {
        signal?.throwIfAborted();
        if (child?.ready && !hasChildExited(child.process)) {
          return;
        }
        readiness.length = 0;
        const commandEntrypoint = await entrypoint();
        const spawnManagedChild = await loadManagedChildSpawner();
        signal?.throwIfAborted();
        const gatewayArgs = [
          ...commandEntrypoint,
          "gateway",
          "--port",
          String(port),
          "--bind",
          "loopback",
          "--allow-unconfigured",
          ...(options.gatewayArgs ?? []),
        ];
        await stopGatewayChild({ forceWindowsTree: true });
        // Parent-side seeds retain leases that the child's startup maintenance must acquire.
        await cleanupSessionStateForTest({ stateDir: state.stateDir, rootPath: state.root });
        signal?.throwIfAborted();
        const deadline = Date.now() + (options.startTimeoutMs ?? GATEWAY_START_TIMEOUT_MS);
        let restarts = 0;

        while (true) {
          signal?.throwIfAborted();
          const remainingMs = deadline - Date.now();
          if (remainingMs <= 0) {
            throw new Error(
              `timeout waiting for gateway readiness on port ${port}\n${formatLogs(stdout, stderr)}`,
            );
          }
          const attemptStderr = createBoundedStringLog();
          await releasePort();
          signal?.throwIfAborted();
          let spawned: Awaited<ReturnType<typeof spawnGatewayProcess>>;
          try {
            spawned = await spawnGatewayProcess(spawnManagedChild, gatewayArgs, attemptStderr);
          } catch (error) {
            await runQaGatewayFixture(async (): Promise<never> => {
              throw error;
            }, reserveIdlePort);
            return;
          }
          const attempt = spawned.process;
          const owner = { ...spawned, ready: false, spawnedAtMs: Date.now() };
          child = owner;
          constructionCleanup = undefined;
          try {
            await owner.started;
            await waitForGatewayReady(
              attempt,
              stdout,
              stderr,
              port,
              remainingMs,
              fetch,
              signal,
              (diagnostic) => readiness.push(diagnostic),
            );
            signal?.throwIfAborted();
            owner.ready = true;
            return;
          } catch (err) {
            const exitCode = attempt.exitCode;
            const signalCode = attempt.signalCode;
            // Startup expiry stops retry admission, not ownership cleanup. Use the
            // same separate shutdown budget as explicit stop, retaining failed owners.
            let closed = false;
            const cleanupErrors: unknown[] = [];
            try {
              await verifyCleanup(async () => {
                closed = await releaseGatewayChild(attempt, Date.now() + stopTimeoutMs * 2, {
                  // An exited leader may still have inherited diagnostics to drain.
                  forceWindowsTree: signal?.aborted === true || !hasChildExited(attempt),
                });
                // The optional lifetime must retain failed rollback even if
                // startup never handed a process to its caller.
                if (!closed && options.verifyCleanup) {
                  throw new Error(
                    `gateway process cleanup could not verify termination and output closure\n${formatLogs(stdout, stderr)}`,
                    { cause: err },
                  );
                }
              });
              if (closed) {
                await reserveIdlePort();
              }
            } catch (cleanupError) {
              cleanupErrors.push(cleanupError);
            }
            // Exit precedes pipe closure. Capture output after the owner's drain,
            // including when reclaiming its port failed after successful cleanup.
            if (err instanceof GatewayAgentAdmissionError) {
              err.message += `\n${formatLogs(stdout, stderr)}`;
            }
            const startupError =
              err instanceof GatewayReadinessError && !(err instanceof GatewayAgentAdmissionError)
                ? new Error(`${err.message}\n${formatLogs(stdout, stderr)}`, { cause: err })
                : err;
            if (cleanupErrors.length > 0) {
              throw new AggregateError(
                [startupError, ...cleanupErrors],
                "gateway startup and cleanup failed",
                {
                  cause: err,
                },
              );
            }
            // Exit can precede stderr delivery. Classify only this completed
            // attempt, never the readiness error's snapshot or earlier starts.
            const completedStderr = readLogBuffer(attemptStderr);
            if (closed && !signal?.aborted && exitCode === 78 && signalCode === null) {
              // Admission after a checkpoint and a refused migration step have
              // different reports; both must name the source and its repair.
              const admissionRefusal = completedStderr.match(
                /^(?:Gateway failed to start: )?Legacy session store requires migration: (.+)\. Run "([^"\r\n]+)" against the same state\/config before starting OpenClaw\.\r?$/mu,
              );
              const legacyStorePath =
                admissionRefusal?.[2] === formatCliCommand("openclaw doctor --fix", env)
                  ? admissionRefusal[1]
                  : completedStderr.match(
                      /^OpenClaw startup migrations did not complete cleanly; refusing to report the gateway ready\.\r?\n- Legacy sessions store unreadable; left in place at ([^\r\n]+)\r?\n(?:- [^\r\n]+\r?\n)*Run "openclaw doctor --fix" against the same state\/config, then restart the gateway\.\r?$/mu,
                    )?.[1];
              if (legacyStorePath) {
                throw new GatewayStartupRefusedError(
                  legacyStorePath,
                  completedStderr,
                  startupError,
                );
              }
            }
            const shouldRestart =
              !signal?.aborted &&
              restarts < GATEWAY_MIGRATION_CONVERGENCE_MAX_RESTARTS &&
              isGatewayMigrationConvergenceRefusal(exitCode, signalCode, completedStderr);
            if (shouldRestart && closed && Date.now() < deadline) {
              restarts += 1;
              appendLogChunk(stderr, GATEWAY_MIGRATION_CONVERGENCE_RESTART_MARKER);
              continue;
            }
            throw startupError;
          }
        }
      });
    },
    crashGateway: () =>
      enqueue("crash", async () => {
        signal?.throwIfAborted();
        const target = child;
        if (
          !acceptingWork ||
          !target?.ready ||
          !target.process.pid ||
          hasChildExited(target.process)
        ) {
          throw new Error("Running Gateway command is unavailable for crash");
        }
        target.ready = false;
        // The adapter exposes the command PID, not its relay/anchor. Do not use
        // target.process.kill(), whose adapter implementation cancels the entire tree.
        const exited = once(target.process, "exit");
        process.kill(target.process.pid, "SIGKILL");
        await exited;
        crashedChildren.add(target);
        child = undefined;
      }),
    stopGateway: () => enqueue("stop", stopAllGatewayChildren),
    logs: () => formatLogs(stdout, stderr),
    diagnose: async () => {
      const owner = child;
      const ready = readiness.at(-1);
      const readyProbe = ready?.probes.at(-1);
      const facts = {
        port,
        child: owner
          ? {
              pid: owner.process.pid ?? null,
              exitCode: owner.process.exitCode,
              signalCode: owner.process.signalCode,
              ready: owner.ready,
              ageMs: Date.now() - owner.spawnedAtMs,
            }
          : null,
        readiness: ready
          ? {
              outcome: ready.outcome,
              attempts: ready.attempts,
              elapsedMs: ready.elapsedMs,
              lastProbe: ready.lastProbe,
              // A responder older than the child cannot be the child.
              childAgeAtLastProbeMs: readyProbe
                ? readyProbe.startedAtMs - (owner?.spawnedAtMs ?? ready.startedAtMs)
                : null,
            }
          : null,
        listeners: await inspectPortListeners(port),
      };
      return `[openclaw-test-instance] gateway ${JSON.stringify(facts)}\n${formatLogs(
        stdout,
        stderr,
        64 * 1024,
      )}`;
    },
    cleanup: () => {
      acceptingWork = false;
      signal?.removeEventListener("abort", closeAdmission);
      // Commands may need the Gateway to finish. Drain them first, still attempt
      // Gateway shutdown on failure, and never turn an unverified drain into a retry success.
      return (cleanupPromise ??= enqueue("cleanup", async () => {
        await runQaGatewayFixture(
          async () => {
            const results = await Promise.allSettled(commands);
            const errors = results.flatMap((result) =>
              result.status === "rejected" && hasUnjoinedWork(result.reason) ? [result.reason] : [],
            );
            if (errors.length === 1) {
              throw errors[0];
            }
            if (errors.length > 1) {
              throw new AggregateError(
                errors,
                "CLI cleanup unverified; test instance state retained",
              );
            }
          },
          () => {
            // Terminal cleanup has no graceful-shutdown contract. Force the Windows
            // tree so inherited pipes cannot outlive the completed test instance.
            return stopAllGatewayChildren({ forceWindowsTree: true });
          },
          releasePort,
        );
        await state.cleanup();
        // Keep the logical claim across the socket handoff, stop/restart, and
        // failed shutdown. Only verified terminal cleanup releases either port.
        if (releasePortClaims) {
          await verifyCleanup(releasePortClaims);
          releasePortClaims = undefined;
        }
      }));
    },
  };

  return instance;
}

async function runCommand(params: {
  args: string[];
  cwd: string;
  env: NodeJS.ProcessEnv;
  timeoutMs: number;
  signal?: AbortSignal;
}): Promise<OpenClawTestInstanceCommandResult> {
  const [command, ...args] = params.args;
  if (!command) {
    throw new Error("missing command");
  }
  const stdout = createCapturedOutputBuffers();
  const maxStdoutBytes = resolveMaxOutputBytes(undefined, "stdout");
  const outputLimit = new AbortController();
  const readStdout = () => finalizeCapturedOutput(stdout, "head", true).toString("utf8");
  const stdoutDiagnostic = createBoundedStringLog();
  const stdoutDiagnosticDecoder = new StringDecoder("utf8");
  const stderr = createBoundedStringLog();
  let child!: ChildProcess;
  try {
    await runManagedCommand({
      bin: command,
      args,
      cwd: params.cwd,
      // The fixture environment is complete; never merge credentials from the parent.
      env: params.env,
      stdio: ["ignore", "pipe", "pipe"],
      shell: false,
      timeoutMs: params.timeoutMs,
      timeoutKillGraceMs: 0,
      signal: params.signal
        ? AbortSignal.any([params.signal, outputLimit.signal])
        : outputLimit.signal,
      abortKillGraceMs: 0,
      onReady: (process) => {
        child = process;
        child.stderr?.setEncoding("utf8");
        child.stdout?.on("data", (chunk) => {
          appendCapturedOutput(stdout, chunk, maxStdoutBytes, "head");
          appendLogChunk(stdoutDiagnostic, stdoutDiagnosticDecoder.write(chunk));
          if (stdout.truncatedBytes > 0) {
            outputLimit.abort();
          }
        });
        child.stderr?.on("data", (chunk) => appendLogChunk(stderr, chunk));
      },
    });
  } catch (error) {
    appendLogChunk(stdoutDiagnostic, stdoutDiagnosticDecoder.end());
    const message = hasErrnoCode(error, "ETIMEDOUT")
      ? `command timed out after ${params.timeoutMs}ms: ${params.args.join(" ")}`
      : stdout.truncatedBytes > 0
        ? "command stdout exceeded capture limit"
        : error instanceof Error
          ? error.message
          : String(error);
    throw new Error(`${message}\n${formatLogs(stdoutDiagnostic, stderr)}`, { cause: error });
  }
  return {
    code: child.exitCode,
    signal: child.signalCode,
    stdout: readStdout(),
    stderr: readLogBuffer(stderr),
  };
}

export const testing = {
  appendLogChunk,
  createBoundedStringLog,
  formatLogs,
  stopWindowsGatewayProcess,
  waitForGatewayReady,
};
