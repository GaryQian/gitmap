export const ANSI_OSC_INTRODUCER_PATTERN = "(?:\\x1b\\]|\\x9d)";
export const ANSI_STRING_TERMINATOR_PATTERN = "(?:\\x1b\\\\|\\x07|\\x9c)";
const ANSI_OSC_PATTERN = `${ANSI_OSC_INTRODUCER_PATTERN}[^\\x07\\x1b\\x9c]*${ANSI_STRING_TERMINATOR_PATTERN}`;
export const ANSI_COMPAT_CONTROL_SEQUENCE_PATTERN =
  "[\\u001B\\u009B][[\\]()#;?]*(?:\\d{1,4}(?:[;:]\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]";

const ansiOscAtIndexRegex = new RegExp(ANSI_OSC_PATTERN, "y");
// eslint-disable-next-line no-control-regex -- ANSI introducers delimit visible text runs.
const ansiIntroducerRegex = /[\u001b\u009b\u009d]/g;

type AnsiSegment =
  | { controls: string[]; kind: "ansi"; value: string }
  | { kind: "text"; value: string };

export function matchAnsiOscAt(input: string, index: number): string | undefined {
  // Reset the sticky matcher when callers interleave segment iterators.
  ansiOscAtIndexRegex.lastIndex = index;
  return ansiOscAtIndexRegex.exec(input)?.[0];
}

type AnsiCsiScan = {
  controls: string[];
  ended: boolean;
  value: string;
};

function isCompatPrefixCode(code: number): boolean {
  return (
    code === 0x5b ||
    code === 0x5d ||
    code === 0x28 ||
    code === 0x29 ||
    code === 0x23 ||
    code === 0x3b ||
    code === 0x3f
  );
}

function isCompatParameterCode(code: number): boolean {
  return (code >= 0x30 && code <= 0x39) || code === 0x3a || code === 0x3b;
}

function isDigitCode(code: number): boolean {
  return code >= 0x30 && code <= 0x39;
}

function isCompatFinalCode(code: number): boolean {
  return (
    (code >= 0x30 && code <= 0x39) ||
    (code >= 0x40 && code <= 0x5a) ||
    code === 0x63 ||
    (code >= 0x66 && code <= 0x6e) ||
    (code >= 0x71 && code <= 0x75) ||
    code === 0x79 ||
    code === 0x3d ||
    code === 0x3e ||
    code === 0x3c ||
    code === 0x7e
  );
}

/**
 * Incrementally strip the ANSI grammar accepted by the agent output sanitizer.
 * Parser state stays constant-size so unterminated OSC payloads cannot escape
 * or accumulate outside the caller's output limits.
 */
export class AnsiSequenceStripper {
  private state: "text" | "escape" | "osc" | "osc-escape" | "csi" | "compat" = "text";
  private csiCompatPrefixOnly = false;
  private compatParameterDigits: number | undefined;
  private csi: string | undefined;

  constructor(private readonly onCsi?: (sequence: string) => void) {}

  private startCsi() {
    this.state = "csi";
    this.csiCompatPrefixOnly = true;
    this.csi = this.onCsi ? "" : undefined;
  }

  write(input: string): string {
    if (typeof input !== "string") {
      throw new TypeError(`Expected a \`string\`, got \`${typeof input}\``);
    }
    if (
      this.state === "text" &&
      !input.includes("\u001B") &&
      !input.includes("\u009B") &&
      !input.includes("\u009D")
    ) {
      return input;
    }

    const output: string[] = [];
    let index = 0;
    while (index < input.length) {
      const code = input.charCodeAt(index);

      if (this.state === "osc" || this.state === "osc-escape") {
        if (code === 0x07 || code === 0x9c || (this.state === "osc-escape" && code === 0x5c)) {
          this.state = "text";
        } else {
          this.state = code === 0x1b ? "osc-escape" : "osc";
        }
        index += 1;
        continue;
      }

      // OSC payloads own their escape bytes; only other pending sequences restart.
      if (code === 0x1b || code === 0x9b || code === 0x9d) {
        if (code === 0x9b) {
          this.startCsi();
        } else {
          this.state = code === 0x1b ? "escape" : "osc";
        }
        index += 1;
        continue;
      }

      if (this.state === "text") {
        ansiIntroducerRegex.lastIndex = index;
        const end = ansiIntroducerRegex.exec(input)?.index ?? input.length;
        output.push(input.slice(index, end));
        index = end;
        continue;
      }

      if (this.state === "csi") {
        if (code === 0x18 || code === 0x1a) {
          this.state = "text";
        } else if (code <= 0x1f || code === 0x7f) {
          output.push(input.charAt(index));
        } else if (code >= 0x20 && code <= 0x3f) {
          // Only retain bounded CSI metadata; oversized controls are still stripped
          // through their final byte, but never dispatch a truncated command.
          if (this.csi !== undefined) {
            this.csi = this.csi.length < 64 ? this.csi + input.charAt(index) : undefined;
          }
          if (!isCompatPrefixCode(code)) {
            this.csiCompatPrefixOnly = false;
          }
        } else if ((code === 0x5b || code === 0x5d) && this.csiCompatPrefixOnly) {
          // The compatibility grammar accepts bracket runs before parameters.
          // Keep them pending so a chunk split cannot expose the final byte.
          this.state = "compat";
          this.compatParameterDigits = undefined;
        } else if (code >= 0x40 && code <= 0x7e) {
          if (this.csi !== undefined) {
            this.onCsi?.(this.csi + input.charAt(index));
          }
          this.state = "text";
        } else {
          this.state = "text";
          continue;
        }
      } else if (this.state === "escape") {
        if (code === 0x5d) {
          this.state = "osc";
        } else if (code === 0x5b) {
          this.startCsi();
        } else if (isCompatPrefixCode(code)) {
          this.state = "compat";
          this.compatParameterDigits = undefined;
        } else if (isDigitCode(code)) {
          this.state = "compat";
          this.compatParameterDigits = 1;
        } else if (isCompatFinalCode(code)) {
          this.state = "text";
        } else {
          this.state = "text";
          continue;
        }
      } else if (code === 0x18 || code === 0x1a) {
        this.state = "text";
      } else if (this.compatParameterDigits === undefined && isCompatPrefixCode(code)) {
        index += 1;
        continue;
      } else if (this.compatParameterDigits === undefined && isDigitCode(code)) {
        this.compatParameterDigits = 1;
      } else if (this.compatParameterDigits !== undefined && isCompatParameterCode(code)) {
        if (code === 0x3a || code === 0x3b) {
          this.compatParameterDigits = 0;
        } else if (this.compatParameterDigits < 4) {
          this.compatParameterDigits += 1;
        } else {
          this.state = "text";
        }
      } else if (isCompatFinalCode(code)) {
        this.state = "text";
      } else {
        this.state = "text";
        continue;
      }
      index += 1;
    }
    return output.join("");
  }

  finish(): string {
    this.csi = undefined;
    this.state = "text";
    this.csiCompatPrefixOnly = false;
    this.compatParameterDigits = undefined;
    return "";
  }
}

/** Scan one CSI parser pass, retaining independently executed C0 controls. */
export function scanAnsiCsiAt(input: string, index: number): AnsiCsiScan | undefined {
  const firstCode = input.charCodeAt(index);
  if (firstCode !== 0x9b && (firstCode !== 0x1b || input.charCodeAt(index + 1) !== 0x5b)) {
    return undefined;
  }

  let cursor = index + (firstCode === 0x9b ? 1 : 2);
  const controls: string[] = [];
  let ended = false;
  while (cursor < input.length) {
    const code = input.charCodeAt(cursor);
    if (code === 0x18 || code === 0x1a) {
      cursor += 1;
      ended = true;
      break;
    }
    if (code === 0x1b || code === 0x9b) {
      ended = true;
      break;
    }
    if (code <= 0x1f || code === 0x7f) {
      controls.push(input.charAt(cursor));
      cursor += 1;
      continue;
    }
    if (code >= 0x20 && code <= 0x3f) {
      cursor += 1;
      continue;
    }
    if (code >= 0x40 && code <= 0x7e) {
      cursor += 1;
    }
    ended = true;
    break;
  }
  return { controls, ended, value: input.slice(index, cursor) };
}

export function* iterateAnsiSegments(input: string): Generator<AnsiSegment, void> {
  let position = 0;
  let index = 0;

  while (index < input.length) {
    const code = input.charCodeAt(index);
    if (code !== 0x1b && code !== 0x9b && code !== 0x9d) {
      index += 1;
      continue;
    }

    const osc = matchAnsiOscAt(input, index);
    const csi = osc ? undefined : scanAnsiCsiAt(input, index);
    const value = osc ?? csi?.value;
    if (!value) {
      index += 1;
      continue;
    }
    if (index > position) {
      yield { kind: "text", value: input.slice(position, index) };
    }
    yield { controls: csi?.controls ?? [], kind: "ansi", value };
    index += value.length;
    position = index;
  }
  if (position < input.length) {
    yield { kind: "text", value: input.slice(position) };
  }
}
