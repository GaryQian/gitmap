// Public memory host contracts shared by runtime, builtin search, and package consumers.
import { asNullableRecord } from "@openclaw/normalization-core/record-coerce";
export type MemorySource = "memory" | "sessions";

export type MemoryOriginClass = "owner" | "agent" | "untrusted" | "system";

export type MemorySessionKind = "interactive" | "cron" | "heartbeat" | "subagent" | "unknown";

/** Additional memory root, optionally narrowed by a root-relative glob. */
export type MemoryExtraPath =
  | string
  | {
      path: string;
      pattern?: string;
      /** Keep matching reference files out of mtime-based temporal decay. */
      evergreen?: boolean;
    };

export type MemoryEntryProvenance = {
  originClass: MemoryOriginClass;
  sessionKind: MemorySessionKind;
  observedAt: number;
  supersedesKey?: string;
};

export type MemorySearchResult = {
  path: string;
  startLine: number;
  endLine: number;
  score: number;
  vectorScore?: number;
  textScore?: number;
  snippet: string;
  source: MemorySource;
  importance?: number;
  triggers?: string;
  /** Semicolon-separated stable repository identities lifted from inline annotations. */
  projectKey?: string;
  /** @deprecated Use provenance.originClass. This field is not authoritative for automatic injection. */
  originClass?: string;
  citation?: string;
  provenance?: MemoryEntryProvenance;
};

export type MemoryCliSearchResult = {
  results: MemorySearchResult[];
  stale?: true;
  warning?: string;
  action?: string;
};

/** Indexed-memory search response shared by the Gateway and browser presentation. */
export type MemorySearchResponse = MemoryCliSearchResult & {
  agentId: string;
  provider: string;
  searchMode: "hybrid" | "fts-only";
};

export type MemoryCliSearchOutcome =
  | MemoryCliSearchResult
  | { agentId: string; status: "disabled" }
  | { agentId: string; status: "failed"; error: string };

/** Automatic prompt injection is reserved for content with authoritative trusted provenance. */
export function isMemoryOriginEligibleForAutomaticInjection(
  originClass: unknown,
): originClass is "owner" | "agent" {
  return originClass === "owner" || originClass === "agent";
}

export function isAutomaticMemoryEntryEligible(
  entry: Pick<MemorySearchResult, "provenance">,
): boolean {
  return isMemoryOriginEligibleForAutomaticInjection(entry.provenance?.originClass);
}

export type MemoryEmbeddingProbeResult = {
  ok: boolean;
  error?: string;
  checked?: boolean;
  cached?: boolean;
  checkedAtMs?: number;
  cacheExpiresAtMs?: number;
};

export type MemorySyncProgressUpdate = {
  completed: number;
  total: number;
  label?: string;
};

export type MemorySessionSyncTarget = {
  /** Owning OpenClaw agent. Omit only when the active manager scope already supplies it. */
  agentId?: string;
  /** Storage-neutral transcript/session identity. */
  sessionId: string;
  /** Optional visible session-store key for callers that already carry it. */
  sessionKey?: string;
};

export type MemorySyncParams = {
  reason?: string;
  force?: boolean;
  /** Storage-neutral session transcript targets to refresh. */
  sessions?: MemorySessionSyncTarget[];
  /** Archive/support transcript files to refresh without treating paths as active session identity. */
  archiveFiles?: string[];
  progress?: (update: MemorySyncProgressUpdate) => void;
};

export type MemorySearchRuntimeDebug = {
  backend: "builtin";
  configuredMode?: string;
  effectiveMode?: string;
  fallback?: string;
  embeddingBootstrap?: {
    ok: false;
    provider: string;
    reason: string;
    degradedTo: "keyword-only";
  };
};

type MemoryReadSuccessResult = {
  status: "ok";
  text: string;
  path: string;
  truncated?: boolean;
  from?: number;
  lines?: number;
  nextFrom?: number;
};

/** An allowed memory path that does not exist. */
type MemoryReadNotFoundResult = {
  status: "not_found";
  text: "";
  path: string;
  truncated?: never;
  from?: never;
  lines?: never;
  nextFrom?: never;
};

export type MemoryReadResult = MemoryReadSuccessResult | MemoryReadNotFoundResult;

/** Pre-status result accepted only from registered memory managers during migration. */
export type LegacyMemoryReadResult = Omit<MemoryReadSuccessResult, "status"> & {
  status?: never;
};

export type MemoryVectorIndexState =
  | { state: "empty" }
  | { state: "complete" }
  | { state: "incomplete" }
  | { state: "unverified" };

export type MemoryProviderStatus = {
  backend: "builtin";
  provider: string;
  model?: string;
  requestedProvider?: string;
  files?: number;
  chunks?: number;
  dirty?: boolean;
  /** Process-local failure from the newest admitted sync without a newer successful sync. */
  lastSyncError?: string;
  workspaceDir?: string;
  dbPath?: string;
  /** Explicit diagnostics for the whole shared agent database; payload sizes are not additive. */
  storage?: {
    databaseBytes: number;
    walBytes: number;
    reusableBytes: number;
    embeddingCacheBytes: number;
    embeddingCacheEntries: number;
  };
  extraPaths?: MemoryExtraPath[];
  sources?: MemorySource[];
  sourceCounts?: Array<{
    source: MemorySource;
    files: number;
    chunks: number;
    /** Stored chunk text and JSON embedding bytes, excluding cache and index overhead. */
    chunkBytes?: number;
    eligible?: number | null;
    issues?: string[];
  }>;
  cache?: { enabled: boolean; entries?: number; maxEntries?: number };
  fts?: { enabled: boolean; available: boolean; error?: string };
  fallback?: { from: string; reason?: string };
  vector?: {
    enabled: boolean;
    index?: MemoryVectorIndexState;
    storeAvailable?: boolean;
    semanticAvailable?: boolean;
    available?: boolean;
    extensionPath?: string;
    loadError?: string;
    dims?: number;
  };
  batch?: {
    enabled: boolean;
    failures: number;
    limit: number;
    wait: boolean;
    concurrency: number;
    pollIntervalMs: number;
    timeoutMs: number;
    lastError?: string;
    lastProvider?: string;
  };
  custom?: Record<string, unknown>;
};

export type MemoryIndexIdentityState =
  | { status: "valid" }
  | {
      status: "missing";
      reason: string;
      code: "metadata_missing";
      owner: "openclaw";
    }
  | ({ status: "mismatched"; reason: string } & (
      | {
          code: "provenance_version" | "chunking_version" | "embedding_input_format";
          owner: "openclaw";
          // Older-chunking corpus marker: set only when every configuration-owned
          // constraint (sources, scope hash, chunk settings, FTS tokenizer) still
          // matches, so a pending OpenClaw chunking upgrade cannot mask a narrowed
          // scope. It excludes embedding identity — provider, model, provider
          // settings, and vector dims may differ — and does not establish keyword
          // retrieval availability; consumers must still check usable FTS before
          // treating the index as servable.
          chunkingVersionOnly?: boolean;
          /** Older embedding format with the same corpus; requires usable FTS for retrieval. */
          lexicalCompatible?: boolean;
        }
      | {
          code:
            | "model"
            | "provider"
            | "provider_settings"
            | "sources"
            | "scope"
            | "chunking"
            | "vector_dims"
            | "fts_tokenizer";
          owner: "configuration";
        }
    ));

export type MemoryIndexIdentityDiagnostic = Exclude<MemoryIndexIdentityState, { status: "valid" }>;

export function resolveMemoryIndexIdentityReason(
  status: Pick<MemoryProviderStatus, "custom">,
): string | undefined {
  const identity = asNullableRecord(status.custom?.indexIdentity);
  if (identity?.status !== "mismatched" && identity?.status !== "missing") {
    return undefined;
  }
  const reason = typeof identity.reason === "string" ? identity.reason.trim() : "";
  return reason || "memory index identity is missing or mismatched";
}

export function resolveMemoryIndexIdentityDiagnostic(
  status: Pick<MemoryProviderStatus, "custom">,
): MemoryIndexIdentityDiagnostic | undefined {
  const identity = asNullableRecord(status.custom?.indexIdentity);
  const reason = typeof identity?.reason === "string" ? identity.reason.trim() : "";
  if (!identity || !reason) {
    return undefined;
  }
  if (
    identity.status === "missing" &&
    identity.code === "metadata_missing" &&
    identity.owner === "openclaw"
  ) {
    return { status: "missing", reason, code: "metadata_missing", owner: "openclaw" };
  }
  if (identity.status !== "mismatched") {
    return undefined;
  }
  if (
    identity.owner === "openclaw" &&
    (identity.code === "provenance_version" ||
      identity.code === "chunking_version" ||
      identity.code === "embedding_input_format")
  ) {
    return {
      status: "mismatched",
      reason,
      code: identity.code,
      owner: "openclaw",
      ...(identity.code === "chunking_version" &&
      identity.chunkingVersionOnly === true &&
      identity.versionOrder !== "newer"
        ? { chunkingVersionOnly: true }
        : {}),
      ...(identity.code === "embedding_input_format" &&
      identity.lexicalCompatible === true &&
      identity.versionOrder !== "newer"
        ? { lexicalCompatible: true }
        : {}),
    };
  }
  if (
    identity.owner === "configuration" &&
    (identity.code === "model" ||
      identity.code === "provider" ||
      identity.code === "provider_settings" ||
      identity.code === "sources" ||
      identity.code === "scope" ||
      identity.code === "chunking" ||
      identity.code === "vector_dims" ||
      identity.code === "fts_tokenizer")
  ) {
    return { status: "mismatched", reason, code: identity.code, owner: "configuration" };
  }
  return undefined;
}

export function formatMemoryIndexRebuildGuidance(
  status: Partial<Pick<MemoryProviderStatus, "provider" | "requestedProvider">>,
  agentId?: string,
): string {
  const command = `openclaw memory status --index${agentId?.trim() ? ` --agent ${agentId.trim()}` : ""}`;
  const configuredProvider = status.requestedProvider?.trim() || status.provider?.trim();
  const disclosure =
    configuredProvider === "none"
      ? "Rebuilding uses keyword indexing only and does not call an embedding provider."
      : "Rebuilding may call the configured embedding provider and can incur provider cost.";
  return `${command}. ${disclosure}`;
}

export function resolveMemoryIndexSearchDiagnostic(
  diagnostic: MemoryIndexIdentityDiagnostic,
  status: Partial<
    Pick<MemoryProviderStatus, "provider" | "requestedProvider" | "lastSyncError" | "custom">
  >,
  agentId?: string,
) {
  const repairFailure = diagnostic.owner === "openclaw" && status.lastSyncError?.trim();
  const newerIndex =
    diagnostic.owner === "openclaw" &&
    diagnostic.status === "mismatched" &&
    asNullableRecord(status.custom?.indexIdentity)?.versionOrder === "newer";
  if (repairFailure && !newerIndex) {
    const guidance = {
      warning: `Memory index repair failed: ${repairFailure}. The existing index was left unchanged.`,
      action: `Run: openclaw memory status --deep${agentId?.trim() ? ` --agent ${agentId.trim()}` : ""}. Resolve the reported sync failure before retrying the search.`,
    };
    return {
      error: repairFailure,
      ...guidance,
      staleness: { stale: true as const, ...guidance },
    };
  }
  const cause =
    diagnostic.owner === "configuration"
      ? `the current memory configuration no longer matches the index (${diagnostic.reason})`
      : diagnostic.code === "metadata_missing"
        ? `the memory index metadata is missing (${diagnostic.reason}); no configuration change is needed`
        : newerIndex
          ? diagnostic.reason
          : `this OpenClaw version changed the memory index format (${diagnostic.reason}); no configuration change is needed`;
  const guidance = formatMemoryIndexRebuildGuidance(status, agentId);
  const priorFailure = repairFailure ? ` Previous memory sync failed: ${repairFailure}.` : "";
  return {
    error: diagnostic.reason,
    warning: `Tell the user: memory search is paused because ${cause}.${priorFailure}`,
    action: newerIndex
      ? `Tell the user to upgrade OpenClaw or reindex explicitly: ${guidance}`
      : `Tell the user to run: ${guidance}`,
    staleness: {
      stale: true as const,
      warning: `Memory index is stale: ${diagnostic.reason} (owner: ${diagnostic.owner}, code: ${diagnostic.code}). Search results may be incomplete.${priorFailure}`,
      action: newerIndex
        ? `Upgrade OpenClaw or reindex explicitly: ${guidance}`
        : `Run: ${guidance}`,
    },
  };
}

export function resolveMemorySearchStaleness(
  status: Pick<MemoryProviderStatus, "custom" | "lastSyncError"> &
    Partial<Pick<MemoryProviderStatus, "provider" | "requestedProvider" | "dirty">>,
  agentId?: string,
): { stale: true; warning: string; action: string } | null {
  const diagnostic = resolveMemoryIndexIdentityDiagnostic(status);
  if (diagnostic) {
    return resolveMemoryIndexSearchDiagnostic(diagnostic, status, agentId).staleness;
  }
  const reason = status.lastSyncError?.trim();
  if (!reason) {
    return status.dirty
      ? {
          stale: true,
          warning: "Memory index has pending updates. Results use the last published index.",
          action: `Retry after background indexing, or run: ${formatMemoryIndexRebuildGuidance(status, agentId)}`,
        }
      : null;
  }
  return {
    stale: true,
    warning: `Memory index is stale: ${reason}. Search results may be incomplete.`,
    action: `Run: ${formatMemoryIndexRebuildGuidance(status, agentId)}`,
  };
}

/** Preserve synchronous third-party managers while built-in status reads run in their worker. */
export async function readMemorySearchManagerStatus<Status>(
  manager: {
    status(): Status;
    statusAsync?(options?: { includeCounts?: boolean }): Promise<Status>;
  },
  options?: { includeCounts?: boolean },
): Promise<Status> {
  return manager.statusAsync ? manager.statusAsync(options) : manager.status();
}
