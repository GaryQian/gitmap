import type { TSchema } from "typebox";
import type {
  ModelDataCostRates,
  ModelDataMediaInputConfig,
  ModelDataRawPricingTier,
  ModelDataThinkingFormat,
  ModelDataThinkingLevel,
  ModelDataThinkingLevelMap,
  ModelRoutingMaxPrice,
  ModelRoutingPercentiles,
  ModelRoutingSortConfig,
} from "./model-data.js";
import type { AssistantMessageDiagnostic } from "./utils/diagnostics.js";
export type { AssistantMessageDiagnostic, DiagnosticErrorInfo } from "./utils/diagnostics.js";

/** Provider API families with first-class request/stream adapters in OpenClaw. */
export type KnownApi =
  | "openai-completions"
  | "mistral-conversations"
  | "openai-responses"
  | "azure-openai-responses"
  | "openai-chatgpt-responses"
  | "anthropic-messages"
  | "bedrock-converse-stream"
  | "google-generative-ai"
  | "google-interactions"
  | "google-vertex";

/** Provider API id; custom providers can use ids outside the built-in set. */
export type Api = KnownApi | (string & {});

/** Image-generation API families with first-class adapters in OpenClaw. */
export type KnownImagesApi = "openrouter-images";

/** Image API id; custom image providers can use ids outside the built-in set. */
export type ImagesApi = KnownImagesApi | (string & {});

/** Provider id used for routing, diagnostics, and config lookups. */
export type Provider = string;

/** Image provider ids with first-class adapters in OpenClaw. */
export type KnownImagesProvider = "openrouter";

/** Image provider id used for routing, diagnostics, and config lookups. */
export type ImagesProvider = string;

/** Normalized reasoning-effort levels shared across provider-specific knobs. */
export type ThinkingLevel = Exclude<ModelDataThinkingLevel, "off">;
/** Model thinking setting including explicit disabled state. */
export type ModelThinkingLevel = ModelDataThinkingLevel;
/** Provider-specific values for normalized thinking levels. */
export type ThinkingLevelMap = ModelDataThinkingLevelMap;

/** Token budgets for each thinking level (token-based providers only) */
export interface ThinkingBudgets {
  minimal?: number;
  low?: number;
  medium?: number;
  high?: number;
  max?: number;
}

/** Prompt-cache retention preference shared by providers that expose cache controls. */
export type CacheRetention = "none" | "short" | "long";

/** Streaming transport preference for providers that support multiple transports. */
export type Transport = "sse" | "websocket" | "websocket-cached" | "auto";

export type MaybePromise<T> = T | Promise<T>;

export interface ProviderResponse {
  status: number;
  headers: Record<string, string>;
}

/** Runtime header overrides; null preserves an SDK's default-header deletion sentinel. */
export type ModelRequestHeaders = Record<string, string | null>;

export interface StreamOptions {
  temperature?: number;
  maxTokens?: number;
  /**
   * Optional JSON Schema for the generated response. Providers that support
   * constrained decoding map it to their native request shape; others ignore it.
   */
  responseFormat?: Record<string, unknown>;
  /**
   * Stop sequences forwarded to providers that support them. Providers map this
   * to their native request field, such as OpenAI `stop` or Anthropic
   * `stop_sequences`.
   */
  stop?: string[];
  signal?: AbortSignal;
  apiKey?: string;
  /**
   * Preferred transport for providers that support multiple transports.
   * Providers that do not support this option ignore it.
   */
  transport?: Transport;
  /**
   * Prompt cache retention preference. Providers map this to their supported values.
   * Default: "short".
   */
  cacheRetention?: CacheRetention;
  /** Request-level cache lifetime for GPT-5.6+ Responses APIs; unset preserves provider defaults. */
  promptCacheTtl?: "30m" | "12h";
  /**
   * Optional session identifier for providers that support session-based caching.
   * Providers can use this to enable prompt caching, request routing, or other
   * session-aware features. Ignored by providers that don't support it.
   */
  sessionId?: string;
  /**
   * Opaque per-model-call identifier for provider transport correlation.
   * Providers that do not expose request correlation ignore it.
   */
  requestId?: string;
  /**
   * Optional provider prompt-cache affinity key, distinct from transcript/session identity.
   * Providers that do not support separate cache affinity ignore it.
   */
  promptCacheKey?: string;
  /**
   * Optional callback for inspecting or replacing provider payloads before sending.
   * Return undefined to keep the payload unchanged.
   */
  onPayload?: (payload: unknown, model: Model) => MaybePromise<unknown>;
  /**
   * Optional callback invoked after an HTTP response is received and before
   * its body stream is consumed.
   */
  onResponse?: (response: ProviderResponse, model: Model) => void | Promise<void>;
  /** Local-provider wait observation. Slot waits require request-correlated backend evidence. */
  onProviderWait?: (reason: "response" | "slot" | null) => void;
  /**
   * Observe a live response that accepts user input before generation finishes.
   * `steer` resolves false only when the input was definitely not admitted;
   * admitted input cannot be withdrawn. Providers settle pending submissions
   * before closing the response and call the returned cleanup on closure.
   */
  onActiveResponse?: (control: {
    steer(messages: readonly UserMessage[]): Promise<boolean>;
    /** Read-only after closure: deferred input still needs an explicit continuation request. */
    needsContinuation?: () => boolean;
  }) => (() => void) | void;
  /**
   * The caller can execute completed async calls before generation finishes.
   * Providers advertise async tools only with this host capability; this is
   * independent of parallel execution of an ordinary completed tool batch.
   */
  asyncToolExecution?: boolean;
  /**
   * Optional custom HTTP headers to include in API requests.
   * Merged with provider defaults; can override default headers.
   * Not supported by all providers (e.g., AWS Bedrock uses SDK auth).
   */
  headers?: ModelRequestHeaders;
  /**
   * HTTP request timeout in milliseconds for providers/SDKs that support it.
   * For example, OpenAI and Anthropic SDK clients default to 10 minutes.
   */
  timeoutMs?: number;
  /** @deprecated Ignored by built-in text transports; retries are owned by the host runner. */
  maxRetries?: number;
  /**
   * Maximum delay in milliseconds to wait for a retry when the server requests a long wait.
   * If the server's requested delay exceeds this value, the request fails immediately
   * with an error containing the requested delay, allowing higher-level retry logic
   * to handle it with user visibility.
   * Default: 60000 (60 seconds). Set to 0 to disable the cap.
   */
  maxRetryDelayMs?: number;
  /**
   * Optional metadata to include in API requests.
   * Providers extract the fields they understand and ignore the rest.
   * For example, Anthropic uses `user_id` for abuse tracking and rate limiting.
   */
  metadata?: Record<string, unknown>;
}

export type ProviderStreamOptions = StreamOptions & Record<string, unknown>;

export interface ImagesOptions {
  signal?: AbortSignal;
  apiKey?: string;
  /**
   * Optional callback for inspecting or replacing provider payloads before sending.
   * Return undefined to keep the payload unchanged.
   */
  onPayload?: (payload: unknown, model: ImagesModel) => MaybePromise<unknown>;
  onResponse?: (response: ProviderResponse, model: ImagesModel) => void | Promise<void>;
  /**
   * Optional custom HTTP headers to include in API requests.
   * Merged with provider defaults; can override default headers.
   */
  headers?: Record<string, string>;
  /**
   * HTTP request timeout in milliseconds for providers/SDKs that support it.
   */
  timeoutMs?: number;
  /**
   * Maximum retry attempts for providers/SDKs that support client-side retries.
   */
  maxRetries?: number;
  /**
   * Maximum delay in milliseconds to wait for a retry when the server requests a long wait.
   * If the server's requested delay exceeds this value, the request fails immediately
   * with an error containing the requested delay, allowing higher-level retry logic
   * to handle it with user visibility.
   * Default: 60000 (60 seconds). Set to 0 to disable the cap.
   */
  maxRetryDelayMs?: number;
  /**
   * Optional metadata to include in API requests.
   * Providers extract the fields they understand and ignore the rest.
   */
  metadata?: Record<string, unknown>;
}

export type ProviderImagesOptions = ImagesOptions & Record<string, unknown>;

/** Unified text options used by simple completion helpers. */
export interface SimpleStreamOptions extends StreamOptions {
  /** Optional processing tier; only providers supporting these tiers apply it. */
  serviceTier?: "default" | "priority";
  reasoning?: ModelThinkingLevel;
  /** Custom token budgets for thinking levels (token-based providers only) */
  thinkingBudgets?: ThinkingBudgets;
}

// Contract:
// - Must return an AssistantMessageEventStream.
// - Once invoked, request/model/runtime failures should be encoded in the
//   returned stream, not thrown.
// - Error termination must produce an AssistantMessage with stopReason
//   "error" or "aborted" and errorMessage, emitted via the stream protocol.
export type StreamFunction<
  TApi extends Api = Api,
  TOptions extends StreamOptions = StreamOptions,
> = (
  model: Model<TApi>,
  context: Context,
  options?: TOptions,
) => AssistantMessageEventStreamContract;

export type ImagesFunction<
  TApi extends ImagesApi = ImagesApi,
  TOptions extends ImagesOptions = ImagesOptions,
> = (
  model: ImagesModel<TApi>,
  context: ImagesContext,
  options?: TOptions,
) => Promise<AssistantImages>;

export interface TextSignatureV1 {
  v: 1;
  id: string;
  phase?: "commentary" | "final_answer";
}

export interface TextContent {
  type: "text";
  text: string;
  textSignature?: string; // e.g., for OpenAI responses, message metadata (legacy id string or TextSignatureV1 JSON)
}

export interface ThinkingContent {
  type: "thinking";
  thinking: string;
  thinkingSignature?: string; // e.g., for OpenAI responses, the reasoning item ID
  /** When true, the thinking content was redacted by safety filters. The opaque
   *  encrypted payload is stored in `thinkingSignature` so it can be passed back
   *  to the API for multi-turn continuity. */
  redacted?: boolean;
}

/** Opaque provider-owned state that must survive transcript replay without being rendered. */
export interface ProviderReplayState {
  v: 1;
  type: string;
  id?: string;
  data: string;
  replayIndex?: number;
  provider: Provider;
  api: Api;
  model: string;
  baseUrlHash?: string;
  sessionHash?: string;
  authProfileHash?: string;
}

/** Base64 image content block with MIME type metadata. */
export interface ImageContent {
  type: "image";
  data: string; // base64 encoded image data
  mimeType: string; // e.g., "image/jpeg", "image/png"
}

/** Normalized assistant tool call emitted by providers or repaired from text. */
export interface ToolCall {
  /** The provider completed this call and permits generation to continue without its result. */
  async?: true;
  type: "toolCall";
  id: string;
  name: string;
  arguments: Record<string, unknown>;
  /**
   * Producer-only cumulative argument JSON while the call streams. Producers remove it before
   * `toolcall_end` or terminal cleanup; it never appears in final messages or transcripts.
   */
  partialJson?: string;
  /** Provider argument bytes paired with their normalized value for exact replay. */
  argumentsSignature?: { value: string; raw: string };
  thoughtSignature?: string; // Google-specific: opaque signature for reusing thought context
  executionMode?: "sequential" | "parallel";
}

export interface Usage {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
  /** Whether the provider reported a cache-read/write token split. */
  cacheTelemetry?: { state: "available" | "unavailable" };
  /** Subset of `cacheWrite` written with 1-hour retention when reported. */
  cacheWrite1h?: number;
  /** Subset of `cacheWrite` written with 5-minute retention when reported. */
  cacheWrite5m?: number;
  /**
   * Whether usage is complete for this provider response. Missing terminal usage
   * and provisional stream counters are unavailable, including after interruption.
   * Omitted on older transcripts and adapters that do not report completeness.
   */
  usageReport?: { state: "available" | "unavailable" };
  /** Exact context snapshot for the final provider iteration. */
  contextUsage?:
    | { state: "available"; promptTokens: number; totalTokens: number }
    | { state: "unavailable" };
  totalTokens: number;
  cost: {
    input: number;
    output: number;
    cacheRead: number;
    cacheWrite: number;
    total: number;
    /** Provenance for the recorded total cost; provider-billed totals are authoritative. */
    totalOrigin?: "provider-billed";
  };
}

/** Per-million-token rates for separately billed token buckets. */
export type ModelCostRates = ModelDataCostRates;

/** One whole-request tier on the cache-inclusive prompt-token axis. */
export type PricingTier = ModelCostRates & {
  /** Half-open prompt-token interval `[start, end)`. */
  range: [number, number];
};

export type RawPricingTier = ModelDataRawPricingTier;

/** Normalized pricing used by token accounting and usage summaries. */
export type ModelCostConfig = ModelCostRates & { tieredPricing?: PricingTier[] };
export type RawModelCostConfig = ModelCostRates & { tieredPricing?: RawPricingTier[] };

export type StopReason = "stop" | "length" | "toolUse" | "error" | "aborted";

/** Stable error codes for provider outcomes that cannot be replayed safely. */
export const PROVIDER_POST_DISPATCH_AMBIGUITY_ERROR_CODE = "PROVIDER_POST_DISPATCH_AMBIGUITY";
export const PROVIDER_FAILURE_WITH_OUTPUT_ERROR_CODE = "PROVIDER_FAILURE_WITH_OUTPUT";
/** The stream owner removed repetitive content before persistence and replay. */
export const REPETITIVE_OUTPUT_ERROR_CODE = "openclaw_repetitive_output";
/** Pre-dispatch argument rejection; callers still enforce output and effect guards. */
export const MALFORMED_TOOL_CALL_ARGUMENTS_ERROR_CODE = "malformed_tool_call_arguments";

export const DEFAULT_MISSING_TOOL_RESULT_TEXT =
  "Tool call interrupted before a result was recorded; its outcome is unknown. Retry only if the operation is read-only or safe to repeat. If it may have had side effects, verify the current state first instead of repeating it.";

export interface UserMessage {
  role: "user";
  /** Host-generated context projected as a user message, not a human-authored turn. */
  synthetic?: true;
  content: string | (TextContent | ImageContent)[];
  timestamp: number; // Unix timestamp in milliseconds
  /** Trusted runtime-context metadata; ordinary user messages omit it. */
  runtimeContext?: {
    /** Prefix-bound providers retain these messages across turns. */
    retained?: boolean;
  };
  /**
   * @deprecated Shipped through v2026.9.7. Use `runtimeContext`; remove after
   * the minimum supported plugin API no longer includes that release.
   */
  runtimeContextCarrier?: boolean;
  /**
   * @deprecated Shipped through v2026.9.7. Use `runtimeContext.retained`;
   * remove with `runtimeContextCarrier`.
   */
  runtimeContextCarrierRetained?: boolean;
  /** Operator-authored text projected to system authority on capable routes. */
  operatorMessage?: { turnScoped: boolean };
}

export const RUNTIME_CONTEXT_CUSTOM_TYPE = "openclaw.runtime-context";
export const RUNTIME_CONTEXT_BEGIN_MARKER = "<<<BEGIN_OPENCLAW_INTERNAL_CONTEXT>>>";
export const RUNTIME_CONTEXT_END_MARKER = "<<<END_OPENCLAW_INTERNAL_CONTEXT>>>";
export const RUNTIME_CONTEXT_HEADER = "OpenClaw runtime context:";
export const RUNTIME_CONTEXT_FOOTER = "End OpenClaw runtime context.";
const ESCAPED_RUNTIME_CONTEXT_FOOTER = "[[RUNTIME_CONTEXT_FOOTER_ESCAPED]]";

/** Identifies the exact delimiter envelope emitted by shipped transcript carriers. */
export function hasLegacyRuntimeContextEnvelope(content: string): boolean {
  return (
    content.startsWith(`${RUNTIME_CONTEXT_BEGIN_MARKER}\n`) &&
    content.endsWith(`\n${RUNTIME_CONTEXT_END_MARKER}`)
  );
}

/** Prevent untrusted carrier content from terminating its provider projection. */
export function escapeRuntimeContextFooter(content: string): string {
  return content.replaceAll(RUNTIME_CONTEXT_FOOTER, ESCAPED_RUNTIME_CONTEXT_FOOTER);
}

/** Builds the human-readable projection used only at provider boundaries. */
export function labelRuntimeContextText(content: string): string {
  return `${RUNTIME_CONTEXT_HEADER}\n${escapeRuntimeContextFooter(content)}\n${RUNTIME_CONTEXT_FOOTER}`;
}

/** Labels runtime context once while preserving structured text blocks. */
export function labelRuntimeContextContent(
  content: string | TextContent[],
): string | TextContent[] {
  if (typeof content === "string") {
    return labelRuntimeContextText(content);
  }
  if (content.length === 0) {
    return [{ type: "text", text: `${RUNTIME_CONTEXT_HEADER}\n${RUNTIME_CONTEXT_FOOTER}` }];
  }
  return content.map((block, index) => ({
    ...block,
    text: [
      ...(index === 0 ? [RUNTIME_CONTEXT_HEADER] : []),
      escapeRuntimeContextFooter(block.text),
      ...(index === content.length - 1 ? [RUNTIME_CONTEXT_FOOTER] : []),
    ].join("\n"),
  }));
}

/** Flattens already-labeled runtime context for string-only provider messages. */
export function runtimeContextContentToText(content: string | TextContent[]): string {
  return typeof content === "string" ? content : content.map((block) => block.text).join("\n");
}

/** Trusted per-turn OpenClaw context, projected by each provider at its valid authority level. */
export type RuntimeContextMessage = Omit<UserMessage, "content"> & {
  content: string | TextContent[];
} & (
    | { runtimeContext: NonNullable<UserMessage["runtimeContext"]> }
    | { runtimeContextCarrier: true }
  );

/** Identifies trusted runtime context independently of its provider-compatible shape. */
export function hasRuntimeContextMarker(message: {
  role: string;
  runtimeContext?: unknown;
  runtimeContextCarrier?: unknown;
}): boolean {
  return (
    message.role === "user" &&
    (message.runtimeContext !== undefined || message.runtimeContextCarrier === true)
  );
}

/** Distinguishes trusted runtime context while preserving user-role plugin compatibility. */
export function isRuntimeContextMessage(message: {
  role: string;
  content?: unknown;
  runtimeContext?: unknown;
  runtimeContextCarrier?: unknown;
}): message is RuntimeContextMessage {
  const textOnlyContent =
    typeof message.content === "string" ||
    (Array.isArray(message.content) &&
      message.content.every(
        (part) =>
          typeof part === "object" &&
          part !== null &&
          "type" in part &&
          part.type === "text" &&
          "text" in part &&
          typeof part.text === "string",
      ));
  return textOnlyContent && hasRuntimeContextMarker(message);
}

/** Reads canonical metadata while accepting the shipped v2026.9.7 carrier fields. */
export function readRuntimeContextMetadata(
  message: RuntimeContextMessage,
): NonNullable<UserMessage["runtimeContext"]> {
  if (message.runtimeContext !== undefined) {
    return message.runtimeContext;
  }
  return message.runtimeContextCarrierRetained === undefined
    ? {}
    : { retained: message.runtimeContextCarrierRetained };
}

/** Updates canonical retention and its shipped compatibility projection together. */
export function setRuntimeContextRetention(
  message: RuntimeContextMessage,
  retained: boolean | undefined,
): void {
  message.runtimeContext = { ...readRuntimeContextMetadata(message), retained };
  message.runtimeContextCarrier = true;
  message.runtimeContextCarrierRetained = retained;
}

export type AssistantDeliveryTtsFacts = {
  tagged: true;
  text?: string;
  directives?: Array<{
    provider?: string;
    values: Record<string, string>;
  }>;
};

export interface AssistantMessage {
  role: "assistant";
  content: (TextContent | ThinkingContent | ToolCall)[];
  openclawDelivery?: {
    audioAsVoice?: true;
    /** Exact media directives consumed by the managed-media transcript rewrite owner. */
    mediaUrls?: string[];
    replyToCurrent?: true;
    replyToId?: string;
    /** Consumed transport input; implicit reply policy still applies. */
    sourceMessageId?: string;
    /** @deprecated Ignored; omit this field. Retained until the next Plugin SDK major. */
    textPhaseRequiresTerminal?: true;
    /** Parsed once at the assistant write boundary; delivery resolves policy from these facts. */
    tts?: AssistantDeliveryTtsFacts;
  };
  api: Api;
  provider: Provider;
  model: string;
  responseModel?: string; // Concrete `chunk.model` when different from the requested `model` (e.g. OpenRouter `auto` -> `anthropic/...`)
  /** Provider-reported access only; absent/null never confirms a requested program. */
  responseAccessProgram?: "standard" | "daybreak_blue" | "daybreak_red" | null;
  responseId?: string; // Provider-specific response/message identifier when the upstream API exposes one
  providerReplay?: ProviderReplayState; // Opaque provider state carried into a compatible later request.
  turnId?: string; // Runtime-assigned stable turn identity when the provider does not expose one
  diagnostics?: AssistantMessageDiagnostic[]; // Redacted provider/runtime completion, failure, and recovery diagnostics.
  usage: Usage;
  stopReason: StopReason;
  /** A completed provider response can explicitly request another inference with false. */
  endTurn?: boolean;
  errorMessage?: string;
  errorCode?: string;
  /** Transport-owned repair outcome; execution owns whether a deferred request can replay. */
  itemConflictRecovery?: "deferred" | "recovered" | "failed";
  errorType?: string;
  errorBody?: string;
  /** Provider retry floor before diagnostic clipping; null means too large to represent. */
  retryAfterMs?: number | null;
  timestamp: number; // Unix timestamp in milliseconds
}

export interface ToolResultMessage<TDetails = unknown> {
  role: "toolResult";
  toolCallId: string;
  toolName: string;
  content: (TextContent | ImageContent)[];
  details?: TDetails;
  isError: boolean;
  timestamp: number; // Unix timestamp in milliseconds
}

export type Message = UserMessage | AssistantMessage | ToolResultMessage;

export type ImagesInputContent = TextContent | ImageContent;
export type ImagesOutputContent = TextContent | ImageContent;

export interface ImagesContext {
  input: ImagesInputContent[];
}

export type ImagesStopReason = "stop" | "error" | "aborted";

export interface AssistantImages {
  api: ImagesApi;
  provider: ImagesProvider;
  model: string;
  output: ImagesOutputContent[];
  responseId?: string;
  usage?: Usage;
  stopReason: ImagesStopReason;
  errorMessage?: string;
  timestamp: number; // Unix timestamp in milliseconds
}

export interface Tool<TParameters extends TSchema = TSchema> {
  name: string;
  description: string;
  parameters: TParameters;
  /**
   * `false` keeps calls synchronous where the provider can keep generating after a call
   * (OpenAI async tools): the response pauses until earlier results are delivered.
   */
  async?: false;
}

/** Derived prompt bytes belong to this exact immutable text revision. */
export interface PreparedSystemPrompt {
  readonly text: string;
  readonly stripped: string;
  readonly instructions: string;
}

export interface Context {
  systemPrompt?: string;
  preparedSystemPrompt?: PreparedSystemPrompt;
  messages: Message[];
  tools?: Tool[];
}

/**
 * Event protocol for AssistantMessageEventStream.
 *
 * Streams should emit `start` before partial updates, then terminate with either:
 * - `done` carrying the final successful AssistantMessage, or
 * - `error` carrying the final AssistantMessage with stopReason "error" or "aborted"
 *   and errorMessage.
 */
export type AssistantMessageEvent =
  | { type: "start"; partial: AssistantMessage }
  | { type: "text_start"; contentIndex: number; partial: AssistantMessage }
  /**
   * Plain text deltas may omit `partial` to avoid retaining one full assistant
   * snapshot per token. Consumers that need current text should replay `delta`
   * from the latest start/end partial checkpoint.
   */
  | { type: "text_delta"; contentIndex: number; delta: string; partial?: AssistantMessage }
  | { type: "text_end"; contentIndex: number; content: string; partial: AssistantMessage }
  | { type: "thinking_start"; contentIndex: number; partial: AssistantMessage }
  | { type: "thinking_delta"; contentIndex: number; delta: string; partial: AssistantMessage }
  | { type: "thinking_end"; contentIndex: number; content: string; partial: AssistantMessage }
  | { type: "toolcall_start"; contentIndex: number; partial: AssistantMessage }
  | { type: "toolcall_delta"; contentIndex: number; delta: string; partial: AssistantMessage }
  | { type: "toolcall_end"; contentIndex: number; toolCall: ToolCall; partial: AssistantMessage }
  | {
      type: "done";
      reason: Extract<StopReason, "stop" | "length" | "toolUse">;
      message: AssistantMessage;
    }
  | { type: "error"; reason: Extract<StopReason, "aborted" | "error">; error: AssistantMessage };

export interface AssistantMessageEventStreamContract extends AsyncIterable<AssistantMessageEvent> {
  push(event: AssistantMessageEvent): void;
  /** Complete the stream and optionally resolve the final message. */
  end(result?: AssistantMessage): void;
  /** Final assistant message produced independently of event iteration. */
  result(): Promise<AssistantMessage>;
}

/** Read-only stream contract accepted by consumers that do not need to push events. */
export interface AssistantMessageEventStreamLike extends AsyncIterable<AssistantMessageEvent> {
  result(): Promise<AssistantMessage>;
}

/**
 * Compatibility settings for OpenAI-compatible completions APIs.
 * Use this to override URL-based auto-detection for custom providers.
 */
export interface OpenAICompletionsCompat {
  /** Whether the provider supports the `store` field. Default: auto-detected from URL. */
  supportsStore?: boolean;
  /** Whether the provider supports the `developer` role (vs `system`). Default: auto-detected from URL. */
  supportsDeveloperRole?: boolean;
  /** Whether the provider supports `reasoning_effort`. Default: auto-detected from URL. */
  supportsReasoningEffort?: boolean;
  /** Provider-native reasoning efforts accepted by the model. Overrides known model defaults. */
  supportedReasoningEfforts?: string[];
  /** Per-level reasoning effort overrides, e.g. map "off" to "low" for models that cannot disable thinking. */
  reasoningEffortMap?: Record<string, string>;
  /** Whether the provider supports `stream_options: { include_usage: true }` for token usage in streaming responses. Default: true. */
  supportsUsageInStreaming?: boolean;
  /** Which field to use for max tokens. Default: auto-detected from URL. */
  maxTokensField?: "max_completion_tokens" | "max_tokens";
  /** Whether tool results require the `name` field. Default: auto-detected from URL. */
  requiresToolResultName?: boolean;
  /** Whether a user message after tool results requires an assistant message in between. Default: auto-detected from URL. */
  requiresAssistantAfterToolResult?: boolean;
  /** Whether thinking blocks must be converted to text blocks with <thinking> delimiters. Default: auto-detected from URL. */
  requiresThinkingAsText?: boolean;
  /** Whether all replayed assistant messages must include an empty reasoning_content field when reasoning is enabled. Default: auto-detected from URL. */
  requiresReasoningContentOnAssistantMessages?: boolean;
  /** Format for reasoning/thinking parameter. "openai" uses reasoning_effort, "openrouter" uses reasoning: { effort }, "deepseek" uses thinking: { type } plus reasoning_effort, "together" uses reasoning: { enabled } plus reasoning_effort when supported, "zai" uses top-level enable_thinking: boolean, "qwen" uses top-level enable_thinking: boolean, and "qwen-chat-template" uses chat_template_kwargs.enable_thinking, plus chat_template_kwargs.reasoning_effort for selected enabled levels when supportedReasoningEfforts is declared. Default: "openai". */
  thinkingFormat?: ModelDataThinkingFormat;
  /** OpenRouter-specific routing preferences. Only used when baseUrl points to OpenRouter. */
  openRouterRouting?: OpenRouterRouting;
  /** Vercel AI Gateway routing preferences. Only used when baseUrl points to Vercel AI Gateway. */
  vercelGatewayRouting?: VercelGatewayRouting;
  /** Whether z.ai supports top-level `tool_stream: true` for streaming tool call deltas. Default: false. */
  zaiToolStream?: boolean;
  /** Whether the provider supports the `strict` field in tool definitions. Default: true. */
  supportsStrictMode?: boolean;
  /** Whether the provider supports JSON Schema through `response_format`. Default: false for unknown compatible endpoints. */
  supportsJsonSchemaResponseFormat?: boolean;
  /** Cache control convention for prompt caching. "anthropic" applies Anthropic-style `cache_control` markers to the system prompt, last tool definition, and last user/assistant text content. */
  cacheControlFormat?: "anthropic";
  /** Whether to send known session-affinity headers (`session_id`, `x-client-request-id`, `x-session-affinity`) from `options.sessionId` when caching is enabled. Default: false. */
  sendSessionAffinityHeaders?: boolean;
  /** Whether the provider supports OpenAI-style `prompt_cache_key`. Default: false for third-party completions providers. */
  supportsPromptCacheKey?: boolean;
  /** Whether the provider supports long prompt cache retention (`prompt_cache_retention: "24h"` or Anthropic-style `cache_control.ttl: "1h"`, depending on format). Default: true. */
  supportsLongCacheRetention?: boolean;
}

/** Compatibility settings for OpenAI Responses APIs. */
export interface OpenAIResponsesCompat {
  /** Whether a compatible provider accepts the `strict` tool field. Default: auto-detected from the endpoint. */
  supportsStrictMode?: boolean;
  /** Whether the provider supports the `developer` role (vs `system`). Default: true. */
  supportsDeveloperRole?: boolean;
  /** Whether to send reasoning effort settings. Defaults to the model's known capabilities. */
  supportsReasoningEffort?: boolean;
  /** Provider-native reasoning efforts accepted by the model. Overrides known model defaults. */
  supportedReasoningEfforts?: string[];
  /** Per-level reasoning effort overrides, e.g. map "off" to "low" for models that cannot disable thinking. */
  reasoningEffortMap?: Record<string, string>;
  /** Whether the model accepts the `temperature` parameter. Default: true. */
  supportsTemperature?: boolean;
  /** Whether to send the OpenAI `session_id` cache-affinity header from `options.sessionId` when caching is enabled. Default: true. */
  sendSessionIdHeader?: boolean;
  /** Whether to send `prompt_cache_key`. Default: true for Azure; endpoint-detected for OpenAI. */
  supportsPromptCacheKey?: boolean;
  /** Whether the provider supports `prompt_cache_retention: "24h"`. Default: true. */
  supportsLongCacheRetention?: boolean;
  /** Whether the provider honors top-level `instructions`. Defaults to true only for verified native routes (OpenAI, xAI); every other route defaults to false and embeds the system prompt in `input` unless set true here after verifying against that endpoint. */
  supportsInstructions?: boolean;
  /** Whether the model caches top-level `instructions`. False sends the system prompt as a cacheable input item placed after the last compaction item. Default: true. */
  cachesInstructions?: boolean;
  /**
   * Explicit opt-in for HTTP continuation (client-side delta + `previous_response_id`)
   * on a custom/proxy OpenAI-Responses-compatible endpoint. A native `api.openai.com`
   * connection is eligible by default; a custom endpoint carries no trust signal of
   * its own, so this is the only path to eligibility there — set it once you've
   * verified the backend correctly resolves `previous_response_id` and persists
   * `store: true` turns. Default: false.
   */
  supportsResponsesContinuation?: boolean;
}

/** Compatibility settings for Anthropic Messages-compatible APIs. */
export interface AnthropicMessagesCompat {
  /**
   * Whether the provider accepts per-tool `eager_input_streaming`.
   * When false, the Anthropic provider omits `tools[].eager_input_streaming`
   * and sends the legacy `fine-grained-tool-streaming-2025-05-14` beta header
   * for tool-enabled requests.
   * Default: true.
   */
  supportsEagerToolInputStreaming?: boolean;
  /** Whether the provider supports Anthropic long cache retention (`cache_control.ttl: "1h"`). Default: true. */
  supportsLongCacheRetention?: boolean;
  /**
   * Whether to send the `x-session-affinity` header from `options.sessionId`
   * when caching is enabled. Required for providers like Fireworks that use
   * session affinity for prompt cache routing (requests to the same replica
   * maximize cache hits).
   * Default: false.
   */
  sendSessionAffinityHeaders?: boolean;
  /**
   * Whether the provider supports Anthropic-style `cache_control` markers on
   * tool definitions. When false, `cache_control` is omitted from tool params.
   * Some Anthropic-compatible providers (e.g., Fireworks) do not support this
   * field on tools and may reject or ignore it.
   * Default: true.
   */
  supportsCacheControlOnTools?: boolean;
  /** Whether empty thinking signatures can be replayed as native thinking blocks. Default: false. */
  allowEmptySignature?: boolean;
}

/**
 * OpenRouter provider routing preferences.
 * Controls which upstream providers OpenRouter routes requests to.
 * Sent as the `provider` field in the OpenRouter API request body.
 * Own member declarations preserve existing module-augmentation semantics.
 * @see https://openrouter.ai/docs/guides/routing/provider-selection
 */
export interface OpenRouterRouting {
  /** Whether to allow backup providers to serve requests. Default: true. */
  allow_fallbacks?: boolean;
  /** Whether to filter providers to only those that support all parameters in the request. Default: false. */
  require_parameters?: boolean;
  /** Data collection setting. "allow" (default): allow providers that may store/train on data. "deny": only use providers that don't collect user data. */
  data_collection?: "deny" | "allow";
  /** Whether to restrict routing to only ZDR (Zero Data Retention) endpoints. */
  zdr?: boolean;
  /** Whether to restrict routing to only models that allow text distillation. */
  enforce_distillable_text?: boolean;
  /** An ordered list of provider names/slugs to try in sequence, falling back to the next if unavailable. */
  order?: string[];
  /** List of provider names/slugs to exclusively allow for this request. */
  only?: string[];
  /** List of provider names/slugs to skip for this request. */
  ignore?: string[];
  /** A list of quantization levels to filter providers by (e.g., ["fp16", "bf16", "fp8", "fp6", "int8", "int4", "fp4", "fp32"]). */
  quantizations?: string[];
  /** Sorting strategy. Can be a string (e.g., "price", "throughput", "latency") or an object with `by` and `partition`. */
  sort?: string | ModelRoutingSortConfig;
  /** Maximum price per million tokens (USD). */
  max_price?: ModelRoutingMaxPrice;
  /** Preferred minimum throughput (tokens/second). Can be a number (applies to p50) or an object with percentile-specific cutoffs. */
  preferred_min_throughput?: number | ModelRoutingPercentiles;
  /** Preferred maximum latency (seconds). Can be a number (applies to p50) or an object with percentile-specific cutoffs. */
  preferred_max_latency?: number | ModelRoutingPercentiles;
}

/**
 * Vercel AI Gateway routing preferences.
 * Controls which upstream providers the gateway routes requests to.
 * @see https://vercel.com/docs/ai-gateway/models-and-providers/provider-options
 */
export interface VercelGatewayRouting {
  /** List of provider slugs to exclusively use for this request (e.g., ["bedrock", "anthropic"]). */
  only?: string[];
  /** List of provider slugs to try in order (e.g., ["anthropic", "openai"]). */
  order?: string[];
}

export interface Model<TApi extends Api = Api> {
  id: string;
  name: string;
  api: TApi;
  provider: Provider;
  baseUrl: string;
  reasoning: boolean;
  /**
   * Maps OpenClaw thinking levels to provider/model-specific values.
   * Missing keys use provider defaults. null marks a level as unsupported.
   */
  thinkingLevelMap?: ThinkingLevelMap;
  input: ("text" | "image")[];
  cost: RawModelCostConfig;
  contextWindow?: number;
  /**
   * Optional effective runtime cap used for compaction/session budgeting.
   * Keeps provider/native contextWindow metadata intact while allowing a
   * smaller practical window.
   */
  contextTokens?: number;
  /** Provider/catalog-declared total parameter count, including inactive experts. */
  parameterCount?: number;
  /** Provider/catalog-declared canonical developer lineage, such as `anthropic`. */
  family?: string;
  maxTokens: number;
  /** Provider-specific request/runtime parameters passed through to provider plugins. */
  params?: Record<string, unknown>;
  headers?: ModelRequestHeaders;
  /** Sends runtime credentials as Authorization: Bearer instead of provider-specific key headers. */
  authHeader?: boolean;
  /** Compatibility overrides for OpenAI-compatible APIs. If not set, auto-detected from baseUrl. */
  compat?: TApi extends "openai-completions"
    ? OpenAICompletionsCompat
    : TApi extends
          | "openai-responses"
          | "azure-openai-responses"
          | "openai-chatgpt-responses"
          | "openai-codex-responses"
      ? OpenAIResponsesCompat
      : TApi extends "anthropic-messages"
        ? AnthropicMessagesCompat
        : never;
  /** Provider-documented media input limits used by attachment preprocessing. */
  mediaInput?: ModelDataMediaInputConfig;
}

export interface ImagesModel<TApi extends ImagesApi = ImagesApi> extends Omit<
  Model,
  "api" | "provider" | "reasoning" | "contextWindow" | "maxTokens" | "compat"
> {
  api: TApi;
  provider: ImagesProvider;
  output: ("text" | "image")[];
}

export type StreamFn = (
  model: Model,
  context: Context,
  options?: SimpleStreamOptions,
) => AssistantMessageEventStreamLike | Promise<AssistantMessageEventStreamLike>;

export type CompleteSimpleFn = (
  model: Model,
  context: Pick<Context, "systemPrompt" | "messages">,
  options?: SimpleStreamOptions,
) => Promise<AssistantMessage>;

export type ValidateToolArgumentsFn = (tool: Tool, toolCall: ToolCall) => unknown;
