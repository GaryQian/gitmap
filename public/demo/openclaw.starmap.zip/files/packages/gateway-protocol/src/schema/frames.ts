import type { Static } from "typebox";
import { Type } from "typebox";
import { closedObject } from "./closed-object.js";
import { ErrorShapeSchema } from "./error-shape.js";
import {
  ControlUiLinkReaderDescriptorSchema,
  ControlUiPluginTabSchema,
  ControlUiPluginWidgetKindSchema,
} from "./plugins.js";
import {
  GatewayClientIdSchema,
  GatewayClientModeSchema,
  NonEmptyString,
  UserProfileIdSchema,
} from "./primitives.js";
import { SessionVisibilitySchema } from "./sessions-sharing-values.js";
import { SnapshotSchema, StateVersionSchema } from "./snapshot.js";
import { stringLiteralUnion } from "./string-literal-union.js";
import { WorkerAdmissionHandshakeSchema } from "./worker-admission.js";

export { GATEWAY_SERVER_CAPS } from "../server-capabilities.js";
export { ErrorShapeSchema, type ErrorShape } from "./error-shape.js";

export const TickEventSchema = closedObject({
  ts: Type.Integer({ minimum: 0 }),
});

export const ShutdownEventSchema = closedObject({
  reason: NonEmptyString,
  restartExpectedMs: Type.Optional(Type.Integer({ minimum: 0 })),
});

/** Initial client hello/connect payload sent before the gateway accepts frames. */
export const ConnectParamsSchema = closedObject({
  minProtocol: Type.Integer({ minimum: 1 }),
  maxProtocol: Type.Integer({ minimum: 1 }),
  client: closedObject({
    id: GatewayClientIdSchema,
    displayName: Type.Optional(NonEmptyString),
    version: NonEmptyString,
    buildId: Type.Optional(Type.String({ minLength: 1, maxLength: 96 })),
    platform: NonEmptyString,
    deviceFamily: Type.Optional(NonEmptyString),
    modelIdentifier: Type.Optional(NonEmptyString),
    /** Self-reported IANA zone. Bounded because the longest real name is well under this cap. */
    timeZone: Type.Optional(Type.String({ minLength: 1, maxLength: 64 })),
    mode: GatewayClientModeSchema,
    instanceId: Type.Optional(NonEmptyString),
  }),
  caps: Type.Optional(Type.Array(NonEmptyString, { default: [] })),
  /** Initial roster-body preference; exact subscriptions always receive complete messages. */
  includeSessionMessageBodies: Type.Optional(Type.Boolean()),
  commands: Type.Optional(Type.Array(NonEmptyString)),
  /** Additive Computer Use declaration; the owning core contract validates its bounded shape. */
  computerUse: Type.Optional(Type.Unknown()),
  /** @deprecated Accepted for the shipped v1 node-host envelope; current hosts use runner inventory. */
  workerRuns: Type.Optional(WorkerAdmissionHandshakeSchema),
  permissions: Type.Optional(Type.Record(NonEmptyString, Type.Boolean())),
  pathEnv: Type.Optional(Type.String()),
  role: Type.Optional(NonEmptyString),
  scopes: Type.Optional(Type.Array(NonEmptyString)),
  /** Initial catalog read scope; method authorization still owns access. */
  modelCatalog: Type.Optional(
    Type.Union([
      closedObject({
        agentId: Type.Optional(NonEmptyString),
        sessionKey: Type.Optional(NonEmptyString),
      }),
      closedObject({
        agentId: Type.Optional(NonEmptyString),
        shortId: NonEmptyString,
        slugHint: Type.Optional(NonEmptyString),
      }),
    ]),
  ),
  device: Type.Optional(
    closedObject({
      id: NonEmptyString,
      publicKey: NonEmptyString,
      signature: NonEmptyString,
      signedAt: Type.Integer({ minimum: 0 }),
      nonce: NonEmptyString,
    }),
  ),
  auth: Type.Optional(
    closedObject({
      token: Type.Optional(Type.String()),
      bootstrapToken: Type.Optional(Type.String()),
      deviceToken: Type.Optional(Type.String()),
      password: Type.Optional(Type.String()),
      approvalRuntimeToken: Type.Optional(Type.String()),
      agentRuntimeIdentityToken: Type.Optional(Type.String()),
    }),
  ),
  locale: Type.Optional(Type.String()),
  userAgent: Type.Optional(Type.String()),
});

export const HelloOkSchema = closedObject({
  type: Type.Literal("hello-ok"),
  protocol: Type.Integer({ minimum: 1 }),
  server: closedObject({
    version: NonEmptyString,
    buildId: Type.Optional(Type.String({ minLength: 1, maxLength: 96 })),
    commit: Type.Optional(Type.String({ pattern: "^[0-9a-f]{7,40}$" })),
    builtAt: Type.Optional(NonEmptyString),
    bootId: Type.Optional(Type.String({ minLength: 1, maxLength: 96 })),
    controlUiBuildSource: Type.Optional(stringLiteralUnion(["bundled", "configured"])),
    connId: NonEmptyString,
  }),
  features: closedObject({
    methods: Type.Array(NonEmptyString),
    events: Type.Array(NonEmptyString),
    capabilities: Type.Optional(Type.Array(NonEmptyString)),
  }),
  snapshot: SnapshotSchema,
  // Public Control UI origin and mount path, independent of local SSH tunnels.
  controlUiUrl: Type.Optional(NonEmptyString),
  // Additive: the linked claw's Control UI address, only on OpenClaw ID tunnel connections.
  // Reaches claw members only, so anonymous share links keep using controlUiUrl.
  controlUiClawUrl: Type.Optional(NonEmptyString),
  // Additive: Control UI mount path on this listener, for clients that reach it by host and port.
  controlUiBasePath: Type.Optional(NonEmptyString),
  // Additive: plugin-declared Control UI tabs (surface "tab" descriptors).
  controlUiTabs: Type.Optional(Type.Array(ControlUiPluginTabSchema)),
  // Additive: active plugin widget kinds whose renderers ship in the trusted UI bundle.
  controlUiWidgetKinds: Type.Optional(Type.Array(ControlUiPluginWidgetKindSchema)),
  controlUiLinkReaders: Type.Optional(Type.Array(ControlUiLinkReaderDescriptorSchema)),
  pluginSurfaceUrls: Type.Optional(Type.Record(NonEmptyString, NonEmptyString)),
  auth: closedObject({
    method: Type.Optional(
      stringLiteralUnion([
        "none",
        "token",
        "password",
        "tailscale",
        "device-token",
        "bootstrap-token",
        "trusted-proxy",
      ]),
    ),
    deviceToken: Type.Optional(NonEmptyString),
    recoveryMigrationAllowed: Type.Optional(Type.Literal(true)),
    recoveryScope: Type.Optional(NonEmptyString),
    role: NonEmptyString,
    scopes: Type.Array(NonEmptyString),
    // Presentation only: device approval cannot exceed this authenticated role ceiling.
    roleAllowsAdmin: Type.Optional(Type.Boolean()),
    // Presentation only: a restricted viewer is bound to the authenticated profile, not socket scopes.
    profileActivityViewerId: Type.Optional(Type.Union([UserProfileIdSchema, Type.Null()])),
    sessionCap: Type.Optional(stringLiteralUnion(["write", "suggest", "view", "invited", "none"])),
    issuedAtMs: Type.Optional(Type.Integer({ minimum: 0 })),
    deviceTokens: Type.Optional(
      Type.Array(
        closedObject({
          deviceToken: NonEmptyString,
          role: NonEmptyString,
          scopes: Type.Array(NonEmptyString),
          issuedAtMs: Type.Integer({ minimum: 0 }),
        }),
      ),
    ),
  }),
  policy: closedObject({
    maxPayload: Type.Integer({ minimum: 1 }),
    maxBufferedBytes: Type.Integer({ minimum: 1 }),
    tickIntervalMs: Type.Integer({ minimum: 1 }),
    // Additive: unconditional decoded-size ceilings for chat attachments, so
    // clients can validate a file before sending instead of hardcoding guesses.
    // Per attachment, not per frame: the encoded request must still fit
    // `maxPayload`. MIME acceptance and per-message counts stay server-side
    // because they depend on the entrypoint, resolved model, and payload sniffing.
    attachments: Type.Optional(
      closedObject({
        maxBytes: Type.Integer({ minimum: 1 }),
        maxImageBytes: Type.Integer({ minimum: 1 }),
      }),
    ),
    allowedSessionVisibilities: Type.Optional(Type.Array(SessionVisibilitySchema)),
    hasMultipleSessionSharingIdentities: Type.Optional(Type.Boolean()),
  }),
});

/** Client request frame envelope; `method` selects the payload validator. */
export const RequestFrameSchema = closedObject({
  type: Type.Literal("req"),
  id: NonEmptyString,
  method: NonEmptyString,
  params: Type.Optional(Type.Unknown()),
  traceparent: Type.Optional(Type.String({ maxLength: 128 })),
  expectedProfileId: Type.Optional(UserProfileIdSchema),
});

export const ResponseFrameSchema = closedObject({
  type: Type.Literal("res"),
  id: NonEmptyString,
  ok: Type.Boolean(),
  payload: Type.Optional(Type.Unknown()),
  error: Type.Optional(ErrorShapeSchema),
});

/** Server event frame envelope; `event` selects the payload validator. */
export const EventFrameSchema = closedObject({
  type: Type.Literal("event"),
  event: NonEmptyString,
  payload: Type.Optional(Type.Unknown()),
  seq: Type.Optional(Type.Integer({ minimum: 0 })),
  stateVersion: Type.Optional(StateVersionSchema),
  recipientProfileId: Type.Optional(UserProfileIdSchema),
});

// Discriminated union of all top-level frames. Using a discriminator makes
// downstream codegen (quicktype) produce tighter types instead of all-optional
// blobs.
export const GatewayFrameSchema = Type.Union(
  [RequestFrameSchema, ResponseFrameSchema, EventFrameSchema],
  { discriminator: "type" },
);

// Frame types are owner-local because they cross the public client/plugin SDK.
// Keeping them off the aggregate registry avoids retaining every RPC schema.
export type ConnectParams = Static<typeof ConnectParamsSchema>;
export type HelloOk = Static<typeof HelloOkSchema>;
export type RequestFrame = Static<typeof RequestFrameSchema>;
export type ResponseFrame = Static<typeof ResponseFrameSchema>;
export type EventFrame = Static<typeof EventFrameSchema>;
export type GatewayFrame = Static<typeof GatewayFrameSchema>;

// Wire types derive directly from local schema consts so public d.ts graphs never
// pull in the ProtocolSchemas registry.
export type TickEvent = Static<typeof TickEventSchema>;
export type ShutdownEvent = Static<typeof ShutdownEventSchema>;
