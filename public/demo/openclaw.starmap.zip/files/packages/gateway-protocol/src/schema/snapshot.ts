import type { Static } from "typebox";
import { Type } from "typebox";
import { AgentOwnershipSchema } from "./agents-models-skills.js";
import { closedObject } from "./closed-object.js";
import { UpdateAvailableSchema, UpdateScheduleStateSchema } from "./config.js";
import { GatewaySuspensionSchema } from "./gateway-suspend.js";
import { NonEmptyString } from "./primitives.js";
import { GatewayEventLoopHealthSchema } from "./runtime-vitals.js";
import { SessionPersonSchema } from "./session-participant.js";
import { stringLiteralUnion } from "./string-literal-union.js";

/**
 * Gateway state snapshot schemas.
 *
 * Snapshots are sent during hello and later event streams; they summarize node
 * presence, health, session defaults, and version counters for clients.
 */
/** One gateway-visible presence record for a node/client/runtime. */
export const PresenceEntrySchema = closedObject({
  /** Gateway-assigned id for this connection; changes after reconnect. */
  connectionId: Type.Optional(NonEmptyString),
  host: Type.Optional(NonEmptyString),
  clientId: Type.Optional(NonEmptyString),
  ip: Type.Optional(NonEmptyString),
  version: Type.Optional(NonEmptyString),
  platform: Type.Optional(NonEmptyString),
  deviceFamily: Type.Optional(NonEmptyString),
  modelIdentifier: Type.Optional(NonEmptyString),
  timeZone: Type.Optional(NonEmptyString),
  mode: Type.Optional(NonEmptyString),
  lastInputSeconds: Type.Optional(Type.Integer({ minimum: 0 })),
  reason: Type.Optional(NonEmptyString),
  tags: Type.Optional(Type.Array(NonEmptyString)),
  text: Type.Optional(Type.String()),
  /** Heartbeat freshness, not online duration or user activity. */
  ts: Type.Integer({ minimum: 0 }),
  /** Server timestamps for the person's continuous online interval and last accepted activity. */
  onlineSince: Type.Optional(Type.Integer({ minimum: 0 })),
  lastActivityAt: Type.Optional(Type.Integer({ minimum: 0 })),
  /** Latest accepted OpenClaw interaction on this connection, independent of person timing. */
  connectionLastActivityAt: Type.Optional(Type.Integer({ minimum: 0 })),
  deviceId: Type.Optional(NonEmptyString),
  roles: Type.Optional(Type.Array(NonEmptyString)),
  scopes: Type.Optional(Type.Array(NonEmptyString)),
  instanceId: Type.Optional(NonEmptyString),
  user: Type.Optional(
    closedObject({
      /** Canonical profile id when resolved, otherwise authenticated identity; grouping also uses identity qualification. */
      id: NonEmptyString,
      identity: Type.Optional(SessionPersonSchema.properties.identity),
      email: Type.Optional(NonEmptyString),
      name: Type.Optional(NonEmptyString),
      avatarUrl: Type.Optional(NonEmptyString),
    }),
  ),
  /** Sessions this connection declares it is viewing, independent of transport subscriptions. Sorted lexicographically. */
  watchedSessions: Type.Optional(Type.Array(NonEmptyString)),
});

const HealthSessionSummarySchema = closedObject({
  path: Type.String(),
  count: Type.Integer({ minimum: 0 }),
  recent: Type.Array(
    closedObject({
      key: Type.String(),
      updatedAt: Type.Union([Type.Integer({ minimum: 0 }), Type.Null()]),
      age: Type.Union([Type.Integer({ minimum: 0 }), Type.Null()]),
    }),
  ),
});

const HealthSnapshotSchema = closedObject({
  // Every field is optional because hello snapshots use an empty object until
  // the asynchronous health producer has populated the cache.
  ok: Type.Optional(Type.Literal(true)),
  // Live health RPC readiness, independent of optional channel health.
  coreReady: Type.Optional(Type.Boolean()),
  ts: Type.Optional(Type.Integer({ minimum: 0 })),
  durationMs: Type.Optional(Type.Integer({ minimum: 0 })),
  eventLoop: Type.Optional(GatewayEventLoopHealthSchema),
  plugins: Type.Optional(
    closedObject({
      loaded: Type.Array(Type.String()),
      errors: Type.Array(
        closedObject({
          id: Type.String(),
          origin: Type.String(),
          activated: Type.Boolean(),
          activationSource: Type.Optional(Type.String()),
          activationReason: Type.Optional(Type.String()),
          failurePhase: Type.Optional(Type.String()),
          error: Type.String(),
        }),
      ),
      unavailable: Type.Optional(
        Type.Array(
          closedObject({
            id: Type.String(),
            state: Type.Literal("configured-unavailable"),
            diagnostic: closedObject({
              kind: Type.Literal("plugin-verification"),
              reason: Type.String(),
              detail: Type.String(),
            }),
          }),
        ),
      ),
    }),
  ),
  contextEngines: Type.Optional(
    closedObject({
      quarantined: Type.Array(
        closedObject({
          engineId: Type.String(),
          owner: Type.Optional(Type.String()),
          operation: Type.String(),
          reason: Type.String(),
          failedAt: Type.Integer({ minimum: 0 }),
        }),
      ),
    }),
  ),
  deliveryQueues: Type.Optional(
    closedObject({
      failed: Type.Array(
        closedObject({
          queueName: Type.String(),
          count: Type.Integer({ minimum: 0 }),
          oldestFailedAt: Type.Optional(Type.Integer({ minimum: 0 })),
        }),
      ),
      ingressFailed: Type.Optional(
        Type.Array(
          closedObject({
            channelId: Type.String(),
            accountId: Type.String(),
            count: Type.Integer({ minimum: 0 }),
            oldestFailedAt: Type.Optional(Type.Integer({ minimum: 0 })),
          }),
        ),
      ),
      ingressPressure: Type.Optional(
        Type.Array(
          closedObject({
            channelId: Type.String(),
            accountId: Type.String(),
            laneCount: Type.Integer({ minimum: 0 }),
            pendingCount: Type.Integer({ minimum: 0 }),
            claimedCount: Type.Integer({ minimum: 0 }),
            blockedCount: Type.Integer({ minimum: 0 }),
            oldestReceivedAt: Type.Integer({ minimum: 0 }),
          }),
        ),
      ),
    }),
  ),
  modelPricing: Type.Optional(
    closedObject({
      state: stringLiteralUnion(["ok", "degraded", "disabled"]),
      sources: Type.Array(
        closedObject({
          source: stringLiteralUnion(["openrouter", "litellm", "bootstrap", "refresh"]),
          state: stringLiteralUnion(["ok", "degraded"]),
          lastFailureAt: Type.Optional(Type.Integer({ minimum: 0 })),
          detail: Type.Optional(Type.String()),
        }),
      ),
      lastFailureAt: Type.Optional(Type.Integer({ minimum: 0 })),
      detail: Type.Optional(Type.String()),
    }),
  ),
  configReload: Type.Optional(
    closedObject({
      hotReloadStatus: stringLiteralUnion(["active", "disabled"]),
    }),
  ),
  // Readers see runtime availability; only admins receive the Node binary path.
  childRuntime: Type.Optional(
    closedObject({
      execPath: Type.String(),
      available: Type.Boolean(),
    }),
  ),
  // Channel plugins own their nested account/probe summaries, so this is the
  // one provider-contributed bag that deliberately remains unknown.
  channels: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
  channelOrder: Type.Optional(Type.Array(Type.String())),
  channelLabels: Type.Optional(Type.Record(Type.String(), Type.String())),
  heartbeatSeconds: Type.Optional(Type.Integer({ minimum: 0 })),
  defaultAgentId: Type.Optional(Type.String()),
  agents: Type.Optional(
    Type.Array(
      closedObject({
        agentId: Type.String(),
        name: Type.Optional(Type.String()),
        isDefault: Type.Boolean(),
        heartbeat: closedObject({
          enabled: Type.Boolean(),
          every: Type.String(),
          everyMs: Type.Union([Type.Integer({ minimum: 0 }), Type.Null()]),
          prompt: Type.String(),
          target: Type.String(),
          model: Type.Optional(Type.String()),
          session: Type.Optional(Type.String()),
          ackMaxChars: Type.Integer({ minimum: 0 }),
        }),
        sessions: HealthSessionSummarySchema,
      }),
    ),
  ),
  sessions: Type.Optional(HealthSessionSummarySchema),
});

/** Default session routing keys included in initial gateway snapshots. */
const SessionDefaultsSchema = closedObject({
  defaultAgentId: NonEmptyString,
  modelConfigured: Type.Optional(Type.Boolean()),
  ownership: Type.Optional(AgentOwnershipSchema),
  selectionRequired: Type.Optional(Type.Boolean()),
  mainKey: NonEmptyString,
  mainSessionKey: NonEmptyString,
  scope: Type.Optional(NonEmptyString),
});

/** Monotonic version counters for snapshot subtrees. */
export const StateVersionSchema = closedObject({
  presence: Type.Integer({ minimum: 0 }),
  health: Type.Integer({ minimum: 0 }),
});

/** Initial and incremental gateway state snapshot payload. */
export const SnapshotSchema = closedObject({
  suspension: Type.Optional(GatewaySuspensionSchema),
  presence: Type.Array(PresenceEntrySchema),
  health: HealthSnapshotSchema,
  stateVersion: StateVersionSchema,
  uptimeMs: Type.Integer({ minimum: 0 }),
  /** Resolved source-config revision accepted by the active Gateway runtime. */
  appliedConfigHash: Type.Optional(Type.Union([NonEmptyString, Type.Null()])),
  configPath: Type.Optional(NonEmptyString),
  stateDir: Type.Optional(NonEmptyString),
  sessionDefaults: Type.Optional(SessionDefaultsSchema),
  /** Credential-free browser sign-in endpoint advertised to authenticated operators. */
  controlUiIdentityUrl: Type.Optional(NonEmptyString),
  authMode: Type.Optional(stringLiteralUnion(["none", "token", "password", "trusted-proxy"])),
  /** Address the running Gateway listens on, including startup flags that config can't show. */
  bindHost: Type.Optional(NonEmptyString),
  /** Tailscale exposure of the running Gateway, which keeps a loopback bind. */
  tailscaleMode: Type.Optional(stringLiteralUnion(["off", "serve", "funnel"])),
  updateAvailable: Type.Optional(UpdateAvailableSchema),
  updateSchedule: Type.Optional(UpdateScheduleStateSchema),
});

// Wire types derive directly from local schema consts so public d.ts graphs never
// pull in the ProtocolSchemas registry.
export type Snapshot = Static<typeof SnapshotSchema>;
export type PresenceEntry = Static<typeof PresenceEntrySchema>;
export type StateVersion = Static<typeof StateVersionSchema>;
