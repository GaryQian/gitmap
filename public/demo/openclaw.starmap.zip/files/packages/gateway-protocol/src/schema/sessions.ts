import type { Static } from "typebox";
import { Type } from "typebox";
import {
  SESSION_COMPANION_MAX_EXCHANGE_BYTES,
  SESSION_COMPANION_SELECTION_CONTEXT_MAX_CHARS,
} from "../session-companion-contract.js";
import { closedObject } from "./closed-object.js";
import { ErrorShapeSchema } from "./error-shape.js";
import { HumanMentionsSchema } from "./human-mentions.js";
import { ChatAttachmentsSchema, ChatHistoryParamsSchema } from "./logs-chat.js";
import { PluginJsonValueSchema } from "./plugin-json-value.js";
import { NonEmptyString, SessionLabelString } from "./primitives.js";
import { SessionOwnerSchema } from "./sessions-row.js";
import { stringLiteralUnion } from "./string-literal-union.js";

export * from "./sessions-create.js";
export * from "./sessions-communication.js";
export * from "./sessions-involvement.js";
export * from "./sessions-activity-summary.js";
export {
  SessionsStorageParamsSchema,
  SessionsStorageStatusResultSchema,
  type SessionsStorageStatusResult,
} from "./sessions-storage.js";
export * from "./sessions-title.js";
export * from "./sessions-goal.js";
export * from "./sessions-provider-review.js";
export {
  SessionsListParamsSchema,
  SessionsSubscribeParamsSchema,
  SessionOwnerSessionCountSchema,
  type SessionsListParams,
  type SessionOwnerSessionCount,
} from "./sessions-list.js";
export {
  SessionParticipantIdentitySchema,
  SessionParticipantSchema,
  SessionPersonSchema,
  type SessionParticipantIdentity,
  type SessionParticipant,
  type SessionPerson,
} from "./session-participant.js";
export {
  PreservedSessionWorktreeSchema,
  SessionsDeleteParamsSchema,
  SessionsDeleteResultSchema,
  WorktreePreservationReasonSchema,
  WORKTREE_PRESERVATION_REASONS,
  type PreservedSessionWorktree,
  type SessionsDeleteParams,
  type SessionsDeleteResult,
  type WorktreePreservationReason,
} from "./sessions-delete.js";
export {
  SESSIONS_PATCH_MANY_MAX_TARGETS,
  SessionsPatchManyParamsSchema,
  SessionsPatchManyResultSchema,
  SessionsPatchManyTargetSchema,
  SessionsPatchMutationSchema,
  SessionsPatchParamsSchema,
  type SessionsPatchManyParams,
  type SessionsPatchManyResult,
  type SessionsPatchManyTarget,
  type SessionsPatchMutation,
  type SessionsPatchParams,
} from "./sessions-patch.js";
export {
  SessionAncestorRefSchema,
  SessionCreatedActorSchema,
  SessionEventAncestorsSchema,
  SessionPermissionModeSchema,
  SessionOwnerSchema,
  SessionRowSchema,
  SessionToolOverridesSchema,
  type SessionAncestorRef,
  type SessionCreatedActor,
  type SessionEventAncestors,
  type SessionOwner,
  type SessionPermissionMode,
  type SessionRow,
  type SessionRunStatus,
  type SessionToolOverrides,
} from "./sessions-row.js";

export const SESSION_OBSERVER_HEALTH_VALUES = [
  "on-track",
  "grinding",
  "stuck",
  "waiting-on-user",
  "wrapping-up",
  "done",
  "failed",
] as const;

/** Trajectory judgment produced for one observed agent session. */
export const SessionObserverHealthSchema = stringLiteralUnion(SESSION_OBSERVER_HEALTH_VALUES);

export const SessionObserverPlanProgressSchema = closedObject({
  completed: Type.Integer({ minimum: 0 }),
  total: Type.Integer({ minimum: 0 }),
});

/** Live session status judgment broadcast to subscribed operator clients. */
export const SessionObserverDigestSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  sessionId: Type.Optional(NonEmptyString),
  lifecycleRevision: Type.Optional(NonEmptyString),
  runId: Type.Optional(NonEmptyString),
  revision: Type.Integer({ minimum: 1 }),
  updatedAt: Type.Integer({ minimum: 0 }),
  headline: Type.String({ minLength: 1, maxLength: 120 }),
  assessment: Type.Optional(Type.String({ minLength: 1, maxLength: 320 })),
  health: SessionObserverHealthSchema,
  planProgress: Type.Optional(SessionObserverPlanProgressSchema),
});

/** Declares whether this connection currently renders session observer output. */
export const SessionsObserverVisibilityParamsSchema = closedObject({
  visible: Type.Boolean(),
});

export const SessionsObserverVisibilityResultSchema = closedObject({
  ok: Type.Literal(true),
});

/** One bounded question/answer exchange in the ephemeral session companion. */
const SessionCompanionAnswerSchema = Type.String({
  minLength: 1,
  maxLength: SESSION_COMPANION_MAX_EXCHANGE_BYTES,
});
export const SessionCompanionExchangeSchema = closedObject({
  question: Type.String({ minLength: 1, maxLength: 400 }),
  answer: SessionCompanionAnswerSchema,
  ts: Type.Integer({ minimum: 0 }),
});

/** Asks the read-only companion about one session and its workspace. */
export const SessionsCompanionAskParamsSchema = closedObject({
  askId: Type.Optional(NonEmptyString),
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  question: Type.String({ minLength: 1, maxLength: 400 }),
  selectionContext: Type.Optional(
    Type.String({ minLength: 1, maxLength: SESSION_COMPANION_SELECTION_CONTEXT_MAX_CHARS }),
  ),
  attachments: Type.Optional(ChatAttachmentsSchema),
  /** Side chat model for this question; omitted uses the agent's utility model. */
  model: Type.Optional(NonEmptyString),
  /** Reasoning level for this question; omitted uses the model default. */
  thinkingLevel: Type.Optional(NonEmptyString),
  /** Speed for this question; omitted uses the model default. */
  fastMode: Type.Optional(
    Type.Union([Type.Boolean(), Type.Literal("auto"), Type.Literal("ultrafast")]),
  ),
});

/** Companion answer returned only to the requesting operator. */
export const SessionsCompanionAskResultSchema = closedObject({
  answer: SessionCompanionAnswerSchema,
  ts: Type.Integer({ minimum: 0 }),
});

/** Selects the in-memory companion thread for one session. */
export const SessionsCompanionStateParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
});

export const SessionsCompanionStateResultSchema = closedObject({
  exchanges: Type.Array(SessionCompanionExchangeSchema, { maxItems: 24 }),
  /** Model Side chat answers with when a question names none; absent when unavailable. */
  defaultModel: Type.Optional(NonEmptyString),
});

/** Without cancelAskId clear the thread; with it stop only that question. */
export const SessionsCompanionResetParamsSchema = closedObject({
  ...SessionsCompanionStateParamsSchema.properties,
  cancelAskId: Type.Optional(NonEmptyString),
});

export const SessionsCompanionResetResultSchema = closedObject({
  ok: Type.Literal(true),
});

export const SessionOperationEventSchema = closedObject({
  operationId: NonEmptyString,
  operation: Type.Literal("compact"),
  phase: stringLiteralUnion(["start", "end"]),
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  ts: Type.Integer({ minimum: 0 }),
  completed: Type.Optional(Type.Boolean()),
  reason: Type.Optional(Type.String()),
});

export * from "./sessions-files.js";

export const SessionDiffFileStatusSchema = stringLiteralUnion([
  "added",
  "modified",
  "deleted",
  "renamed",
]);

export const SessionDiffFileSchema = closedObject({
  path: NonEmptyString,
  oldPath: Type.Optional(NonEmptyString),
  status: SessionDiffFileStatusSchema,
  additions: Type.Integer({ minimum: 0 }),
  deletions: Type.Integer({ minimum: 0 }),
  binary: Type.Optional(Type.Boolean()),
  untracked: Type.Optional(Type.Boolean()),
  /** Per-file unified patch text; absent for binary or oversized files. */
  patch: Type.Optional(Type.String()),
  truncated: Type.Optional(Type.Boolean()),
});

export const SessionDiffCommitSchema = closedObject({
  sha: NonEmptyString,
  subject: Type.String(),
});

/** Selects the session checkout state represented by the diff. */
export const SessionDiffScopeSchema = stringLiteralUnion(["all", "uncommitted", "commit"]);

/** Reads the git diff of a session checkout against its base branch. */
export const SessionsDiffParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  scope: Type.Optional(SessionDiffScopeSchema),
  commit: Type.Optional(NonEmptyString),
  /** File metadata and line counts only; skip patches and branch history. */
  summaryOnly: Type.Optional(Type.Boolean()),
  /** Return a computing result while a shared checkout read is pending. */
  poll: Type.Optional(Type.Boolean()),
});

/** Branch + working-tree diff for one session checkout. */
export const SessionsDiffResultSchema = closedObject({
  sessionKey: NonEmptyString,
  root: Type.Optional(NonEmptyString),
  branch: Type.Optional(NonEmptyString),
  /** Display label of the diff base: the default branch name or "HEAD". */
  baseRef: Type.Optional(NonEmptyString),
  /** Number of commits between the resolved branch merge base and HEAD. */
  aheadCount: Type.Optional(Type.Integer({ minimum: 0 })),
  /** Newest-first commits between the resolved branch merge base and HEAD. */
  commits: Type.Optional(Type.Array(SessionDiffCommitSchema, { maxItems: 50 })),
  /** The resolved branch merge-base commit. */
  mergeBase: Type.Optional(SessionDiffCommitSchema),
  files: Type.Array(SessionDiffFileSchema),
  additions: Type.Integer({ minimum: 0 }),
  deletions: Type.Integer({ minimum: 0 }),
  truncated: Type.Optional(Type.Boolean()),
  /** Poll again for the completed diff; empty files do not mean no changes. */
  computing: Type.Optional(Type.Boolean()),
  unavailableReason: Type.Optional(
    stringLiteralUnion(["unknown_session", "not_git", "unknown_commit", "workspace_stopped"]),
  ),
});

export {
  SessionsSearchParamsSchema,
  SessionsSearchHitSchema,
  SessionsSearchResultSchema,
  type SessionsSearchParams,
  type SessionsSearchHit,
  type SessionsSearchResult,
} from "./sessions-search.js";

/** Repairs or removes invalid session records from the selected agent scope. */
export const SessionsCleanupParamsSchema = closedObject({
  agent: Type.Optional(NonEmptyString),
  allAgents: Type.Optional(Type.Boolean()),
  enforce: Type.Optional(Type.Boolean()),
  activeKey: Type.Optional(NonEmptyString),
  fixMissing: Type.Optional(Type.Boolean()),
  fixDmScope: Type.Optional(Type.Boolean()),
});

export const SessionsPreviewParamsSchema = closedObject({
  keys: Type.Array(NonEmptyString, { minItems: 1 }),
  limit: Type.Optional(Type.Integer({ minimum: 1 })),
  maxChars: Type.Optional(Type.Integer({ minimum: 20 })),
});

export const SessionsDescribeParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  includeNativeSubagents: Type.Optional(Type.Boolean()),
  includeDerivedTitles: Type.Optional(Type.Boolean()),
  includeLastMessage: Type.Optional(Type.Boolean()),
});

export const SessionWorktreeInfoSchema = closedObject({
  id: NonEmptyString,
  path: NonEmptyString,
  branch: NonEmptyString,
});

export const SessionsCreateResultSchema = Type.Object(
  {
    ok: Type.Literal(true),
    key: NonEmptyString,
    sessionId: Type.Optional(NonEmptyString),
    entry: Type.Optional(Type.Record(Type.String(), Type.Unknown())),
    runStarted: Type.Optional(Type.Boolean()),
    runId: Type.Optional(NonEmptyString),
    messageSeq: Type.Optional(Type.Integer({ minimum: 1 })),
    runError: Type.Optional(ErrorShapeSchema),
    worktree: Type.Optional(SessionWorktreeInfoSchema),
  },
  { additionalProperties: true },
);

/** Discover one steerable physical backend under the same write policy as active steering. */
export const SessionsSteerTargetParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
});
export const SessionsSteerTargetResultSchema = closedObject({
  target: Type.Union([
    closedObject({ sessionId: NonEmptyString, runId: NonEmptyString }),
    Type.Null(),
  ]),
});
export type SessionsSteerTargetParams = Static<typeof SessionsSteerTargetParamsSchema>;
export type SessionsSteerTargetResult = Static<typeof SessionsSteerTargetResultSchema>;

/** Literal human input for one exact running backend; never starts a turn. */
export const SessionsSteerActiveParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  sessionId: NonEmptyString,
  runId: NonEmptyString,
  message: Type.String({ minLength: 1 }),
  idempotencyKey: NonEmptyString,
});

export const SessionsSteerActiveResultSchema = closedObject({
  runId: NonEmptyString,
  inputId: NonEmptyString,
  status: stringLiteralUnion(["accepted", "rejected", "indeterminate", "in_flight"]),
  reason: Type.Optional(Type.String()),
  messageSeq: Type.Optional(Type.Integer({ minimum: 1 })),
  receiptPersisted: Type.Boolean(),
});

export type SessionsSteerActiveParams = Static<typeof SessionsSteerActiveParamsSchema>;
export type SessionsSteerActiveResult = Static<typeof SessionsSteerActiveResultSchema>;

export const SessionsSendParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  message: Type.String(),
  mentions: Type.Optional(HumanMentionsSchema),
  thinking: Type.Optional(Type.String()),
  attachments: Type.Optional(ChatAttachmentsSchema),
  timeoutMs: Type.Optional(Type.Integer({ minimum: 0 })),
  idempotencyKey: Type.Optional(NonEmptyString),
});

export const SessionsMessagesSubscribeParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  /** Stable connection-local observer identity; omission replaces the legacy observer. */
  subscriptionId: Type.Optional(Type.String({ minLength: 1, maxLength: 128 })),
  /** Background narration receives bounded digests; omission preserves full transcript streams. */
  mode: Type.Optional(Type.Literal("narration")),
  /** Opt in to sanitized durable approval events for this session and its descendants. */
  includeApprovals: Type.Optional(Type.Literal(true)),
  /** Opt in to optional live tool stdout; legacy tool updates and history are unchanged. */
  includeLiveToolOutput: Type.Optional(Type.Literal(true)),
  /** Read the first transcript snapshot after this observer is admitted. */
  initialHistory: Type.Optional(
    closedObject({
      cursor: ChatHistoryParamsSchema.properties.cursor,
      knownState: ChatHistoryParamsSchema.properties.knownState,
      limit: ChatHistoryParamsSchema.properties.limit,
      maxBytes: ChatHistoryParamsSchema.properties.maxBytes,
      toolResultMaxChars: ChatHistoryParamsSchema.properties.toolResultMaxChars,
      inputRunIds: ChatHistoryParamsSchema.properties.inputRunIds,
    }),
  ),
});

/** Latest bounded assistant text for a background narration subscriber. */
export const SessionNarrationEventSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  runId: NonEmptyString,
  text: Type.String({ maxLength: 16384 }),
});

export const SessionsMessagesUnsubscribeParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  subscriptionId: Type.Optional(Type.String({ minLength: 1, maxLength: 128 })),
});

export const SessionsAbortParamsSchema = closedObject({
  key: Type.Optional(NonEmptyString),
  runId: Type.Optional(NonEmptyString),
  agentId: Type.Optional(NonEmptyString),
  /** Also discard followup and lane queues for a key-only non-global session abort. */
  clearQueued: Type.Optional(Type.Boolean()),
  /** Explicit Stop action; presentation only, never cancellation authority. */
  userInitiated: Type.Optional(Type.Boolean()),
});

/** Updates or clears one plugin namespace value on a session record. */
export const SessionsPluginPatchParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  pluginId: NonEmptyString,
  namespace: NonEmptyString,
  value: Type.Optional(PluginJsonValueSchema),
  unset: Type.Optional(Type.Boolean()),
});

export const SessionsPluginPatchResultSchema = closedObject({
  ok: Type.Literal(true),
  key: NonEmptyString,
  value: Type.Optional(PluginJsonValueSchema),
});

export const SessionsResetParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  reason: Type.Optional(stringLiteralUnion(["new", "reset"])),
  expectedSessionId: Type.Optional(NonEmptyString),
});

/** Reassigns mutable session responsibility without changing provenance or sharing authority. */
export const SessionsAssignOwnerParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  owner: closedObject({
    type: stringLiteralUnion(["agent", "human"]),
    id: NonEmptyString,
  }),
});

export const SessionsAssignOwnerResultSchema = closedObject({
  ok: Type.Literal(true),
  key: NonEmptyString,
  owner: SessionOwnerSchema,
});

/** Lists the gateway-owned custom session group catalog (names + order). */
export const SessionsGroupsListParamsSchema = closedObject({});

export const SessionGroupSchema = closedObject({
  name: SessionLabelString,
  position: Type.Integer({ minimum: 0 }),
});

/** New Session defaults visible only to operators who can update them. */
export const SessionGroupDefaultsSchema = closedObject({
  name: SessionLabelString,
  cwd: Type.Optional(NonEmptyString),
  worktree: Type.Optional(Type.Boolean()),
});

const SidebarSectionIdString = Type.String({ minLength: 1, maxLength: 512 });

/** Custom session group catalog in display order. */
export const SessionsGroupsListResultSchema = closedObject({
  groups: Type.Array(SessionGroupSchema),
  sectionOrder: Type.Optional(Type.Array(SidebarSectionIdString)),
});

export const SessionsGroupsDefaultsParamsSchema = closedObject({});

/** Write-scoped group defaults, kept separate from the read-scoped catalog. */
export const SessionsGroupsDefaultsResultSchema = closedObject({
  defaults: Type.Array(SessionGroupDefaultsSchema),
});

/** Atomically adds a group without replacing existing groups, defaults, or order. */
export const SessionsGroupsCreateParamsSchema = closedObject({
  name: Type.String({ ...SessionLabelString, pattern: "\\S" }),
});

/** Replaces the ordered group catalog; creates listed names, keeps member categories untouched. */
export const SessionsGroupsPutParamsSchema = closedObject({
  names: Type.Array(SessionLabelString),
  sectionOrder: Type.Optional(Type.Array(SidebarSectionIdString)),
});

/** Renames a group and repoints every member session's category. */
export const SessionsGroupsRenameParamsSchema = closedObject({
  name: SessionLabelString,
  to: SessionLabelString,
});

/** Updates the New Session defaults owned by one custom group. */
export const SessionsGroupsUpdateParamsSchema = closedObject({
  name: SessionLabelString,
  cwd: Type.Union([NonEmptyString, Type.Null()]),
  worktree: Type.Boolean(),
});

/** Result after updating defaults without widening the read-scoped catalog. */
export const SessionsGroupsUpdateResultSchema = closedObject({
  ok: Type.Literal(true),
  defaults: Type.Array(SessionGroupDefaultsSchema),
});

/** Deletes a group and clears every member session's category. */
export const SessionsGroupsDeleteParamsSchema = closedObject({ name: SessionLabelString });

/** Result for group catalog mutations, with member sessions updated where applicable. */
export const SessionsGroupsMutationResultSchema = closedObject({
  ok: Type.Literal(true),
  groups: Type.Array(SessionGroupSchema),
  sectionOrder: Type.Optional(Type.Array(SidebarSectionIdString)),
  updatedSessions: Type.Optional(Type.Integer({ minimum: 0 })),
});

export const SessionsCompactParamsSchema = closedObject({
  key: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  maxLines: Type.Optional(Type.Integer({ minimum: 1 })),
});

/** Repoints a session to the active-path state before one persisted user message. */
export const SessionsRewindParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  entryId: NonEmptyString,
});

/** Creates a new session from the active-path state before one persisted user message. */
export const SessionsForkParamsSchema = closedObject(SessionsRewindParamsSchema.properties);

const SessionEditorAttachmentSchema = closedObject({
  mimeType: Type.String(),
  data: Type.String(),
});

export const SessionsRewindResultSchema = closedObject({
  editorText: Type.Optional(Type.String()),
  editorAttachments: Type.Optional(Type.Array(SessionEditorAttachmentSchema)),
});

export const SessionsForkResultSchema = closedObject({
  sessionKey: NonEmptyString,
  editorText: Type.Optional(Type.String()),
  editorAttachments: Type.Optional(Type.Array(SessionEditorAttachmentSchema)),
});

export const SessionBranchSchema = closedObject({
  leafEntryId: NonEmptyString,
  headline: Type.String(),
  messageCount: Type.Integer({ minimum: 0 }),
  updatedAt: Type.Optional(NonEmptyString),
  active: Type.Boolean(),
});

/** Lists transcript DAG tips available for branch switching. */
export const SessionsBranchesListParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
});

export const SessionsBranchesListResultSchema = closedObject({
  branches: Type.Array(SessionBranchSchema),
});

/** Repoints the active transcript path to one existing DAG tip. */
export const SessionsBranchesSwitchParamsSchema = closedObject({
  sessionKey: NonEmptyString,
  agentId: Type.Optional(NonEmptyString),
  leafEntryId: NonEmptyString,
});

export const SessionsBranchesSwitchResultSchema = closedObject({});

/** Usage report query across one session, one agent, or all agent sessions. */
export const SessionsUsageParamsSchema = closedObject({
  /** Specific session key to analyze; if omitted returns sessions for the effective agent. */
  key: Type.Optional(NonEmptyString),
  /** Agent scope for list-style usage queries. */
  agentId: Type.Optional(NonEmptyString),
  /** Explicit all-agent scope for list-style usage queries. */
  agentScope: Type.Optional(Type.Literal("all")),
  /** Opaque creator identity returned by sessions.usage; filters before the row limit. */
  creatorKey: Type.Optional(NonEmptyString),
  startDate: Type.Optional(Type.String({ pattern: "^\\d{4}-\\d{2}-\\d{2}$" })),
  endDate: Type.Optional(Type.String({ pattern: "^\\d{4}-\\d{2}-\\d{2}$" })),
  /** How start/end dates should be interpreted. Defaults to UTC when omitted. */
  mode: Type.Optional(stringLiteralUnion(["utc", "gateway", "specific"])),
  /** Preset range for usage queries when explicit start/end dates are omitted. */
  range: Type.Optional(stringLiteralUnion(["7d", "30d", "90d", "1y", "all"])),
  /** Usage row grouping. `family` rolls up known rotated session ids for a logical key. */
  groupBy: Type.Optional(stringLiteralUnion(["instance", "family"])),
  /** Backward-compatible alias for requesting family grouping. */
  includeHistorical: Type.Optional(
    Type.Boolean({
      deprecated: true,
      description: "Deprecated alias for groupBy: family.",
    }),
  ),
  /** UTC offset to use when mode is `specific` (for example, UTC-4 or UTC+5:30). */
  utcOffset: Type.Optional(
    Type.String({
      pattern: "^UTC[+-]\\d{1,2}(?::[0-5]\\d)?$",
      deprecated: true,
      description: "Deprecated compatibility fallback; use timeZone.",
    }),
  ),
  /** IANA time zone for `specific`; preferred over `utcOffset`, which remains a compatibility fallback. */
  timeZone: Type.Optional(NonEmptyString),
  /** Maximum sessions to return (default 50). */
  limit: Type.Optional(Type.Integer({ minimum: 1 })),
  /** Bounded, server-filtered usage view; omitted preserves the full legacy projection. */
  projection: Type.Optional(Type.Literal("overview")),
  offset: Type.Optional(Type.Integer({ minimum: 0 })),
  query: Type.Optional(Type.String()),
  selectedDays: Type.Optional(Type.Array(Type.String({ pattern: "^\\d{4}-\\d{2}-\\d{2}$" }))),
  selectedHours: Type.Optional(Type.Array(Type.Integer({ minimum: 0, maximum: 23 }))),
  selectedSessions: Type.Optional(Type.Array(NonEmptyString)),
  /** Restrict only the comparison roster; charts keep their selected population. */
  recentKeys: Type.Optional(Type.Array(NonEmptyString, { maxItems: 8 })),
  sort: Type.Optional(stringLiteralUnion(["recent", "tokens", "cost", "messages", "errors"])),
  sortDirection: Type.Optional(stringLiteralUnion(["asc", "desc"])),
  /** Include context weight breakdown (systemPromptReport). */
  includeContextWeight: Type.Optional(Type.Boolean()),
});

// Wire types derive directly from local schema consts so public d.ts graphs never
// pull in the ProtocolSchemas registry.
export type SessionsCleanupParams = Static<typeof SessionsCleanupParamsSchema>;
export type SessionsPreviewParams = Static<typeof SessionsPreviewParamsSchema>;
export type SessionsDescribeParams = Static<typeof SessionsDescribeParamsSchema>;
export type SessionOperationEvent = Static<typeof SessionOperationEventSchema>;
export type SessionObserverHealth = Static<typeof SessionObserverHealthSchema>;
export type SessionObserverPlanProgress = Static<typeof SessionObserverPlanProgressSchema>;
export type SessionObserverDigest = Static<typeof SessionObserverDigestSchema>;
export type SessionsObserverVisibilityParams = Static<
  typeof SessionsObserverVisibilityParamsSchema
>;
export type SessionsObserverVisibilityResult = Static<
  typeof SessionsObserverVisibilityResultSchema
>;
export type SessionCompanionExchange = Static<typeof SessionCompanionExchangeSchema>;
export type SessionsCompanionAskParams = Static<typeof SessionsCompanionAskParamsSchema>;
export type SessionsCompanionAskResult = Static<typeof SessionsCompanionAskResultSchema>;
export type SessionsCompanionStateParams = Static<typeof SessionsCompanionStateParamsSchema>;
export type SessionsCompanionStateResult = Static<typeof SessionsCompanionStateResultSchema>;
export type SessionsCompanionResetParams = Static<typeof SessionsCompanionResetParamsSchema>;
export type SessionsCompanionResetResult = Static<typeof SessionsCompanionResetResultSchema>;
export type SessionsRewindParams = Static<typeof SessionsRewindParamsSchema>;
export type SessionsForkParams = Static<typeof SessionsForkParamsSchema>;
export type SessionsRewindResult = Static<typeof SessionsRewindResultSchema>;
export type SessionsForkResult = Static<typeof SessionsForkResultSchema>;
export type SessionBranch = Static<typeof SessionBranchSchema>;
export type SessionsBranchesListParams = Static<typeof SessionsBranchesListParamsSchema>;
export type SessionsBranchesListResult = Static<typeof SessionsBranchesListResultSchema>;
export type SessionsBranchesSwitchParams = Static<typeof SessionsBranchesSwitchParamsSchema>;
export type SessionsBranchesSwitchResult = Static<typeof SessionsBranchesSwitchResultSchema>;
export type SessionWorktreeInfo = Static<typeof SessionWorktreeInfoSchema>;
export type SessionsCreateResult = Static<typeof SessionsCreateResultSchema>;
export type SessionsSendParams = Static<typeof SessionsSendParamsSchema>;
export type SessionsMessagesSubscribeParams = Static<typeof SessionsMessagesSubscribeParamsSchema>;
export type SessionNarrationEvent = Static<typeof SessionNarrationEventSchema>;
export type SessionsMessagesUnsubscribeParams = Static<
  typeof SessionsMessagesUnsubscribeParamsSchema
>;
export type SessionsAbortParams = Static<typeof SessionsAbortParamsSchema>;
export type SessionsPluginPatchParams = Static<typeof SessionsPluginPatchParamsSchema>;
export type SessionsPluginPatchResult = Static<typeof SessionsPluginPatchResultSchema>;
export type SessionsResetParams = Static<typeof SessionsResetParamsSchema>;
export type SessionsAssignOwnerParams = Static<typeof SessionsAssignOwnerParamsSchema>;
export type SessionsAssignOwnerResult = Static<typeof SessionsAssignOwnerResultSchema>;
export type SessionGroup = Static<typeof SessionGroupSchema>;
export type SessionGroupDefaults = Static<typeof SessionGroupDefaultsSchema>;
export type SessionsGroupsListParams = Static<typeof SessionsGroupsListParamsSchema>;
export type SessionsGroupsListResult = Static<typeof SessionsGroupsListResultSchema>;
export type SessionsGroupsDefaultsParams = Static<typeof SessionsGroupsDefaultsParamsSchema>;
export type SessionsGroupsDefaultsResult = Static<typeof SessionsGroupsDefaultsResultSchema>;
export type SessionsGroupsCreateParams = Static<typeof SessionsGroupsCreateParamsSchema>;
export type SessionsGroupsPutParams = Static<typeof SessionsGroupsPutParamsSchema>;
export type SessionsGroupsRenameParams = Static<typeof SessionsGroupsRenameParamsSchema>;
export type SessionsGroupsUpdateParams = Static<typeof SessionsGroupsUpdateParamsSchema>;
export type SessionsGroupsUpdateResult = Static<typeof SessionsGroupsUpdateResultSchema>;
export type SessionsGroupsDeleteParams = Static<typeof SessionsGroupsDeleteParamsSchema>;
export type SessionsGroupsMutationResult = Static<typeof SessionsGroupsMutationResultSchema>;
export type SessionsCompactParams = Static<typeof SessionsCompactParamsSchema>;
export type SessionsUsageParams = Static<typeof SessionsUsageParamsSchema>;
export type SessionDiffFileStatus = Static<typeof SessionDiffFileStatusSchema>;
export type SessionDiffFile = Static<typeof SessionDiffFileSchema>;
export type SessionDiffCommit = Static<typeof SessionDiffCommitSchema>;
export type SessionDiffScope = Static<typeof SessionDiffScopeSchema>;
export type SessionsDiffParams = Static<typeof SessionsDiffParamsSchema>;
export type SessionsDiffResult = Static<typeof SessionsDiffResultSchema>;
