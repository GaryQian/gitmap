import type { Static } from "typebox";
import { Type } from "typebox";
import { closedObject } from "./closed-object.js";
import { NonEmptyString } from "./primitives.js";
import { stringLiteralUnion } from "./string-literal-union.js";
import { UpdateRunRecordSchema } from "./update-runs.js";

/**
 * Gateway config and update protocol schemas.
 *
 * These payloads carry raw config text plus optional delivery context so the
 * gateway can report edits/restarts back to the originating channel.
 */
const ConfigSchemaLookupPathString = Type.String({
  minLength: 1,
  maxLength: 1024,
  pattern: "^[A-Za-z0-9_./\\[\\]\\-*]+$",
});

const ConfigDeliveryContextSchema = closedObject({
  channel: Type.Optional(Type.String()),
  to: Type.Optional(Type.String()),
  accountId: Type.Optional(Type.String()),
  threadId: Type.Optional(Type.Union([Type.String(), Type.Number()])),
});

/** Empty request payload for reading the current raw config. */
export const ConfigGetParamsSchema = closedObject({});

/** Full raw config replacement request with optional base hash guard. */
export const ConfigSetParamsSchema = closedObject({
  raw: NonEmptyString,
  baseHash: Type.Optional(NonEmptyString),
});

/** Shared config apply/patch payload with optional restart notification context. */
const ConfigApplyLikeParamProperties = {
  raw: NonEmptyString,
  baseHash: Type.Optional(NonEmptyString),
  sessionKey: Type.Optional(Type.String()),
  deliveryContext: Type.Optional(ConfigDeliveryContextSchema),
  note: Type.Optional(Type.String()),
  restartDelayMs: Type.Optional(Type.Integer({ minimum: 0 })),
} as const;

/** Raw config apply request that may schedule a restart. */
export const ConfigApplyParamsSchema = closedObject(ConfigApplyLikeParamProperties);
/** Raw config patch request that may schedule a restart. */
export const ConfigPatchParamsSchema = closedObject({
  ...ConfigApplyLikeParamProperties,
  replacePaths: Type.Optional(Type.Array(NonEmptyString, { maxItems: 256 })),
  response: Type.Optional(Type.Literal("summary")),
});

/** Empty request payload for fetching the generated config schema. */
export const ConfigSchemaParamsSchema = closedObject({});

/** Schema lookup request for one config path. */
export const ConfigSchemaLookupParamsSchema = closedObject({
  path: ConfigSchemaLookupPathString,
});

/** Request payload for cached status or an explicit checkout refresh. */
export const UpdateStatusParamsSchema = closedObject({
  refreshCheckout: Type.Optional(Type.Boolean()),
});

const UpdateCommitSchema = closedObject({
  sha: NonEmptyString,
  subject: Type.String({ maxLength: 120 }),
});

/** Backward-compatible update availability metadata. */
export const UpdateAvailableSchema = closedObject({
  currentVersion: NonEmptyString,
  latestVersion: NonEmptyString,
  channel: NonEmptyString,
  currentSha: Type.Optional(NonEmptyString),
  upstreamRef: Type.Optional(NonEmptyString),
  upstreamSha: Type.Optional(NonEmptyString),
  repositoryUrl: Type.Optional(NonEmptyString),
  commitsBehind: Type.Optional(Type.Integer({ minimum: 0 })),
  commits: Type.Optional(Type.Array(UpdateCommitSchema, { maxItems: 5 })),
});

const GitInstallMetadataProperties = {
  currentSha: Type.Optional(NonEmptyString),
  upstreamSha: Type.Optional(NonEmptyString),
  repositoryUrl: Type.Optional(NonEmptyString),
  commitAtMs: Type.Optional(Type.Integer({ minimum: 0 })),
  installedAtMs: Type.Optional(Type.Integer({ minimum: 0 })),
} as const;

const GitUpdateStatusSchema = Type.Union([
  closedObject({ ...GitInstallMetadataProperties, status: Type.Literal("current") }),
  closedObject({
    ...GitInstallMetadataProperties,
    status: Type.Literal("behind"),
    commitsBehind: Type.Integer({ minimum: 1 }),
  }),
  closedObject({
    ...GitInstallMetadataProperties,
    status: Type.Literal("ahead"),
    commitsAhead: Type.Integer({ minimum: 1 }),
  }),
  closedObject({
    ...GitInstallMetadataProperties,
    status: Type.Literal("diverged"),
    commitsAhead: Type.Integer({ minimum: 1 }),
    commitsBehind: Type.Integer({ minimum: 1 }),
  }),
  closedObject({
    ...GitInstallMetadataProperties,
    status: Type.Literal("unavailable"),
    reason: stringLiteralUnion([
      "fetch-failed",
      "no-upstream",
      "no-upstream-sha",
      "comparison-failed",
      "git-unavailable",
    ]),
  }),
]);

const ImmutableGenerationSha = Type.String({ pattern: "^[a-f0-9]{40}$" });
const ImmutableOperationId = Type.String({ format: "uuid" });

/** Recorded installation facts; preparation does not authorize activation. */
const UpdateImmutableInstallSchema = closedObject({
  root: NonEmptyString,
  currentSha: ImmutableGenerationSha,
  currentPath: NonEmptyString,
  activationEnabled: Type.Optional(Type.Boolean()),
  releaseRetention: Type.Optional(
    closedObject({
      version: Type.Literal(1),
      mode: Type.Literal("inspect"),
      keepVerifiedGenerations: Type.Literal(3),
      pins: Type.Array(closedObject({ sha: ImmutableGenerationSha, identity: NonEmptyString })),
      generations: Type.Array(
        closedObject({
          sha: ImmutableGenerationSha,
          path: NonEmptyString,
          identity: NonEmptyString,
          buildDigest: Type.String({ pattern: "^[a-f0-9]{64}$" }),
          publishedRevision: Type.Integer({ minimum: 0 }),
          verifiedRevision: Type.Union([Type.Integer({ minimum: 0 }), Type.Null()]),
        }),
      ),
    }),
  ),
  activation: Type.Optional(
    closedObject({
      operationId: ImmutableOperationId,
      phase: stringLiteralUnion([
        "prepared",
        "draining",
        "stopping",
        "stopped",
        "publishing",
        "starting",
        "verifying",
        "rollback-stopping",
        "rollback-publishing",
        "rollback-starting",
        "rolled-back",
        "recovery-required",
      ]),
      previousSha: ImmutableGenerationSha,
      candidateSha: ImmutableGenerationSha,
      failure: Type.Optional(NonEmptyString),
      recoveryCommand: Type.Optional(NonEmptyString),
    }),
  ),
  lastActivation: Type.Optional(
    closedObject({
      operationId: ImmutableOperationId,
      outcome: stringLiteralUnion(["succeeded", "rolled-back"]),
      selectedSha: ImmutableGenerationSha,
      verifiedAtMs: Type.Integer({ minimum: 0 }),
      gateway: Type.Optional(
        closedObject({
          pid: Type.Integer({ minimum: 1 }),
          bootId: NonEmptyString,
          version: NonEmptyString,
          buildId: NonEmptyString,
        }),
      ),
    }),
  ),
  prepared: Type.Optional(
    closedObject({
      sha: ImmutableGenerationSha,
      path: NonEmptyString,
      buildDigest: Type.String({ pattern: "^[a-f0-9]{64}$" }),
      preparedAtMs: Type.Integer({ minimum: 0 }),
    }),
  ),
});

/** Authoritative automatic-update schedule and in-memory campaign state. */
export const UpdateScheduleStateSchema = closedObject({
  channel: NonEmptyString,
  autoEnabled: Type.Boolean(),
  install: Type.Optional(
    closedObject({
      kind: stringLiteralUnion(["package", "git", "immutable", "unknown"]),
      git: Type.Optional(GitUpdateStatusSchema),
      immutable: Type.Optional(UpdateImmutableInstallSchema),
    }),
  ),
  target: Type.Optional(
    Type.Union([
      closedObject({
        kind: Type.Literal("package"),
        version: NonEmptyString,
      }),
      closedObject({
        kind: Type.Literal("git"),
        upstreamRef: NonEmptyString,
        upstreamSha: NonEmptyString,
        commitsBehind: Type.Integer({ minimum: 0 }),
      }),
    ]),
  ),
  campaign: Type.Optional(
    closedObject({
      id: NonEmptyString,
      state: stringLiteralUnion(["waiting-for-idle", "countdown", "applying"]),
      announcedAtMs: Type.Integer({ minimum: 0 }),
      applyAtMs: Type.Optional(Type.Integer({ minimum: 0 })),
      holdUntilMs: Type.Optional(Type.Integer({ minimum: 0 })),
      forceAtMs: Type.Integer({ minimum: 0 }),
      updatedAtMs: Type.Integer({ minimum: 0 }),
    }),
  ),
});

/** Validated response payload for update.status. */
export const UpdateStatusResultSchema = closedObject({
  sentinel: Type.Unknown(),
  updateAvailable: Type.Union([UpdateAvailableSchema, Type.Null()]),
  activeRun: Type.Optional(UpdateRunRecordSchema),
  lastRun: Type.Optional(UpdateRunRecordSchema),
  effectiveChannel: Type.Optional(stringLiteralUnion(["stable", "extended-stable", "beta", "dev"])),
  schedule: Type.Optional(UpdateScheduleStateSchema),
});

/** Empty request payload for deferring the active update campaign. */
export const UpdateHoldParamsSchema = closedObject({});

/** Result of attempting to defer the active update campaign. */
export const UpdateHoldResultSchema = closedObject({
  ok: Type.Boolean(),
  schedule: Type.Optional(UpdateScheduleStateSchema),
});

/** Request payload for running an update/restart flow with optional channel delivery context. */
export const UpdateRunParamsSchema = closedObject({
  requester: Type.Optional(
    closedObject({
      channel: Type.Optional(Type.String()),
      accountId: Type.Optional(Type.String()),
      senderId: Type.Optional(Type.String()),
    }),
  ),
  sessionKey: Type.Optional(Type.String()),
  deliveryContext: Type.Optional(ConfigDeliveryContextSchema),
  note: Type.Optional(Type.String()),
  continuationMessage: Type.Optional(Type.String()),
  restartDelayMs: Type.Optional(Type.Integer({ minimum: 0 })),
  timeoutMs: Type.Optional(Type.Integer({ minimum: 1 })),
  target: Type.Optional(
    closedObject({
      kind: Type.Literal("git"),
      upstreamRef: Type.String({
        minLength: 1,
        pattern: "^[^\\s\\u0000-\\u001f\\u007f-\\u009f]+$",
      }),
      upstreamSha: Type.String({ pattern: "^[a-fA-F0-9]{40}$" }),
    }),
  ),
});

/** Explicit two-step request for previewing or submitting one failed update report. */
export const UpdateReportParamsSchema = Type.Union([
  closedObject({
    action: Type.Literal("preview"),
    attemptId: Type.String({ minLength: 1, maxLength: 256 }),
  }),
  closedObject({
    action: Type.Literal("submit"),
    attemptId: Type.String({ minLength: 1, maxLength: 256 }),
    previewDigest: Type.String({ pattern: "^[a-f0-9]{64}$" }),
  }),
]);

const UpdateReportUrlSchema = Type.String({ minLength: 1, maxLength: 16_384 });

/** Result of a consent-gated update failure report action. */
export const UpdateReportResultSchema = Type.Union([
  closedObject({
    status: Type.Literal("ready"),
    attemptId: Type.String({ minLength: 1, maxLength: 256 }),
    body: Type.String({ maxLength: 16_000 }),
    previewDigest: Type.String({ pattern: "^[a-f0-9]{64}$" }),
    title: Type.String({ minLength: 1, maxLength: 200 }),
  }),
  closedObject({
    status: Type.Literal("created"),
    message: Type.Optional(Type.String({ maxLength: 512 })),
    url: UpdateReportUrlSchema,
  }),
  closedObject({
    status: Type.Literal("fallback"),
    fallbackUrl: UpdateReportUrlSchema,
    message: Type.String({ maxLength: 512 }),
  }),
  closedObject({
    status: Type.Literal("pending"),
    message: Type.String({ maxLength: 512 }),
  }),
  closedObject({
    status: Type.Literal("retryable"),
    message: Type.String({ maxLength: 512 }),
  }),
  closedObject({
    status: Type.Literal("duplicate"),
    fallbackUrl: Type.Optional(UpdateReportUrlSchema),
    message: Type.String({ maxLength: 512 }),
    url: Type.Optional(UpdateReportUrlSchema),
  }),
]);

/** UI metadata attached to config schema paths. */
const ConfigUiHintSchema = closedObject({
  label: Type.Optional(Type.String()),
  help: Type.Optional(Type.String()),
  docsUrl: Type.Optional(Type.String()),
  tags: Type.Optional(Type.Array(Type.String())),
  group: Type.Optional(Type.String()),
  groups: Type.Optional(
    Type.Array(
      closedObject({
        id: NonEmptyString,
        title: NonEmptyString,
        order: Type.Optional(Type.Integer()),
        properties: Type.Array(NonEmptyString),
      }),
    ),
  ),
  order: Type.Optional(Type.Integer()),
  advanced: Type.Optional(Type.Boolean()),
  sensitive: Type.Optional(Type.Boolean()),
  placeholder: Type.Optional(Type.String()),
  multiline: Type.Optional(Type.Boolean()),
  // The placeholder describes an inherited default, not an example input.
  inheritedDefault: Type.Optional(Type.Boolean()),
  presentation: Type.Optional(Type.Literal("phone-number")),
  itemTemplate: Type.Optional(Type.Unknown()),
});

/** Full generated config schema response. */
export const ConfigSchemaResponseSchema = closedObject({
  schema: Type.Unknown(),
  uiHints: Type.Record(Type.String(), ConfigUiHintSchema),
  version: NonEmptyString,
  generatedAt: NonEmptyString,
});

/** Child entry returned when looking up a config schema path. */
const ConfigSchemaLookupChildSchema = closedObject({
  key: NonEmptyString,
  path: NonEmptyString,
  type: Type.Optional(Type.Union([Type.String(), Type.Array(Type.String())])),
  required: Type.Boolean(),
  hasChildren: Type.Boolean(),
  reloadKind: Type.Optional(stringLiteralUnion(["restart", "hot", "none"])),
  hint: Type.Optional(ConfigUiHintSchema),
  hintPath: Type.Optional(Type.String()),
});

/** Schema lookup response for one config path and its immediate children. */
export const ConfigSchemaLookupResultSchema = closedObject({
  path: NonEmptyString,
  schema: Type.Unknown(),
  reloadKind: ConfigSchemaLookupChildSchema.properties.reloadKind,
  hint: Type.Optional(ConfigUiHintSchema),
  hintPath: Type.Optional(Type.String()),
  children: Type.Array(ConfigSchemaLookupChildSchema),
});

// Wire types derive directly from local schema consts so public d.ts graphs never
// pull in the ProtocolSchemas registry.
export type ConfigGetParams = Static<typeof ConfigGetParamsSchema>;
export type ConfigSetParams = Static<typeof ConfigSetParamsSchema>;
export type ConfigApplyParams = Static<typeof ConfigApplyParamsSchema>;
export type ConfigPatchParams = Static<typeof ConfigPatchParamsSchema>;
export type ConfigSchemaParams = Static<typeof ConfigSchemaParamsSchema>;
export type ConfigSchemaLookupParams = Static<typeof ConfigSchemaLookupParamsSchema>;
export type ConfigSchemaResponse = Static<typeof ConfigSchemaResponseSchema>;
export type ConfigSchemaLookupResult = Static<typeof ConfigSchemaLookupResultSchema>;
export type UpdateStatusParams = Static<typeof UpdateStatusParamsSchema>;
export type UpdateAvailable = Static<typeof UpdateAvailableSchema>;
export type UpdateImmutableInstall = Static<typeof UpdateImmutableInstallSchema>;
export type UpdateScheduleState = Static<typeof UpdateScheduleStateSchema>;
export type UpdateStatusResult = Static<typeof UpdateStatusResultSchema>;
export type UpdateHoldParams = Static<typeof UpdateHoldParamsSchema>;
export type UpdateHoldResult = Static<typeof UpdateHoldResultSchema>;
export type UpdateRunParams = Static<typeof UpdateRunParamsSchema>;
export type UpdateReportParams = Static<typeof UpdateReportParamsSchema>;
export type UpdateReportResult = Static<typeof UpdateReportResultSchema>;
