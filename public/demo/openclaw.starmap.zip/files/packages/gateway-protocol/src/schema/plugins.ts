import type { Static } from "typebox";
import { Type } from "typebox";
import { PLUGIN_UI_CAPABILITIES } from "../plugin-ui-capabilities.js";
import {
  ClawHubDownloadabilitySchema,
  ClawHubSelectedReleaseSchema,
  ClawHubPluginMetadataSchema,
  ClawHubPluginConfigFieldSchema,
  ClawHubPluginMcpServerSchema,
} from "./clawhub-listing.js";
import { closedObject } from "./closed-object.js";
import {
  ControlUiLinkReaderMetadataSchema,
  ControlUiLinkReaderDescriptorSchema,
} from "./control-ui-link-reader.js";
import { PluginCatalogInstallActionSchema } from "./plugin-catalog-install.js";
import { PluginSdkDeprecationNoticeSchema } from "./plugin-compatibility.js";
import { PluginCredentialDescriptorSchema } from "./plugin-credentials.js";
import {
  PluginDecisionProviderStatusSchema,
  PluginDeclaredSurfaceSchema,
  PluginHookGrantSchema,
  PluginInspectSourceSchema,
  PluginInstalledComponentsSchema,
  PluginInstallTrustSchema,
  PluginOperatorGrantsSchema,
} from "./plugin-inspection.js";
import { PluginJsonValueSchema } from "./plugin-json-value.js";
import { PluginInspectRuntimeRetentionSchema } from "./plugin-retention.js";
import { NonEmptyString } from "./primitives.js";
import { RecommendedPromptsSchema } from "./recommended-prompts.js";
import { stringLiteralUnion } from "./string-literal-union.js";

export {
  PluginCatalogClawHubInstallSchema,
  PluginCatalogOfficialInstallSchema,
  PluginCatalogInstallActionSchema,
} from "./plugin-catalog-install.js";

export { PluginJsonValueSchema } from "./plugin-json-value.js";

export {
  PLUGIN_UI_CAPABILITIES,
  validatePluginUiCapabilities,
  type PluginUiCapability,
} from "../plugin-ui-capabilities.js";

export {
  PluginInstallActivitySchema,
  PluginsInstallProgressEventSchema,
  type PluginInstallActivity,
  type PluginsInstallProgressEvent,
} from "./plugin-install-progress.js";

export {
  PluginDecisionProviderStatusSchema,
  PluginDeclaredSurfaceSchema,
  PluginHookGrantSchema,
  PluginInspectSourceSchema,
  PluginInstalledComponentsSchema,
  PluginInstallTrustSchema,
  PluginOperatorGrantsSchema,
} from "./plugin-inspection.js";

export {
  ControlUiLinkReaderMetadataSchema,
  ControlUiLinkReaderDescriptorSchema,
} from "./control-ui-link-reader.js";

/**
 * Plugin control-surface protocol schemas.
 *
 * These payloads let the gateway expose plugin-provided UI actions without
 * baking plugin-specific payload shapes into the core protocol.
 */

export const PluginControlUiDescriptorSchema = closedObject({
  id: NonEmptyString,
  pluginId: NonEmptyString,
  pluginName: Type.Optional(NonEmptyString),
  surface: stringLiteralUnion([
    "session",
    "tool",
    "run",
    "settings",
    "tab",
    "widget",
    "link-reader",
    "inline",
  ]),
  linkReader: Type.Optional(ControlUiLinkReaderMetadataSchema),
  label: NonEmptyString,
  description: Type.Optional(Type.String()),
  icon: Type.Optional(Type.String()),
  path: Type.Optional(Type.String()),
  placement: Type.Optional(Type.String()),
  group: Type.Optional(stringLiteralUnion(["control", "agent"])),
  order: Type.Optional(Type.Number()),
  version: Type.Optional(Type.Integer({ minimum: 1, maximum: 65535 })),
  schema: Type.Optional(PluginJsonValueSchema),
  requiredScopes: Type.Optional(Type.Array(NonEmptyString)),
});

export const PluginsUiDescriptorsParamsSchema = closedObject({});

export const ControlUiPluginTabSchema = closedObject({
  pluginId: NonEmptyString,
  id: NonEmptyString,
  label: NonEmptyString,
  description: Type.Optional(Type.String()),
  icon: Type.Optional(Type.String()),
  path: Type.Optional(Type.String()),
  placement: Type.Optional(Type.String()),
  slug: Type.Optional(Type.String({ pattern: "^[a-z0-9]+(?:-[a-z0-9]+)*$", maxLength: 64 })),
  requiresGatewayAuth: Type.Optional(Type.Boolean()),
  group: Type.Optional(stringLiteralUnion(["control", "agent"])),
  order: Type.Optional(Type.Number()),
});

export const ControlUiPluginWidgetKindSchema = closedObject({
  pluginId: NonEmptyString,
  kind: NonEmptyString,
  label: NonEmptyString,
});

export const PluginsUiDescriptorsResultSchema = closedObject({
  ok: Type.Literal(true),
  descriptors: Type.Array(PluginControlUiDescriptorSchema),
  generation: Type.Optional(Type.Integer({ minimum: 0 })),
  methods: Type.Optional(Type.Array(NonEmptyString)),
  controlUiTabs: Type.Optional(Type.Array(ControlUiPluginTabSchema)),
  controlUiWidgetKinds: Type.Optional(Type.Array(ControlUiPluginWidgetKindSchema)),
  controlUiLinkReaders: Type.Optional(Type.Array(ControlUiLinkReaderDescriptorSchema)),
  pluginSurfaceUrls: Type.Optional(Type.Record(NonEmptyString, NonEmptyString)),
});

export const PluginUiCapabilitySchema = Type.Enum(PLUGIN_UI_CAPABILITIES, { type: "string" });
const PluginUiCapabilitiesSchema = Type.Array(PluginUiCapabilitySchema, {
  maxItems: PLUGIN_UI_CAPABILITIES.length,
  uniqueItems: true,
});

/** One immutable browser build owned by an active native plugin. */
export const PluginControlUiModuleSchema = closedObject({
  pluginId: NonEmptyString,
  name: NonEmptyString,
  revision: NonEmptyString,
  entryUrl: NonEmptyString,
  panelIcon: Type.Optional(Type.String({ maxLength: 16 * 1024 * 3 + 64 })),
  imports: Type.Optional(Type.Array(NonEmptyString, { maxItems: 128 })),
  uiCapabilities: Type.Optional(PluginUiCapabilitiesSchema),
  // Host-owned runtime provenance; plugin manifests cannot opt into this delivery route.
  bundledDistribution: Type.Optional(
    closedObject({ packageName: NonEmptyString, packageVersion: NonEmptyString }),
  ),
  styles: Type.Array(NonEmptyString, { maxItems: 16 }),
});

export const PluginControlUiDiagnosticSchema = closedObject({
  pluginId: NonEmptyString,
  message: Type.String({ maxLength: 512 }),
  code: Type.Optional(Type.Literal("custom-plugin-ui-disabled")),
});

/** Lists browser builds; reading this catalog never reloads backend plugin code. */
export const PluginsControlUiListParamsSchema = closedObject({});
export const PluginsControlUiReloadParamsSchema = closedObject({
  pluginId: Type.Optional(NonEmptyString),
});
export const PluginsControlUiCatalogSchema = closedObject({
  revision: NonEmptyString,
  plugins: Type.Array(PluginControlUiModuleSchema, { maxItems: 64 }),
  inlineViews: Type.Optional(
    Type.Array(
      closedObject({
        pluginId: NonEmptyString,
        id: NonEmptyString,
        label: NonEmptyString,
        version: Type.Integer({ minimum: 1, maximum: 65535 }),
      }),
    ),
  ),
  diagnostics: Type.Array(PluginControlUiDiagnosticSchema, { maxItems: 64 }),
});
export const PluginsControlUiChangedEventSchema = closedObject({ revision: NonEmptyString });
const PluginControlUiActivationSchema = closedObject({
  pluginId: NonEmptyString,
  revision: NonEmptyString,
  status: stringLiteralUnion(["activated", "failed"]),
  error: Type.Optional(Type.String({ maxLength: 512 })),
});
export const PluginsControlUiReportParamsSchema = closedObject({
  reports: Type.Array(PluginControlUiActivationSchema, { minItems: 1, maxItems: 64 }),
});
export const PluginsControlUiStatusParamsSchema = closedObject({
  pluginId: Type.Optional(NonEmptyString),
});
export const PluginsControlUiStatusResultSchema = closedObject({
  clients: Type.Array(
    closedObject({
      connId: NonEmptyString,
      activations: Type.Array(PluginControlUiActivationSchema, { maxItems: 64 }),
    }),
    { maxItems: 128 },
  ),
});

export const PluginsSessionActionParamsSchema = closedObject({
  pluginId: NonEmptyString,
  actionId: NonEmptyString,
  sessionKey: Type.Optional(NonEmptyString),
  agentId: Type.Optional(NonEmptyString),
  payload: Type.Optional(PluginJsonValueSchema),
});

export const PluginsSessionActionSuccessResultSchema = closedObject({
  ok: Type.Literal(true),
  result: Type.Optional(PluginJsonValueSchema),
  continueAgent: Type.Optional(Type.Boolean()),
  reply: Type.Optional(PluginJsonValueSchema),
});

/** Failed plugin action result with plugin-owned detail payload. */
export const PluginsSessionActionFailureResultSchema = closedObject({
  ok: Type.Literal(false),
  error: Type.String(),
  code: Type.Optional(Type.String()),
  details: Type.Optional(PluginJsonValueSchema),
});

export const PluginsSessionActionResultSchema = Type.Union([
  PluginsSessionActionSuccessResultSchema,
  PluginsSessionActionFailureResultSchema,
]);

/** Observed state of the plugin in the current Gateway runtime generation. */
export const PluginRuntimeStatusSchema = closedObject({
  state: stringLiteralUnion(["unloaded", "disabled", "active", "service-failed"]),
  error: Type.Optional(Type.String()),
});

/** Catalog metadata and desired enablement, with optional observed runtime state. */
export const PluginCatalogEntrySchema = closedObject({
  id: NonEmptyString,
  name: NonEmptyString,
  packageName: Type.Optional(NonEmptyString),
  /** Canonical ClawHub identity proven by install provenance or the official catalog. */
  clawhubPackage: Type.Optional(NonEmptyString),
  /** Opaque discovery identity for loading local or ClawHub presentation metadata. */
  catalogId: Type.Optional(NonEmptyString),
  description: Type.Optional(Type.String()),
  recommendedPrompts: Type.Optional(RecommendedPromptsSchema),
  version: Type.Optional(NonEmptyString),
  kind: Type.Optional(Type.Array(NonEmptyString)),
  origin: Type.Optional(NonEmptyString),
  installed: Type.Boolean(),
  enabled: Type.Boolean(),
  state: stringLiteralUnion(["enabled", "disabled", "needs-setup", "not-installed", "error"]),
  featured: Type.Optional(Type.Boolean()),
  featuredAt: Type.Optional(Type.Integer({ minimum: 0 })),
  order: Type.Optional(Type.Number()),
  /** Manifest hint: list this bundled plugin with installed plugins while it is enabled. */
  sidebar: Type.Optional(Type.Boolean()),
  /** Install-record time in epoch milliseconds; bundled plugins have none. */
  installedAt: Type.Optional(Type.Integer({ minimum: 0 })),
  /** Selected installed manifest declares a native Control UI entry; not a sandbox or grant. */
  hasNativeUi: Type.Optional(Type.Boolean()),
  /** True when the gateway can resolve a manifest or catalog icon for this plugin identity. */
  hasIcon: Type.Optional(Type.Boolean()),
  /** Usable branding for tools: nonbundled, with a proven non-OpenClaw ClawHub publisher. */
  hasToolBrandIcon: Type.Optional(Type.Boolean()),
  /** True when the installed package supplies a default compact activity glyph. */
  hasActivityIcon: Type.Optional(Type.Boolean()),
  /** Exact effective tool IDs with package-owned activity glyph overrides. */
  activityIconTools: Type.Optional(
    Type.Array(
      Type.String({
        minLength: 1,
        maxLength: 128,
        pattern: "^[A-Za-z0-9_][A-Za-z0-9_.-]*$",
      }),
      { maxItems: 128 },
    ),
  ),
  /** Channel identities declared by this installed plugin. */
  channelIds: Type.Optional(Type.Array(NonEmptyString)),
  install: Type.Optional(PluginCatalogInstallActionSchema),
  error: Type.Optional(Type.String()),
  runtime: Type.Optional(PluginRuntimeStatusSchema),
  compatibilityNotices: Type.Optional(Type.Array(PluginSdkDeprecationNoticeSchema)),
  /** Ordered package or registry categories; the first category is primary. */
  categories: Type.Optional(Type.Array(NonEmptyString, { minItems: 1, maxItems: 3 })),
  /** Additional browse memberships derived from enabled plugins' declared capabilities. */
  capabilityCategories: Type.Optional(Type.Array(NonEmptyString, { uniqueItems: true })),
  /** Compatibility projection of the primary category. */
  category: Type.Optional(NonEmptyString),
  /** True when the plugin has an install record and can be removed via plugins.uninstall. */
  removable: Type.Optional(Type.Boolean()),
});

/** Empty request payload for the cold plugin catalog. */
export const PluginsListParamsSchema = closedObject({});

/** Installed and curated plugin catalog visible to the current gateway client. */
export const PluginsListResultSchema = closedObject({
  generation: Type.Optional(Type.Integer({ minimum: 0 })),
  plugins: Type.Array(PluginCatalogEntrySchema),
  diagnostics: Type.Array(Type.Unknown()),
  mutationAllowed: Type.Boolean(),
});

/** Request payload for inspecting one plugin's declared capability surface. */
export const PluginsInspectParamsSchema = Type.Union([
  closedObject({ pluginId: NonEmptyString }),
  closedObject({
    source: Type.Literal("clawhub"),
    packageName: NonEmptyString,
    version: Type.Optional(NonEmptyString),
  }),
  closedObject({
    catalogId: Type.String({ minLength: 1, maxLength: 512, pattern: "^[A-Za-z0-9_-]+$" }),
    version: Type.Optional(NonEmptyString),
  }),
]);

/** Newly declared capability items grouped by their existing manifest surface. */
export const PluginDeclaredSurfaceWideningSchema = Type.Partial(PluginDeclaredSurfaceSchema, {
  additionalProperties: false,
});

/** Typed failure payload that lets clients review and acknowledge plugin capabilities. */
export const CapabilityConsentErrorDetailsSchema = closedObject({
  capabilityConsentCode: Type.Literal("PLUGIN_CAPABILITY_CONSENT_REQUIRED"),
  pluginId: NonEmptyString,
  reviewToken: NonEmptyString,
  widened: Type.Optional(PluginDeclaredSurfaceWideningSchema),
  acceptedAt: Type.Optional(NonEmptyString),
});

const PluginCapabilityAcknowledgmentSchema = closedObject({
  reviewToken: NonEmptyString,
});

/** Request payload for searching installable ClawHub plugin families. */
export const PluginsSearchParamsSchema = closedObject({
  query: NonEmptyString,
  limit: Type.Optional(Type.Integer({ minimum: 1, maximum: 100 })),
});

export const PluginSearchPackageSchema = closedObject({
  name: NonEmptyString,
  displayName: NonEmptyString,
  family: stringLiteralUnion(["code-plugin", "bundle-plugin"]),
  channel: stringLiteralUnion(["official", "community", "private"]),
  isOfficial: Type.Boolean(),
  summary: Type.Optional(Type.String()),
  latestVersion: Type.Optional(NonEmptyString),
  runtimeId: Type.Optional(NonEmptyString),
  downloads: Type.Optional(Type.Number({ minimum: 0 })),
  verificationTier: Type.Optional(NonEmptyString),
});

export const PluginSearchResultEntrySchema = closedObject({
  score: Type.Number(),
  package: PluginSearchPackageSchema,
});

/** Ranked installable plugin packages matching the query. */
export const PluginsSearchResultSchema = closedObject({
  results: Type.Array(PluginSearchResultEntrySchema),
});

const PluginDiscoveryIntentSchema = stringLiteralUnion([
  "all",
  "bundled",
  "trending",
  "official",
  "featured",
]);

const PluginDiscoveryIconKeySchema = Type.String({
  minLength: 1,
  maxLength: 64,
  pattern: "^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$",
});

export const PluginDiscoveryCategorySchema = closedObject({
  slug: NonEmptyString,
  label: NonEmptyString,
  description: NonEmptyString,
  icon: PluginDiscoveryIconKeySchema,
  order: Type.Integer({ minimum: 0 }),
  pinnedPackages: Type.Optional(Type.Array(NonEmptyString, { uniqueItems: true })),
});

export const PluginDiscoveryCatalogFactsSchema = closedObject({
  name: NonEmptyString,
  packageName: Type.Optional(NonEmptyString),
  summary: Type.Optional(Type.String()),
  family: Type.Optional(stringLiteralUnion(["code-plugin", "bundle-plugin"])),
  author: Type.Optional(NonEmptyString),
  official: Type.Boolean(),
  categories: Type.Array(NonEmptyString),
  icon: Type.Optional(PluginDiscoveryIconKeySchema),
  imageUrl: Type.Optional(NonEmptyString),
  latestVersion: Type.Optional(NonEmptyString),
  downloads: Type.Optional(Type.Number({ minimum: 0 })),
  installs: Type.Optional(Type.Number({ minimum: 0 })),
  verificationTier: Type.Optional(NonEmptyString),
  featured: Type.Optional(Type.Boolean()),
  trending: Type.Optional(Type.Boolean()),
  featuredRank: Type.Optional(Type.Integer({ minimum: 0 })),
  trendingRank: Type.Optional(Type.Integer({ minimum: 0 })),
  categoryRanks: Type.Optional(Type.Record(NonEmptyString, Type.Integer({ minimum: 0 }))),
  publishedToClawHub: Type.Optional(Type.Boolean()),
});

export const PluginDiscoveryLocalFactsSchema = closedObject({
  present: Type.Boolean(),
  installed: Type.Boolean(),
  enabled: Type.Boolean(),
  state: PluginCatalogEntrySchema.properties.state,
  pluginId: Type.Optional(NonEmptyString),
  install: Type.Optional(PluginCatalogInstallActionSchema),
  action: stringLiteralUnion(["install", "manage", "unavailable"]),
});

export const PluginDiscoveryEntrySchema = closedObject({
  id: Type.String({ minLength: 1, maxLength: 512, pattern: "^[A-Za-z0-9_-]+$" }),
  catalog: PluginDiscoveryCatalogFactsSchema,
  local: PluginDiscoveryLocalFactsSchema,
});

export const PluginsCatalogBrowseParamsSchema = closedObject({
  query: Type.Optional(Type.String({ maxLength: 200 })),
  searchSource: Type.Optional(Type.Literal("openclaw-control-ui")),
  intent: Type.Optional(PluginDiscoveryIntentSchema),
  category: Type.Optional(
    Type.String({ minLength: 1, maxLength: 64, pattern: "^[a-z][a-z0-9-]*$" }),
  ),
  cursor: Type.Optional(Type.String({ minLength: 1, maxLength: 4096 })),
  pageSize: Type.Optional(Type.Integer({ minimum: 1, maximum: 100 })),
});

export const PluginsCatalogBrowseResultSchema = closedObject({
  items: Type.Array(PluginDiscoveryEntrySchema),
  categories: Type.Optional(Type.Array(PluginDiscoveryCategorySchema)),
  nextCursor: Type.Optional(Type.String({ minLength: 1, maxLength: 4096 })),
  remoteError: Type.Optional(Type.String()),
});

export const PluginsCatalogCategoriesParamsSchema = closedObject({});

export const PluginsCatalogCategoriesResultSchema = closedObject({
  categories: Type.Array(PluginDiscoveryCategorySchema),
});

export const PluginsCatalogGetParamsSchema = closedObject({
  id: Type.String({ minLength: 1, maxLength: 512, pattern: "^[A-Za-z0-9_-]+$" }),
  version: Type.Optional(NonEmptyString),
});

const PluginDiscoveryCompatibilitySchema = closedObject({
  pluginApiRange: Type.Optional(NonEmptyString),
  builtWithOpenClawVersion: Type.Optional(NonEmptyString),
  pluginSdkVersion: Type.Optional(NonEmptyString),
  minGatewayVersion: Type.Optional(NonEmptyString),
});

const PluginDiscoveryVersionSchema = closedObject({
  version: NonEmptyString,
  createdAt: Type.Integer({ minimum: 0 }),
  changelog: Type.String(),
  tags: Type.Array(NonEmptyString),
});

export const PluginDiscoveryDetailSchema = closedObject({
  origin: stringLiteralUnion(["clawhub", "local"]),
  packageName: Type.Optional(NonEmptyString),
  registry: Type.Optional(NonEmptyString),
  requestedVersion: Type.Optional(NonEmptyString),
  tags: Type.Optional(Type.Record(NonEmptyString, NonEmptyString)),
  selectedRelease: Type.Optional(Type.Union([ClawHubSelectedReleaseSchema, Type.Null()])),
  downloadability: Type.Optional(ClawHubDownloadabilitySchema),
  remoteError: Type.Optional(Type.String()),
  metadata: Type.Optional(ClawHubPluginMetadataSchema),
  author: Type.Optional(
    closedObject({
      handle: Type.Optional(NonEmptyString),
      displayName: Type.Optional(NonEmptyString),
      imageUrl: Type.Optional(NonEmptyString),
      official: Type.Optional(Type.Boolean()),
    }),
  ),
  topics: Type.Array(NonEmptyString),
  createdAt: Type.Optional(Type.Integer({ minimum: 0 })),
  updatedAt: Type.Optional(Type.Integer({ minimum: 0 })),
  readme: Type.Optional(Type.String({ maxLength: 524_288 })),
  repositoryUrl: Type.Optional(NonEmptyString),
  documentationUrl: Type.Optional(NonEmptyString),
  compatibility: Type.Optional(PluginDiscoveryCompatibilitySchema),
  contracts: Type.Optional(Type.Record(NonEmptyString, Type.Array(NonEmptyString))),
  providers: Type.Optional(Type.Array(NonEmptyString)),
  channels: Type.Optional(Type.Array(NonEmptyString)),
  uiCapabilities: Type.Optional(PluginUiCapabilitiesSchema),
  recommendedPrompts: Type.Optional(RecommendedPromptsSchema),
  configuration: Type.Array(ClawHubPluginConfigFieldSchema),
  mcpServers: Type.Array(NonEmptyString),
  mcpServerDetails: Type.Optional(Type.Array(ClawHubPluginMcpServerSchema)),
  skills: Type.Array(
    closedObject({
      name: NonEmptyString,
      description: Type.Optional(Type.String()),
    }),
  ),
  versions: Type.Array(PluginDiscoveryVersionSchema, { maxItems: 10 }),
  verification: Type.Optional(
    closedObject({
      tier: NonEmptyString,
      summary: Type.Optional(Type.String()),
      sourceRepo: Type.Optional(NonEmptyString),
      sourceCommit: Type.Optional(NonEmptyString),
      sourcePath: Type.Optional(NonEmptyString),
      scanStatus: Type.Optional(NonEmptyString),
    }),
  ),
  security: Type.Optional(
    closedObject({
      status: NonEmptyString,
      auditUrl: Type.Optional(NonEmptyString),
      verdict: Type.Optional(NonEmptyString),
      summary: Type.Optional(Type.String()),
      guidance: Type.Optional(Type.String()),
      checkedAt: Type.Optional(Type.Integer({ minimum: 0 })),
    }),
  ),
});

export const PluginsCatalogGetResultSchema = closedObject({
  plugin: PluginDiscoveryEntrySchema,
  detail: PluginDiscoveryDetailSchema,
});

const PluginOverviewCapabilitiesSchema = closedObject({
  ui: Type.Optional(PluginUiCapabilitiesSchema),
  providers: Type.Array(NonEmptyString),
  channels: Type.Array(NonEmptyString),
  contracts: Type.Record(NonEmptyString, Type.Array(NonEmptyString)),
});

/** Consent snapshot plus the installed-version presentation projection used by Control UI. */
export const PluginsInspectResultSchema = closedObject({
  ok: Type.Literal(true),
  overview: Type.Optional(
    closedObject({
      /** Selected inspected manifest declares native browser code, independently of UI capabilities. */
      hasNativeUi: Type.Optional(Type.Boolean()),
      readme: Type.Optional(Type.String({ maxLength: 524_288 })),
      repositoryUrl: Type.Optional(NonEmptyString),
      documentationUrl: Type.Optional(NonEmptyString),
      publisherName: Type.Optional(NonEmptyString),
      recommendedPrompts: Type.Optional(RecommendedPromptsSchema),
      /** Selected plugin metadata; declared below remains the package-wide consent surface. */
      capabilities: Type.Optional(PluginOverviewCapabilitiesSchema),
    }),
  ),
  credentials: Type.Optional(
    Type.Array(
      closedObject({
        ...PluginCredentialDescriptorSchema.properties,
        /** Presence/configuration only; never secret values or service-health validation. */
        status: stringLiteralUnion(["configured", "missing", "invalid", "unresolved"]),
      }),
    ),
  ),
  /** Stored shared OAuth state for matching plugin-owned, operator-configured HTTP servers. */
  mcpAuth: Type.Optional(
    Type.Array(
      closedObject({
        serverName: NonEmptyString,
        state: stringLiteralUnion([
          "authorized",
          "requires-authorization",
          "pending-authorization",
          "unauthenticated",
        ]),
      }),
    ),
  ),
  /** Live cross-session acquisition facts; emitted only for current administrators. */
  runtimeRetention: Type.Optional(Type.Union([PluginInspectRuntimeRetentionSchema, Type.Null()])),
  decisions: Type.Optional(Type.Array(PluginDecisionProviderStatusSchema)),
  plugin: closedObject({
    id: NonEmptyString,
    name: NonEmptyString,
    version: Type.Optional(NonEmptyString),
    description: Type.Optional(Type.String()),
    origin: Type.Optional(NonEmptyString),
    installed: Type.Boolean(),
    enabled: Type.Boolean(),
  }),
  source: Type.Optional(PluginInspectSourceSchema),
  declared: PluginDeclaredSurfaceSchema,
  components: PluginInstalledComponentsSchema,
  /** Catalog summaries are partial and cannot produce a capability-consent token. */
  reviewToken: Type.Optional(NonEmptyString),
  declaredSurfaceStatus: Type.Optional(stringLiteralUnion(["partial", "unavailable"])),
  grants: PluginOperatorGrantsSchema,
  trust: Type.Optional(PluginInstallTrustSchema),
  /** Exact installed-version ClawHub metadata when a canonical package match exists. */
  catalog: Type.Optional(PluginsCatalogGetResultSchema),
});

const PluginInstallOptions = {
  /** False preserves existing enablement policy while installing the source. */
  enable: Type.Optional(Type.Boolean()),
  mode: Type.Optional(stringLiteralUnion(["install", "update"])),
  acknowledgeInstallPolicyWarning: Type.Optional(Type.Literal(true)),
  acknowledgeCapabilities: Type.Optional(PluginCapabilityAcknowledgmentSchema),
};

/** Source intent only; install provenance and capability review remain host-owned. */
export const PluginsInstallParamsSchema = Type.Union([
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("clawhub"),
    packageName: NonEmptyString,
    version: Type.Optional(NonEmptyString),
    expectedPluginId: Type.Optional(NonEmptyString),
    expectedIntegrity: Type.Optional(NonEmptyString),
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("official"),
    pluginId: NonEmptyString,
    version: Type.Optional(Type.Literal("latest")),
    pin: Type.Optional(Type.Boolean()),
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("npm"),
    spec: NonEmptyString,
    pin: Type.Optional(Type.Boolean()),
    expectedPluginId: Type.Optional(NonEmptyString),
    expectedIntegrity: Type.Optional(NonEmptyString),
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("git"),
    spec: NonEmptyString,
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("local"),
    path: NonEmptyString,
    link: Type.Optional(Type.Boolean()),
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("npm-pack"),
    archivePath: NonEmptyString,
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("marketplace"),
    marketplace: NonEmptyString,
    plugin: NonEmptyString,
  }),
  closedObject({
    ...PluginInstallOptions,
    source: Type.Literal("bundled"),
    pluginId: NonEmptyString,
    spec: Type.Optional(NonEmptyString),
  }),
]);

/** Receipt emitted only after the requested runtime generation was applied. */
export const PluginRuntimeApplicationSchema = closedObject({
  operationId: NonEmptyString,
  generation: Type.Integer({ minimum: 0 }),
  pluginIds: Type.Array(NonEmptyString),
  sourceDigests: Type.Optional(Type.Record(NonEmptyString, NonEmptyString)),
  selectedEntries: Type.Optional(Type.Record(NonEmptyString, NonEmptyString)),
});

export const PluginsChangedEventSchema = closedObject({
  generation: Type.Integer({ minimum: 0 }),
});

export const PluginsInstallResultSchema = closedObject({
  ok: Type.Literal(true),
  plugin: PluginCatalogEntrySchema,
  restartRequired: Type.Boolean(),
  runtime: Type.Optional(PluginRuntimeApplicationSchema),
  warnings: Type.Optional(Type.Array(Type.String())),
});

/** Internal signal that persisted plugin metadata changed outside the Gateway process. */
export const PluginsRefreshParamsSchema = closedObject({});

export const PluginsRefreshResultSchema = closedObject({
  ok: Type.Literal(true),
  restartRequired: Type.Optional(Type.Boolean()),
  runtime: Type.Optional(PluginRuntimeApplicationSchema),
  warnings: Type.Optional(Type.Array(Type.String())),
});

/** Reload installed sources without changing their enabled policy. */
export const MAX_PLUGIN_RELOAD_TARGETS = 64;
export const PluginReloadTargetSchema = closedObject({
  pluginId: NonEmptyString,
  installHash: Type.Optional(Type.String({ pattern: "^[a-f0-9]{64}$" })),
  sourceDigests: Type.Optional(
    Type.Record(NonEmptyString, Type.String({ pattern: "^[a-f0-9]{64}$" })),
  ),
});
export const PluginsReloadParamsSchema = closedObject({
  plugins: Type.Array(PluginReloadTargetSchema, {
    minItems: 1,
    maxItems: MAX_PLUGIN_RELOAD_TARGETS,
    uniqueItems: true,
  }),
  waitForDrain: Type.Optional(Type.Boolean()),
  acknowledgeCapabilities: Type.Optional(PluginCapabilityAcknowledgmentSchema),
});
export const PluginsReloadResultSchema = closedObject({
  ok: Type.Literal(true),
  pluginIds: Type.Array(NonEmptyString, { minItems: 1, maxItems: MAX_PLUGIN_RELOAD_TARGETS }),
  restartRequired: Type.Boolean(),
  runtime: PluginRuntimeApplicationSchema,
  warnings: Type.Optional(Type.Array(Type.String())),
});

/** Request payload for removing one installed plugin and its managed files. */
export const PluginsUninstallParamsSchema = closedObject({
  pluginId: NonEmptyString,
  keepFiles: Type.Optional(Type.Boolean()),
});

/** Successful plugin removal result listing the cleanup actions that ran. */
export const PluginsUninstallResultSchema = closedObject({
  ok: Type.Literal(true),
  pluginId: NonEmptyString,
  restartRequired: Type.Boolean(),
  runtime: Type.Optional(PluginRuntimeApplicationSchema),
  removed: Type.Array(Type.String()),
  warnings: Type.Optional(Type.Array(Type.String())),
});

export const PluginsSetEnabledParamsSchema = closedObject({
  pluginId: NonEmptyString,
  enabled: Type.Boolean(),
  allowlistPolicy: Type.Optional(Type.Literal("preserve")),
  acknowledgeCapabilities: Type.Optional(PluginCapabilityAcknowledgmentSchema),
});

export const PluginsSetEnabledResultSchema = closedObject(PluginsInstallResultSchema.properties);

export type PluginCatalogEntry = Static<typeof PluginCatalogEntrySchema>;
export type ControlUiPluginTab = Static<typeof ControlUiPluginTabSchema>;
export type ControlUiPluginWidgetKind = Static<typeof ControlUiPluginWidgetKindSchema>;
export type PluginRuntimeStatus = Static<typeof PluginRuntimeStatusSchema>;
export type PluginsListParams = Static<typeof PluginsListParamsSchema>;
export type PluginsListResult = Static<typeof PluginsListResultSchema>;
export type PluginsInspectParams = Static<typeof PluginsInspectParamsSchema>;
export type PluginsInspectResult = Static<typeof PluginsInspectResultSchema>;
export type PluginOverviewCapabilities = Static<typeof PluginOverviewCapabilitiesSchema>;
export type PluginHookGrant = Static<typeof PluginHookGrantSchema>;
export type PluginInspectSource = Static<typeof PluginInspectSourceSchema>;
export type PluginDeclaredSurface = Static<typeof PluginDeclaredSurfaceSchema>;
export type PluginInstalledComponents = Static<typeof PluginInstalledComponentsSchema>;
export type PluginOperatorGrants = Static<typeof PluginOperatorGrantsSchema>;
export type PluginInstallTrust = Static<typeof PluginInstallTrustSchema>;
export type PluginsSearchParams = Static<typeof PluginsSearchParamsSchema>;
export type PluginsSearchResult = Static<typeof PluginsSearchResultSchema>;
export type PluginDiscoveryCategory = Static<typeof PluginDiscoveryCategorySchema>;
export type PluginDiscoveryCatalogFacts = Static<typeof PluginDiscoveryCatalogFactsSchema>;
export type PluginDiscoveryLocalFacts = Static<typeof PluginDiscoveryLocalFactsSchema>;
export type PluginDiscoveryEntry = Static<typeof PluginDiscoveryEntrySchema>;
export type PluginDiscoveryDetail = Static<typeof PluginDiscoveryDetailSchema>;
export type PluginsCatalogBrowseParams = Static<typeof PluginsCatalogBrowseParamsSchema>;
export type PluginsCatalogBrowseResult = Static<typeof PluginsCatalogBrowseResultSchema>;
export type PluginsCatalogCategoriesParams = Static<typeof PluginsCatalogCategoriesParamsSchema>;
export type PluginsCatalogCategoriesResult = Static<typeof PluginsCatalogCategoriesResultSchema>;
export type PluginsCatalogGetParams = Static<typeof PluginsCatalogGetParamsSchema>;
export type PluginsCatalogGetResult = Static<typeof PluginsCatalogGetResultSchema>;
export type PluginsInstallParams = Static<typeof PluginsInstallParamsSchema>;
export type PluginsInstallResult = Static<typeof PluginsInstallResultSchema>;
export type PluginsRefreshParams = Static<typeof PluginsRefreshParamsSchema>;
export type PluginsRefreshResult = Static<typeof PluginsRefreshResultSchema>;
export type PluginReloadTarget = Static<typeof PluginReloadTargetSchema>;
export type PluginsReloadParams = Static<typeof PluginsReloadParamsSchema>;
export type PluginsReloadResult = Static<typeof PluginsReloadResultSchema>;
export type PluginRuntimeApplication = Static<typeof PluginRuntimeApplicationSchema>;
export type PluginsChangedEvent = Static<typeof PluginsChangedEventSchema>;
export type PluginsUninstallParams = Static<typeof PluginsUninstallParamsSchema>;
export type PluginsUninstallResult = Static<typeof PluginsUninstallResultSchema>;
export type PluginsSetEnabledParams = Static<typeof PluginsSetEnabledParamsSchema>;
export type PluginsSetEnabledResult = Static<typeof PluginsSetEnabledResultSchema>;

// Wire types derive directly from local schema consts so public d.ts graphs never
// pull in the ProtocolSchemas registry.
export type PluginControlUiDescriptor = Static<typeof PluginControlUiDescriptorSchema>;
export type PluginsUiDescriptorsParams = Static<typeof PluginsUiDescriptorsParamsSchema>;
export type PluginsUiDescriptorsResult = Static<typeof PluginsUiDescriptorsResultSchema>;
export type PluginControlUiModule = Static<typeof PluginControlUiModuleSchema>;
export type PluginControlUiDiagnostic = Static<typeof PluginControlUiDiagnosticSchema>;
export type PluginsControlUiCatalog = Static<typeof PluginsControlUiCatalogSchema>;
export type PluginsControlUiReloadParams = Static<typeof PluginsControlUiReloadParamsSchema>;
export type PluginControlUiActivation = Static<typeof PluginControlUiActivationSchema>;
export type PluginsSessionActionParams = Static<typeof PluginsSessionActionParamsSchema>;
export type PluginsSessionActionResult = Static<typeof PluginsSessionActionResultSchema>;
