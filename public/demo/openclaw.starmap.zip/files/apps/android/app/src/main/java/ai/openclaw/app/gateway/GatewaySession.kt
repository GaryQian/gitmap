package ai.openclaw.app.gateway

import ai.openclaw.app.node.asArrayOrNull
import ai.openclaw.app.node.asObjectOrNull
import ai.openclaw.app.node.asStringOrNull
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlinx.coroutines.selects.onTimeout
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import okhttp3.Call
import okhttp3.EventListener
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.Buffer
import java.io.IOException
import java.net.ConnectException
import java.net.NoRouteToHostException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.URI
import java.net.UnknownHostException
import java.util.Base64
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.random.Random

/**
 * Identity advertised during gateway connect; these fields become the device row users approve.
 */
data class GatewayClientInfo(
  val id: String,
  val displayName: String?,
  val version: String,
  val platform: String,
  val mode: String,
  val instanceId: String?,
  val deviceFamily: String?,
  val modelIdentifier: String?,
)

internal fun GatewayClientInfo.toJsonObject(): JsonObject =
  buildJsonObject {
    put("id", JsonPrimitive(id))
    displayName?.let { put("displayName", JsonPrimitive(it)) }
    put("version", JsonPrimitive(version))
    put("platform", JsonPrimitive(platform))
    put("mode", JsonPrimitive(mode))
    instanceId?.let { put("instanceId", JsonPrimitive(it)) }
    deviceFamily?.let { put("deviceFamily", JsonPrimitive(it)) }
    modelIdentifier?.let { put("modelIdentifier", JsonPrimitive(it)) }
  }

data class GatewayLoadedImage(
  val bytes: ByteArray,
  val mimeType: String,
)

enum class TalkSessionCloseDisposition(
  val wireValue: String,
) {
  Abort("abort"),
  Detach("detach"),
}

enum class GatewayMediaKind(
  val wireValue: String,
  val maximumBufferedBytes: Long,
  val acceptHeader: String = "$wireValue/*",
) {
  Image("image", 12L * 1024L * 1024L),
  Audio("audio", 16L * 1024L * 1024L),
  Video("video", 0L),
  File("file", 100L * 1024L * 1024L, "*/*"), // Gateway document limit (media-core/constants).
  ;

  fun acceptsMimeType(mimeType: String): Boolean =
    // Files are exported, not rendered; the Gateway owns document admission.
    if (this == File) mimeType.isNotBlank() else mimeType.startsWith("$wireValue/")
}

sealed interface GatewayLoadedMedia {
  data class Buffered(
    val bytes: ByteArray,
    val mimeType: String,
    val headers: Map<String, String>,
    val client: OkHttpClient,
  ) : GatewayLoadedMedia

  /** A short-lived gateway capability resolved with the exact socket's HTTP transport policy. */
  data class Streaming(
    val url: String,
    val headers: Map<String, String>,
    val client: OkHttpClient,
    val mimeType: String?,
    val retryPreparingPlayback: Boolean,
  ) : GatewayLoadedMedia
}

private const val GATEWAY_PLAYBACK_PREPARATION_TIMEOUT_MS = 120_000L

/** Shared bounded backoff for both buffered fetches and Media3's streaming HTTP path. */
internal class GatewayPlaybackRetryState(
  private val startedAtMs: Long = SystemClock.elapsedRealtime(),
) {
  private var attempt = 0

  fun canAttempt(nowMs: Long = SystemClock.elapsedRealtime()): Boolean = nowMs - startedAtMs < GATEWAY_PLAYBACK_PREPARATION_TIMEOUT_MS

  fun nextDelayMs(nowMs: Long = SystemClock.elapsedRealtime()): Long? {
    val remainingMs = GATEWAY_PLAYBACK_PREPARATION_TIMEOUT_MS - (nowMs - startedAtMs).coerceAtLeast(0L)
    if (remainingMs <= 0L) return null
    val multiplier = 1L shl attempt.coerceAtMost(30)
    val delayMs = (500L * multiplier).coerceAtMost(5_000L)
    attempt += 1
    return delayMs.coerceAtMost(remainingMs)
  }
}

/** Keeps Media3's OkHttp data source in its loading state while a rendition is being prepared. */
internal class GatewayPreparingPlaybackInterceptor(
  private val nowMs: () -> Long = SystemClock::elapsedRealtime,
  private val sleepMs: (Long) -> Unit = Thread::sleep,
) : Interceptor {
  override fun intercept(chain: Interceptor.Chain): okhttp3.Response {
    val retry = GatewayPlaybackRetryState(startedAtMs = nowMs())
    while (true) {
      if (!retry.canAttempt(nowMs())) throw IOException("playback preparation timed out")
      val response = chain.proceed(chain.request())
      if (response.code != 202) return response
      val retryDelayMs = retry.nextDelayMs(nowMs()) ?: return response
      response.close()
      try {
        sleepMs(retryDelayMs)
      } catch (error: InterruptedException) {
        Thread.currentThread().interrupt()
        throw IOException("playback preparation interrupted", error)
      }
    }
  }
}

/**
 * Role, scopes, commands, and permission snapshot sent with the connect frame.
 */
data class GatewayConnectOptions(
  val role: String,
  val scopes: List<String>,
  val caps: List<String>,
  val commands: List<String>,
  val permissions: Map<String, Boolean>,
  val client: GatewayClientInfo,
  val userAgent: String? = null,
)

private enum class GatewayConnectAuthSource {
  DEVICE_TOKEN,
  SHARED_TOKEN,
  BOOTSTRAP_TOKEN,
  PASSWORD,
  NONE,
}

/**
 * Structured gateway error details, preserved for reconnect, authorization, and UI decisions.
 */
data class GatewayErrorDetails(
  val code: String?,
  val canRetryWithDeviceToken: Boolean,
  val recommendedNextStep: String?,
  val pauseReconnect: Boolean? = null,
  val reason: String? = null,
  val method: String? = null,
  val requestId: String? = null,
  val retryable: Boolean = false,
  val clientMinProtocol: Int? = null,
  val clientMaxProtocol: Int? = null,
  val expectedProtocol: Int? = null,
  val minimumProbeProtocol: Int? = null,
  val clawhubWarning: String? = null,
  val missingScope: String? = null,
  val requiredScopes: List<String> = emptyList(),
  val retryAfterMs: Int? = null,
)

data class GatewayMissingScopeErrorDetails(
  val missingScope: String,
  val requiredScopes: List<String>,
)

private val legacyMissingScopePattern = Regex("\\bmissing scope:\\s*([a-z0-9._-]+)", RegexOption.IGNORE_CASE)

private val gatewayApprovalRequestIdPattern = Regex("^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")

/** Keeps copied approval commands single-argument and safe for a gateway host shell. */
internal fun normalizeGatewayApprovalRequestId(requestId: String?): String? {
  val trimmed = requestId?.trim()?.takeIf { it.isNotEmpty() } ?: return null
  return trimmed.takeIf { gatewayApprovalRequestIdPattern.matches(it) }
}

/**
 * Server hello fields cached by the Android runtime after a successful connect.
 */
data class GatewayHelloSummary(
  val serverName: String?,
  val remoteAddress: String?,
  val serverVersion: String?,
  val mainSessionKey: String?,
  val updateAvailable: GatewayUpdateAvailableSummary?,
  val authRole: String? = null,
  val authScopes: List<String> = emptyList(),
  val authSessionCap: String? = null,
  val methods: Set<String>? = null,
  val capabilities: Set<String>? = null,
)

internal data class GatewaySessionRouting(
  val mainSessionKey: String?,
  val mainKey: String?,
)

data class GatewayUpdateAvailableSummary(
  val currentVersion: String?,
  val latestVersion: String?,
  val channel: String?,
)

internal fun parseGatewayUpdateAvailableSummary(value: JsonObject?): GatewayUpdateAvailableSummary? {
  if (value == null) return null
  return GatewayUpdateAvailableSummary(
    currentVersion = value["currentVersion"].asStringOrNull()?.trim()?.takeIf(String::isNotEmpty),
    latestVersion = value["latestVersion"].asStringOrNull()?.trim()?.takeIf(String::isNotEmpty),
    channel = value["channel"].asStringOrNull()?.trim()?.takeIf(String::isNotEmpty),
  )
}

private data class SelectedConnectAuth(
  val authToken: String?,
  val authBootstrapToken: String?,
  val authDeviceToken: String?,
  val authPassword: String?,
  val storedToken: String?,
  val storedScopes: List<String>,
  val authSource: GatewayConnectAuthSource,
)

private class GatewayConnectFailure(
  val gatewayError: GatewaySession.ErrorShape,
) : IllegalStateException(gatewayError.message)

internal sealed class GatewayRequestDefinitiveFailure(
  message: String,
) : IllegalStateException(message)

internal class GatewayRequestNotEnqueued(
  message: String,
) : GatewayRequestDefinitiveFailure(message)

internal class GatewayRequestRejected(
  val gatewayError: GatewaySession.ErrorShape,
) : GatewayRequestDefinitiveFailure("${gatewayError.code}: ${gatewayError.message}")

/** Request frame was sent, but no response proved whether the gateway applied it. */
internal class GatewayRequestOutcomeUnknown(
  message: String,
) : IllegalStateException(message)

internal enum class NodeEventSendOutcome {
  COMPLETED,
  DISCONNECTED,
  FAILED,
}

internal data class GatewayCanvasHostRoute(
  val url: String,
  val tlsFingerprintSha256: String?,
)

/** Preserve the first six retry slots; prolonged outages converge to a finite 30–60s timer band. */
internal fun gatewayReconnectDelayMs(attempt: Int): Long {
  val ceilingMs = if (attempt <= 6) 8_000L else 60_000L
  val delayMs = minOf(ceilingMs, (350.0 * Math.pow(1.7, attempt.toDouble())).toLong())
  return if (delayMs == 60_000L) Random.nextLong(30_000L, 60_001L) else delayMs
}

/** Select atomically: a timeout must not cancel a receive that already consumed the wake. */
@OptIn(ExperimentalCoroutinesApi::class)
internal suspend fun awaitGatewayReconnectSignal(
  signal: ReceiveChannel<Unit>,
  delayMs: Long,
): Boolean =
  select {
    signal.onReceive { true }
    onTimeout(delayMs) { false }
  }

internal const val GATEWAY_CONNECT_TIMEOUT_MS = 20_000L

/**
 * WebSocket RPC session that maintains gateway connection lifecycle, auth, events, and node invokes.
 */
class GatewaySession(
  private val scope: CoroutineScope,
  private val identityStore: DeviceIdentityStore,
  private val deviceAuthStore: DeviceAuthTokenStore,
  private val onConnected: (GatewayHelloSummary) -> Unit,
  private val onDisconnected: (message: String) -> Unit,
  private val onConnectFailure: (error: ErrorShape, pauseReconnect: Boolean) -> Unit = { _, _ -> },
  private val onEvent: (event: String, payloadJson: String?) -> Unit,
  private val onInvoke: (suspend (GatewayNodeInvokeRequest) -> InvokeResult)? = null,
  private val customHeadersProvider: ((stableId: String) -> Map<String, String>)? = null,
  private val connectTimeoutMs: Long = GATEWAY_CONNECT_TIMEOUT_MS,
  private val webSocketFactory: ((OkHttpClient, Request, WebSocketListener) -> WebSocket)? = null,
  private val lifecycleDispatcher: CoroutineDispatcher = Dispatchers.IO,
  private val ingressAuthorizationProvider: ((GatewayEndpoint) -> GatewayIngressAuthorization?)? = null,
) {
  private companion object {
    // Keep connect timeout above observed gateway unauthorized close on lower-end devices.
    private const val CONNECT_RPC_TIMEOUT_MS = 12_000L
  }

  data class InvokeResult(
    val ok: Boolean,
    val payloadJson: String?,
    val error: ErrorShape?,
  ) {
    companion object {
      fun ok(payloadJson: String?) = InvokeResult(ok = true, payloadJson = payloadJson, error = null)

      fun error(
        code: String,
        message: String,
      ) = InvokeResult(ok = false, payloadJson = null, error = ErrorShape(code = code, message = message))
    }
  }

  data class ErrorShape(
    val code: String,
    val message: String,
    val details: GatewayErrorDetails? = null,
    val retryable: Boolean = false,
  ) {
    /** Only the method-bound startup refusal proves this chat send did no handler work. */
    fun startupRetryDelayMs(method: String): Long? {
      if (
        method != "chat.send" || code != "UNAVAILABLE" || !retryable ||
        details?.reason != "startup-sidecars" || details.method != method
      ) {
        return null
      }
      return (details.retryAfterMs ?: 500).coerceIn(100, 2_000).toLong()
    }

    fun missingScopeDetails(): GatewayMissingScopeErrorDetails? {
      val details = details ?: return null
      val missingScope = details.missingScope?.trim().orEmpty()
      val requiredScopes = details.requiredScopes.map { it.trim() }
      if (details.code != "MISSING_SCOPE" || missingScope.isEmpty() || requiredScopes.any { it.isEmpty() }) {
        return null
      }
      return requiredScopes.takeIf { it.isNotEmpty() }?.let {
        GatewayMissingScopeErrorDetails(missingScope = missingScope, requiredScopes = it)
      }
    }

    fun missingScope(): String? {
      missingScopeDetails()?.let { return it.missingScope }
      if (code != "FORBIDDEN" && code != "INVALID_REQUEST") return null
      return legacyMissingScopePattern.find(message)?.groupValues?.getOrNull(1)
    }
  }

  /**
   * Structured RPC result used by callers that need error codes without exceptions.
   */
  data class RpcResult(
    val ok: Boolean,
    val payloadJson: String?,
    val error: ErrorShape?,
  )

  /** One ready physical WebSocket captured before queued work starts waiting. */
  internal class RequestLease internal constructor(
    val endpointStableId: String,
    private val isCurrentImpl: () -> Boolean = { true },
    private val commitIfCurrentImpl: ((block: () -> Unit) -> Boolean)? = null,
    private val advertisedMethods: Set<String> = emptySet(),
    val controlUiCredential: NativeControlUiCredential? = null,
    private val advertisedCapabilities: Set<String> = emptySet(),
    private val reconnectIfCurrentImpl: () -> Unit = {},
    private val requestImpl: suspend (method: String, paramsJson: String?, timeoutMs: Long, withEnqueue: (() -> Unit) -> Unit) -> String,
  ) {
    fun isCurrent(): Boolean = isCurrentImpl()

    fun supportsMethod(method: String): Boolean = method in advertisedMethods

    suspend fun closeTalkSession(
      sessionId: String,
      disposition: TalkSessionCloseDisposition,
      withEnqueue: (() -> Unit) -> Unit = { it() },
    ): String =
      try {
        request(
          "talk.session.close",
          buildJsonObject {
            put("sessionId", JsonPrimitive(sessionId))
            // Older Gateways reject unknown fields and retain the legacy aborting close.
            if ("talk-session-close-disposition" in advertisedCapabilities) put("disposition", JsonPrimitive(disposition.wireValue))
          }.toString(),
          timeoutMs = 5_000,
          withEnqueue = withEnqueue,
        )
      } catch (error: Throwable) {
        // Disconnect also detaches accepted work if the close could not be confirmed.
        if (disposition == TalkSessionCloseDisposition.Detach) reconnectIfCurrentImpl()
        throw error
      }

    fun commitIfCurrent(block: () -> Unit): Boolean {
      commitIfCurrentImpl?.let { return it(block) }
      if (!isCurrentImpl()) return false
      block()
      return true
    }

    /** After transport waiting, [withEnqueue] must enqueue synchronously or throw to reject the request. */
    suspend fun request(
      method: String,
      paramsJson: String?,
      timeoutMs: Long = 15_000,
      withEnqueue: (() -> Unit) -> Unit = { it() },
    ): String = requestImpl(method, paramsJson, timeoutMs, withEnqueue)

    /** Voice retains its original input while startup refuses admission on this socket. */
    suspend fun requestAwaitingStartup(
      method: String,
      paramsJson: String?,
      timeoutMs: Long = 15_000,
      withEnqueue: (() -> Unit) -> Unit = { it() },
    ): String {
      while (true) {
        try {
          return request(method, paramsJson, timeoutMs, withEnqueue)
        } catch (error: GatewayRequestRejected) {
          val retryDelayMs = error.gatewayError.startupRetryDelayMs(method) ?: throw error
          delay(retryDelayMs)
        }
      }
    }
  }

  private val json =
    Json {
      ignoreUnknownKeys = true
      encodeDefaults = true
      explicitNulls = false
    }
  private val writeLock = Mutex()

  @Volatile private var pluginSurfaceUrls: Map<String, String> = emptyMap()

  @Volatile internal var sessionRouting: GatewaySessionRouting? = null
    private set

  private class DesiredConnection(
    val endpoint: GatewayEndpoint,
    val token: String?,
    @Volatile var bootstrapToken: String?,
    val password: String?,
    val options: GatewayConnectOptions,
    val tls: GatewayTlsParams?,
    val bootstrapHandoff: GatewayBootstrapHandoff?,
    val onReady: (() -> Unit)?,
  ) {
    var recoveringStoredBootstrap = false

    // Retry state belongs to this connect intent, not a later target whose socket may already be ready.
    @Volatile var pendingDeviceTokenRetry = false

    // A shared-token mismatch gets only one retry with the stored device token.
    @Volatile var deviceTokenRetryBudgetUsed = false

    @Volatile var reconnectPausedForAuthFailure = false

    var attempt = 0
    var cleanupDeadline: Job? = null
  }

  private val lifecycleLock = Any()

  // Acquire notificationLock before lifecycleLock. Disconnect can retire an owner while its
  // callback drains, but a replacement cannot publish until that notification has finished.
  private val notificationLock = Any()

  @Volatile private var desired: DesiredConnection? = null

  private var job: Job? = null

  // Disconnect cleanups form one ordered tail so an awaited auth reset also waits for any earlier
  // fire-and-forget disconnect that already detached the reconnect job from this session.
  private var disconnectTail: Job? = null

  @Volatile private var currentConnection: Connection? = null

  // Network recovery must interrupt the current backoff without creating a parallel loop.
  private val reconnectSignal = Channel<Unit>(Channel.CONFLATED)

  /** Starts or replaces the desired gateway connection and launches the reconnect loop. */
  fun connect(
    endpoint: GatewayEndpoint,
    token: String?,
    bootstrapToken: String?,
    password: String?,
    options: GatewayConnectOptions,
    tls: GatewayTlsParams? = null,
    bootstrapHandoff: GatewayBootstrapHandoff? = null,
    onReady: (() -> Unit)? = null,
  ) {
    val connectionToClose: Connection?
    synchronized(notificationLock) {
      val target = DesiredConnection(endpoint, token, bootstrapToken, password, options, tls, bootstrapHandoff, onReady)
      synchronized(lifecycleLock) {
        desired?.cleanupDeadline?.cancel()
        desired = target
        connectionToClose = currentConnection
        connectionToClose?.retire()
        if (connectionToClose != null) {
          // A replacement cannot start another resolver until the previous transport drains.
          // Bound its visible wait independently of OkHttp's eventual cancellation callback.
          target.cleanupDeadline =
            scope.launch(lifecycleDispatcher) {
              delay(connectTimeoutMs)
              synchronized(notificationLock) {
                if (synchronized(lifecycleLock) {
                    desired === target && currentConnection === connectionToClose
                  }
                ) {
                  onConnectFailure(gatewayNetworkConnectError(waitingForCleanup = true), false)
                }
              }
            }
        }
        if (job?.isActive != true) {
          job = scope.launch(lifecycleDispatcher) { runLoop() }
        } else {
          reconnectSignal.trySend(Unit)
        }
      }
    }
    connectionToClose?.closeQuietly()
  }

  /** Clears desired connection state, closes the socket, and stops reconnect attempts. */
  fun disconnect() {
    scheduleDisconnect()
  }

  /** Disconnects and waits until the old reconnect loop and its final callback have stopped. */
  suspend fun disconnectAndJoin() {
    scheduleDisconnect().join()
  }

  private fun scheduleDisconnect(): Job {
    val jobToCancel: Job?
    val connectionToClose: Connection?
    val cleanup: Job
    synchronized(lifecycleLock) {
      desired?.cleanupDeadline?.cancel()
      desired = null
      drainReconnectSignals()
      connectionToClose = currentConnection
      connectionToClose?.retire()
      jobToCancel = job
      job = null
      // Stop retry work now; the ordered tail still drains accepted tokens and callbacks.
      jobToCancel?.cancel()
      val previousCleanup = disconnectTail
      cleanup =
        scope.launch(lifecycleDispatcher, start = CoroutineStart.LAZY) {
          previousCleanup?.join()
          jobToCancel?.join()
          connectionToClose?.joinOwnedWork()
          synchronized(notificationLock) {
            if (desired == null) {
              pluginSurfaceUrls = emptyMap()
              sessionRouting = null
              onDisconnected("Offline")
            }
          }
        }
      disconnectTail = cleanup
    }
    connectionToClose?.closeQuietly()
    cleanup.start()
    return cleanup
  }

  /** Forces the current socket closed so the loop reconnects to the current desired endpoint. */
  fun reconnect() {
    signalReconnect(resumeAuthPaused = true)
  }

  /** Wakes transport backoff without overriding a deliberate auth-failure pause. */
  internal fun retryAfterNetworkRestore() {
    signalReconnect(resumeAuthPaused = false)
  }

  private fun signalReconnect(resumeAuthPaused: Boolean) {
    val connectionToClose: Connection?
    synchronized(lifecycleLock) {
      val target = desired ?: return
      if (resumeAuthPaused) {
        target.reconnectPausedForAuthFailure = false
      } else if (target.reconnectPausedForAuthFailure || currentConnection?.hasOpenTransport() == true) {
        // Another network becoming available does not invalidate an open WebSocket.
        // Its handshake may already have consumed a one-time setup code.
        return
      }
      connectionToClose = currentConnection
      connectionToClose?.retire()
      reconnectSignal.trySend(Unit)
    }
    connectionToClose?.closeQuietly()
  }

  // The channel is conflated. A wake queued just after timeout still resets the next attempt.
  private fun drainReconnectSignals(): Boolean = reconnectSignal.tryReceive().isSuccess

  private fun readyConnection(expectedEndpointStableId: String? = null): Connection? =
    currentConnection?.takeIf {
      it.isReady() && (expectedEndpointStableId == null || it.target.endpoint.stableId == expectedEndpointStableId)
    }

  internal fun isReady(): Boolean = readyConnection() != null

  internal fun currentCanvasHostRoute(): GatewayCanvasHostRoute? =
    synchronized(lifecycleLock) {
      val connection = readyConnection() ?: return@synchronized null
      val url = pluginSurfaceUrls["canvas"] ?: return@synchronized null
      // TLS validation can learn the certificate during the WebSocket handshake. Read
      // the live TLS config so the widget document inherits that exact trust.
      val fingerprint =
        connection.tlsConfig
          ?.effectiveFingerprintSha256
          ?.let(::normalizeGatewayTlsFingerprintInput)
      GatewayCanvasHostRoute(
        url = url,
        tlsFingerprintSha256 =
          gatewayTlsFingerprintForCanvasSurface(
            fingerprint = fingerprint,
            surfaceUrl = url,
            endpoint = connection.target.endpoint,
            isTlsConnection = connection.tlsConfig != null,
          ),
      )
    }

  internal suspend fun refreshCanvasHostRouteIfCurrent(observedSurfaceUrl: String?): GatewayCanvasHostRoute? {
    refreshCanvasHostUrlIfCurrent(observedSurfaceUrl)
    // Pair the URL with the currently installed connection after suspension;
    // a reconnect can replace both the capability and its certificate pin.
    return currentCanvasHostRoute()
  }

  internal suspend fun refreshCanvasHostUrlIfCurrent(observedSurfaceUrl: String?): String? {
    val (lease, target, requestObservedSurfaceUrl) =
      synchronized(lifecycleLock) {
        val current = pluginSurfaceUrls["canvas"]
        if (current != observedSurfaceUrl) return current
        val capturedLease = captureRequestLease() ?: return null
        val capturedTarget =
          desired
            ?.takeIf { it.endpoint.stableId == capturedLease.endpointStableId }
            ?: return null
        Triple(capturedLease, capturedTarget, current)
      }
    val refreshMethod =
      when (
        target.options.role
          .trim()
          .lowercase(Locale.ROOT)
      ) {
        "node" -> GatewayMethod.NodePluginSurfaceRefresh
        "operator" -> GatewayMethod.PluginSurfaceRefresh
        else -> return null
      }
    val response =
      runCatching {
        lease.request(
          refreshMethod.rawValue,
          buildJsonObject {
            put("surface", JsonPrimitive("canvas"))
            requestObservedSurfaceUrl?.let { put("observedUrl", JsonPrimitive(it)) }
          }.toString(),
          timeoutMs = 8_000,
        )
      }.getOrNull() ?: return null
    val raw =
      parseJsonOrNull(response)
        .asObjectOrNull()
        ?.get("pluginSurfaceUrls")
        .asObjectOrNull()
        ?.get("canvas")
        .asStringOrNull()
    val refreshed = normalizeCanvasHostUrl(raw, target.endpoint, isTlsConnection = target.tls != null) ?: return null
    var result: String? = null
    val committed =
      lease.commitIfCurrent {
        val current = pluginSurfaceUrls["canvas"]
        result =
          if (current != observedSurfaceUrl) {
            current
          } else {
            pluginSurfaceUrls = pluginSurfaceUrls + ("canvas" to refreshed)
            refreshed
          }
      }
    return if (committed) result else null
  }

  /** Current physical connection identity, including events sent during connect publication. */
  internal fun currentEndpointStableId(): String? = currentConnection?.target?.endpoint?.stableId

  internal suspend fun sendNodeEventForEndpoint(
    expectedEndpointStableId: String?,
    event: String,
    payloadJson: String?,
    logFailure: Boolean = true,
  ): Boolean =
    sendNodeEventWithOutcomeForEndpoint(expectedEndpointStableId, event, payloadJson, logFailure) ==
      NodeEventSendOutcome.COMPLETED

  internal suspend fun sendNodeEventWithOutcomeForEndpoint(
    expectedEndpointStableId: String?,
    event: String,
    payloadJson: String?,
    logFailure: Boolean = true,
  ): NodeEventSendOutcome {
    val conn = readyConnection(expectedEndpointStableId) ?: return NodeEventSendOutcome.DISCONNECTED
    return try {
      conn.request(
        GatewayMethod.NodeEvent.rawValue,
        buildNodeEventParams(event = event, payloadJson = payloadJson),
        timeoutMs = 8_000,
      )
      NodeEventSendOutcome.COMPLETED
    } catch (_: GatewayRequestNotEnqueued) {
      NodeEventSendOutcome.DISCONNECTED
    } catch (err: CancellationException) {
      // Voice/audio ownership takeover must cancel before a stale node event dispatches.
      throw err
    } catch (err: Throwable) {
      if (logFailure) Log.w("OpenClawGateway", "node.event failed: ${err::class.java.simpleName}")
      NodeEventSendOutcome.FAILED
    }
  }

  /** Sends node.event and preserves the gateway RPC error shape for callers that need diagnostics. */
  internal suspend fun sendNodeEventDetailedForEndpoint(
    expectedEndpointStableId: String?,
    event: String,
    payloadJson: String?,
    timeoutMs: Long = 8_000,
  ): RpcResult {
    val conn =
      readyConnection(expectedEndpointStableId)
        ?: return RpcResult(
          ok = false,
          payloadJson = null,
          error = ErrorShape("UNAVAILABLE", "not connected"),
        )
    val params = buildNodeEventParams(event = event, payloadJson = payloadJson)
    try {
      return conn.request(GatewayMethod.NodeEvent.rawValue, params, timeoutMs = timeoutMs)
    } catch (err: Throwable) {
      Log.w("OpenClawGateway", "node.event failed: ${err::class.java.simpleName}")
      return RpcResult(
        ok = false,
        payloadJson = null,
        error = ErrorShape("UNAVAILABLE", "node.event failed"),
      )
    }
  }

  private fun buildNodeEventParams(
    event: String,
    payloadJson: String?,
  ): JsonElement =
    json
      .encodeToJsonElement(
        GatewayNodeEventParams.serializer(),
        GatewayNodeEventParams(event = event, payloadJson = payloadJson ?: "{}"),
      )

  /** Sends an RPC request and throws a code-prefixed exception when the gateway returns an error. */
  suspend fun request(
    method: String,
    paramsJson: String?,
    timeoutMs: Long? = null,
  ): String = requestDetailed(method = method, paramsJson = paramsJson, timeoutMs = timeoutMs).payloadOrThrow()

  suspend fun loadImageArtifact(
    expectedEndpointStableId: String?,
    sessionKey: String,
    agentId: String?,
    artifactId: String,
  ): GatewayLoadedImage? {
    val loaded =
      loadMediaArtifact(
        expectedEndpointStableId = expectedEndpointStableId,
        sessionKey = sessionKey,
        agentId = agentId,
        artifactId = artifactId,
        kind = GatewayMediaKind.Image,
      ) as? GatewayLoadedMedia.Buffered ?: return null
    return GatewayLoadedImage(bytes = loaded.bytes, mimeType = loaded.mimeType)
  }

  /** [basePath] is the accepted Control UI mount; null uses the socket's context path. */
  internal suspend fun loadInboundImage(
    expectedEndpointStableId: String?,
    basePath: String?,
    sessionKey: String,
    agentId: String?,
    source: String,
  ): GatewayLoadedImage? {
    val conn = readyConnection(expectedEndpointStableId) ?: return null
    val image = conn.loadInboundImage(basePath, sessionKey, agentId, source, guardRequestEnqueue(conn) { it() })
    return synchronized(lifecycleLock) { image.takeIf { currentConnection === conn && conn.isReady() } }
  }

  internal suspend fun loadSourceFavicon(
    expectedEndpointStableId: String,
    config: GatewaySourcePreviewConfig,
    hostname: String,
    withEnqueue: (() -> Unit) -> Unit,
  ): GatewayLoadedImage? {
    if (!config.automaticallyFetchFavicons) return null
    val conn = readyConnection(expectedEndpointStableId) ?: return null
    val image = conn.loadSourceFavicon(config, hostname, guardRequestEnqueue(conn, withEnqueue))
    return synchronized(lifecycleLock) { image.takeIf { currentConnection === conn && conn.isReady() } }
  }

  suspend fun loadMediaArtifact(
    expectedEndpointStableId: String?,
    sessionKey: String,
    agentId: String?,
    artifactId: String,
    kind: GatewayMediaKind,
    playbackRendition: Boolean = false,
  ): GatewayLoadedMedia? {
    val conn = readyConnection(expectedEndpointStableId) ?: return null
    val params =
      buildJsonObject {
        put("sessionKey", JsonPrimitive(sessionKey))
        agentId?.trim()?.takeIf(String::isNotEmpty)?.let { put("agentId", JsonPrimitive(it)) }
        put("artifactId", JsonPrimitive(artifactId))
      }
    val response = conn.request(GatewayMethod.ArtifactsDownload.rawValue, params, timeoutMs = 15_000)
    if (!response.ok) {
      throw GatewayRequestRejected(response.error ?: ErrorShape("UNAVAILABLE", "artifact download failed"))
    }
    val payload = response.payloadJson?.let(::parseJsonOrNull).asObjectOrNull() ?: return null
    val artifact = payload["artifact"].asObjectOrNull()
    // Older gateways returned only the managed-image URL. Other media require the typed
    // artifact envelope, so keep the narrow image fallback without weakening their type gate.
    if (artifact == null && kind != GatewayMediaKind.Image) return null
    if (artifact != null && artifact["type"].asStringOrNull()?.trim()?.lowercase(Locale.ROOT) != kind.wireValue) return null
    val mimeType =
      artifact
        ?.get("mimeType")
        .asStringOrNull()
        ?.trim()
        ?.lowercase(Locale.ROOT)
    if (mimeType != null && !kind.acceptsMimeType(mimeType)) return null
    val loaded =
      payload["data"].asStringOrNull()?.let { encoded ->
        if (kind == GatewayMediaKind.Video) return@let null
        val maximumEncodedLength = ((kind.maximumBufferedBytes + 2L) / 3L) * 4L
        if (encoded.length.toLong() > maximumEncodedLength) return@let null
        val bytes = runCatching { Base64.getDecoder().decode(encoded) }.getOrNull() ?: return@let null
        if (bytes.size.toLong() > kind.maximumBufferedBytes) return@let null
        val resolvedMimeType = mimeType ?: return@let null
        conn.bufferedMedia(bytes = bytes, mimeType = resolvedMimeType)
      } ?: payload["url"].asStringOrNull()?.trim()?.takeIf(String::isNotEmpty)?.let { ticketedPath ->
        if (kind == GatewayMediaKind.Video) {
          conn.resolveTicketedMediaStream(ticketedPath, mimeType, playbackRendition)
        } else {
          conn.loadTicketedMedia(ticketedPath, kind, playbackRendition)
        }
      } ?: return null
    return synchronized(lifecycleLock) {
      loaded.takeIf { currentConnection === conn && conn.isReady() }
    }
  }

  internal suspend fun requestForEndpoint(
    expectedEndpointStableId: String,
    method: String,
    paramsJson: String?,
    timeoutMs: Long? = null,
  ): String = requestDetailed(expectedEndpointStableId, method, paramsJson, timeoutMs).payloadOrThrow()

  private fun RpcResult.payloadOrThrow(): String {
    if (!ok) throw GatewayRequestRejected(error ?: ErrorShape("UNAVAILABLE", "request failed"))
    return payloadJson ?: ""
  }

  /** Captures the current physical connection; requests never resolve a replacement socket. */
  internal fun captureRequestLease(expectedEndpointStableId: String? = null): RequestLease? =
    synchronized(lifecycleLock) {
      val conn = readyConnection(expectedEndpointStableId) ?: return@synchronized null
      RequestLease(
        endpointStableId = conn.target.endpoint.stableId,
        advertisedMethods = conn.advertisedMethods,
        controlUiCredential = conn.controlUiCredential,
        advertisedCapabilities = conn.advertisedCapabilities,
        reconnectIfCurrentImpl = {
          synchronized(lifecycleLock) {
            if (currentConnection === conn && conn.isReady()) reconnect()
          }
        },
        isCurrentImpl = { currentConnection === conn && conn.isReady() },
        commitIfCurrentImpl = { block ->
          synchronized(lifecycleLock) {
            if (currentConnection !== conn || !conn.isReady()) {
              false
            } else {
              block()
              true
            }
          }
        },
      ) { method, paramsJson, timeoutMs, withEnqueue ->
        requestDetailed(conn, method, paramsJson, timeoutMs, withEnqueue).payloadOrThrow()
      }
    }

  /** Sends an RPC request and returns the structured success/error payload. */
  suspend fun requestDetailed(
    method: String,
    paramsJson: String?,
    timeoutMs: Long? = null,
  ): RpcResult =
    requestDetailed(
      expectedEndpointStableId = null,
      method,
      paramsJson,
      timeoutMs,
    )

  private suspend fun requestDetailed(
    expectedEndpointStableId: String?,
    method: String,
    paramsJson: String?,
    timeoutMs: Long?,
  ): RpcResult {
    val conn = readyConnection(expectedEndpointStableId) ?: throw GatewayRequestNotEnqueued("not connected")
    return requestDetailed(conn, method, paramsJson, timeoutMs)
  }

  private suspend fun requestDetailed(
    conn: Connection,
    method: String,
    paramsJson: String?,
    timeoutMs: Long?,
    withEnqueue: (() -> Unit) -> Unit = { it() },
  ): RpcResult {
    val params = parseRequestParams(paramsJson)
    val hasAudio =
      method == "chat.send" &&
        params.asObjectOrNull()?.get("attachments").asArrayOrNull()?.any { attachment ->
          attachment
            .asObjectOrNull()
            ?.get("mimeType")
            .asStringOrNull()
            ?.lowercase()
            ?.startsWith("audio/") == true
        } == true
    // Audio transcription precedes durable admission. Disconnect and caller
    // cancellation still settle the request while it waits for that ACK.
    val requestTimeoutMs = timeoutMs ?: if (hasAudio) 0L else 15_000L
    val enqueue = guardRequestEnqueue(conn, withEnqueue)
    if (method != "talk.catalog") return conn.request(method, params, requestTimeoutMs, enqueue)
    // A disabled RPC deadline must not disable the catalog's bounded warm-up budget.
    var remainingMs = if (requestTimeoutMs == 0L) 10_000L else minOf(requestTimeoutMs, 10_000)
    val deadline = SystemClock.elapsedRealtime() + remainingMs
    while (true) {
      val result = conn.request(method, params, remainingMs, enqueue)
      val error = result.error
      if (
        result.ok || error?.code != "UNAVAILABLE" || error.details?.retryable != true ||
        error.details.reason != "talk-catalog-warming"
      ) {
        return result
      }
      val retryDelayMs = (error.details.retryAfterMs ?: 250).coerceAtLeast(250).toLong()
      if (SystemClock.elapsedRealtime() + retryDelayMs >= deadline) return result
      delay(retryDelayMs)
      remainingMs = deadline - SystemClock.elapsedRealtime()
      if (remainingMs <= 0) return result
    }
  }

  private fun parseRequestParams(paramsJson: String?): JsonElement? = paramsJson?.takeUnless(String::isBlank)?.let(json::parseToJsonElement)

  private fun guardRequestEnqueue(
    conn: Connection,
    withEnqueue: (() -> Unit) -> Unit,
  ): (() -> Unit) -> Unit =
    { enqueue ->
      // Check after the transport mutex wait, in the same physical -> caller-owner
      // lock order as hello publication. Only OkHttp's synchronous enqueue is guarded.
      synchronized(lifecycleLock) {
        if (currentConnection !== conn || !conn.isReady()) {
          throw GatewayRequestNotEnqueued("gateway request lease changed")
        }
        withEnqueue(enqueue)
      }
    }

  /** Sends an RPC request frame and reports errors asynchronously through [onError]. */
  internal suspend fun sendRequestFrameForEndpoint(
    expectedEndpointStableId: String?,
    method: String,
    paramsJson: String?,
    timeoutMs: Long = 15_000,
    withEnqueue: (() -> Unit) -> Unit = { it() },
    onError: (ErrorShape) -> Unit = {},
  ) {
    val conn = readyConnection(expectedEndpointStableId) ?: throw IllegalStateException("not connected")
    conn.sendRequestFrame(method, parseRequestParams(paramsJson), timeoutMs, guardRequestEnqueue(conn, withEnqueue), onError)
  }

  private data class TicketedMediaRequest(
    val url: String,
    val headers: Map<String, String>,
  )

  private data class ConnectedGateway(
    val pluginSurfaceUrls: Map<String, String>,
    val sessionRouting: GatewaySessionRouting,
    val hello: GatewayHelloSummary,
  )

  private data class ConnectChallenge(
    val nonce: String,
    val issuedAtMs: Long,
  )

  private enum class ConnectionState {
    CONNECTING,
    READY,
    CLOSED,
  }

  private inner class Connection(
    val target: DesiredConnection,
  ) {
    var advertisedMethods: Set<String> = emptySet()
      private set

    var advertisedCapabilities: Set<String> = emptySet()
      private set

    var controlUiCredential: NativeControlUiCredential? = null
      private set

    private val connectionJob = SupervisorJob(scope.coroutineContext[Job])
    private val connectionScope = CoroutineScope(scope.coroutineContext + connectionJob)
    private val state = AtomicReference(ConnectionState.CONNECTING)
    private val connectDeferred = CompletableDeferred<ConnectedGateway>()
    private val closedDeferred = CompletableDeferred<Unit>()
    private val connectChallengeDeferred = CompletableDeferred<ConnectChallenge>()
    private val terminalCallbackClaimed = AtomicBoolean(false)
    private val socketCancellationStarted = AtomicBoolean(false)
    private val connectResponseAccepted = AtomicBoolean(false)
    private val ingressRetirementStarted = AtomicBoolean(false)
    private val ingressCalls = ConcurrentHashMap.newKeySet<Call>()
    private val ingressAuthorization =
      if (target.tls == null) null else ingressAuthorizationProvider?.invoke(target.endpoint)
    private var ingressHeaders: Map<String, String> = emptyMap()

    @Volatile
    private var connectHandshakeJob: Job? = null

    @Volatile
    private var connectRequestId: String? = null
    val tlsConfig: GatewayTlsConfig? = buildGatewayTlsConfig(target.tls)
    private val client: OkHttpClient = buildClient()
    private val imageLoader by lazy { GatewayImageLoader(client) }
    private var controlUiReadCredentials: List<String> = emptyList()
    private val listener = Listener()
    private var socket: WebSocket? = null

    // A null socket is not a completed transport while OkHttp's factory still owns its return.
    private var socketCreationPending = false
    private var transportFinished = false
    private val loggerTag = "OpenClawGateway"
    private val incomingMessages = Channel<String>(Channel.UNLIMITED)
    private var lastEventSequence: Long? = null
    private val liveTextProjection = GatewayLiveTextProjection()

    // RPC waiters belong to this socket generation. Closing it must not touch a replacement connection.
    private val pending = ConcurrentHashMap<String, CompletableDeferred<RpcResult>>()

    private val pendingLock = Any()
    private val messagePumpJob =
      connectionScope.launch(Dispatchers.IO) {
        for (text in incomingMessages) {
          try {
            handleMessage(text)
          } catch (err: CancellationException) {
            throw err
          } catch (err: Throwable) {
            Log.w(
              loggerTag,
              "gateway message handling failed: ${err.message ?: err::class.java.simpleName}",
            )
          }
        }
      }

    val remoteAddress: String = formatGatewayAuthority(target.endpoint.host, target.endpoint.port)

    suspend fun connect(): ConnectedGateway =
      try {
        withTimeout(connectTimeoutMs) {
          val original =
            buildGatewayWebSocketUpgradeRequest(
              endpoint = target.endpoint,
              tls = target.tls,
              customHeadersProvider = customHeadersProvider,
            )
          val request =
            if (ingressAuthorization == null) {
              original
            } else {
              // This probe belongs to the connecting transport, not a shared sign-in. Retirement
              // cancels and drains it before the reconnect loop can start another attempt.
              val authorization = async(start = CoroutineStart.LAZY) { ingressAuthorization.authorizeUpgrade(original) }
              try {
                select {
                  closedDeferred.onAwait { error("Gateway closed") }
                  authorization.onAwait { it }
                }
              } finally {
                authorization.cancelAndJoin()
              }
            }
          check(request.url == original.url) { "Ingress authorization cannot change the Gateway route" }
          ingressAuthorization?.requireCurrent(request)
          if (ingressAuthorization != null) {
            ingressHeaders = request.headers.names().associateWith { request.header(it).orEmpty() }
          }
          // OkHttp can invoke onOpen before newWebSocket returns. Keep publication under the
          // send lock, and reject a retirement that won while this coroutine waited for it.
          var socketToCancel: WebSocket? = null
          try {
            writeLock.withLock {
              val context = currentCoroutineContext()
              context.ensureActive()
              synchronized(lifecycleLock) {
                check(state.get() == ConnectionState.CONNECTING && desired === target) { "Gateway closed" }
                socketCreationPending = true
              }
              val createdSocket =
                try {
                  webSocketFactory?.invoke(client, request, listener) ?: client.newWebSocket(request, listener)
                } catch (error: Throwable) {
                  synchronized(lifecycleLock) {
                    socketCreationPending = false
                    retire()
                  }
                  throw error
                }
              synchronized(lifecycleLock) {
                // Own the returned socket before observing cancellation. An early terminal
                // callback must not be undone by publishing the factory's late return.
                socketCreationPending = false
                if (transportFinished) {
                  closedDeferred.complete(Unit)
                } else {
                  socket = createdSocket
                  if (!context.isActive || state.get() != ConnectionState.CONNECTING || desired !== target || currentConnection !== this@Connection) {
                    socketToCancel = retire()
                  }
                }
              }
            }
          } finally {
            cancelSocket(socketToCancel)
          }
          connectDeferred.await()
        }
      } catch (_: TimeoutCancellationException) {
        throw GatewayConnectFailure(gatewayNetworkConnectError(timedOut = true))
      } catch (_: GatewayRequestOutcomeUnknown) {
        throw GatewayConnectFailure(gatewayNetworkConnectError())
      }

    suspend fun request(
      method: String,
      params: JsonElement?,
      timeoutMs: Long,
      withEnqueue: (() -> Unit) -> Unit = { it() },
    ): RpcResult {
      val id = UUID.randomUUID().toString()
      if (method == "connect") connectRequestId = id
      val deferred = registerPending(id)
      try {
        sendJson(buildRequestFrame(id = id, method = method, params = params), withEnqueue)
        return if (timeoutMs == 0L) deferred.await() else withTimeout(timeoutMs) { deferred.await() }
      } catch (err: TimeoutCancellationException) {
        if (method == GatewayMethod.Connect.rawValue) {
          throw GatewayConnectFailure(gatewayNetworkConnectError(timedOut = true))
        }
        throw GatewayRequestOutcomeUnknown("request timeout")
      } finally {
        pending.remove(id)
        if (connectRequestId == id) connectRequestId = null
      }
    }

    fun resolveTicketedMediaStream(
      ticketedPath: String,
      mimeType: String?,
      playbackRendition: Boolean,
    ): GatewayLoadedMedia.Streaming? {
      val request = resolveTicketedMediaRequest(ticketedPath, playbackRendition) ?: return null
      return GatewayLoadedMedia.Streaming(
        url = request.url,
        headers = request.headers + ("Accept" to "video/*"),
        client = client,
        mimeType = mimeType,
        retryPreparingPlayback = playbackRendition,
      )
    }

    suspend fun loadSourceFavicon(
      config: GatewaySourcePreviewConfig,
      hostname: String,
      withEnqueue: (() -> Unit) -> Unit,
    ): GatewayLoadedImage? =
      imageLoader.loadFavicon(
        gatewayUrl = "${if (tlsConfig != null) "https" else "http"}://${formatGatewayAuthority(target.endpoint.host, target.endpoint.port)}",
        basePath = config.basePath,
        hostname = hostname,
        headers = mediaTransportHeaders(),
        credentials = controlUiReadCredentials,
        withEnqueue = withEnqueue,
      )

    suspend fun loadInboundImage(
      basePath: String?,
      sessionKey: String,
      agentId: String?,
      source: String,
      withEnqueue: (() -> Unit) -> Unit,
    ): GatewayLoadedImage? =
      imageLoader.loadInboundImage(
        gatewayUrl = "${if (tlsConfig != null) "https" else "http"}://${formatGatewayAuthority(target.endpoint.host, target.endpoint.port)}",
        basePath = basePath ?: target.endpoint.contextPath,
        source = source,
        sessionKey = sessionKey,
        agentId = agentId,
        headers = mediaTransportHeaders(),
        credentials = controlUiReadCredentials,
        withEnqueue = withEnqueue,
      )

    fun bufferedMedia(
      bytes: ByteArray,
      mimeType: String,
    ): GatewayLoadedMedia.Buffered =
      GatewayLoadedMedia.Buffered(
        bytes = bytes,
        mimeType = mimeType,
        headers = mediaTransportHeaders(),
        client = client,
      )

    suspend fun loadTicketedMedia(
      ticketedPath: String,
      kind: GatewayMediaKind,
      playbackRendition: Boolean,
    ): GatewayLoadedMedia.Buffered? =
      withContext(Dispatchers.IO) {
        val resolved = resolveTicketedMediaRequest(ticketedPath, playbackRendition) ?: return@withContext null
        val request = Request.Builder().url(resolved.url).header("Accept", kind.acceptHeader)
        for ((name, value) in resolved.headers) {
          request.header(name, value)
        }
        // Exported documents must not follow a redirect outside the ticketed Gateway route.
        val downloadClient =
          if (kind == GatewayMediaKind.File) {
            client
              .newBuilder()
              .followRedirects(false)
              .followSslRedirects(false)
              .build()
          } else {
            client
          }
        val retry = GatewayPlaybackRetryState()
        repeat(Int.MAX_VALUE) {
          if (!retry.canAttempt()) return@withContext null
          val call = downloadClient.newCall(request.build())
          call.timeout().timeout(20, java.util.concurrent.TimeUnit.SECONDS)
          var retryDelayMs: Long? = null
          call.execute().use { response ->
            if (response.code == 202 && playbackRendition) {
              retryDelayMs = retry.nextDelayMs()
            } else {
              if (!response.isSuccessful) return@withContext null
              val body = response.body
              val mimeType = body.contentType()?.toString()?.lowercase(Locale.ROOT) ?: return@withContext null
              if (!kind.acceptsMimeType(mimeType)) return@withContext null
              val maximumBytes = kind.maximumBufferedBytes
              val declaredLength = body.contentLength()
              if (declaredLength > maximumBytes) return@withContext null
              val buffer = Buffer()
              val source = body.source()
              var total = 0L
              while (true) {
                val read = source.read(buffer, minOf(8192L, maximumBytes + 1L - total))
                if (read == -1L) break
                total += read
                if (total > maximumBytes) return@withContext null
              }
              return@withContext bufferedMedia(bytes = buffer.readByteArray(), mimeType = mimeType)
            }
          }
          delay(retryDelayMs ?: return@withContext null)
        }
        null
      }

    private fun resolveTicketedMediaRequest(
      ticketedPath: String,
      playbackRendition: Boolean = false,
    ): TicketedMediaRequest? {
      val uri = runCatching { URI(ticketedPath) }.getOrNull() ?: return null
      val rawPath = uri.rawPath ?: return null
      val rawQuery = uri.rawQuery ?: return null
      if (uri.isAbsolute || uri.rawAuthority != null || uri.rawFragment != null) return null
      val hasMediaTicket =
        rawQuery
          .split('&')
          .any { field -> field.substringBefore('=') == "mediaTicket" && field.substringAfter('=', "").isNotEmpty() }
      if (!rawPath.startsWith("/api/chat/media/outgoing/") || !hasMediaTicket) return null
      val scheme = if (tlsConfig != null) "https" else "http"
      val playbackPath =
        if (playbackRendition && rawQuery.split('&').none { it.substringBefore('=') == "playback" }) {
          "$ticketedPath&playback=1"
        } else {
          ticketedPath
        }
      val url = "$scheme://${formatGatewayAuthority(target.endpoint.host, target.endpoint.port)}${target.endpoint.contextPath}$playbackPath"
      val headers = mediaTransportHeaders()
      return TicketedMediaRequest(url = url, headers = headers)
    }

    private fun mediaTransportHeaders(): Map<String, String> {
      ingressAuthorization?.let { authorization ->
        if (state.get() == ConnectionState.CLOSED) throw GatewayExternalAuthorizationException()
        authorization.requireCurrent(
          Request
            .Builder()
            .url(
              buildGatewayWebSocketUrl(target.endpoint.host, target.endpoint.port, true, target.endpoint.contextPath),
            ).build(),
        )
      }
      return if (tlsConfig == null) {
        emptyMap()
      } else if (ingressAuthorization != null) {
        // Media stays bound to the grant admitted for this physical socket. A
        // later account must never supply credentials to an older capability.
        ingressHeaders
      } else {
        GatewayCustomHeaders.sanitized(customHeadersProvider?.invoke(target.endpoint.stableId).orEmpty())
      }
    }

    suspend fun sendRequestFrame(
      method: String,
      params: JsonElement?,
      timeoutMs: Long,
      withEnqueue: (() -> Unit) -> Unit = { it() },
      onError: (ErrorShape) -> Unit,
    ) {
      val id = UUID.randomUUID().toString()
      val deferred = registerPending(id)
      try {
        sendJson(buildRequestFrame(id = id, method = method, params = params), withEnqueue)
      } catch (err: Throwable) {
        pending.remove(id)
        throw err
      }
      // Queued callbacks still owe a terminal result when teardown cancels their owner.
      launchDrainingWork {
        try {
          val response =
            try {
              withTimeout(timeoutMs) { deferred.await() }
            } catch (_: TimeoutCancellationException) {
              onError(ErrorShape("UNAVAILABLE", "request timeout"))
              return@launchDrainingWork
            } catch (err: GatewayRequestOutcomeUnknown) {
              onError(ErrorShape("UNAVAILABLE", err.message ?: "request outcome unknown"))
              return@launchDrainingWork
            }
          if (!response.ok) {
            onError(response.error ?: ErrorShape("UNAVAILABLE", "request failed"))
          }
        } finally {
          pending.remove(id)
        }
      }
    }

    private fun registerPending(id: String): CompletableDeferred<RpcResult> {
      val deferred = CompletableDeferred<RpcResult>()
      // Registration and the close drain are one lifecycle decision; no waiter may slip between them.
      synchronized(pendingLock) {
        if (state.get() == ConnectionState.CLOSED) {
          throw GatewayRequestNotEnqueued("Gateway closed")
        }
        pending[id] = deferred
      }
      return deferred
    }

    suspend fun sendJson(
      obj: JsonElement,
      withEnqueue: (() -> Unit) -> Unit = { it() },
    ) {
      val jsonString = obj.toString()
      writeLock.withLock {
        currentCoroutineContext().ensureActive()
        withEnqueue {
          if (state.get() == ConnectionState.CLOSED || socket?.send(jsonString) != true) {
            // Closing during the lock wait, like an OkHttp false return, means no frame was queued.
            throw GatewayRequestNotEnqueued("gateway send failed")
          }
        }
      }
    }

    private fun buildRequestFrame(
      id: String,
      method: String,
      params: JsonElement?,
    ): JsonElement =
      json
        .encodeToJsonElement(
          GatewayRequestFrame.serializer(),
          GatewayRequestFrame(id = id, method = method, params = params),
        )

    suspend fun awaitClose() = closedDeferred.await()

    suspend fun joinOwnedWork() {
      // Close the inbound channel before joining so already accepted frames drain in order. A
      // connect response may contain the one-time device token needed after bootstrap auth.
      messagePumpJob.join()
      closedDeferred.await()
      failPending()
      // handleResponse() completes the request deferred; the separate handshake continuation must
      // still parse and persist its issued token before remaining connection work is cancelled.
      connectHandshakeJob?.join()
      connectionJob.cancelAndJoin()
    }

    fun isReady(): Boolean = state.get() == ConnectionState.READY

    fun hasOpenTransport(): Boolean = state.get() != ConnectionState.CLOSED && connectHandshakeJob != null

    fun markReady(hello: GatewayHelloSummary): Boolean {
      if (!state.compareAndSet(ConnectionState.CONNECTING, ConnectionState.READY)) return false
      advertisedMethods = hello.methods.orEmpty()
      advertisedCapabilities = hello.capabilities.orEmpty()
      return true
    }

    fun retire(): WebSocket? =
      synchronized(lifecycleLock) {
        if (state.getAndSet(ConnectionState.CLOSED) != ConnectionState.CLOSED) {
          retireIngressRequests()
          incomingMessages.close()
          connectDeferred.completeExceptionally(IllegalStateException("Gateway closed"))
        }
        if (socket == null && !socketCreationPending) closedDeferred.complete(Unit)
        socket
      }

    fun closeQuietly() {
      cancelSocket(retire())
    }

    @OptIn(DelicateCoroutinesApi::class)
    private fun launchDrainingWork(block: suspend CoroutineScope.() -> Unit) {
      // ATOMIC enters cleanup even after cancellation; NonCancellable drains accepted work.
      connectionScope.launch(Dispatchers.IO, start = CoroutineStart.ATOMIC) {
        withContext(NonCancellable, block)
      }
    }

    private fun retireIngressRequests() {
      if (ingressAuthorization == null || !ingressRetirementStarted.compareAndSet(false, true)) return
      launchDrainingWork {
        // Dispatcher ownership ends when headers are delivered. Keep calls
        // through body consumption so an already playing stream is retired too.
        ingressCalls.forEach { it.cancel() }
        client.connectionPool.evictAll()
      }
    }

    private fun cancelSocket(socket: WebSocket?) {
      if (socket == null || !socketCancellationStarted.compareAndSet(false, true)) return
      // Callbacks can retire a connection reentrantly under notificationLock. Keep physical
      // cancellation off that thread; this one owned child still drains in joinOwnedWork().
      launchDrainingWork { socket.cancel() }
    }

    private fun finishTransport(
      message: String,
      connectError: Throwable,
    ) {
      if (!terminalCallbackClaimed.compareAndSet(false, true)) return
      val shouldNotify = state.getAndSet(ConnectionState.CLOSED) != ConnectionState.CLOSED
      retireIngressRequests()
      incomingMessages.close()
      // Completion handlers run synchronously and cannot own app-level disconnect cleanup.
      launchDrainingWork {
        try {
          messagePumpJob.join()
          if (connectResponseAccepted.get()) {
            connectHandshakeJob?.join()
          } else {
            connectChallengeDeferred.completeExceptionally(connectError)
          }
          synchronized(notificationLock) {
            if (shouldNotify && currentConnection === this@Connection && desired === target) onDisconnected(message)
          }
        } finally {
          connectDeferred.completeExceptionally(connectError)
          synchronized(lifecycleLock) {
            transportFinished = true
            socket = null
            if (!socketCreationPending) closedDeferred.complete(Unit)
          }
        }
      }
    }

    private fun buildClient(): OkHttpClient {
      val builder =
        OkHttpClient
          .Builder()
          .writeTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
          .readTimeout(0, java.util.concurrent.TimeUnit.SECONDS)
          .pingInterval(30, java.util.concurrent.TimeUnit.SECONDS)
      if (tlsConfig != null) {
        builder.sslSocketFactory(tlsConfig.sslSocketFactory, tlsConfig.trustManager)
        builder.hostnameVerifier(tlsConfig.hostnameVerifier)
      }
      ingressAuthorization?.let { authorization ->
        builder.followRedirects(false).followSslRedirects(false)
        builder.retryOnConnectionFailure(false)
        builder.eventListener(
          object : EventListener() {
            override fun callStart(call: Call) {
              ingressCalls.add(call)
              // Late registration meets the closed-state interceptor before I/O;
              // existing calls remain owned until the response body terminates.
            }

            override fun callEnd(call: Call) {
              ingressCalls.remove(call)
            }

            override fun callFailed(
              call: Call,
              ioe: IOException,
            ) {
              ingressCalls.remove(call)
            }
          },
        )
        builder.addNetworkInterceptor { chain ->
          // Media's preparation retry interceptor can call proceed repeatedly.
          // Network interceptors guard each exchange; WebSockets use the guard below.
          if (state.get() == ConnectionState.CLOSED) throw GatewayExternalAuthorizationException()
          authorization.requireCurrent(chain.request())
          chain.proceed(chain.request())
        }
        builder.addInterceptor { chain ->
          val request = chain.request()
          if (state.get() == ConnectionState.CLOSED) throw GatewayExternalAuthorizationException()
          authorization.requireCurrent(request)
          val response = chain.proceed(request)
          try {
            if (state.get() == ConnectionState.CLOSED) throw GatewayExternalAuthorizationException()
            authorization.requireCurrent(request)
            authorization.rejection(response)?.let { throw it }
          } catch (error: Throwable) {
            // A 101 response owns the socket until RealWebSocket adopts it.
            // Rejecting here must close both streams even if another close fails.
            runCatching { response.close() }
            runCatching { response.socket?.sink?.close() }
            runCatching { response.socket?.source?.close() }
            throw error
          }
          response
        }
      }
      return builder.build()
    }

    private inner class Listener : WebSocketListener() {
      override fun onOpen(
        webSocket: WebSocket,
        response: Response,
      ) {
        try {
          // A queued upgrade can outlive its grant. Pairing starts only after
          // both ingress validity and the physical connection owner admit it.
          ingressAuthorization?.requireCurrent(response.request)
        } catch (error: Exception) {
          finishTransport("Gateway error: ${error.message}", error)
          cancelSocket(webSocket)
          return
        }
        val accepted =
          synchronized(lifecycleLock) {
            if (currentConnection !== this@Connection || desired !== target || state.get() != ConnectionState.CONNECTING) {
              false
            } else {
              connectHandshakeJob =
                connectionScope.launch {
                  try {
                    val challenge = awaitConnectChallenge()
                    sendConnect(challenge)
                  } catch (err: Throwable) {
                    connectDeferred.completeExceptionally(err)
                    closeQuietly()
                  }
                }
              true
            }
          }
        if (!accepted) {
          cancelSocket(webSocket)
        }
      }

      override fun onMessage(
        webSocket: WebSocket,
        text: String,
      ) {
        incomingMessages.trySend(text)
      }

      override fun onFailure(
        webSocket: WebSocket,
        t: Throwable,
        response: Response?,
      ) {
        val error = response?.let { ingressAuthorization?.rejection(it) } ?: t
        finishTransport(
          message = "Gateway error: ${error.message ?: error::class.java.simpleName}",
          connectError = error,
        )
      }

      override fun onClosing(
        webSocket: WebSocket,
        code: Int,
        reason: String,
      ) {
        // OkHttp requires the client to acknowledge a peer-initiated close before onClosed fires.
        webSocket.close(code, reason)
      }

      override fun onClosed(
        webSocket: WebSocket,
        code: Int,
        reason: String,
      ) {
        finishTransport(
          message = "Gateway closed: $reason",
          connectError = IllegalStateException("Gateway closed: $reason"),
        )
      }
    }

    private suspend fun sendConnect(connectChallenge: ConnectChallenge) {
      val identity = identityStore.loadOrCreate()
      val storedEntry = deviceAuthStore.loadEntry(target.endpoint.stableId, identity.deviceId, target.options.role)
      val storedToken = storedEntry?.token?.trim()
      val selectedAuth =
        selectConnectAuth(
          target = target,
          explicitGatewayToken = target.token?.trim()?.takeIf { it.isNotEmpty() },
          explicitBootstrapToken = target.bootstrapToken?.trim()?.takeIf { it.isNotEmpty() && !target.recoveringStoredBootstrap },
          explicitPassword = target.password?.trim()?.takeIf { it.isNotEmpty() },
          storedToken = storedToken?.takeIf { it.isNotEmpty() },
          storedScopes = storedEntry?.scopes.orEmpty(),
        )
      if (selectedAuth.authDeviceToken != null) {
        target.pendingDeviceTokenRetry = false
      }
      val payload =
        buildConnectParams(
          identity = identity,
          connectChallenge = connectChallenge,
          selectedAuth = selectedAuth,
        )
      val res = request(GatewayMethod.Connect.rawValue, payload, timeoutMs = CONNECT_RPC_TIMEOUT_MS)
      if (!res.ok) {
        val error = res.error ?: ErrorShape("UNAVAILABLE", "connect failed")
        // Only implicitly loaded credentials may recover an old install's spent setup code.
        // Never turn a rejection of newly supplied setup auth into access under an older grant.
        if (
          selectedAuth.authSource == GatewayConnectAuthSource.BOOTSTRAP_TOKEN &&
          target.bootstrapHandoff?.allowStoredTokenRecovery == true &&
          !target.recoveringStoredBootstrap &&
          error.details?.code == "AUTH_BOOTSTRAP_TOKEN_INVALID" &&
          shouldPersistBootstrapHandoffTokens(selectedAuth.authSource) &&
          listOf("node", "operator").all { role ->
            !deviceAuthStore.loadToken(target.endpoint.stableId, identity.deviceId, role).isNullOrBlank()
          }
        ) {
          target.recoveringStoredBootstrap = true
        }
        val shouldRetryWithDeviceToken =
          !target.deviceTokenRetryBudgetUsed &&
            selectedAuth.authDeviceToken == null &&
            !target.token.isNullOrBlank() &&
            !storedToken.isNullOrEmpty() &&
            isTrustedDeviceRetryEndpoint(target.endpoint, target.tls) &&
            error.details?.canRetryWithDeviceToken == true
        if (shouldRetryWithDeviceToken) {
          target.pendingDeviceTokenRetry = true
          target.deviceTokenRetryBudgetUsed = true
        } else if (
          selectedAuth.authDeviceToken != null &&
          error.details?.code == "AUTH_DEVICE_TOKEN_MISMATCH"
        ) {
          deviceAuthStore.clearToken(target.endpoint.stableId, identity.deviceId, target.options.role, onlyIfToken = storedToken)
        }
        throw GatewayConnectFailure(error)
      }
      val connected = parseConnectSuccess(res, identity.deviceId, selectedAuth)
      connectDeferred.complete(connected)
    }

    private fun shouldPersistBootstrapHandoffTokens(authSource: GatewayConnectAuthSource): Boolean {
      if (authSource != GatewayConnectAuthSource.BOOTSTRAP_TOKEN) return false
      return isLocalCleartextGatewayHost(target.endpoint.host) || target.tls != null
    }

    private fun filteredBootstrapHandoffScopes(
      role: String,
      scopes: List<String>,
    ): List<String>? =
      when (role.trim()) {
        "node" -> {
          emptyList()
        }

        // The Gateway bounds setup-code handoff to a closed mobile profile. Persist
        // only the supported full or limited scope set and drop unexpected extras.
        "operator" -> {
          val allowedOperatorScopes =
            setOf(
              "operator.admin",
              "operator.approvals",
              "operator.questions",
              "operator.read",
              "operator.talk.secrets",
              "operator.write",
            )
          scopes.filter { allowedOperatorScopes.contains(it) }.distinct().sorted()
        }

        else -> {
          null
        }
      }

    private fun persistIssuedDeviceToken(
      authSource: GatewayConnectAuthSource,
      deviceId: String,
      role: String,
      token: String,
      scopes: List<String>,
      replacesStoredToken: String? = null,
    ): Boolean {
      val persistedScopes =
        if (authSource == GatewayConnectAuthSource.BOOTSTRAP_TOKEN) {
          if (!shouldPersistBootstrapHandoffTokens(authSource)) return false
          filteredBootstrapHandoffScopes(role, scopes) ?: return false
        } else {
          scopes
        }
      return deviceAuthStore.saveToken(target.endpoint.stableId, deviceId, role, token, persistedScopes, replacesStoredToken)
    }

    private fun parseConnectSuccess(
      res: RpcResult,
      deviceId: String,
      selectedAuth: SelectedConnectAuth,
    ): ConnectedGateway {
      val payloadJson = res.payloadJson ?: throw IllegalStateException("connect failed: missing payload")
      val obj = json.parseToJsonElement(payloadJson).asObjectOrNull() ?: throw IllegalStateException("connect failed")
      target.pendingDeviceTokenRetry = false
      target.deviceTokenRetryBudgetUsed = false
      target.reconnectPausedForAuthFailure = false
      val server = obj["server"].asObjectOrNull()
      val serverName = server?.get("host").asStringOrNull()
      val serverVersion = server?.get("version").asStringOrNull()
      val features = obj["features"].asObjectOrNull()

      fun featureSet(name: String): Set<String>? =
        features
          ?.get(name)
          .asArrayOrNull()
          ?.mapNotNull { it.asStringOrNull()?.trim()?.takeIf(String::isNotEmpty) }
          ?.toSet()
      val authObj = obj["auth"].asObjectOrNull()
      val acceptedMethod = authObj?.get("method").asStringOrNull()
      // Legacy hello omits method, so use the exact accepted selection. A device-token
      // retry must never reuse the rejected shared token still present in that request.
      controlUiCredential =
        when {
          (acceptedMethod == "token" || acceptedMethod == null) && selectedAuth.authSource == GatewayConnectAuthSource.SHARED_TOKEN -> {
            selectedAuth.authToken?.let { NativeControlUiCredential.Token(it) }
          }

          (acceptedMethod == "password" || acceptedMethod == null) && selectedAuth.authSource == GatewayConnectAuthSource.PASSWORD -> {
            selectedAuth.authPassword?.let { NativeControlUiCredential.Password(it) }
          }

          else -> {
            null
          } // Device/bootstrap/other methods use the current scoped device grant.
        }
      val deviceToken = authObj?.get("deviceToken").asStringOrNull()
      val authRole = authObj?.get("role").asStringOrNull() ?: target.options.role
      val authSessionCap = authObj?.get("sessionCap").asStringOrNull()
      controlUiReadCredentials =
        listOfNotNull(deviceToken, selectedAuth.authDeviceToken, selectedAuth.authToken, selectedAuth.authPassword)
          .map(String::trim)
          .filter(String::isNotEmpty)
          .distinct()
      val authScopes = authObj?.get("scopes").asStringList()
      val persistedRoles = mutableMapOf<String, Boolean>()
      if (!deviceToken.isNullOrBlank()) {
        // Hello scopes describe this socket. Reissuing the same stored token must not narrow its
        // reusable grant metadata, while a rotated token starts with the live approved scopes.
        val sameStoredTokenRecord =
          selectedAuth.authSource != GatewayConnectAuthSource.BOOTSTRAP_TOKEN &&
            deviceToken.trim() == selectedAuth.storedToken &&
            authRole.trim().equals(target.options.role.trim(), ignoreCase = true)
        val persistedScopes = if (sameStoredTokenRecord) selectedAuth.storedScopes else authScopes
        val replacesStoredToken =
          if (selectedAuth.authSource == GatewayConnectAuthSource.DEVICE_TOKEN &&
            authRole.trim().equals(target.options.role.trim(), ignoreCase = true)
          ) {
            selectedAuth.storedToken
          } else {
            null
          }
        persistedRoles[authRole.trim()] =
          persistIssuedDeviceToken(selectedAuth.authSource, deviceId, authRole, deviceToken, persistedScopes, replacesStoredToken)
      }
      if (shouldPersistBootstrapHandoffTokens(selectedAuth.authSource)) {
        // Bootstrap connects can mint role-specific device tokens; store only locally trusted handoffs.
        authObj
          ?.get("deviceTokens")
          .asArrayOrNull()
          ?.mapNotNull { it.asObjectOrNull() }
          ?.forEach { tokenEntry ->
            val handoffToken = tokenEntry["deviceToken"].asStringOrNull()
            val handoffRole = tokenEntry["role"].asStringOrNull()
            val handoffScopes = tokenEntry["scopes"].asStringList()
            if (!handoffToken.isNullOrBlank() && !handoffRole.isNullOrBlank()) {
              persistedRoles[handoffRole.trim()] =
                persistIssuedDeviceToken(selectedAuth.authSource, deviceId, handoffRole, handoffToken, handoffScopes)
            }
          }
      }
      if (target.recoveringStoredBootstrap && selectedAuth.authSource == GatewayConnectAuthSource.DEVICE_TOKEN) {
        // A successful stored-node hello validates legacy recovery. Recommit both saved
        // roles before retiring its rejected bootstrap; this is never a fresh-setup path.
        for (role in listOf("node", "operator")) {
          if (role in persistedRoles) continue
          val entry = deviceAuthStore.loadEntry(target.endpoint.stableId, deviceId, role) ?: continue
          persistedRoles[role] =
            deviceAuthStore.saveToken(target.endpoint.stableId, deviceId, role, entry.token, entry.scopes, replacesStoredToken = entry.token)
        }
      }
      if (persistedRoles["node"] == true && persistedRoles["operator"] == true) {
        synchronized(lifecycleLock) {
          if (desired === target && currentConnection === this && target.bootstrapHandoff?.complete() == true) {
            target.bootstrapToken = null
          }
        }
      }
      val rawPluginSurfaceUrls = obj["pluginSurfaceUrls"].asObjectOrNull()
      val normalizedPluginSurfaceUrls =
        rawPluginSurfaceUrls?.mapNotNull { (surface, value) ->
          // Canvas URLs may be loopback gateway metadata; normalize them to the reachable Android endpoint.
          normalizeCanvasHostUrl(value.asStringOrNull(), target.endpoint, isTlsConnection = target.tls != null)
            ?.let { normalized -> surface to normalized }
        } ?: emptyList()
      val nextPluginSurfaceUrls = normalizedPluginSurfaceUrls.toMap()
      val snapshot = obj["snapshot"].asObjectOrNull()
      val sessionDefaults =
        snapshot
          ?.get("sessionDefaults")
          .asObjectOrNull()
      val nextMainSessionKey = sessionDefaults?.get("mainSessionKey").asStringOrNull()
      return ConnectedGateway(
        pluginSurfaceUrls = nextPluginSurfaceUrls,
        sessionRouting = GatewaySessionRouting(nextMainSessionKey, sessionDefaults?.get("mainKey").asStringOrNull()),
        hello =
          GatewayHelloSummary(
            serverName = serverName,
            remoteAddress = remoteAddress,
            serverVersion = serverVersion,
            mainSessionKey = nextMainSessionKey,
            updateAvailable = parseGatewayUpdateAvailableSummary(snapshot?.get("updateAvailable").asObjectOrNull()),
            authRole = authRole,
            authScopes = authScopes,
            authSessionCap = authSessionCap,
            methods = featureSet("methods"),
            capabilities = featureSet("capabilities"),
          ),
      )
    }

    private fun buildConnectParams(
      identity: DeviceIdentity,
      connectChallenge: ConnectChallenge,
      selectedAuth: SelectedConnectAuth,
    ): JsonObject {
      val client = target.options.client
      val locale = Locale.getDefault().toLanguageTag()
      val authJson =
        buildJsonObject {
          when {
            selectedAuth.authToken != null -> {
              put("token", JsonPrimitive(selectedAuth.authToken))
              selectedAuth.authDeviceToken?.let { put("deviceToken", JsonPrimitive(it)) }
            }

            selectedAuth.authBootstrapToken != null -> {
              put("bootstrapToken", JsonPrimitive(selectedAuth.authBootstrapToken))
            }

            selectedAuth.authPassword != null -> {
              put("password", JsonPrimitive(selectedAuth.authPassword))
            }
          }
        }.takeIf { it.isNotEmpty() }

      val connectScopes = resolveConnectScopes(selectedAuth)
      val signedAtMs = connectChallenge.issuedAtMs
      val connectNonce = connectChallenge.nonce
      // V3 signatures bind the auth token, nonce, role, and scopes so replayed connect frames fail.
      val payload =
        DeviceAuthPayload.buildV3(
          deviceId = identity.deviceId,
          clientId = client.id,
          clientMode = client.mode,
          role = target.options.role,
          scopes = connectScopes,
          signedAtMs = signedAtMs,
          token = selectedAuth.authToken ?: selectedAuth.authBootstrapToken,
          nonce = connectNonce,
          platform = client.platform,
          deviceFamily = client.deviceFamily,
        )
      val signature = identityStore.signPayload(payload, identity)
      val publicKey = identityStore.publicKeyBase64Url(identity)
      val deviceJson =
        if (!signature.isNullOrBlank() && !publicKey.isNullOrBlank()) {
          buildJsonObject {
            put("id", JsonPrimitive(identity.deviceId))
            put("publicKey", JsonPrimitive(publicKey))
            put("signature", JsonPrimitive(signature))
            put("signedAt", JsonPrimitive(signedAtMs))
            put("nonce", JsonPrimitive(connectNonce))
          }
        } else {
          null
        }

      return buildJsonObject {
        put("minProtocol", JsonPrimitive(GATEWAY_MIN_PROTOCOL_VERSION))
        put("maxProtocol", JsonPrimitive(GATEWAY_PROTOCOL_VERSION))
        put("client", client.toJsonObject())
        if (target.options.caps.isNotEmpty()) put("caps", JsonArray(target.options.caps.map(::JsonPrimitive)))
        if (target.options.commands.isNotEmpty()) put("commands", JsonArray(target.options.commands.map(::JsonPrimitive)))
        if (target.options.permissions.isNotEmpty()) {
          put("permissions", JsonObject(target.options.permissions.mapValues { (_, value) -> JsonPrimitive(value) }))
        }
        put("role", JsonPrimitive(target.options.role))
        if (connectScopes.isNotEmpty()) put("scopes", JsonArray(connectScopes.map(::JsonPrimitive)))
        authJson?.let { put("auth", it) }
        deviceJson?.let { put("device", it) }
        put("locale", JsonPrimitive(locale))
        target.options.userAgent?.trim()?.takeIf { it.isNotEmpty() }?.let {
          put("userAgent", JsonPrimitive(it))
        }
      }
    }

    private fun resolveConnectScopes(selectedAuth: SelectedConnectAuth): List<String> {
      if (selectedAuth.authSource == GatewayConnectAuthSource.BOOTSTRAP_TOKEN) {
        return filteredBootstrapHandoffScopes(target.options.role, target.options.scopes).orEmpty()
      }
      if (selectedAuth.authSource == GatewayConnectAuthSource.DEVICE_TOKEN && selectedAuth.storedScopes.isNotEmpty()) {
        return selectedAuth.storedScopes
      }
      return target.options.scopes
    }

    private suspend fun handleMessage(text: String) {
      val frame = json.parseToJsonElement(text).asObjectOrNull() ?: return
      // Accepted responses settle this socket's pending requests even after close.
      when (frame["type"].asStringOrNull()) {
        "res" -> handleResponse(frame)
        "event" -> if (state.get() != ConnectionState.CLOSED) handleEvent(frame)
      }
    }

    private fun handleResponse(frame: JsonObject) {
      val response =
        runCatching {
          json.decodeFromJsonElement(GatewayResponseFrame.serializer(), frame)
        }.getOrNull() ?: return
      val id = response.id
      if (id == connectRequestId) connectResponseAccepted.set(true)
      // Read the raw element so an explicit JSON null remains distinguishable from an omitted payload.
      val payloadJson = frame["payload"]?.toString()
      val error =
        response.error?.let { wireError ->
          val detailObj = wireError.details.asObjectOrNull()
          val details =
            detailObj?.let {
              GatewayErrorDetails(
                code = it["code"].asStringOrNull(),
                canRetryWithDeviceToken = it["canRetryWithDeviceToken"].asBooleanOrNull() == true,
                recommendedNextStep = it["recommendedNextStep"].asStringOrNull(),
                pauseReconnect = it["pauseReconnect"].asBooleanOrNull(),
                reason = it["reason"].asStringOrNull(),
                method = it["method"].asStringOrNull(),
                requestId = normalizeGatewayApprovalRequestId(it["requestId"].asStringOrNull()),
                retryable = it["retryable"].asBooleanOrNull() == true || wireError.retryable == true,
                retryAfterMs = frame["error"].asObjectOrNull()?.get("retryAfterMs").asIntOrNull(),
                clientMinProtocol = it["clientMinProtocol"].asIntOrNull(),
                clientMaxProtocol = it["clientMaxProtocol"].asIntOrNull(),
                expectedProtocol = it["expectedProtocol"].asIntOrNull(),
                minimumProbeProtocol = it["minimumProbeProtocol"].asIntOrNull(),
                clawhubWarning = it["warning"].asStringOrNull(),
                missingScope = it["missingScope"].asStringOrNull(),
                requiredScopes = it["requiredScopes"].asStringList(),
              )
            }
          ErrorShape(wireError.code, wireError.message, details, retryable = wireError.retryable == true)
        }
      pending.remove(id)?.complete(RpcResult(response.ok, payloadJson, error))
    }

    private fun handleEvent(frame: JsonObject) {
      val gatewayEvent =
        runCatching {
          json.decodeFromJsonElement(GatewayEventFrame.serializer(), frame)
        }.getOrNull() ?: return
      val event = gatewayEvent.event
      val payloadJson = frame["payload"]?.toString()
      if (event == GatewayEvent.ConnectChallenge.rawValue) {
        if (!connectChallengeDeferred.isCompleted) {
          val challenge = extractConnectChallenge(payloadJson)
          if (challenge == null) {
            connectChallengeDeferred.completeExceptionally(
              IllegalStateException("gateway connect challenge invalid"),
            )
          } else {
            connectChallengeDeferred.complete(challenge)
          }
        }
        return
      }
      // Retired sockets can still drain queued frames after reconnect. Never let them mutate current state.
      if (currentConnection !== this) return
      gatewayEvent.seq?.let { sequence ->
        val previous = lastEventSequence
        if (previous != null && sequence > previous + 1) {
          if (event == "chat" && payloadJson != null) {
            val payload = frame["payload"].asObjectOrNull()
            if (payload != null && payload["state"].asStringOrNull() in listOf("final", "error", "aborted")) {
              liveTextProjection.project(event, payload)
              onEvent(event, payloadJson)
              if (currentConnection !== this || !isReady()) return
            }
          }
          recoverLiveEvents()
          return
        }
        lastEventSequence = sequence
      }
      if (event == GatewayEvent.NodeInvokeRequest.rawValue && payloadJson != null && onInvoke != null) {
        handleInvokeEvent(payloadJson)
        return
      }
      val projectedPayload =
        if ((event == "chat" || event == "agent") && payloadJson != null) {
          val payload = frame["payload"].asObjectOrNull()
          if (payload == null) {
            payloadJson
          } else {
            val projected = liveTextProjection.project(event, payload)
            if (projected == null) {
              recoverLiveEvents()
              return
            }
            projected.toString()
          }
        } else {
          payloadJson
        }
      onEvent(event, projectedPayload)
    }

    private fun recoverLiveEvents() {
      onEvent("seqGap", null)
      synchronized(lifecycleLock) {
        // A recovery callback can disconnect or replace this connection itself.
        if (currentConnection === this && state.get() != ConnectionState.CLOSED) reconnect()
      }
    }

    private suspend fun awaitConnectChallenge(): ConnectChallenge =
      try {
        withTimeout(2_000) { connectChallengeDeferred.await() }
      } catch (err: TimeoutCancellationException) {
        throw GatewayConnectFailure(gatewayNetworkConnectError(timedOut = true))
      }

    private fun extractConnectChallenge(payloadJson: String?): ConnectChallenge? {
      if (payloadJson.isNullOrBlank()) return null
      val obj = parseJsonOrNull(payloadJson)?.asObjectOrNull() ?: return null
      val nonce = obj["nonce"].asStringOrNull()?.trim()?.takeIf { it.isNotEmpty() } ?: return null
      val issuedAtMs =
        obj["ts"].asJsonIntegerLongOrNull()?.takeIf { it >= 0 } ?: return null
      return ConnectChallenge(nonce = nonce, issuedAtMs = issuedAtMs)
    }

    private fun handleInvokeEvent(payloadJson: String) {
      val payload =
        runCatching {
          json.decodeFromString(GatewayNodeInvokeRequest.serializer(), payloadJson)
        }.getOrNull() ?: return
      connectionScope.launch {
        val result = executeInvokeRequest(payload)
        sendInvokeResult(payload.id, payload.nodeId, result, payload.timeoutMs)
      }
    }

    private suspend fun executeInvokeRequest(request: GatewayNodeInvokeRequest): InvokeResult {
      val handler = onInvoke ?: return InvokeResult.error("UNAVAILABLE", "invoke handler missing")
      return try {
        val timeoutMs = resolveInvokeExecutionTimeoutMs(request.timeoutMs)
        if (timeoutMs == null) {
          handler(request)
        } else {
          // Keep the deadline owner separate so a blocking handler cannot delay the timeout result.
          // Cancellation still reaches cooperative handlers; late results are never sent.
          val handlerTask = connectionScope.async { handler(request) }
          try {
            withTimeoutOrNull(timeoutMs) { handlerTask.await() }
              ?: run {
                handlerTask.cancel(CancellationException("node invoke timed out"))
                InvokeResult.error("TIMEOUT", "node invoke timed out")
              }
          } catch (err: CancellationException) {
            handlerTask.cancel(err)
            throw err
          }
        }
      } catch (err: TimeoutCancellationException) {
        InvokeResult.error("TIMEOUT", err.message ?: "node invoke timed out")
      } catch (err: CancellationException) {
        throw err
      } catch (err: Throwable) {
        val parsed = parseInvokeErrorFromThrowable(err, fallbackMessage = err::class.java.simpleName)
        InvokeResult.error(code = parsed.code, message = parsed.message)
      }
    }

    private suspend fun sendInvokeResult(
      id: String,
      nodeId: String,
      result: InvokeResult,
      invokeTimeoutMs: Long?,
    ) {
      val parsedPayload = result.payloadJson?.let { parseJsonOrNull(it) }
      val params =
        json
          .encodeToJsonElement(
            GatewayNodeInvokeResultParams.serializer(),
            GatewayNodeInvokeResultParams(
              id = id,
              nodeId = nodeId,
              ok = result.ok,
              payload = parsedPayload,
              payloadJson = if (parsedPayload == null) result.payloadJson else null,
              error =
                result.error?.let { err ->
                  GatewayNodeInvokeResultParamsError(code = err.code, message = err.message)
                },
            ),
          )
      val ackTimeoutMs = resolveInvokeResultAckTimeoutMs(invokeTimeoutMs)
      try {
        request(GatewayMethod.NodeInvokeResult.rawValue, params, timeoutMs = ackTimeoutMs)
      } catch (err: Throwable) {
        Log.w(
          loggerTag,
          "node.invoke.result failed (ackTimeoutMs=$ackTimeoutMs): ${err.message ?: err::class.java.simpleName}",
        )
      }
    }

    private fun failPending() {
      val waiters =
        synchronized(pendingLock) {
          pending.values.toList().also { pending.clear() }
        }
      for (waiter in waiters) {
        waiter.completeExceptionally(GatewayRequestOutcomeUnknown("Gateway disconnected before response"))
      }
    }
  }

  private suspend fun runLoop() {
    val loopJob = currentCoroutineContext().job
    while (loopJob.isActive) {
      val target =
        synchronized(lifecycleLock) {
          if (job !== loopJob) return
          desired ?: return
        }
      if (target.reconnectPausedForAuthFailure) {
        // Only explicit reconnect/target replacement can resume an auth-paused intent.
        reconnectSignal.receive()
        target.attempt = 0
        continue
      }

      try {
        synchronized(notificationLock) {
          if (synchronized(lifecycleLock) { job === loopJob && loopJob.isActive && desired === target }) {
            if (drainReconnectSignals()) target.attempt = 0
            onDisconnected(if (target.attempt == 0) "Connecting…" else "Reconnecting…")
          }
        }
        connectOnce(target, loopJob)
        target.attempt = 0
      } catch (err: Throwable) {
        loopJob.ensureActive()
        if (err is CancellationException) throw err
        target.attempt = (target.attempt + 1).coerceAtMost(10)
        if (desired !== target || target.reconnectPausedForAuthFailure) continue
        if (awaitGatewayReconnectSignal(reconnectSignal, gatewayReconnectDelayMs(target.attempt))) {
          target.attempt = 0
        }
      }
    }
  }

  private suspend fun connectOnce(
    target: DesiredConnection,
    loopJob: Job,
  ) = withContext(Dispatchers.IO) {
    var ownedConnection: Connection? = null
    try {
      val conn = Connection(target).also { ownedConnection = it }
      synchronized(lifecycleLock) {
        if (desired !== target) return@withContext
        target.cleanupDeadline?.cancel()
        target.cleanupDeadline = null
        currentConnection = conn
      }
      val connected = conn.connect()
      synchronized(notificationLock) {
        synchronized(lifecycleLock) {
          if (currentConnection !== conn || desired !== target || job?.isActive != true || !conn.markReady(connected.hello)) return@withContext
          // Ready metadata precedes callbacks; retries requested by a callback remain queued.
          pluginSurfaceUrls = connected.pluginSurfaceUrls
          sessionRouting = connected.sessionRouting
          drainReconnectSignals()
          onConnected(connected.hello)
          // The callback can replace or disconnect this intent; only its current socket publishes readiness.
          if (currentConnection === conn && desired === target && job?.isActive == true && conn.isReady()) {
            target.onReady?.invoke()
          }
        }
      }
      conn.awaitClose()
    } catch (err: CancellationException) {
      throw err
    } catch (err: Throwable) {
      // Publish before cleanup: OkHttp cannot deliver onFailure while native DNS is blocked.
      // The reconnect loop still waits for cleanup, so Retry cannot accumulate resolver workers.
      synchronized(notificationLock) {
        val conn = ownedConnection
        val error =
          when (err) {
            is GatewayConnectFailure -> err.gatewayError

            is GatewayExternalAuthorizationException -> ErrorShape("EXTERNAL_AUTH_REQUIRED", err.message.orEmpty())

            is ConnectException,
            is NoRouteToHostException,
            is UnknownHostException,
            is SocketException,
            is SocketTimeoutException,
            -> gatewayNetworkConnectError()

            else -> null
          }
        val current =
          synchronized(lifecycleLock) {
            if ((conn != null && currentConnection !== conn) || desired !== target || job !== loopJob || !loopJob.isActive) {
              false
            } else {
              // Commit before callbacks so a reentrant connect/reconnect owns the next state.
              target.reconnectPausedForAuthFailure = error?.let { shouldPauseReconnectAfterAuthFailure(target, it) } == true
              true
            }
          }
        if (current) {
          conn?.retire()
          onDisconnected("Gateway error: ${err.message ?: err::class.java.simpleName}")
          if (error != null && synchronized(lifecycleLock) { job === loopJob && loopJob.isActive && desired === target }) {
            onConnectFailure(error, target.reconnectPausedForAuthFailure)
          }
        }
      }
      throw err
    } finally {
      // Callback failures and cancellation must drain this socket's owned work before the loop
      // forgets it. Otherwise a retired connect can restore device auth after a later reset.
      ownedConnection?.let { conn ->
        withContext(NonCancellable) {
          conn.closeQuietly()
          conn.joinOwnedWork()
        }
        synchronized(lifecycleLock) {
          if (currentConnection === conn) {
            currentConnection = null
            pluginSurfaceUrls = emptyMap()
            sessionRouting = null
          }
        }
      }
    }
  }

  private fun normalizeCanvasHostUrl(
    raw: String?,
    endpoint: GatewayEndpoint,
    isTlsConnection: Boolean,
  ): String? {
    val trimmed = raw?.trim().orEmpty()
    val parsed = trimmed.takeIf { it.isNotBlank() }?.let { runCatching { java.net.URI(it) }.getOrNull() }
    val host = parsed?.host?.trim().orEmpty()
    val scheme = parsed?.scheme ?: "http"
    val port = parsed?.port?.takeIf { it > 0 } ?: if (scheme.equals("https", ignoreCase = true)) 443 else 80
    val usesFallbackHost = host.isBlank() || isLoopbackGatewayHost(host)
    val isGatewayAuthority = usesFallbackHost || endpoint.matchesGatewayAuthority(host, port)
    val path = parsed?.rawPath.orEmpty()
    val capability = path.removePrefix("/__openclaw__/cap/")
    val isRootCapability = path != capability && capability.isNotEmpty() && !capability.contains('/')
    val hasUriExtras = parsed?.rawUserInfo != null || parsed?.rawQuery != null || parsed?.rawFragment != null
    val isHttpSurface = scheme.equals("http", ignoreCase = true) || scheme.equals("https", ignoreCase = true)
    // Only gateway-hosted root capabilities inherit its proxy prefix. Judge the original
    // authority before TLS rewriting, and leave explicit surface paths and token bytes intact.
    val contextPath =
      if (isGatewayAuthority && isRootCapability && !hasUriExtras && isHttpSurface) {
        endpoint.contextPath
      } else {
        ""
      }
    val suffix = contextPath + buildUrlSuffix(parsed)

    val needsTlsRewrite = isTlsConnection && (!scheme.equals("https", ignoreCase = true) || port != endpoint.port)
    if (!usesFallbackHost && !needsTlsRewrite && contextPath.isEmpty()) return trimmed
    val resolvedHost =
      if (usesFallbackHost) {
        endpoint.tailnetDns?.trim().takeIf { !it.isNullOrEmpty() }
          ?: endpoint.lanHost?.trim().takeIf { !it.isNullOrEmpty() }
          ?: endpoint.host.trim()
      } else {
        host
      }
    if (resolvedHost.isEmpty()) return trimmed.ifBlank { null }
    val resolvedScheme = (if (isTlsConnection) "https" else scheme).lowercase()
    val resolvedPort = if (usesFallbackHost || isTlsConnection) endpoint.port else port
    val portSuffix = if ((resolvedScheme == "https" && resolvedPort == 443) || (resolvedScheme == "http" && resolvedPort == 80)) "" else ":$resolvedPort"
    return "$resolvedScheme://${formatGatewayAuthorityHost(resolvedHost)}$portSuffix$suffix"
  }

  private fun buildUrlSuffix(uri: java.net.URI?): String {
    if (uri == null) return ""
    val path = uri.rawPath?.takeIf { it.isNotBlank() } ?: ""
    val query = uri.rawQuery?.takeIf { it.isNotBlank() }?.let { "?$it" } ?: ""
    val fragment = uri.rawFragment?.takeIf { it.isNotBlank() }?.let { "#$it" } ?: ""
    return "$path$query$fragment"
  }

  private fun selectConnectAuth(
    target: DesiredConnection,
    explicitGatewayToken: String?,
    explicitBootstrapToken: String?,
    explicitPassword: String?,
    storedToken: String?,
    storedScopes: List<String>,
  ): SelectedConnectAuth {
    val shouldUseDeviceRetryToken =
      target.pendingDeviceTokenRetry &&
        explicitGatewayToken != null &&
        storedToken != null &&
        isTrustedDeviceRetryEndpoint(target.endpoint, target.tls)
    val authToken = explicitGatewayToken ?: storedToken.takeIf { explicitPassword == null && explicitBootstrapToken == null }
    val authDeviceToken = if (shouldUseDeviceRetryToken) storedToken else null
    val authBootstrapToken = if (authToken == null) explicitBootstrapToken else null
    val authSource =
      when {
        authDeviceToken != null || (explicitGatewayToken == null && authToken != null) -> GatewayConnectAuthSource.DEVICE_TOKEN
        authToken != null -> GatewayConnectAuthSource.SHARED_TOKEN
        authBootstrapToken != null -> GatewayConnectAuthSource.BOOTSTRAP_TOKEN
        explicitPassword != null -> GatewayConnectAuthSource.PASSWORD
        else -> GatewayConnectAuthSource.NONE
      }
    return SelectedConnectAuth(
      authToken = authToken,
      authBootstrapToken = authBootstrapToken,
      authDeviceToken = authDeviceToken,
      authPassword = explicitPassword,
      storedToken = storedToken,
      storedScopes = storedScopes,
      authSource = authSource,
    )
  }

  private fun shouldPauseReconnectAfterAuthFailure(
    target: DesiredConnection,
    error: ErrorShape,
  ): Boolean =
    error.code == "EXTERNAL_AUTH_REQUIRED" ||
      (
        !(target.recoveringStoredBootstrap && error.details?.code == "AUTH_BOOTSTRAP_TOKEN_INVALID") &&
          shouldPauseGatewayReconnectAfterAuthFailure(
            error = error,
            hasBootstrapToken = target.bootstrapToken?.trim()?.isNotEmpty() == true,
            role = target.options.role,
            scopes = target.options.scopes,
            pendingDeviceTokenRetry = target.pendingDeviceTokenRetry,
          )
      )

  private fun isTrustedDeviceRetryEndpoint(
    endpoint: GatewayEndpoint,
    tls: GatewayTlsParams?,
  ): Boolean {
    if (isLocalCleartextGatewayHost(endpoint.host)) return true
    // Retrying a stored device token alongside a shared token is only safe for
    // remote gateways when an existing TLS pin already identifies the endpoint.
    return tls?.expectedFingerprint?.trim()?.isNotEmpty() == true
  }
}

internal fun gatewayNetworkConnectError(
  timedOut: Boolean = false,
  waitingForCleanup: Boolean = false,
): GatewaySession.ErrorShape =
  GatewaySession.ErrorShape(
    code = "NETWORK_UNREACHABLE",
    message =
      when {
        waitingForCleanup -> "The previous network request is still stopping. Check your connection, then retry."
        timedOut -> "Gateway connection timed out. Check your network and that the Gateway is running, then retry."
        else -> "Could not reach the Gateway. Check your network and that the Gateway is running, then retry."
      },
    details =
      GatewayErrorDetails(
        code = "NETWORK_UNREACHABLE",
        canRetryWithDeviceToken = false,
        recommendedNextStep = null,
        reason =
          when {
            waitingForCleanup -> "transport-cleanup"
            timedOut -> "timeout"
            else -> "unreachable"
          },
        retryable = true,
      ),
  )

/** Decides whether auth failures should stop reconnect churn until the user changes credentials. */
internal fun shouldPauseGatewayReconnectAfterAuthFailure(
  error: GatewaySession.ErrorShape,
  hasBootstrapToken: Boolean,
  role: String?,
  scopes: List<String>,
  pendingDeviceTokenRetry: Boolean,
): Boolean {
  val details = error.details
  val code = details?.code
  if (code == "PAIRING_REQUIRED") {
    val pairingDetails = details
    return !(
      hasBootstrapToken &&
        role?.trim() == "node" &&
        scopes.isEmpty() &&
        pairingDetails.reason == "not-paired" &&
        (
          pairingDetails.pauseReconnect == false ||
            pairingDetails.recommendedNextStep == "wait_then_retry"
        )
    )
  }
  // Gateway rate limits last minutes; generic retry advice must not trigger the short reconnect loop.
  if (code == "AUTH_RATE_LIMITED") return true
  when (details?.recommendedNextStep) {
    "wait_then_retry" -> return false

    "retry_with_device_token" -> return !pendingDeviceTokenRetry

    "update_auth_configuration",
    "update_auth_credentials",
    "review_auth_configuration",
    -> return true
  }
  return when (code) {
    "AUTH_TOKEN_MISSING",
    "AUTH_TOKEN_NOT_CONFIGURED",
    "AUTH_DEVICE_TOKEN_MISMATCH",
    "AUTH_BOOTSTRAP_TOKEN_INVALID",
    "AUTH_PASSWORD_MISSING",
    "AUTH_PASSWORD_MISMATCH",
    "AUTH_PASSWORD_NOT_CONFIGURED",
    "AUTH_SCOPE_MISMATCH",
    "AUTH_VERIFIED_USER_REQUIRED",
    "CONTROL_UI_DEVICE_IDENTITY_REQUIRED",
    "DEVICE_IDENTITY_REQUIRED",
    -> true

    // The first shared-token mismatch may schedule one trusted stored-device-token retry.
    // Once no retry is pending, keep the terminal recovery action visible until credentials change.
    "AUTH_TOKEN_MISMATCH" -> !pendingDeviceTokenRetry

    "PROTOCOL_MISMATCH" -> true

    else -> false
  }
}

private fun GatewayEndpoint.matchesGatewayAuthority(
  surfaceHost: String,
  surfacePort: Int,
): Boolean =
  "http://${formatGatewayAuthority(host.trim().trimEnd('.'), port)}".toHttpUrlOrNull()?.let {
    it == "http://${formatGatewayAuthority(surfaceHost.trim().trimEnd('.'), surfacePort)}".toHttpUrlOrNull()
  } == true

/** Retains pins for the same TLS authority, canonicalizing numeric hosts without adding DNS aliases. */
internal fun gatewayTlsFingerprintForCanvasSurface(
  fingerprint: String?,
  surfaceUrl: String,
  endpoint: GatewayEndpoint,
  isTlsConnection: Boolean,
): String? {
  if (!isTlsConnection || fingerprint == null) return null
  val surface = runCatching { java.net.URI(surfaceUrl) }.getOrNull() ?: return null
  if (!surface.scheme.equals("https", ignoreCase = true)) return null
  val surfaceHost = surface.host?.trim()?.trimEnd('.') ?: return null
  if (!surfaceHost.equals(endpoint.host.trim().trimEnd('.'), ignoreCase = true) && ':' !in surfaceHost && ':' !in endpoint.host) return null
  return fingerprint.takeIf { endpoint.matchesGatewayAuthority(surfaceHost, surface.port.takeIf { it > 0 } ?: 443) }
}

internal fun buildGatewayWebSocketUrl(
  host: String,
  port: Int,
  useTls: Boolean,
  contextPath: String = "",
): String {
  val scheme = if (useTls) "wss" else "ws"
  val path = normalizeGatewayContextPath(contextPath)
  return "$scheme://${formatGatewayAuthority(host, port)}$path"
}

/** Builds one gateway upgrade request without exposing proxy credentials to cleartext routes. */
internal fun buildGatewayWebSocketUpgradeRequest(
  endpoint: GatewayEndpoint,
  tls: GatewayTlsParams?,
  customHeadersProvider: ((stableId: String) -> Map<String, String>)?,
): Request {
  val request =
    Request.Builder().url(
      buildGatewayWebSocketUrl(
        endpoint.host,
        endpoint.port,
        tls != null,
        endpoint.contextPath,
      ),
    )
  if (tls == null) return request.build()

  // Read at connect time so edits apply on the next reconnect. Headers may contain service tokens
  // or Authorization values, so the cleartext branch above must never invoke the provider.
  for ((name, value) in GatewayCustomHeaders.sanitized(customHeadersProvider?.invoke(endpoint.stableId).orEmpty())) {
    request.addHeader(name, value)
  }
  return request.build()
}

/** Formats host/port for gateway URLs, including IPv6 bracket wrapping. */
internal fun formatGatewayAuthority(
  host: String,
  port: Int,
): String = "${formatGatewayAuthorityHost(host)}:$port"

private fun formatGatewayAuthorityHost(host: String): String {
  val normalizedHost = host.trim().trim('[', ']')
  return if (normalizedHost.contains(":")) "[$normalizedHost]" else normalizedHost
}

private fun JsonElement?.asBooleanOrNull(): Boolean? {
  val content = (this as? JsonPrimitive)?.content?.trim() ?: return null
  return when {
    content.equals("true", ignoreCase = true) -> true
    content.equals("false", ignoreCase = true) -> false
    else -> null
  }
}

private fun JsonElement?.asJsonIntegerLongOrNull(): Long? = (this as? JsonPrimitive)?.takeUnless { it.isString }?.content?.toLongOrNull()

private fun JsonElement?.asIntOrNull(): Int? = (this as? JsonPrimitive)?.content?.toIntOrNull()

private fun JsonElement?.asStringList(): List<String> = asArrayOrNull()?.mapNotNull { it.asStringOrNull() }.orEmpty()

private fun parseJsonOrNull(payload: String): JsonElement? {
  val trimmed = payload.trim()
  if (trimmed.isEmpty()) return null
  return try {
    Json.parseToJsonElement(trimmed)
  } catch (_: Throwable) {
    null
  }
}

/** Keeps invoke-result ack waits inside the gateway-supported timeout window. */
internal fun resolveInvokeResultAckTimeoutMs(invokeTimeoutMs: Long?): Long {
  val normalized = invokeTimeoutMs?.takeIf { it > 0L } ?: 15_000L
  return normalized.coerceIn(15_000L, 120_000L)
}

/** Zero disables the deadline; an omitted value uses the same 30s default as Gateway/iOS. */
internal fun resolveInvokeExecutionTimeoutMs(invokeTimeoutMs: Long?): Long? {
  val normalized = invokeTimeoutMs ?: 30_000L
  if (normalized <= 0L) return null
  return normalized.coerceAtMost(Int.MAX_VALUE.toLong())
}
