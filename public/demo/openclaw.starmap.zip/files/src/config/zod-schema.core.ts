import path from "node:path";
import { normalizeStringEntries } from "@openclaw/normalization-core/string-normalization";
import { z } from "zod";
import { isSafeExecutableValue } from "../infra/exec-safety.js";
import { normalizeExactAllowedHost } from "../secrets/exact-hostname.js";
import { ENV_SECRET_REF_ID_RE, SECRET_PROVIDER_ALIAS_PATTERN } from "../secrets/ref-contract.js";
import { MODEL_APIS } from "./model-config-vocabulary.js";
import { isBuiltInModelProviderOverlayId } from "./model-provider-overlay-ids.js";
import { AgentRuntimePolicySchema } from "./zod-schema.agent-entry-base.js";
import { createAllowDenyChannelRulesSchema } from "./zod-schema.allowdeny.js";
import { DmConfigSchema } from "./zod-schema.messages.js";
import { ModelCompatSchema } from "./zod-schema.model-compat.js";
import { SecretInputSchema } from "./zod-schema.secret-input.js";
import { sensitive } from "./zod-schema.sensitive.js";
import { TtsAutoSchema } from "./zod-schema.tts-auto.js";

export {
  DmConfigSchema,
  GroupChatSchema,
  MentionPatternsPolicySchema,
  ProviderCommandsSchema,
} from "./zod-schema.messages.js";
export { SecretInputSchema, SecretRefSchema } from "./zod-schema.secret-input.js";
export { TtsAutoSchema } from "./zod-schema.tts-auto.js";

const WINDOWS_ABS_PATH_PATTERN = /^[A-Za-z]:[\\/]/;
const WINDOWS_UNC_PATH_PATTERN = /^\\\\[^\\]+\\[^\\]+/;

function isAbsolutePath(value: string): boolean {
  // `path.isAbsolute` follows the host OS, but config files can be authored for Windows from
  // macOS/Linux. Accept Windows forms explicitly so cross-platform config validation stays stable.
  return (
    path.isAbsolute(value) ||
    WINDOWS_ABS_PATH_PATTERN.test(value) ||
    WINDOWS_UNC_PATH_PATTERN.test(value)
  );
}

/** Canonical operator-configurable SSRF policy shared by network-capable surfaces. */
export const SsrFPolicyConfigSchema = z.strictObject({
  dangerouslyAllowPrivateNetwork: z.boolean().optional(),
  allowRfc2544BenchmarkRange: z.boolean().optional(),
  allowIpv6UniqueLocalRange: z.boolean().optional(),
  allowedHostnames: z.array(z.string()).optional(),
  blockedHostnames: z.array(z.string()).optional(),
});

const SecretsEnvProviderSchema = z.strictObject({
  source: z.literal("env"),
  /** Optional env var allowlist (exact names). */
  allowlist: z.array(z.string().regex(ENV_SECRET_REF_ID_RE)).max(256).optional(),
});

const SecretsFileProviderSchema = z.strictObject({
  source: z.literal("file"),
  path: z.string().min(1),
  mode: z.union([z.literal("singleValue"), z.literal("json")]).optional(),
  timeoutMs: z.number().int().positive().max(120000).optional(),
  maxBytes: z
    .number()
    .int()
    .positive()
    .max(20 * 1024 * 1024)
    .optional(),
});

const SecretsManualExecProviderSchema = z.strictObject({
  source: z.literal("exec"),
  command: z
    .string()
    .min(1)
    .refine(isSafeExecutableValue, "secrets.providers.*.command is unsafe.")
    .refine(isAbsolutePath, "secrets.providers.*.command must be an absolute path."),
  args: z.array(z.string().max(1024)).max(128).optional(),
  timeoutMs: z.number().int().positive().max(120000).optional(),
  noOutputTimeoutMs: z.number().int().positive().max(120000).optional(),
  maxOutputBytes: z
    .number()
    .int()
    .positive()
    .max(20 * 1024 * 1024)
    .optional(),
  jsonOnly: z.boolean().optional(),
  env: z.record(z.string(), z.string()).optional(),
  passEnv: z.array(z.string().regex(ENV_SECRET_REF_ID_RE)).max(128).optional(),
  trustedDirs: z
    .array(z.string().min(1).refine(isAbsolutePath, "trustedDirs entries must be absolute paths."))
    .max(64)
    .optional(),
});

const SecretsPluginIntegrationExecProviderSchema = z.strictObject({
  source: z.literal("exec"),
  pluginIntegration: z.strictObject({
    pluginId: z.string().min(1).max(128),
    integrationId: z.string().min(1).max(128),
  }),
});

const SecretsExecProviderSchema = z.union([
  SecretsManualExecProviderSchema,
  SecretsPluginIntegrationExecProviderSchema,
]);

const SecretsStoreProviderSchema = z.strictObject({ source: z.literal("store") });

// Same exact-host contract as per-secret destination bindings: rejecting schemes,
// ports, wildcards, and malformed hostnames here keeps invalid entries out of the
// egress-proxy startup path, which would otherwise throw while starting the Gateway.
const EgressProxyExactHostSchema = z
  .string()
  .trim()
  .min(1)
  .superRefine((host, ctx) => {
    try {
      normalizeExactAllowedHost(host);
    } catch (error) {
      ctx.addIssue({
        code: "custom",
        message: error instanceof Error ? error.message : "Invalid allowed host",
      });
    }
  });

export const SecretProviderSchema = z.union([
  SecretsEnvProviderSchema,
  SecretsFileProviderSchema,
  SecretsExecProviderSchema,
  SecretsStoreProviderSchema,
]);

export const SecretsConfigSchema = z
  .strictObject({
    egressProxy: z
      .strictObject({
        enabled: z.boolean().optional(),
        allowedHosts: z.array(EgressProxyExactHostSchema).max(256).optional(),
        bypassHosts: z.array(EgressProxyExactHostSchema).max(256).optional(),
      })
      .optional(),
    providers: z.object({}).catchall(SecretProviderSchema).optional(),
    defaults: z
      .strictObject({
        env: z.string().regex(SECRET_PROVIDER_ALIAS_PATTERN).optional(),
        file: z.string().regex(SECRET_PROVIDER_ALIAS_PATTERN).optional(),
        exec: z.string().regex(SECRET_PROVIDER_ALIAS_PATTERN).optional(),
        store: z.string().regex(SECRET_PROVIDER_ALIAS_PATTERN).optional(),
      })
      .optional(),
  })
  .optional();

const LEGACY_OPENAI_CODEX_RESPONSES_API = "openai-codex-responses";
const OPENAI_CHATGPT_RESPONSES_API =
  "openai-chatgpt-responses" satisfies (typeof MODEL_APIS)[number];

const ModelApiSchema = z.enum(MODEL_APIS, {
  error: (issue) =>
    issue.input === LEGACY_OPENAI_CODEX_RESPONSES_API
      ? `"${LEGACY_OPENAI_CODEX_RESPONSES_API}" is a removed api id; use "${OPENAI_CHATGPT_RESPONSES_API}"`
      : undefined,
});

const ConfiguredProviderRequestTlsSchema = z
  .strictObject({
    ca: SecretInputSchema.optional().register(sensitive),
    cert: SecretInputSchema.optional().register(sensitive),
    key: SecretInputSchema.optional().register(sensitive),
    passphrase: SecretInputSchema.optional().register(sensitive),
    serverName: z.string().optional(),
    insecureSkipVerify: z.boolean().optional(),
  })
  .optional();

const ConfiguredProviderRequestAuthSchema = z
  .union([
    z.strictObject({
      mode: z.literal("provider-default"),
    }),
    z.strictObject({
      mode: z.literal("authorization-bearer"),
      token: SecretInputSchema.register(sensitive),
    }),
    z.strictObject({
      mode: z.literal("header"),
      headerName: z.string().min(1),
      value: SecretInputSchema.register(sensitive),
      prefix: z.string().optional(),
    }),
  ])
  .optional();

const ConfiguredProviderRequestProxySchema = z
  .union([
    z.strictObject({
      mode: z.literal("env-proxy"),
      tls: ConfiguredProviderRequestTlsSchema,
    }),
    z.strictObject({
      mode: z.literal("explicit-proxy"),
      url: z.string().min(1),
      tls: ConfiguredProviderRequestTlsSchema,
    }),
  ])
  .optional();

const ConfiguredProviderRequestFields = {
  headers: z.record(z.string(), SecretInputSchema.register(sensitive)).optional(),
  auth: ConfiguredProviderRequestAuthSchema,
  proxy: ConfiguredProviderRequestProxySchema,
  tls: ConfiguredProviderRequestTlsSchema,
};

const ConfiguredProviderRequestSchema = z.strictObject(ConfiguredProviderRequestFields).optional();

const ConfiguredModelProviderRequestSchema = z
  .strictObject({
    ...ConfiguredProviderRequestFields,
    allowPrivateNetwork: z.boolean().optional(),
  })
  .optional();

const ModelImageInputSchema = z.strictObject({
  maxBytes: z.number().int().positive().optional(),
  maxPixels: z.number().int().positive().optional(),
  maxSidePx: z.number().int().positive().optional(),
  preferredSidePx: z.number().int().positive().optional(),
  tokenMode: z.union([z.literal("tile"), z.literal("detail"), z.literal("provider")]).optional(),
});

const ModelMediaInputSchema = z.strictObject({
  image: ModelImageInputSchema.optional(),
});

// Mirrors the runtime ThinkingLevelMap contract (model-registry TypeBox schema). Persisted model
// entries carry thinkingLevelMap, so the strict config schema must accept it or updateConfig rolls back.
const ThinkingLevelMapValueSchema = z.string().nullable();
const ThinkingLevelMapSchema = z.strictObject({
  off: ThinkingLevelMapValueSchema.optional(),
  minimal: ThinkingLevelMapValueSchema.optional(),
  low: ThinkingLevelMapValueSchema.optional(),
  medium: ThinkingLevelMapValueSchema.optional(),
  high: ThinkingLevelMapValueSchema.optional(),
  xhigh: ThinkingLevelMapValueSchema.optional(),
  max: ThinkingLevelMapValueSchema.optional(),
});

const ModelDefinitionSchema = z.strictObject({
  /** Provider-facing model id. */
  id: z.string().min(1),
  name: z.string().min(1),
  /** Optional API adapter override for this model. */
  api: ModelApiSchema.optional(),
  /** Optional base URL override for this model. */
  baseUrl: z.string().min(1).optional(),
  reasoning: z.boolean().optional(),
  input: z
    .array(z.union([z.literal("text"), z.literal("image"), z.literal("video"), z.literal("audio")]))
    .optional(),
  cost: z
    .strictObject({
      input: z.number().optional(),
      output: z.number().optional(),
      cacheRead: z.number().optional(),
      cacheWrite: z.number().optional(),
      tieredPricing: z
        .array(
          z.strictObject({
            input: z.number(),
            output: z.number(),
            cacheRead: z.number(),
            cacheWrite: z.number(),
            range: z.union([z.tuple([z.number(), z.number()]), z.tuple([z.number()])]),
          }),
        )
        .optional(),
    })
    .optional(),
  /** Provider/native maximum context window in tokens. */
  contextWindow: z.number().positive().optional(),
  /**
   * Optional effective runtime cap used for compaction/session budgeting.
   * Keeps provider/native contextWindow metadata intact while letting configs
   * prefer a smaller practical window.
   */
  contextTokens: z.number().int().positive().optional(),
  maxTokens: z.number().positive().optional(),
  /** Maps OpenClaw thinking levels to provider/model-specific values. */
  thinkingLevelMap: ThinkingLevelMapSchema.optional(),
  /** Provider-specific request/runtime parameters passed through to provider plugins. */
  params: z.record(z.string(), z.unknown()).optional(),
  /** Optional agent execution runtime override for this provider/model pair. */
  agentRuntime: AgentRuntimePolicySchema,
  /** Static headers merged into requests for this model. */
  headers: z.record(z.string(), z.string()).optional(),
  /** Provider compatibility flags for payload shaping and feature gating. */
  compat: ModelCompatSchema,
  /** Media input limits used by routing and preflight compression. */
  mediaInput: ModelMediaInputSchema.optional(),
  /** Custom authored rows may accept endpoint-selected response ids; official policy still wins. */
  responseModelEquivalent: z.boolean().optional(),
  /** Metadata source marker for models added by CLI/catalog tooling. */
  metadataSource: z.literal("models-add").optional(),
});

const ModelProviderLocalServiceSchema = z
  .strictObject({
    /** Executable started before model requests are sent. */
    command: z.string().min(1),
    /** Arguments passed without shell expansion. */
    args: z.array(z.string()).optional(),
    cwd: z.string().min(1).optional(),
    /** Environment variables added to the service process. */
    env: z.record(z.string(), z.string().register(sensitive)).optional(),
    /** Optional health endpoint polled before the provider is considered ready. */
    healthUrl: z.string().min(1).optional(),
    readyTimeoutMs: z.number().int().positive().optional(),
    /** Idle timeout in milliseconds before stopping the local service. */
    idleStopMs: z.number().int().nonnegative().optional(),
  })
  .optional();

const ModelProviderIconSchema = z.discriminatedUnion("source", [
  z.strictObject({ source: z.literal("file"), path: z.string().trim().min(1).max(4096) }),
  z.strictObject({
    source: z.literal("url"),
    url: z
      .string()
      .url()
      .max(4096)
      .refine((value) => {
        try {
          const url = new URL(value);
          return url.protocol === "https:" && !url.username && !url.password && !url.hash;
        } catch {
          return false;
        }
      }, "Provider icon URL must use HTTPS without credentials or a fragment"),
  }),
  z.strictObject({ source: z.literal("builtin"), name: z.string().trim().min(1).max(100) }),
]);

const ModelProviderSchema = z.strictObject({
  /** Display-only metadata; never changes provider identity or model routing. */
  name: z.string().trim().min(1).max(100).optional(),
  icon: ModelProviderIconSchema.optional(),
  // Bundled provider overlays are materialized with an empty-string sentinel.
  // ModelProvidersSchema below still rejects empty baseUrl values for custom providers.
  baseUrl: z.string().optional(),
  /** API key or secret reference for this provider. */
  apiKey: SecretInputSchema.optional().register(sensitive),
  /** Authentication mode used when resolving credentials for this provider. */
  auth: z
    .union([
      z.literal("api-key"),
      z.literal("aws-sdk"),
      z.literal("oauth"),
      z.literal("token"),
      z.literal("none"),
      z.literal("native-command"),
    ])
    .optional(),
  /** Default API adapter for models under this provider. */
  api: ModelApiSchema.optional(),
  /** Provider-level default max output tokens. */
  maxTokens: z.number().positive().optional(),
  timeoutSeconds: z.number().int().positive().optional(),
  /** Optional provider deployment/API region used by provider plugins that expose regional endpoints. */
  region: z.string().min(1).optional(),
  injectNumCtxForOpenAICompat: z.boolean().optional(),
  /** Provider-specific runtime parameters interpreted by provider plugins. */
  params: z.record(z.string(), z.unknown()).optional(),
  /** Optional default agent execution runtime for models under this provider. */
  agentRuntime: AgentRuntimePolicySchema,
  /** Optional local service to start before calling this provider. */
  localService: ModelProviderLocalServiceSchema,
  /** Override locality for watchdog timing only, including localService-managed relays. */
  remote: z.boolean().optional(),
  /** Secret-bearing headers merged into provider requests. */
  headers: z.record(z.string(), SecretInputSchema.register(sensitive)).optional(),
  /** Whether default Authorization header injection is enabled. */
  authHeader: z.boolean().optional(),
  /** Provider request transport/retry overrides. */
  request: ConfiguredModelProviderRequestSchema,
  models: z.array(ModelDefinitionSchema).optional(),
});

const ModelProvidersSchema = z
  .record(z.string(), ModelProviderSchema)
  .superRefine((providers, ctx) => {
    for (const [providerId, provider] of Object.entries(providers)) {
      if (isBuiltInModelProviderOverlayId(providerId)) {
        continue;
      }
      if (!provider.baseUrl) {
        ctx.addIssue({
          code: "custom",
          path: [providerId, "baseUrl"],
          message:
            "custom model providers must declare baseUrl; provider overlays without baseUrl are only supported for bundled providers",
        });
      }
      if (!Array.isArray(provider.models)) {
        ctx.addIssue({
          code: "custom",
          path: [providerId, "models"],
          message:
            "custom model providers must declare models; provider overlays without models are only supported for bundled providers",
        });
      }
    }
  });

const ModelCatalogRefreshConfigSchema = z
  .strictObject({
    /** Fetch model catalog updates from the hosted OpenClaw catalog. Default: true. */
    enabled: z.boolean().optional(),
    /** Override the hosted catalog URL (HTTPS mirrors, or localhost HTTP for testing). */
    url: z
      .string()
      .refine(
        (value) => {
          const parsed = URL.parse(value);
          return (
            parsed !== null &&
            (parsed.protocol === "https:" ||
              (parsed.protocol === "http:" &&
                ["localhost", "127.0.0.1", "[::1]"].includes(parsed.hostname)))
          );
        },
        {
          message: "models.catalogRefresh.url must use https, or http on localhost",
        },
      )
      .optional(),
  })
  .optional();

export const ModelsConfigSchema = z
  .strictObject({
    /** Merge provider config with bundled catalogs or replace bundled catalogs entirely. */
    mode: z.union([z.literal("merge"), z.literal("replace")]).optional(),
    providers: ModelProvidersSchema.optional(),
    catalogRefresh: ModelCatalogRefreshConfigSchema,
    usage: z.strictObject({ cacheTtlMs: z.number().int().nonnegative().optional() }).optional(),
  })
  .optional();

export const IdentitySchema = z
  .strictObject({
    name: z.string().optional(),
    theme: z.string().optional(),
    emoji: z.string().optional(),
    avatar: z.string().optional(),
  })
  .optional();

export const ReplyToModeSchema = z.union([
  z.literal("off"),
  z.literal("first"),
  z.literal("all"),
  z.literal("batched"),
]);
export const TypingModeSchema = z.union([
  z.literal("never"),
  z.literal("instant"),
  z.literal("thinking"),
  z.literal("message"),
]);

export const GroupPolicySchema = z.enum(["open", "disabled", "allowlist"]);

export const DmPolicySchema = z.enum(["pairing", "allowlist", "open", "disabled"]);
export const ContextVisibilityModeSchema = z.enum(["all", "allowlist", "allowlist_quote"]);

export const BlockStreamingCoalesceSchema = z.strictObject({
  minChars: z.number().int().positive().optional(),
  maxChars: z.number().int().positive().optional(),
  idleMs: z.number().int().nonnegative().optional(),
});

export const TextChunkModeSchema = z.enum(["length", "newline"]);

export const ChannelStreamingBlockSchema = z.strictObject({
  enabled: z.boolean().optional(),
  coalesce: BlockStreamingCoalesceSchema.optional(),
});

/** Delivery-only nested streaming config for channels without preview modes. */
export const ChannelDeliveryStreamingConfigSchema = z.strictObject({
  chunkMode: TextChunkModeSchema.optional(),
  block: ChannelStreamingBlockSchema.optional(),
});

export const ReplyRuntimeConfigSchemaShape = {
  historyLimit: z.number().int().min(0).optional(),
  dmHistoryLimit: z.number().int().min(0).optional(),
  contextVisibility: ContextVisibilityModeSchema.optional(),
  dms: z.record(z.string(), DmConfigSchema.optional()).optional(),
  textChunkLimit: z.number().int().positive().optional(),
  streaming: ChannelDeliveryStreamingConfigSchema.optional(),
  responsePrefix: z.string().optional(),
  mediaMaxMb: z.number().positive().optional(),
};

export const BlockStreamingChunkSchema = z.strictObject({
  minChars: z.number().int().positive().optional(),
  maxChars: z.number().int().positive().optional(),
  breakPreference: z
    .union([z.literal("paragraph"), z.literal("newline"), z.literal("sentence")])
    .optional(),
});

export const MarkdownConfigSchema = z
  .strictObject({
    tables: z.enum(["off", "bullets", "code", "block"]).optional(),
  })
  .optional();

export const TtsProviderSchema = z.string().min(1);
export const TtsModeSchema = z.enum(["final", "all"]);
const TtsProviderConfigSchema = z
  .object({
    apiKey: SecretInputSchema.optional().register(sensitive),
  })
  .catchall(
    z.union([
      z.string(),
      z.number(),
      z.boolean(),
      z.null(),
      z.array(z.unknown()),
      z.record(z.string(), z.unknown()),
    ]),
  );
const TtsPersonaSchema = z.strictObject({
  label: z.string().optional(),
  description: z.string().optional(),
  provider: TtsProviderSchema.optional(),
  fallbackPolicy: z
    .union([z.literal("preserve-persona"), z.literal("provider-defaults"), z.literal("fail")])
    .optional(),
  providers: z.record(z.string(), TtsProviderConfigSchema).optional(),
});
export const TtsConfigSchema = z
  .strictObject({
    auto: TtsAutoSchema.optional(),
    enabled: z.boolean().optional(),
    mode: TtsModeSchema.optional(),
    provider: TtsProviderSchema.optional(),
    persona: z.string().optional(),
    personas: z.record(z.string(), TtsPersonaSchema).optional(),
    summaryModel: z.string().optional(),
    modelOverrides: z
      .strictObject({
        enabled: z.boolean().optional(),
        allowText: z.boolean().optional(),
        allowProvider: z.boolean().optional(),
        allowVoice: z.boolean().optional(),
        allowModelId: z.boolean().optional(),
        allowVoiceSettings: z.boolean().optional(),
        allowNormalization: z.boolean().optional(),
        allowSeed: z.boolean().optional(),
      })
      .optional(),
    providers: z.record(z.string(), TtsProviderConfigSchema).optional(),
    maxTextLength: z.number().int().min(1).optional(),
    timeoutMs: z.number().int().min(1000).max(120000).optional(),
  })
  .optional();

export const HumanDelaySchema = z.strictObject({
  mode: z.union([z.literal("off"), z.literal("natural"), z.literal("custom")]).optional(),
  minMs: z.number().int().nonnegative().optional(),
  maxMs: z.number().int().nonnegative().optional(),
});

/**
 * Closed set of sender-policy/allowFrom dependency violations. Both cases drop
 * every inbound DM at runtime, so callers surface them as config problems.
 */
export type DmPolicyAllowFromViolation = "open_requires_wildcard" | "allowlist_requires_entries";

/**
 * Canonical cross-field check for dmPolicy vs allowFrom. This is the single
 * source of truth shared by the Zod schema refinements and the CLI config
 * validator so the rule cannot drift between the two surfaces.
 */
export const evaluateDmPolicyAllowFromDependency = (params: {
  policy?: string;
  allowFrom?: Array<string | number>;
}): DmPolicyAllowFromViolation | null => {
  const allow = normalizeStringEntries(params.allowFrom);
  if (params.policy === "open" && !allow.includes("*")) {
    return "open_requires_wildcard";
  }
  if (params.policy === "allowlist" && allow.length === 0) {
    return "allowlist_requires_entries";
  }
  return null;
};

function createDmPolicyAllowFromValidator(violation: DmPolicyAllowFromViolation) {
  return (params: {
    policy?: string;
    allowFrom?: Array<string | number>;
    ctx: z.RefinementCtx;
    path: Array<string | number>;
    message: string;
  }) => {
    if (evaluateDmPolicyAllowFromDependency(params) === violation) {
      params.ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: params.path,
        message: params.message,
      });
    }
  };
}

export const requireOpenAllowFrom = createDmPolicyAllowFromValidator("open_requires_wildcard");

/**
 * Validate that dmPolicy="allowlist" has a non-empty allowFrom array.
 * Without this, all DMs are silently dropped because the allowlist is empty
 * and no senders can match.
 */
export const requireAllowlistAllowFrom = createDmPolicyAllowFromValidator(
  "allowlist_requires_entries",
);

export const MSTeamsReplyStyleSchema = z.enum(["thread", "top-level"]);

export const HexColorSchema = z.string().regex(/^#?[0-9a-fA-F]{6}$/, "expected hex color (RRGGBB)");

export const ExecutableTokenSchema = z
  .string()
  .refine(isSafeExecutableValue, "expected safe executable name or path");

const MediaUnderstandingScopeSchema = createAllowDenyChannelRulesSchema();

const MediaUnderstandingAttachmentsSchema = z
  .strictObject({
    /** Select the first matching attachment or process multiple. */
    mode: z.union([z.literal("first"), z.literal("all")]).optional(),
    /** Max number of attachments to process (default: 1). */
    maxAttachments: z.number().int().positive().optional(),
    prefer: z
      .union([z.literal("first"), z.literal("last"), z.literal("path"), z.literal("url")])
      .optional(),
  })
  .optional();

const ProviderOptionsSchema = z
  .record(
    z.string(),
    z.record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.array(z.string())])),
  )
  .optional();

const MediaUnderstandingRuntimeFields = {
  /** Default prompt; model entries can override it. */
  prompt: z.string().optional(),
  /** Default timeout (seconds); model entries can override it. */
  timeoutSeconds: z.number().int().positive().optional(),
  /** Default language hint for audio transcription; model entries can override it. */
  language: z.string().optional(),
  /** Optional provider-specific query params (merged into requests). */
  providerOptions: ProviderOptionsSchema,
  /** Optional base URL override for provider requests. */
  baseUrl: z.string().optional(),
  /** Optional headers merged into provider requests. */
  headers: z.record(z.string(), z.string()).optional(),
  /** Optional request transport overrides for provider HTTP calls. */
  request: ConfiguredProviderRequestSchema,
};

const MediaUnderstandingModelSchema = z
  .strictObject({
    /** provider API id (e.g. openai, google). */
    provider: z.string().optional(),
    /** Model id for provider-based understanding. */
    model: z.string().optional(),
    /** Optional capability tags for shared model lists. */
    capabilities: z
      .array(z.union([z.literal("image"), z.literal("audio"), z.literal("video")]))
      .optional(),
    /** Use a CLI command instead of provider API. */
    type: z.union([z.literal("provider"), z.literal("cli")]).optional(),
    /** CLI binary (required when type=cli). */
    command: z.string().optional(),
    /** CLI args (template-enabled). */
    args: z.array(z.string()).optional(),
    /** Optional max output characters for this model entry. */
    maxChars: z.number().int().positive().optional(),
    maxBytes: z.number().int().positive().optional(),
    ...MediaUnderstandingRuntimeFields,
    /** Auth profile id to use for this provider. */
    profile: z.string().optional(),
    /** Preferred profile id if multiple are available. */
    preferredProfile: z.string().optional(),
  })
  .optional();

const ToolsMediaCapabilitySchema = z
  .strictObject({
    /** Enable media understanding when models are configured. */
    enabled: z.boolean().optional(),
    /** Prefer a matching shared model entry. */
    preferredModel: z.string().trim().min(1).optional(),
    /** Optional scope gating for understanding. */
    scope: MediaUnderstandingScopeSchema,
    /** Default max bytes to send. */
    maxBytes: z.number().int().positive().optional(),
    /** Default max output characters. */
    maxChars: z.number().int().positive().optional(),
    ...MediaUnderstandingRuntimeFields,
    attachments: MediaUnderstandingAttachmentsSchema,
  })
  .optional();

const ToolsMediaAudioSchema = ToolsMediaCapabilitySchema.unwrap()
  .extend({
    /**
     * Echo the audio transcript back to the originating chat before agent processing.
     * Lets users verify what was heard. Default: false.
     */
    echoTranscript: z.boolean().optional(),
    /**
     * Format string for the echoed transcript. Use `{transcript}` as placeholder.
     * Default: '📝 "{transcript}"'
     */
    echoFormat: z.string().optional(),
  })
  .optional();

export const ToolsMediaSchema = z
  .strictObject({
    models: z.array(MediaUnderstandingModelSchema).optional(),
    concurrency: z.number().int().positive().optional(),
    image: ToolsMediaCapabilitySchema.optional(),
    audio: ToolsMediaAudioSchema.optional(),
    video: ToolsMediaCapabilitySchema.optional(),
  })
  .optional();
const LinkModelSchema = z.strictObject({
  /** Use a CLI command for link processing. */
  type: z.literal("cli").optional(),
  command: z.string().min(1),
  args: z.array(z.string()).optional(),
  timeoutSeconds: z.number().int().positive().optional(),
});

export const ToolsLinksSchema = z
  .strictObject({
    /** Enable link understanding when models are configured. */
    enabled: z.boolean().optional(),
    scope: MediaUnderstandingScopeSchema,
    /** Max number of links to process per message. */
    maxLinks: z.number().int().positive().optional(),
    timeoutSeconds: z.number().int().positive().optional(),
    /** Ordered model list (fallbacks in order). */
    models: z.array(LinkModelSchema).optional(),
  })
  .optional();
