import { z } from "zod";

const InstallSourceSchema = z.union([
  z.literal("npm"),
  z.literal("archive"),
  z.literal("path"),
  z.literal("clawhub"),
  z.literal("git"),
]);

const InstallRecordShape = {
  source: InstallSourceSchema,
  spec: z.string().optional(),
  sourcePath: z.string().optional(),
  installPath: z.string().optional(),
  version: z.string().optional(),
  resolvedName: z.string().optional(),
  resolvedVersion: z.string().optional(),
  resolvedSpec: z.string().optional(),
  integrity: z.string().optional(),
  shasum: z.string().optional(),
  resolvedAt: z.string().optional(),
  installedAt: z.string().optional(),
  clawhubUrl: z.string().optional(),
  clawhubPackage: z.string().optional(),
  clawhubFamily: z.union([z.literal("code-plugin"), z.literal("bundle-plugin")]).optional(),
  clawhubChannel: z
    .union([z.literal("official"), z.literal("community"), z.literal("private")])
    .optional(),
  clawhubTrustDisposition: z
    .union([
      z.literal("clean"),
      z.literal("review-recommended"),
      z.literal("review-required"),
      z.literal("blocked"),
    ])
    .optional(),
  clawhubTrustScanStatus: z.string().optional(),
  clawhubTrustModerationState: z.string().optional(),
  clawhubTrustReasons: z.array(z.string()).optional(),
  clawhubTrustPending: z.boolean().optional(),
  clawhubTrustStale: z.boolean().optional(),
  clawhubTrustCheckedAt: z.string().optional(),
  clawhubTrustAcknowledgedAt: z.string().optional(),
  artifactKind: z.union([z.literal("legacy-zip"), z.literal("npm-pack")]).optional(),
  artifactFormat: z.union([z.literal("zip"), z.literal("tgz")]).optional(),
  npmIntegrity: z.string().optional(),
  npmShasum: z.string().optional(),
  npmTarballName: z.string().optional(),
  clawpackSha256: z.string().optional(),
  clawpackSpecVersion: z.number().int().nonnegative().optional(),
  clawpackManifestSha256: z.string().optional(),
  clawpackSize: z.number().int().nonnegative().optional(),
  gitUrl: z.string().optional(),
  gitRef: z.string().optional(),
  gitCommit: z.string().optional(),
} as const;

const InstallRecordSchema = z.object(InstallRecordShape);
export type InstallRecordBase = z.infer<typeof InstallRecordSchema>;

const SourceSnapshotDigestSchema = z.strictObject({
  contentDigest: z.string().regex(/^[a-f0-9]{64}$/),
  dependencyClosureDigest: z.string().regex(/^[a-f0-9]{64}$/),
});
const SourceSnapshotDigestRecordShape = z.record(z.string(), z.unknown());
// Zod records omit __proto__; validate entries before rebuilding inert own properties.
const SourceSnapshotDigestsSchema = z
  .custom<Record<string, unknown>>(
    (value) => SourceSnapshotDigestRecordShape.safeParse(value).success,
  )
  .transform((value) => Object.entries(value))
  .pipe(z.array(z.tuple([z.string().min(1), SourceSnapshotDigestSchema])))
  .transform((entries) => Object.fromEntries(entries));

export const StrictPluginInstallRecordSchema = z.object({
  ...InstallRecordShape,
  source: z.union([InstallSourceSchema, z.literal("marketplace")]),
  /** Retained package child-plugin engine ownership for uninstall without runtime files. */
  contextEngineIdsByPlugin: z.record(z.string().min(1), z.array(z.string().min(1))).optional(),
  marketplaceName: z.string().optional(),
  marketplaceSource: z.string().optional(),
  marketplacePlugin: z.string().optional(),
  acceptedSurface: z
    .strictObject({
      channels: z.array(z.string().min(1)),
      providers: z.array(z.string().min(1)),
      tools: z.array(z.string().min(1)),
      contracts: z.array(z.string().min(1)),
      hooks: z.array(z.string().min(1)),
      mcpServers: z.array(z.string().min(1)),
      cliCommands: z.array(z.string().min(1)),
      cliBackends: z.array(z.string().min(1)),
      skills: z.array(z.string().min(1)),
      dangerousConfigFlags: z.array(z.string().min(1)),
    })
    .optional(),
  acceptedSurfaceHash: z.string().optional(),
  acceptedSurfaceAt: z.string().optional(),
  acceptedSurfaceIntegrity: z.string().optional(),
  /** Verified installed source closures, keyed by runtime plugin id. */
  sourceSnapshotDigests: SourceSnapshotDigestsSchema.optional(),
} as const);
export type PluginInstallRecord = z.infer<typeof StrictPluginInstallRecordSchema>;
export type PluginAcceptedDeclaredSurface = NonNullable<PluginInstallRecord["acceptedSurface"]>;
