import type { SqliteWalHealth } from "../../infra/sqlite-wal-checkpoint.js";
import type {
  SessionEntrySummary,
  TranscriptEvent,
  TranscriptMessageAppendResult,
} from "./session-accessor.types.js";
import type { SessionTranscriptContextVersion } from "./session-transcript-context-version.types.js";
import type { InternalSessionEntry as SessionEntry } from "./types.js";
export type { SessionTranscriptContextVersion } from "./session-transcript-context-version.types.js";
export type {
  DeletedAgentSessionEntryPurgeParams,
  DeleteSessionEntryLifecycleParams,
  DeleteSessionEntryLifecycleResult,
  ResetSessionEntryLifecycleParams,
  ResetSessionEntryLifecycleResult,
  SessionEntryLifecycleMutationResult,
  SessionEntryLifecycleRemoval,
  SessionEntryLifecycleUpsert,
  SessionLifecycleArchivedTranscript,
  SessionLifecycleArtifactCleanupParams,
  SessionLifecycleArtifactCleanupResult,
} from "./session-accessor.lifecycle-types.js";

export type TranscriptWriteSnapshot<T> = {
  result: T;
  lifecycleRevision?: string;
  before: SessionTranscriptContextVersion;
  after: SessionTranscriptContextVersion;
};

export type TranscriptMessageWriteSnapshot<TMessage> = TranscriptWriteSnapshot<
  TranscriptMessageAppendResult<TMessage> | undefined
> & {
  visibleTail: { entryId: string | null; generation: string | null };
};

export type TranscriptEventAppendResult =
  | { appended: false }
  | { appended: true; effectiveParentId?: string | null };

export type TranscriptEventReadOptions = {
  beforeEventSeq?: number;
  afterEventSeq?: number;
  projection?: "reset-boundary";
  maxEventBytes?: number;
};

export type CacheTtlProjectionPrefix = {
  anchorIds: string[];
  entries: Record<string, unknown>[];
};

export type SessionTranscriptBoundedActiveContext = {
  activeLeafEntryId: string | null;
  version: SessionTranscriptContextVersion;
  opaqueParents: Map<string, string | null>;
  parents: Map<string, string | null>;
  firstKeptRanges: Map<string, { startIndex: number; endIndex: number }>;
  persistedSuffixStartSeq: number;
  boundaryCount: number;
  events: TranscriptEvent[];
  cacheTtlProjectionPrefixes?: CacheTtlProjectionPrefix[];
  serializedBytes: number;
  totalEvents: number;
  transcriptMutationAt: number | null;
  truncated: boolean;
  /** Every indexed active entry is present, without a read fence or byte/event omission. */
  completeActivePath?: true;
};

export type CanonicalSessionValidationResult = {
  validatedRows: number;
  certifiedRows: number;
  hasMore: boolean;
  oversizedRows: number;
};

/** Worker operation facts; no Worker object or plan payload is retained. */
export type SqliteSessionReclamationDiagnostics = {
  kind?:
    | "archive-publish-prepare"
    | "archive-publish-record"
    | "entry"
    | "lifecycle-artifacts"
    | "lifecycle-projection-plan"
    | "lifecycle-projection-commit"
    | "history-eviction"
    | "historical-generation"
    | "maintenance-plan"
    | "maintenance-finalize"
    | "maintenance-statistics"
    | "maintenance-age"
    | "maintenance-pages"
    | "cold-batch"
    | "cold-maintain"
    | "cold-sweep"
    | "cold-restore";
  workerThreadId?: number;
};

/** One validated request owns this record until its observed release event. */
export type SqliteSessionReclamationAdmissionDiagnostics = {
  admissionId: number;
  releaseCause?: "preliminary-release" | "worker-release" | "worker-exit";
};

export type SqliteSessionDatabaseAdmissionDiagnostics = {
  admissionMode?: "cached" | "async";
  admissionMs?: number;
};

/** One cleanup attempt owns these numeric observations; no row or transcript is retained. */
export type SqliteSessionArtifactPreparationDiagnostics =
  SqliteSessionDatabaseAdmissionDiagnostics & {
    nodeInventoryMs?: number;
    referencePlanningMs?: number;
    orphanPlanningMs?: number;
    markerScanMs?: number;
    nodeRows?: number;
    windowRows?: number;
    referenceIds?: number;
    selectedEntries?: number;
    markerWindows?: number;
    markerRows?: number;
    deletePlans?: number;
    completed?: boolean;
  };

/** One pruning attempt retains only aggregate stage observations. */
export type SqliteSessionArchivePruningDiagnostics = {
  highWaterBytes?: number;
  trigger: "initial" | "after-eviction" | "final";
  checkpointCalls?: number;
  checkpointIncomplete?: number;
  checkpoint?: SqliteWalHealth;
  totalBytesBefore?: number;
  totalBytesAfter?: number;
  walBytesBefore?: number;
  walBytesAfter?: number;
  checkpointMs?: number;
  checkpointMaxMs?: number;
  vacuumMs?: number;
  vacuumPasses?: number;
  vacuumPagesRequested?: number;
  queryMs?: number;
  rowDeletionMs?: number;
  fileRemovalMs?: number;
  removedFiles?: number;
  missingFiles?: number;
  failedRemovals?: number;
  measurementMs?: number;
  measurements?: number;
  legacyInventoryMs?: number;
  completed?: boolean;
};

export type SqliteSessionWriteDiagnostics = SqliteSessionReclamationDiagnostics & {
  artifactPreparation?: SqliteSessionArtifactPreparationDiagnostics;
  reclamationAdmission?: SqliteSessionReclamationAdmissionDiagnostics;
};

export type SessionTranscriptInstance = SessionEntrySummary & {
  agentId: string;
  /** Stable transcript identity, including rotated history for one logical session key. */
  sessionId: string;
  /** True when this transcript instance was owned by an ACP runtime. */
  acpOwned: boolean;
  /** True when exclusion-sensitive session ownership was captured for this transcript id. */
  provenanceKnown: boolean;
  /** Activity timestamp for this transcript instance, not the current logical session row. */
  updatedAtMs: number;
  /** Recorded source facts; coarse historical trust classes cannot identify an exact hook source. */
  sourceMetadata: {
    createdAt: number;
    channel: string | null;
    accountId: string | null;
    chatType: NonNullable<SessionEntry["chatType"]> | null;
    hookExternalContentSource: NonNullable<SessionEntry["hookExternalContentSource"]> | null;
  };
};

export type SessionTranscriptInstanceListOptions = {
  /** Include empty and internal windows when inspecting recorded source metadata. */
  includeAllWindows?: boolean;
  sessionId?: string;
  sessionIds?: readonly string[];
};

export type TranscriptEventAppendOptions = {
  appendIntent?: "active-branch";
  /** Synchronous authority check run inside the append transaction. */
  beforeCommitInTransaction?: () => void;
  /** Reject the append when the transcript changed since the caller loaded it. */
  expectedMutationAt?: number | null;
};

export type { TranscriptAppendRefusal } from "./session-transcript-writer-claim-error.js";

export type {
  ForkSessionEntryFromParentTargetParams,
  ForkSessionEntryFromParentTargetResult,
  ForkSessionFromParentTranscriptParams,
  ForkSessionFromParentTranscriptResult,
  SessionParentForkDecision,
  SessionTranscriptRawDeltaLimits,
  SessionTranscriptRawDeltaResult,
  SessionTranscriptVisibleMessageDeltaLimits,
  SessionTranscriptVisibleMessageDeltaResult,
  TranscriptEvent,
} from "./session-accessor.types.js";

export type LatestTranscriptAssistantMessage = {
  id?: string;
  message: unknown;
};

export type {
  ExactSessionEntry,
  LatestTranscriptAssistantText,
  SessionAccessScope,
  SessionEntryPatchOptions,
  SessionEntryReplacementSnapshot,
  SessionEntryReplacementUpdate,
  SessionEntrySummary,
  SessionEntryTargetPatchScope,
  SessionTranscriptAccessScope,
  SessionTranscriptEventRow,
  SessionTranscriptReadScope,
  SessionTranscriptStats,
  SessionTranscriptTurnMessageAppend,
  SessionTranscriptTurnWriteContext,
  SessionTranscriptWriteScope,
  TranscriptMessageAppendOptions,
  TranscriptMessageAppendResult,
  TranscriptUpdatePayload,
} from "./session-accessor.types.js";
