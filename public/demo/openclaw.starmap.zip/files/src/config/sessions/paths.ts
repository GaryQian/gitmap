import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { normalizeLowercaseStringOrEmpty } from "@openclaw/normalization-core/string-coerce";
import { safeRealpathSync } from "../../infra/boundary-path.js";
import { expandHomePrefix, resolveRequiredHomeDir } from "../../infra/home-dir.js";
import {
  isIncognitoSessionKey,
  normalizeAgentId,
  resolveAgentIdFromSessionKey,
} from "../../routing/session-key.js";
import {
  resolveExplicitIncognitoAgentSqliteTarget,
  resolveIncognitoOpenClawAgentSqlitePath,
} from "../../state/openclaw-agent-db.paths.js";
import { resolveStateDir } from "../state-dir.js";
import { isCompactionCheckpointTranscriptFileName } from "./artifacts.js";
import { MULTI_STORE_PATH_SENTINEL } from "./session-sqlite-target-paths.js";

export { resolveConcreteSessionStorePath } from "./session-sqlite-target-paths.js";

export type SessionStorePathScope = {
  agentId?: string;
  env?: NodeJS.ProcessEnv;
  sessionKey?: string;
  storePath?: string;
};

/** Incognito key identity takes precedence over an explicit durable store path. */
export function resolveExplicitSessionStorePathForScope(
  scope: SessionStorePathScope,
): string | undefined {
  const explicit = resolveExplicitIncognitoAgentSqliteTarget(scope.storePath, {
    agentId: isIncognitoSessionKey(scope.sessionKey)
      ? resolveAgentIdFromSessionKey(scope.sessionKey)
      : scope.agentId,
    env: scope.env,
  });
  if (explicit) {
    return explicit.path;
  }
  if (isIncognitoSessionKey(scope.sessionKey)) {
    return resolveIncognitoOpenClawAgentSqlitePath({
      agentId: resolveAgentIdFromSessionKey(scope.sessionKey),
      env: scope.env,
    });
  }
  return scope.storePath || undefined;
}

export function resolveSessionTranscriptsDirForAgent(
  agentId: string,
  env: NodeJS.ProcessEnv = process.env,
  homedir: () => string = () => resolveRequiredHomeDir(env, os.homedir),
): string {
  if (!agentId?.trim()) {
    throw new Error("Session storage path requires an explicit agent id.");
  }
  const root = resolveStateDir(env, homedir);
  const id = normalizeAgentId(agentId);
  return path.join(root, "agents", id, "sessions");
}

export function resolveDefaultSessionStorePath(agentId: string): string {
  return `${resolveSessionTranscriptsDirForAgent(agentId)}${path.sep}sessions.json`;
}

/** Store selectors and explicit databases share the owning agent's session artifact directory. */
export function resolveSessionArtifactDirectory(storePath: string): string {
  const storeDir = path.dirname(storePath);
  return path.basename(storeDir) === "agent"
    ? path.join(path.dirname(storeDir), "sessions")
    : storeDir;
}

type SessionFilePathOptions = {
  agentId?: string;
  sessionsDir?: string;
};

const SQLITE_TRANSCRIPT_TARGET_PREFIX = "sqlite:";

export function resolveSessionFilePathOptions(params: {
  agentId?: string;
  storePath?: string;
}): SessionFilePathOptions | undefined {
  const agentId = params.agentId?.trim();
  const storePath = params.storePath?.trim();
  if (storePath && storePath !== MULTI_STORE_PATH_SENTINEL) {
    const sessionsDir = path.dirname(path.resolve(storePath));
    return agentId ? { sessionsDir, agentId } : { sessionsDir };
  }
  if (agentId) {
    return { agentId };
  }
  return undefined;
}

const SAFE_SESSION_ID_RE = /^[\p{L}\p{N}][\p{L}\p{N}\p{M}._-]{0,127}$/u;

export function validateSessionId(sessionId: string): string {
  const trimmed = sessionId.trim();
  if (
    trimmed !== trimmed.normalize("NFC") ||
    !SAFE_SESSION_ID_RE.test(trimmed) ||
    Buffer.byteLength(`${trimmed}.jsonl`, "utf8") > 255 ||
    isCompactionCheckpointTranscriptFileName(`${trimmed}.jsonl`)
  ) {
    throw new Error(`Invalid session ID: ${sessionId}`);
  }
  return trimmed;
}

function resolveSessionsDir(opts?: SessionFilePathOptions): string {
  const sessionsDir = opts?.sessionsDir?.trim();
  if (sessionsDir) {
    return path.resolve(sessionsDir);
  }
  return resolveSessionTranscriptsDirForAgent(opts?.agentId ?? "");
}

type SessionPathProbe = { kind: "realpath" | "existing"; path: string };
type SessionPathResolution<T> = Generator<SessionPathProbe, T, string | undefined>;

// Keep containment and restored-root policy identical for sync and async callers.
function resolveSessionPathSync<T>(steps: SessionPathResolution<T>): T {
  let step = steps.next();
  while (!step.done) {
    const probe = step.value;
    step = steps.next(
      probe.kind === "realpath"
        ? (safeRealpathSync(probe.path) ?? undefined)
        : fs.existsSync(probe.path)
          ? probe.path
          : undefined,
    );
  }
  return step.value;
}

function* resolvePathFromAgentSessionsDir(
  agentSessionsDir: string,
  candidateAbsPath: string,
): SessionPathResolution<string | undefined> {
  const agentBase =
    (yield { kind: "realpath", path: path.resolve(agentSessionsDir) }) ??
    path.resolve(agentSessionsDir);
  const relative = path.relative(agentBase, candidateAbsPath);
  // The caller already resolved the candidate; resolve this fallback root for containment.
  if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) {
    return yield* resolveRerootedSessionPath(agentBase, candidateAbsPath);
  }
  return path.resolve(agentBase, relative);
}

// Absolute sessionFile paths recorded under another state root (restored
// backups, moved OPENCLAW_STATE_DIR, rehearsal copies) never satisfy the
// relative-containment check above. Re-root the canonical
// `agents/<id>/sessions/<suffix>` tail onto the current sessions dir, but only
// when the file exists there: genuine cross-root layouts keep their foreign
// path via the structural fallback.
function* resolveRerootedSessionPath(
  agentSessionsDir: string,
  candidateAbsPath: string,
): SessionPathResolution<string | undefined> {
  const parsed = resolveAgentSessionsPathParts(candidateAbsPath);
  if (!parsed) {
    return undefined;
  }
  const relativeSegments = parsed.parts.slice(parsed.sessionsIndex + 1);
  if (relativeSegments.length === 0) {
    return undefined;
  }
  const rerooted = path.resolve(agentSessionsDir, ...relativeSegments);
  const contained = path.relative(agentSessionsDir, rerooted);
  if (!contained || contained.startsWith("..") || path.isAbsolute(contained)) {
    return undefined;
  }
  return yield { kind: "existing", path: rerooted };
}

function resolveSiblingAgentSessionsDir(
  baseSessionsDir: string,
  agentId: string,
): string | undefined {
  // Multi-agent stores share a common .../agents/<id>/sessions shape; sibling resolution keeps
  // persisted absolute files portable across active agent stores.
  const agentsDir = resolveAgentsDirFromSessionStorePath(
    path.join(baseSessionsDir, "sessions.json"),
  );
  return agentsDir ? path.join(agentsDir, normalizeAgentId(agentId), "sessions") : undefined;
}

function resolveAgentSessionsPathParts(
  candidateAbsPath: string,
): { parts: string[]; sessionsIndex: number } | null {
  const normalized = path.normalize(path.resolve(candidateAbsPath));
  const parts = normalized.split(path.sep).filter(Boolean);
  const sessionsIndex = parts.lastIndexOf("sessions");
  if (sessionsIndex < 2 || parts[sessionsIndex - 2] !== "agents") {
    return null;
  }
  return { parts, sessionsIndex };
}

function extractAgentIdFromAbsoluteSessionPath(candidateAbsPath: string): string | undefined {
  const parsed = resolveAgentSessionsPathParts(candidateAbsPath);
  if (!parsed) {
    return undefined;
  }
  const { parts, sessionsIndex } = parsed;
  const agentId = parts[sessionsIndex - 1];
  return agentId || undefined;
}

function resolveStructuralSessionFallbackPath(
  candidateAbsPath: string,
  expectedAgentId: string,
): string | undefined {
  const parsed = resolveAgentSessionsPathParts(candidateAbsPath);
  if (!parsed) {
    return undefined;
  }
  const { parts, sessionsIndex } = parsed;
  const agentIdPart = parts[sessionsIndex - 1];
  if (!agentIdPart) {
    return undefined;
  }
  const normalizedAgentId = normalizeAgentId(agentIdPart);
  if (normalizedAgentId !== normalizeLowercaseStringOrEmpty(agentIdPart)) {
    return undefined;
  }
  if (normalizedAgentId !== normalizeAgentId(expectedAgentId)) {
    return undefined;
  }
  const relativeSegments = parts.slice(sessionsIndex + 1);
  // Session transcripts are stored as direct files in "sessions/".
  if (relativeSegments.length !== 1) {
    return undefined;
  }
  const fileName = relativeSegments[0];
  if (!fileName || fileName === "." || fileName === "..") {
    return undefined;
  }
  return path.normalize(path.resolve(candidateAbsPath));
}

function* resolvePathWithinSessionsDir(
  sessionsDir: string,
  candidate: string,
  opts?: { agentId?: string },
): SessionPathResolution<string> {
  const trimmed = candidate.trim();
  if (!trimmed) {
    throw new Error("Session file path must not be empty");
  }
  const resolvedBase = path.resolve(sessionsDir);
  const realBase = (yield { kind: "realpath", path: resolvedBase }) ?? resolvedBase;
  // Normalize absolute paths that are within the sessions directory.
  // Older versions stored absolute sessionFile paths in sessions.json;
  // convert them to relative so the containment check passes.
  const realTrimmed = path.isAbsolute(trimmed)
    ? ((yield { kind: "realpath", path: trimmed }) ?? trimmed)
    : trimmed;
  const normalized = path.isAbsolute(realTrimmed)
    ? path.relative(realBase, realTrimmed)
    : realTrimmed;
  if (normalized.startsWith("..") && path.isAbsolute(realTrimmed)) {
    const tryAgentFallback = function* (
      agentId: string,
    ): SessionPathResolution<string | undefined> {
      const normalizedAgentId = normalizeAgentId(agentId);
      const siblingSessionsDir = resolveSiblingAgentSessionsDir(realBase, normalizedAgentId);
      if (siblingSessionsDir) {
        const siblingResolved = yield* resolvePathFromAgentSessionsDir(
          siblingSessionsDir,
          realTrimmed,
        );
        if (siblingResolved) {
          return siblingResolved;
        }
      }
      return yield* resolvePathFromAgentSessionsDir(
        resolveSessionTranscriptsDirForAgent(normalizedAgentId),
        realTrimmed,
      );
    };

    const explicitAgentId = opts?.agentId?.trim();
    if (explicitAgentId) {
      const resolvedFromAgent = yield* tryAgentFallback(explicitAgentId);
      if (resolvedFromAgent) {
        return resolvedFromAgent;
      }
    }
    const extractedAgentId = extractAgentIdFromAbsoluteSessionPath(realTrimmed);
    if (extractedAgentId) {
      const resolvedFromPath = yield* tryAgentFallback(extractedAgentId);
      if (resolvedFromPath) {
        return resolvedFromPath;
      }
      // Cross-root compatibility for older absolute paths:
      // keep only canonical .../agents/<agentId>/sessions/<file> shapes.
      const structuralFallback = resolveStructuralSessionFallbackPath(
        realTrimmed,
        extractedAgentId,
      );
      if (structuralFallback) {
        return structuralFallback;
      }
    }
  }
  if (!normalized || normalized.startsWith("..") || path.isAbsolute(normalized)) {
    throw new Error("Session file path must be within sessions directory");
  }
  return path.resolve(realBase, normalized);
}

export function* resolveSessionFilePathCoreSteps(
  sessionId: string,
  entry?: object,
  opts?: SessionFilePathOptions,
): SessionPathResolution<string> {
  const sessionsDir = resolveSessionsDir(opts);
  const candidate =
    entry && "sessionFile" in entry && typeof entry.sessionFile === "string"
      ? entry.sessionFile.trim()
      : undefined;
  if (candidate) {
    if (candidate.startsWith(SQLITE_TRANSCRIPT_TARGET_PREFIX)) {
      return candidate;
    }
    try {
      return yield* resolvePathWithinSessionsDir(sessionsDir, candidate, {
        agentId: opts?.agentId,
      });
    } catch {
      // Keep handlers alive when persisted metadata is stale/corrupt.
    }
  }
  return yield* resolvePathWithinSessionsDir(sessionsDir, `${validateSessionId(sessionId)}.jsonl`);
}

export function resolveSessionFilePathCore(
  sessionId: string,
  entry?: object,
  opts?: SessionFilePathOptions,
): string {
  return resolveSessionPathSync(resolveSessionFilePathCoreSteps(sessionId, entry, opts));
}

export class SessionStoreAgentIdRequiredError extends Error {
  constructor() {
    super("Session store path requires an explicit agent id.");
    this.name = "SessionStoreAgentIdRequiredError";
  }
}

/** Resolves fixed literal paths without an owner; derived or templated paths require agentId. */
export function resolveSessionStorePathCore(
  store?: string,
  opts?: { agentId?: string; env?: NodeJS.ProcessEnv },
) {
  const env = opts?.env ?? process.env;
  const homedir = () => resolveRequiredHomeDir(env, os.homedir);
  if (!store) {
    if (!opts?.agentId?.trim()) {
      throw new SessionStoreAgentIdRequiredError();
    }
    return `${resolveSessionTranscriptsDirForAgent(opts.agentId, env, homedir)}${path.sep}sessions.json`;
  }
  let expandedStore = store;
  if (expandedStore.includes("{agentId}")) {
    if (!opts?.agentId?.trim()) {
      throw new SessionStoreAgentIdRequiredError();
    }
    const agentId = normalizeAgentId(opts.agentId);
    expandedStore = expandedStore.replaceAll("{agentId}", agentId);
  }
  if (expandedStore.startsWith("~")) {
    expandedStore = expandHomePrefix(expandedStore, {
      home: resolveRequiredHomeDir(env, homedir),
      env,
      homedir,
    });
  }
  // Service working directories vary; configuration must select the same store after a restart.
  return path.isAbsolute(expandedStore)
    ? path.resolve(expandedStore)
    : path.resolve(resolveStateDir(env, homedir), expandedStore);
}

export function resolveAgentsDirFromSessionStorePath(storePath: string): string | undefined {
  const candidateAbsPath = path.resolve(storePath);
  if (path.basename(candidateAbsPath) !== "sessions.json") {
    return undefined;
  }
  const sessionsDir = path.dirname(candidateAbsPath);
  if (path.basename(sessionsDir) !== "sessions") {
    return undefined;
  }
  const agentDir = path.dirname(sessionsDir);
  const agentsDir = path.dirname(agentDir);
  if (path.basename(agentsDir) !== "agents") {
    return undefined;
  }
  return agentsDir;
}
