import fs from "node:fs";
import path from "node:path";
import { isMainThread } from "node:worker_threads";
import {
  matchesAgentDatabaseReadCandidatePath,
  type AgentDatabaseReadCandidate,
} from "../../infra/agent-database-readers.js";
import { resolveIdentityPathViaExistingAncestorSync } from "../../infra/path-existence.js";
import {
  assertDatabasePathIdentity,
  assertExistingDatabaseIdentity,
  type DatabasePathIdentity,
  inspectDatabasePathIdentitySync,
  readDatabasePathIdentitySync,
} from "../../infra/sqlite-worker-identity.js";
import { isArtifactPreservingStateRead } from "../../state/artifact-preserving-state-reads.js";
import { resolveSessionStorePathCore } from "./paths.js";

export type CapturedSessionStorePaths = ReadonlyMap<
  string,
  { configured: string; default: string }
>;

export function measureSessionStoreTargetInventoryInputBytes(request: {
  paths: CapturedSessionStorePaths;
}): number {
  let bytes = JSON.stringify(request).length * 2;
  // JSON omits Map entries; retain the pool's UTF-16 string charge for captured paths.
  for (const [agentId, paths] of request.paths) {
    bytes += 2 * (agentId.length + paths.configured.length + paths.default.length);
  }
  return bytes;
}

export function resolveCapturedSessionStorePath(
  store: string | undefined,
  agentId: string,
  env: NodeJS.ProcessEnv,
  paths?: CapturedSessionStorePaths,
  kind: "configured" | "default" = "configured",
): string {
  if (!paths) {
    return resolveSessionStorePathCore(kind === "default" ? undefined : store, { agentId, env });
  }
  const captured = paths.get(agentId);
  if (!captured) {
    throw new Error(`Session store path was not captured for ${agentId}`);
  }
  return captured[kind];
}

export type SessionStoreReadCandidate = AgentDatabaseReadCandidate & {
  physicalPath: string;
  identity?: DatabasePathIdentity;
};

export type SessionStoreReadCustody = {
  sourcePath: string;
  candidates: readonly SessionStoreReadCandidate[];
};

/** Registry receipts must retain the captured file generation through every spelling. */
export function isSessionStoreSourceGenerationCurrent(
  captured: { path: string; identity: string; birthtime?: string },
  source: { path: string; physicalPath: string },
): boolean {
  if (captured.birthtime === undefined) {
    return false;
  }
  try {
    for (const pathname of new Set([captured.path, source.path, source.physicalPath])) {
      assertExistingDatabaseIdentity(pathname, captured.identity, captured.birthtime);
    }
    return true;
  } catch {
    return false;
  }
}

/** Capture exact candidates before discovery yields; sibling families have no file identity. */
export function captureSessionStoreCandidateIdentities(
  candidates: readonly SessionStoreReadCandidate[],
) {
  return new Map(
    candidates
      .filter((candidate) => !candidate.scope)
      .map((candidate) => {
        const identity = candidate.identity ?? readDatabasePathIdentitySync(candidate.path);
        return [identity.canonicalPath, identity] as const;
      }),
  );
}

/** Families follow their directory; existing file aliases get separate exact captures. */
export function captureSessionStoreReadCandidate(
  pathname: string,
  scope?: "sibling-family",
): SessionStoreReadCandidate {
  const capturedPath = path.resolve(pathname);
  const physicalPath = scope
    ? path.join(
        resolveIdentityPathViaExistingAncestorSync(path.dirname(capturedPath)),
        path.basename(capturedPath),
      )
    : resolveIdentityPathViaExistingAncestorSync(capturedPath);
  return { path: capturedPath, physicalPath, ...(scope ? { scope } : {}) };
}

/** Re-resolve both sides so aliases that converge after file creation remain in custody. */
export function isSessionStoreReadCandidateCurrent(candidate: SessionStoreReadCandidate): boolean {
  const currentPhysicalPath = captureSessionStoreReadCandidate(
    candidate.path,
    candidate.scope,
  ).physicalPath;
  return matchesSessionStoreReadCandidatePhysicalPath(candidate, currentPhysicalPath);
}

function matchesSessionStoreReadCandidatePhysicalPath(
  candidate: SessionStoreReadCandidate,
  currentPhysicalPath: string,
): boolean {
  const capturedPhysicalPath = resolveCapturedSessionStoreReadCandidatePhysicalPath(candidate);
  if (currentPhysicalPath === capturedPhysicalPath) {
    return true;
  }
  if (
    candidate.scope ||
    (!isSymlinkFreeWindowsShortPath(candidate.path) &&
      !isSymlinkFreeWindowsShortPath(candidate.physicalPath))
  ) {
    return false;
  }
  return matchesWindowsFileAlias(currentPhysicalPath, capturedPhysicalPath);
}

function resolveCapturedSessionStoreReadCandidatePhysicalPath(
  candidate: SessionStoreReadCandidate,
): string {
  // Family custody is anchored to its captured physical directory. Re-resolving that anchor
  // would accept a directory that was replaced with a symlink after capture.
  if (candidate.scope || !isSymlinkFreeWindowsShortPath(candidate.physicalPath)) {
    return candidate.physicalPath;
  }
  return resolveIdentityPathViaExistingAncestorSync(candidate.physicalPath);
}

function isSymlinkFreeWindowsShortPath(pathname: string): boolean {
  if (process.platform !== "win32" || !/(?:^|[\\/])[^\\/]*~\d+(?=[\\/]|$)/iu.test(pathname)) {
    return false;
  }
  return isSymlinkFreePath(pathname);
}

function isSymlinkFreePath(pathname: string): boolean {
  const resolved = path.resolve(pathname);
  const parsed = path.parse(resolved);
  let cursor = parsed.root;
  for (const segment of resolved.slice(parsed.root.length).split(path.sep)) {
    cursor = path.join(cursor, segment);
    const stat = fs.lstatSync(cursor, { throwIfNoEntry: false });
    if (!stat || stat.isSymbolicLink()) {
      return false;
    }
  }
  return true;
}

function matchesWindowsFileAlias(capturedPath: string, selectedPath: string): boolean {
  const shortPath = isSymlinkFreeWindowsShortPath(capturedPath)
    ? capturedPath
    : isSymlinkFreeWindowsShortPath(selectedPath)
      ? selectedPath
      : undefined;
  if (
    process.platform !== "win32" ||
    !shortPath ||
    !isSymlinkFreePath(capturedPath) ||
    !isSymlinkFreePath(selectedPath)
  ) {
    return false;
  }
  const capturedParent = fs.statSync(path.dirname(capturedPath), { bigint: true });
  const selectedParent = fs.statSync(path.dirname(selectedPath), { bigint: true });
  if (capturedParent.dev !== selectedParent.dev || capturedParent.ino !== selectedParent.ino) {
    return false;
  }
  const capturedIdentity = inspectDatabasePathIdentitySync(capturedPath);
  const selectedIdentity = inspectDatabasePathIdentitySync(selectedPath);
  return (
    capturedIdentity?.key.startsWith("file:") === true &&
    capturedIdentity.key === selectedIdentity?.key &&
    capturedIdentity.birthtime === selectedIdentity.birthtime
  );
}

/** Native discovery may use only the captured lexical and physical family together. */
export function assertSessionStoreReadCandidate(
  pathname: string,
  candidates: readonly SessionStoreReadCandidate[],
): string {
  if (isMainThread && isArtifactPreservingStateRead()) {
    const selected = candidates.find(
      (candidate) =>
        candidate.identity &&
        (candidate.path === path.resolve(pathname) ||
          candidate.physicalPath === path.resolve(pathname)),
    );
    if (!selected) {
      throw new Error("Session inspection requires a worker-prepared physical candidate");
    }
    return selected.physicalPath;
  }
  const physicalPath = resolveIdentityPathViaExistingAncestorSync(pathname);
  for (const candidate of candidates) {
    const matchesCapturedPhysicalPath =
      !candidate.scope &&
      physicalPath === resolveCapturedSessionStoreReadCandidatePhysicalPath(candidate);
    if (
      (matchesAgentDatabaseReadCandidatePath(candidate, pathname) ||
        matchesCapturedPhysicalPath ||
        (!candidate.scope && matchesWindowsFileAlias(candidate.path, pathname))) &&
      (!candidate.scope ||
        matchesAgentDatabaseReadCandidatePath(
          { ...candidate, path: resolveCapturedSessionStoreReadCandidatePhysicalPath(candidate) },
          physicalPath,
        )) &&
      // The exact selected path was resolved above in this synchronous assertion.
      (!candidate.scope && candidate.path === path.resolve(pathname)
        ? matchesSessionStoreReadCandidatePhysicalPath(candidate, physicalPath)
        : isSessionStoreReadCandidateCurrent(candidate))
    ) {
      if (candidate.identity) {
        assertDatabasePathIdentity(candidate.path, candidate.identity);
      }
      return physicalPath;
    }
  }
  throw new Error(
    `Session database target changed outside captured discovery custody: ${pathname}`,
  );
}

/** Unlisted siblings inherit absence only from a complete inventory of the original physical family. */
function qualifyAbsentSessionStoreReadCandidate(
  pathname: string,
  captured: { candidates: readonly SessionStoreReadCandidate[]; familyListingComplete: boolean },
) {
  const physicalPath = assertSessionStoreReadCandidate(pathname, captured.candidates);
  const family = captured.candidates.find(
    (candidate) =>
      candidate.scope === "sibling-family" &&
      matchesAgentDatabaseReadCandidatePath(candidate, pathname) &&
      matchesAgentDatabaseReadCandidatePath(
        { ...candidate, path: candidate.physicalPath },
        physicalPath,
      ),
  );
  const listed = captured.candidates.some(
    (candidate) =>
      !candidate.scope &&
      (matchesAgentDatabaseReadCandidatePath(candidate, pathname) ||
        matchesAgentDatabaseReadCandidatePath(
          { ...candidate, path: candidate.physicalPath },
          physicalPath,
        )),
  );
  if (
    listed ||
    !captured.familyListingComplete ||
    !family ||
    !isSessionStoreReadCandidateCurrent(family)
  ) {
    throw new Error("Session database absence was not captured before discovery");
  }
  const identity = readDatabasePathIdentitySync(pathname);
  if (identity.key.startsWith("file:") || identity.canonicalPath !== physicalPath) {
    throw new Error("Session database appeared after its initial inventory");
  }
  return identity;
}

export function resolveSessionStoreWriteCandidate(
  pathname: string,
  captured: {
    candidates: readonly SessionStoreReadCandidate[];
    familyListingComplete: boolean;
    identities: readonly DatabasePathIdentity[];
  },
) {
  if (!captured.candidates.every(isSessionStoreReadCandidateCurrent)) {
    throw new Error("Session database selector changed during discovery");
  }
  const physicalPath = assertSessionStoreReadCandidate(pathname, captured.candidates);
  const identity = captured.identities.find((entry) => entry.canonicalPath === physicalPath);
  if (identity) {
    assertDatabasePathIdentity(pathname, identity);
    return identity;
  }
  return qualifyAbsentSessionStoreReadCandidate(pathname, captured);
}
