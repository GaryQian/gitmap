import { normalizeInternalTurnContext } from "../../auto-reply/internal-turn-source.js";
import { coerceRequiredSqliteNumber as sqliteNumber } from "../../infra/sqlite-number.js";
import { emitSessionLifecycleEvent } from "../../sessions/session-lifecycle-events.js";
import { readOpenClawAgentDatabaseIdentity } from "../../state/openclaw-agent-db-identity.js";
import { runOpenClawAgentWriteWithYieldingAdmission } from "../../state/openclaw-agent-db-transaction.js";
import {
  getOpenClawAgentDatabaseIfOpen,
  openOpenClawAgentDatabase,
  withOpenClawAgentDatabaseRuntime,
} from "../../state/openclaw-agent-db.js";
import type { AgentDatabaseExecutionFileIdentity } from "../../state/openclaw-agent-execution-contract.js";
import { captureOpenClawAgentDatabaseExecution } from "../../state/openclaw-agent-execution.js";
import { prepareSessionMetaPatch } from "./metadata.js";
import type {
  RecordInboundSessionMetaParams,
  UpdateSessionLastRouteParams,
} from "./runtime-types.js";
import type {
  SessionAccessScope,
  SessionEntrySummary,
  SessionEntryTargetPatchScope,
} from "./session-accessor.sqlite-contract.js";
import type { SqliteLifecycleTargetSnapshot } from "./session-accessor.sqlite-entry-equality.js";
import { listSqliteSessionEntriesFromDatabase } from "./session-accessor.sqlite-entry-list.read.js";
import { applySessionEntryPatchInDatabase } from "./session-accessor.sqlite-entry-mutation.js";
import {
  readSessionEntryRow,
  readLifecycleTargetSnapshot,
  readSessionEntrySelectionSnapshot,
} from "./session-accessor.sqlite-entry-store.js";
import { prepareSessionIdentityPublication } from "./session-accessor.sqlite-identity.js";
import { kickSessionEntryMaintenanceAfterWrite } from "./session-accessor.sqlite-maintenance-kick.js";
import { createFallbackSessionEntry } from "./session-accessor.sqlite-normalize.js";
import {
  resolveSqliteScope,
  resolveSqliteTranscriptArchiveDirectory,
  runExclusiveSqliteSessionWrite,
  toDatabaseOptions,
  type ResolvedSqliteScope,
} from "./session-accessor.sqlite-scope.js";
import { withPreparedSqliteWriteScope } from "./session-accessor.sqlite-write-scope.js";
import type { SessionEntryListScope } from "./session-accessor.types.js";
import { patchSessionActorEntryInScope } from "./session-actor-entry-adapter.js";
import { getSessionActorStorageBinding } from "./session-actor-storage-binding.js";
import { assertCanonicalSessionKeyWrite } from "./session-canonical-row.js";
import { readSessionEntryPatchPredicate } from "./session-entry-patch-guard.js";
import {
  mergeSessionEntryPatch,
  projectSessionEntryPatch,
  type SessionEntryPatchOperation,
} from "./session-entry-patch-operation.js";
import { captureSessionEntryPatchSource } from "./session-entry-patch-source.js";
import type {
  SessionEntryUpdater,
  SqliteSessionEntryPatchOptions,
  SqliteSessionEntrySnapshotPatchParams,
} from "./session-entry-patch-source.js";
import { patchSessionEntryInWorker } from "./session-entry-patch.js";
import type {
  SessionEntryPatchGuard,
  SessionEntryPatchCommitted,
} from "./session-entry-patch.types.js";
import { buildInboundSessionCreationStamp } from "./session-entry-provenance.js";
import type { CapturedSessionEntryReadSource } from "./session-entry-read-source.types.js";
import { kickSessionHistoryDiskBudgetMaintenance } from "./session-history-eviction.js";
import {
  captureExternalSessionCommitGuard,
  composeSessionSourceAssertion,
  sessionEntryCommitGuardOptions,
  prepareSessionSourceAuthority,
  runWithSessionSourceScope,
  type PreparedSessionSourceAuthority,
  type SessionSourceAssertion,
} from "./session-source-authority.js";
import { resolveSessionStorePathForScope } from "./session-store-path.js";
import type { InternalSessionEntry as SessionEntry } from "./types.js";
import { mergeSessionEntry } from "./types.js";

export { loadSessionEntryForAdmission } from "./session-accessor.sqlite-entry-admission.js";
export { replaceSessionEntrySync } from "./session-accessor.sqlite-entry-replace.js";
export { ensureSessionEntrySync } from "./session-accessor.sqlite-initial-entry.js";
export { listSessionEntriesReadOnly } from "./session-accessor.sqlite-entry-list.read.js";
export { listSessionEntryKeysReadOnly } from "./session-retirement-read.js";
export {
  loadExactSessionEntryFromStoreReadOnly,
  loadExactSessionEntryReadOnly,
  loadSessionEntryByIdReadOnly,
  loadSessionEntryReadOnly,
  withSessionEntryReadOnlyScope,
  loadSessionEntryReadOnlyInScope,
} from "./session-accessor.sqlite-exact-read.js";

export {
  loadExactSessionEntry,
  loadExactSessionEntryCandidates,
  loadSessionEntry,
} from "./session-accessor.sqlite-entry-admitted-read.js";

export { loadSessionEntryReadOnlyResultInScope } from "./session-accessor.sqlite-exact-read.js";

/** Lists session entries from the additive SQLite session store. */
export function listSessionEntryRows(scope: SessionEntryListScope = {}): SessionEntrySummary[] {
  const memory = getSessionActorStorageBinding(scope);
  if (memory) {
    return memory.actor.storage!.readCurrent(
      { type: "session.entries.read", input: { projection: scope.projection } },
      memory.authority,
    );
  }
  const resolved = resolveSqliteScope({ ...scope, sessionKey: "" });
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  return listSqliteSessionEntriesFromDatabase(database, resolved, scope);
}

/** Reads a session activity timestamp from the additive SQLite session store. */
export function readSessionUpdatedAtCore(scope: SessionAccessScope): number | undefined {
  const memory = getSessionActorStorageBinding(scope);
  if (memory) {
    return memory.actor.storage!.readCurrent(
      { type: "session.entry.read", input: {} },
      memory.authority,
    )?.updatedAt;
  }
  const resolved = resolveSqliteScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  const row = readSessionEntryRow(database, resolved.sessionKey, "list")?.row;
  return row ? sqliteNumber(row.updated_at) : undefined;
}

/** Applies a partial entry update to the additive SQLite session store. */
export async function upsertSessionEntryCore(
  scope: SessionAccessScope,
  patch: Partial<SessionEntry>,
  options: Pick<SqliteSessionEntryPatchOptions, "assertCommitAllowed" | "workerGuard"> = {},
): Promise<SessionEntry | null> {
  return await applySessionEntryOperation(
    scope,
    { kind: "fields", patch },
    {
      ...options,
      fallbackEntry: createFallbackSessionEntry(patch),
    },
  );
}

/** Replaces one entry in the additive SQLite session store. */
export async function replaceSessionEntry(
  scope: SessionAccessScope,
  entry: SessionEntry,
): Promise<SessionEntry | null> {
  return await applySessionEntryOperation(
    scope,
    { kind: "fields", patch: entry },
    {
      fallbackEntry: entry,
      replaceEntry: true,
    },
  );
}

/** Patches one entry in the additive SQLite session store. */
export async function patchSessionEntryCore(
  scope: SessionAccessScope,
  update: SessionEntryUpdater,
  options: Omit<SqliteSessionEntryPatchOptions, "result"> = {},
): Promise<SessionEntry | null> {
  return await patchSessionEntryInScope(scope, update, options);
}

/** Internal fixed operations evaluate the authoritative row inside the writer command. */
export function applySessionEntryOperation(
  scope: SessionAccessScope,
  operation: SessionEntryPatchOperation,
  options: SqliteSessionEntryPatchOptions & { result: "none" },
): Promise<void>;
export function applySessionEntryOperation(
  scope: SessionAccessScope,
  operation: SessionEntryPatchOperation,
  options?: SqliteSessionEntryPatchOptions & { result?: never },
): Promise<SessionEntry | null>;
export async function applySessionEntryOperation(
  scope: SessionAccessScope,
  operation: SessionEntryPatchOperation,
  options: SqliteSessionEntryPatchOptions = {},
): Promise<SessionEntry | null | void> {
  const entry = await patchSessionEntryInScope(scope, structuredClone(operation), {
    workerGuard: {},
    ...options,
  });
  if (options.result !== "none") {
    return entry;
  }
}

async function patchSessionEntryInScope(
  scope: SessionAccessScope,
  update: SqliteSessionEntrySnapshotPatchParams["update"],
  options: SqliteSessionEntryPatchOptions,
  databaseAgentId?: string,
): Promise<SessionEntry | null> {
  const memory = patchSessionActorEntryInScope(scope, {
    update,
    options,
    sessionKey: scope.sessionKey,
  });
  if (memory) {
    return (await memory).entry;
  }
  const storePath = resolveSessionStorePathForScope(scope);
  return withPreparedSqliteWriteScope(
    scope,
    (resolved, sharedWriteReserved) => {
      if (databaseAgentId) {
        resolved.databaseAgentId = databaseAgentId;
      }
      assertCanonicalSessionKeyWrite(resolved.sessionKey, resolved.agentId);
      return patchSqliteSessionEntrySnapshot({
        operationLabel: "session-entry.patch",
        validateCanonicalKeys: options.replaceEntry !== true,
        options,
        selection: {
          kind: "entry",
          sessionKey: resolved.sessionKey,
          exact: options.replaceEntry === true,
        },
        readSnapshot: (database, includeWindowFacts) =>
          readSessionEntrySelectionSnapshot(
            database,
            resolved.sessionKey,
            options.replaceEntry === true,
            includeWindowFacts,
          ),
        resolved,
        sessionKey: resolved.sessionKey,
        storePath,
        sharedWriteReserved,
        update,
      });
    },
    options.signal,
  );
}

/** Patches one logical entry after validating its canonical lifecycle target. */
export async function patchSessionEntryTarget(
  scope: SessionEntryTargetPatchScope,
  update: SessionEntryUpdater,
  options: Omit<SqliteSessionEntryPatchOptions, "result"> = {},
): Promise<SessionEntry | null> {
  return await patchSessionEntryTargetInScope(scope, update, options);
}

export function applySessionEntryTargetOperation(
  scope: SessionEntryTargetPatchScope,
  operation: SessionEntryPatchOperation,
  options: SqliteSessionEntryPatchOptions & { result: "none" },
): Promise<void>;
export function applySessionEntryTargetOperation(
  scope: SessionEntryTargetPatchScope,
  operation: SessionEntryPatchOperation,
  options?: SqliteSessionEntryPatchOptions & { result?: never },
): Promise<SessionEntry | null>;
export async function applySessionEntryTargetOperation(
  scope: SessionEntryTargetPatchScope,
  operation: SessionEntryPatchOperation,
  options: SqliteSessionEntryPatchOptions = {},
): Promise<SessionEntry | null | void> {
  const entry = await patchSessionEntryTargetInScope(scope, structuredClone(operation), {
    workerGuard: {},
    ...options,
  });
  if (options.result !== "none") {
    return entry;
  }
}

async function patchSessionEntryTargetInScope(
  scope: SessionEntryTargetPatchScope,
  update: SqliteSessionEntrySnapshotPatchParams["update"],
  options: SqliteSessionEntryPatchOptions,
): Promise<SessionEntry | null> {
  const memory = patchSessionActorEntryInScope(
    { ...scope, sessionKey: scope.target.canonicalKey },
    { update, options, sessionKey: scope.target.canonicalKey },
  );
  if (memory) {
    return (await memory).entry;
  }
  const source = scope.readSource;
  const target = {
    agentId: scope.agentId,
    env: scope.env,
    sessionKey: scope.target.canonicalKey,
    storePath: scope.storePath,
  };
  const storePath = source?.path ?? resolveSessionStorePathForScope(target);
  const patch = (resolved: ResolvedSqliteScope, sharedWriteReserved = false) =>
    patchSqliteSessionEntrySnapshot({
      operationLabel: "session-entry-target.patch",
      capturedSource: source,
      validateCanonicalKeys: true,
      options,
      selection: { kind: "target", target: scope.target },
      readSnapshot: (database, includeWindowFacts) =>
        readLifecycleTargetSnapshot(database, scope.target, { includeWindowFacts }),
      resolved,
      sessionKey: scope.target.canonicalKey,
      storePath,
      sharedWriteReserved,
      update,
    });
  return source
    ? patch({
        agentId: scope.agentId ?? source.agentId,
        databaseAgentId: source.agentId,
        env: scope.env,
        path: source.path,
        ownerStorePath: source.path,
        sessionKey: "",
      })
    : withPreparedSqliteWriteScope(target, patch, options.signal);
}

/** Callback and fixed-operation patches share source custody, FIFO, and commit publication. */
async function patchSqliteSessionEntrySnapshot(
  params: SqliteSessionEntrySnapshotPatchParams,
): Promise<SessionEntry | null> {
  const { options, sessionKey } = params;
  const captured = params.capturedSource;
  const {
    resolved,
    databaseOptions,
    databasePath,
    targetIdentity,
    useWorker,
    ensureIdentitySource,
    assertCapturedSource,
    assertCurrent,
  } = captureSessionEntryPatchSource(params);
  let lifecycleEffects: SessionEntryPatchCommitted["lifecycleEffects"];
  const prepare = async (prepared: SqliteLifecycleTargetSnapshot) => {
    const existing = prepared[0]?.entry;
    if (
      options.prepareIf?.kind === "live-model-switch-pending" &&
      !existing?.liveModelSwitchPending
    ) {
      return undefined;
    }
    const writeBase = existing ?? options.fallbackEntry;
    if (!writeBase) {
      return undefined;
    }
    let contextEntry = existing;
    let contextEntryBorrowed = true;
    const next =
      typeof params.update !== "function"
        ? projectSessionEntryPatch({
            ...options,
            existing,
            writeBase,
            sessionKey,
            operation: params.update,
            onLifecycleProjection: (effects) => {
              lifecycleEffects = effects;
            },
          })
        : mergeSessionEntryPatch({
            ...options,
            existing,
            writeBase,
            sessionKey,
            patch: await params.update(structuredClone(writeBase), {
              get existingEntry() {
                if (contextEntryBorrowed) {
                  contextEntry = contextEntry ? structuredClone(contextEntry) : undefined;
                  contextEntryBorrowed = false;
                }
                return contextEntry;
              },
              set existingEntry(entry) {
                contextEntry = entry;
                contextEntryBorrowed = false;
              },
            }),
          });
    return {
      selection: params.selection,
      prepared,
      sessionKey,
      writeBase,
      next,
      operationLabel: params.operationLabel,
      validateCanonicalKeys: params.validateCanonicalKeys,
      consumePendingReset: options.consumePendingReset,
      providerReviewMutation: options.providerReviewMutation,
      shouldCommitIf: options.workerGuard?.shouldCommitIf,
      conversation: options.workerGuard?.conversation,
    };
  };
  const withDatabase = <T>(operation: () => T | Promise<T>) => {
    assertCurrent?.();
    return !getOpenClawAgentDatabaseIfOpen(databaseOptions)
      ? withOpenClawAgentDatabaseRuntime(databaseOptions, operation, assertCurrent)
      : operation();
  };
  let writtenSource: AgentDatabaseExecutionFileIdentity | undefined;
  // A background owner can retain the same absent store before its first write.
  const creatingExecution =
    useWorker && !options.retainedExecution && targetIdentity.key.startsWith("path:")
      ? captureOpenClawAgentDatabaseExecution(databaseOptions, {
          expectedCreationIdentity: targetIdentity,
        })
      : undefined;
  const workerPatch = (source: PreparedSessionSourceAuthority, assertSource?: () => void) =>
    patchSessionEntryInWorker({
      database: { ...databaseOptions, path: databasePath },
      expectedCreationIdentity: targetIdentity,
      databaseIdentity:
        typeof captured?.databaseIdentity === "string" ? captured.databaseIdentity : undefined,
      agentId: resolved.agentId,
      selection: params.selection,
      assertCurrent: () => assertCurrent?.(),
      guard: options.workerGuard,
      assertCommitAllowed: () => {
        options.assertCommitAllowed?.();
        assertSource?.();
      },
      shouldCommit: options.shouldCommit,
      preparedSource: source,
      retainedExecution: options.retainedExecution ?? creatingExecution,
      reduction:
        typeof params.update === "function"
          ? undefined
          : {
              operation: params.update,
              selection: params.selection,
              sessionKey,
              operationLabel: params.operationLabel,
              validateCanonicalKeys: params.validateCanonicalKeys,
              returnEntry:
                options.result === "none" && !options.onCommitted && !options.onCommittedSource
                  ? false
                  : undefined,
              fallbackEntry: options.fallbackEntry,
              replaceEntry: options.replaceEntry,
              preserveActivity: options.preserveActivity,
              consumePendingReset: options.consumePendingReset,
              providerReviewMutation: options.providerReviewMutation,
              shouldCommitIf: options.workerGuard?.shouldCommitIf,
              conversation: options.workerGuard?.conversation,
              ensureIdentitySource,
            },
      prepare,
      onCommitted: options.onCommitted,
      onCommittedSource: options.onCommittedSource,
    }).then((result) => {
      writtenSource = result.writtenSource;
      return result.entry;
    });
  const sourceAssertion = options.workerGuard?.source;
  // Reserve the existing FIFO before async source planning or selecting either writer path.
  const pendingCommit = runExclusiveSqliteSessionWrite(
    resolved,
    async () => {
      if (useWorker) {
        const source = await prepareSessionSourceAuthority(sourceAssertion);
        const locality: "same-store" | "cross-store" =
          !source.nativeSource &&
          source.checks.every(
            ({ predicate }) => targetIdentity.key === `file:${predicate.source.databaseIdentity}`,
          )
            ? "same-store"
            : "cross-store";
        if (ensureIdentitySource && locality !== "same-store") {
          await source.release?.();
          throw new Error("Transaction-local entry authority differs from its writer");
        }
        if (locality === "same-store") {
          return workerPatch(source);
        }
        await source.release?.();
        // Cross-store effects need their source receipt in scope at the commit grant.
        return runWithSessionSourceScope(
          sourceAssertion,
          () =>
            workerPatch({ assertCurrent: () => sourceAssertion?.(), checks: [] }, sourceAssertion),
          { checkAfter: false },
        );
      }
      const patchNative = async () =>
        withDatabase(async () => {
          const database = openOpenClawAgentDatabase(databaseOptions);
          assertCapturedSource(database);
          const prepared = params.readSnapshot(database);
          const input = await prepare(prepared);
          if (!input) {
            return null;
          }
          const { writeBase, next } = input;
          // The updater may dispose the prepared handle; re-admit before waiting for the write lock.
          return withDatabase(async () => {
            let result: SessionEntry | null = null;
            let committedSource: CapturedSessionEntryReadSource | undefined;
            let transcriptPredicate: SessionEntryPatchCommitted["transcriptPredicate"];
            const publish = await runOpenClawAgentWriteWithYieldingAdmission(
              (writeDatabase) => {
                assertCapturedSource(writeDatabase);
                options.workerGuard?.assertCurrent?.();
                if (options.shouldCommit?.() === false) {
                  return undefined;
                }
                const predicate = readSessionEntryPatchPredicate(
                  writeDatabase,
                  sessionKey,
                  options.workerGuard?.shouldCommitIf,
                );
                if (!predicate.matches) {
                  return undefined;
                }
                const mutation = applySessionEntryPatchInDatabase(writeDatabase, {
                  operationLabel: params.operationLabel,
                  validateCanonicalKeys: params.validateCanonicalKeys,
                  readSnapshot: (current) => params.readSnapshot(current, true),
                  prepared,
                  sessionKey,
                  writeBase,
                  next,
                  options: {
                    ...options,
                    assertCommitAllowed: () => {
                      options.assertCommitAllowed?.();
                      options.workerGuard?.assertMutationAllowed?.();
                      options.workerGuard?.source?.();
                    },
                  },
                });
                result = mutation.entry;
                transcriptPredicate =
                  mutation.entry.sessionId === predicate.transcriptPredicate?.sessionId
                    ? predicate.transcriptPredicate
                    : undefined;
                if (!mutation.identity) {
                  return undefined;
                }
                const identity = readOpenClawAgentDatabaseIdentity(writeDatabase);
                writtenSource = {
                  kind: "file",
                  physicalIdentity: identity.identity,
                  birthtime: identity.birthtime,
                  nativeLocation: identity.canonicalPath,
                };
                if (options.onCommittedSource) {
                  committedSource = {
                    agentId: writeDatabase.agentId,
                    path: writeDatabase.path,
                    databaseIdentity: identity.identity,
                    databaseBirthtime: identity.birthtime,
                  };
                }
                return prepareSessionIdentityPublication(
                  writeDatabase,
                  resolved.agentId,
                  mutation.identity.previous,
                  mutation.identity.current,
                );
              },
              databaseOptions,
              { operationLabel: params.operationLabel },
            );
            try {
              if (next && result) {
                if (lifecycleEffects) {
                  options.onCommitted?.(result, transcriptPredicate, lifecycleEffects);
                } else if (transcriptPredicate) {
                  options.onCommitted?.(result, transcriptPredicate);
                } else {
                  options.onCommitted?.(result);
                }
                if (committedSource) {
                  options.onCommittedSource?.(committedSource, result);
                }
              }
            } finally {
              publish?.();
            }
            return result;
          });
        });
      return runWithSessionSourceScope(sourceAssertion, patchNative, { checkAfter: false });
    },
    params.operationLabel,
    undefined,
    // The admission owner validates the active reservation and rejects worker-grant reentry.
    params.sharedWriteReserved || options.retainedExecution || (useWorker && !sourceAssertion)
      ? "foreground-reentrant"
      : "foreground",
    options.signal,
  );
  let committed: SessionEntry | null;
  try {
    committed = await pendingCommit;
  } finally {
    await creatingExecution?.release();
  }
  if (writtenSource) {
    kickSessionEntryMaintenanceAfterWrite({
      source: writtenSource,
      activeSessionKey: sessionKey,
      archiveDirectory: resolveSqliteTranscriptArchiveDirectory(resolved),
      maintenanceConfig: options.maintenanceConfig,
      scope: resolved,
      skipMaintenance: options.skipMaintenance,
      storePath: params.storePath,
    });
    kickSessionHistoryDiskBudgetMaintenance({
      ...(resolved.agentId ? { agentId: resolved.agentId } : {}),
      env: resolved.env,
      storePath: params.storePath,
      ...(options.maintenanceConfig ? { maintenanceConfig: options.maintenanceConfig } : {}),
    });
  }
  return committed;
}

export async function recordInboundSessionMeta(
  input: RecordInboundSessionMetaParams,
): Promise<SessionEntry | null> {
  normalizeInternalTurnContext(input.ctx);
  const metadata = prepareSessionMetaPatch(input);
  return await applySessionEntryOperation(
    { sessionKey: input.sessionKey, storePath: input.storePath },
    {
      kind: "inbound-metadata",
      sessionKey: input.sessionKey,
      metadata,
      creation: buildInboundSessionCreationStamp(input.ctx),
    },
    {
      // Inbound metadata must not refresh activity timestamps; idle reset
      // evaluation relies on updatedAt from actual session turns.
      preserveActivity: true,
      workerGuard: { assertMutationAllowed: input.assertCommitAllowed },
      onCommittedSource: metadata.privateTelegramTopicName
        ? (source) =>
            emitSessionLifecycleEvent({
              agentId: source.agentId,
              sessionKey: input.sessionKey,
              reason: "metadata",
              scope: "session-entry",
            })
        : undefined,
      fallbackEntry: input.createIfMissing === false ? undefined : mergeSessionEntry(undefined, {}),
    },
  );
}

/** Updates last-route/delivery metadata without refreshing activity timestamps. */
export async function updateSessionLastRoute(
  params: UpdateSessionLastRouteParams & {
    assertCommitAllowed?: () => void;
    workerGuard?: SessionEntryPatchGuard;
  },
): Promise<SessionEntry | null> {
  return await updateSessionLastRouteInScope(
    { sessionKey: params.sessionKey, storePath: params.storePath },
    {
      ...params,
      assertCommitAllowed: captureExternalSessionCommitGuard(params.assertCommitAllowed),
    },
  );
}

/** Internal callers retain their captured storage owner across route preparation. */
export async function updateSessionLastRouteInScope(
  scope: SessionAccessScope & { databaseAgentId?: string },
  params: Omit<UpdateSessionLastRouteParams, "storePath" | "sessionKey"> & {
    assertCommitAllowed?: SessionSourceAssertion;
    workerGuard?: SessionEntryPatchGuard;
  },
): Promise<SessionEntry | null> {
  if (params.ctx) {
    normalizeInternalTurnContext(params.ctx);
  }
  const createIfMissing = params.createIfMissing ?? true;
  const { source, ...routeGuard } = params.workerGuard ?? {};
  const commitGuard = sessionEntryCommitGuardOptions(
    source
      ? composeSessionSourceAssertion([source, params.assertCommitAllowed])
      : params.assertCommitAllowed,
  );
  return await patchSessionEntryInScope(
    scope,
    {
      kind: "last-route",
      route: {
        channel: params.channel,
        to: params.to,
        accountId: params.accountId,
        threadId: params.threadId,
        route: params.route,
        deliveryContext: params.deliveryContext,
        sessionKey: scope.sessionKey,
        metadata: params.ctx
          ? prepareSessionMetaPatch({ ctx: params.ctx, groupResolution: params.groupResolution })
          : undefined,
      },
      creation: buildInboundSessionCreationStamp(params.ctx),
    },
    {
      // Route updates must not refresh activity timestamps (#49515).
      preserveActivity: true,
      ...commitGuard,
      workerGuard: { ...routeGuard, ...commitGuard.workerGuard },
      ...(createIfMissing ? { fallbackEntry: mergeSessionEntry(undefined, {}) } : {}),
    },
    scope.databaseAgentId,
  );
}
