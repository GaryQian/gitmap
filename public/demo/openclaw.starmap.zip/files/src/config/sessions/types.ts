import crypto from "node:crypto";
import type {
  AcpSessionRuntimeOptions,
  SessionAcpIdentity,
  SessionAcpMeta,
} from "@openclaw/acp-core/types";
import { asNonNegativeFiniteNumber } from "@openclaw/normalization-core/number-coercion";
import { normalizeOptionalString, type FastMode } from "@openclaw/normalization-core/string-coerce";
import type {
  SessionEntryArchiveReason,
  SessionRow,
  SessionRunStatus,
} from "../../../packages/gateway-protocol/src/index.js";
import type { QueueMode } from "../../../packages/gateway-protocol/src/schema/logs-chat.js";
import type { SessionGoal } from "../../../packages/gateway-protocol/src/schema/sessions-goal.js";
import type { SessionObserverDigest } from "../../../packages/gateway-protocol/src/schema/sessions.js";
import type { SessionAgentStatus } from "../../../packages/gateway-protocol/src/session-agent-status.js";
import type { SessionCommunicationPolicy } from "../../../packages/gateway-protocol/src/session-communication.js";
import type { PreemptiveCompactionRoute as SessionContextBudgetStatusRoute } from "../../agents/embedded-agent-runner/run/preemptive-compaction.types.js";
import type { ChatType } from "../../channels/chat-type.js";
import type {
  CronScheduledToolCallerOrigin,
  CronScheduledToolPolicy,
  CronToolsAllowExecTarget,
  CronToolsAllowExecTargetRequirement,
} from "../../cron/scheduled-tool-policy.js";
import type { QueuedOperatorRecoverySource } from "../../gateway/operator-run-recovery-source.codec.js";
import type { ChannelRouteRef } from "../../plugin-sdk/channel-route.js";
import type { PluginJsonValue as SessionPluginJsonValue } from "../../plugins/host-hook-json.js";
import type { SessionBoardFace } from "../../shared/session-types.js";
import type { DeliveryContext } from "../../utils/delivery-context.types.js";
import type { TtsAutoMode } from "../types.tts.js";
import type {
  PendingDeliveryNoticeState,
  PendingFinalDeliveryState,
} from "./pending-final-delivery-types.js";
import type {
  SessionCreatedActor,
  SessionActor,
  SessionCreatedVia,
  SessionEntryProvenance,
  SessionOwnerAssignment,
  SessionParticipant,
} from "./session-entry-provenance.js";
import type { AgentPatchedSessionModelFallback } from "./session-model-fallback.js";
import type { SessionSkillSnapshot } from "./session-prompt-types.js";
import type { SessionSystemPromptReport } from "./session-system-prompt-report.js";
import type { SessionToolOverrides } from "./session-tool-overrides.js";
import type { PendingSessionWorktree } from "./session-worktree-intent.js";

export type { SessionToolOverrides } from "./session-tool-overrides.js";
export type { SessionSystemPromptReport } from "./session-system-prompt-report.js";

export type { SessionScope } from "../types.base.js";
export type SessionChatType = ChatType;
export type PersistedSessionRunStatus = Exclude<SessionRunStatus, "running" | "queued">;
export const SESSION_TOTAL_TOKENS_VERSION = 2 as const;

type SessionGitHubPullRequestSource = {
  repository: string;
  repositoryId: number;
  branch: string;
  commit: string;
};

/** Original PR selection for one managed workspace; never a publication receipt or permission grant. */
export type SessionGitHubPullRequestBinding = {
  url: string;
  host: string;
  number: number;
  base: SessionGitHubPullRequestSource;
  head: SessionGitHubPullRequestSource;
  /** Verified publication before first binding; absent on already-admitted legacy bindings. */
  origin?: "session-publication" | "external-pr";
  /** Prepared initial PR head; absence means its first import is incomplete. */
  preparedHeadCommit?: string;
};

export type SessionOrigin = {
  label?: string;
  provider?: string;
  surface?: string;
  chatType?: SessionChatType;
  from?: string;
  to?: string;
  nativeChannelId?: string;
  nativeDirectUserId?: string;
  avatar?: string;
  accountId?: string;
  threadId?: string | number;
};

/** Canonical persisted delivery ownership for one session. */
export type SessionDeliveryState =
  | { kind: "none" }
  | { kind: "internal" }
  | {
      kind: "external";
      route: ChannelRouteRef;
      context: DeliveryContext;
      origin: SessionOrigin;
    };

/**
 * Durable transcript-repair record: an assistant final that was delivered to
 * the user but could not be appended to the canonical transcript. Kept
 * separate from `pendingFinalDelivery` so transport-replay cleanup never drops
 * the only copy of the missing assistant turn.
 */
export type PendingTranscriptRepairState = {
  /** Stable identity for retry-safe transcript insertion. */
  id: string;
  text: string;
  provider?: string;
  model?: string;
  createdAt: number;
};

type FallbackNoticeState = {
  kind: "active";
  selectedModel: string;
  activeModel: string;
  reason?: string;
};

type MemoryFlushState =
  | { kind: "succeeded"; compactionCount: number }
  | {
      kind: "failed";
      compactionCount?: number;
      failureCount: number;
    };

export type { AcpSessionRuntimeOptions, SessionAcpIdentity, SessionAcpMeta };

export type CliSessionReseedReceipt = {
  version: 1;
  promptHash: string;
  localSessionId: string;
  userTurnDisposition: "persisted" | "omitted";
};

export type SessionDiffBaseline = {
  version: 1;
  sessionId: string;
  root: string;
  files: Array<{ path: string; fingerprint: string }>;
  /** Some checkout entries could not be fingerprinted without exceeding diff safety caps. */
  truncated?: true;
};

export type CliSessionBinding = {
  sessionId: string;
  /** Last successful assistant boundary accepted by the backend's resume contract. */
  resumeCheckpointId?: string;
  /** Resume with the backend's fork argument once, then clear before process start. */
  forkNextResume?: true;
  /** Trust an explicitly attached CLI session even when auth, prompt, or MCP fingerprints drift. */
  forceReuse?: boolean;
  authProfileId?: string;
  authEpoch?: string;
  authEpochVersion?: number;
  extraSystemPromptHash?: string;
  messageToolPolicyHash?: string;
  promptToolNamesHash?: string;
  cwdHash?: string;
  mcpConfigHash?: string;
  mcpResumeHash?: string;
  /** Identifies one synthetic history prompt and the trusted local handling of its user turn. */
  reseedReceipt?: CliSessionReseedReceipt;
  /** Last input snapshot supplied to this native session, independent of recovery authority. */
  transcriptCursor?: {
    localSessionId: string;
    entryId: string | null;
    runId: string;
    userEntryId?: string;
  };
};

type AcpSessionBinding = {
  acpBackendId: string;
  acpAgentId: string;
  agentSessionId: string;
};

export type SessionContextBudgetStatus = {
  schemaVersion: 1;
  source: "pre-prompt-estimate";
  updatedAt: number;
  provider: string;
  model: string;
  route: SessionContextBudgetStatusRoute;
  shouldCompact: boolean;
  estimatedPromptTokens: number;
  contextTokenBudget: number;
  promptBudgetBeforeReserve: number;
  reserveTokens: number;
  effectiveReserveTokens: number;
  remainingPromptBudgetTokens: number;
  overflowTokens: number;
  toolResultReducibleChars: number;
  messageCount: number;
  unwindowedMessageCount: number;
  sessionId?: string;
};

export type AmbientTranscriptWatermark = {
  sessionId: string;
  messageId: string;
  timestampMs?: number;
  updatedAt: number;
};

type SessionPluginDebugEntry = {
  pluginId: string;
  lines: string[];
};

export type { SessionPluginJsonValue };

type SessionPluginNextTurnInjection = {
  id: string;
  pluginId: string;
  pluginName?: string;
  text: string;
  idempotencyKey?: string;
  placement: "prepend_context" | "append_context";
  ttlMs?: number;
  createdAt: number;
  metadata?: SessionPluginJsonValue;
};

type LaneExecutionState =
  | "active"
  | "draining"
  | "suspended"
  | "resuming"
  | "circuit_open"
  | "failed_handoff";

export interface QuotaSuspension {
  schemaVersion: 1;
  suspendedAt: number; // epoch ms
  reason: "quota_exhausted" | "manual" | "circuit_open";
  failedProvider: string;
  failedModel: string;
  /** Recovery briefing text injected into the next attempt when state === "resuming". */
  summary?: string;
  /** Opaque pointer to an external snapshot blob (path/key); not the briefing text itself. */
  snapshotRef?: string;
  /**
   * @deprecated Lane suspension was removed; nothing writes this anymore. Kept only to
   * hold the shipped SDK surface stable; drop at the next surface window.
   */
  laneId?: string;
  expectedResumeBy?: number; // Reaper TTL (e.g. 30min)
  state: LaneExecutionState; // State machine check for hot-path
}

export type {
  SessionGoal,
  SessionGoalStatus,
} from "../../../packages/gateway-protocol/src/schema/sessions-goal.js";

type SessionEntryCore = SessionEntryProvenance &
  Pick<SessionRow, "permissionMode" | "sandboxMode" | "nativeRuntimeConsent" | "sessionRoot"> & {
    /** Collaboration mode. Missing legacy values are equivalent to "shared". */
    visibility?: NonNullable<SessionRow["visibility"]>;
    /**
     * Last delivered heartbeat payload (used to suppress duplicate heartbeat notifications).
     * Stored on the main session entry.
     */
    lastHeartbeatText?: string;
    /** Timestamp (ms) when lastHeartbeatText was delivered. */
    lastHeartbeatSentAt?: number;
    /**
     * Base session key for heartbeat-created isolated sessions.
     * When present, `<base>:heartbeat` is a synthetic isolated session rather than
     * a real user/session-scoped key that merely happens to end with `:heartbeat`.
     */
    heartbeatIsolatedBaseSessionKey?: string;
    /** Legacy heartbeat task timestamps consumed and cleared only by doctor migration. */
    heartbeatTaskState?: Record<string, number>;
    /** Plugin-owned session state, grouped by plugin id then extension namespace. */
    pluginExtensions?: Record<string, Record<string, SessionPluginJsonValue>>;
    /** Trusted session initialization is incomplete; all work admission stays blocked. */
    initializationPending?: true;
    /** Ordinary Template admission owns this exact pending incarnation until verified setup. */
    templateInitialization?: {
      source: { packageName: string; version?: string };
      agentConfig: import("../types.agents.js").AgentEntryConfig;
      workspaceIdentity: string;
      /** Verified intent recorded before instructions or config can change. */
      preparing?: {
        agentConfig: import("../types.agents.js").AgentEntryConfig;
        planDigest: string;
        sourceIntegrity: string;
        /** Only previously absent files (digest) and directories (null). */
        workspaceAdditions: Record<string, string | null>;
      };
      configured?: { planDigest: string; sourceIntegrity: string };
    };
    /** Creation is finished; Retry continues only this hidden Template setup turn. */
    templateSetup?: {
      source: { packageName: string; version?: string };
      report: import("../../templates/conversation.js").TemplateSetupReport;
      /** Workspace is ready; dependency installation can overlap the first conversation turn. */
      dependenciesPending?: true;
      /** Avoid replaying the greeting when Retry only needs to report dependency results. */
      openingComplete?: true;
    };
    /** Top-level SessionEntry mirror slots owned by plugin session extensions. */
    pluginExtensionSlotKeys?: Record<string, Record<string, string>>;
    /** Durable one-shot prompt additions drained before the next agent turn. */
    pluginNextTurnInjections?: Record<string, SessionPluginNextTurnInjection[]>;
    sessionId: string;
    /** Latest operator client declaration; retained across internal turns and restart. */
    clientCapabilities?: string[];
    updatedAt: number;
    /** Process-lifetime session whose entry and transcript stay in the in-memory agent database. */
    incognito?: true;
    /** Opaque owner revision used to reject stale lifecycle mutations. */
    lifecycleRevision?: string;
    /** Current provider precaution; only its acknowledged continuation may start work. */
    providerReview?: import("./provider-review.types.js").SessionProviderReview;
    // archivedAt/pinnedAt mirror the Codex thread-management shape (state DB
    // threads.archived_at: the boolean is always derived from the timestamp and
    // stamped server-side). Codex serializes camelCase but in epoch SECONDS;
    // these are epoch MS like every other session timestamp — convert at the
    // codex plugin seam when exchanging thread metadata.
    /** Timestamp (ms) when the session was archived from active session lists. */
    archivedAt?: number;
    /** Actor that archived the session; cleared when the session is restored. */
    archivedBy?: SessionActor;
    /** Stable lifecycle cause; absent values are legacy archives and remain manually protected. */
    archiveReason?: SessionEntryArchiveReason;
    /** Timestamp (ms) when the session was pinned for quick access. */
    pinnedAt?: number;
    /** Independent sidebar placement; origin, execution ownership, and access remain unchanged. */
    sidebarRoot?: boolean;
    /** Epoch ms wake time; suppresses the active session in sidebar lists until then. */
    snoozedUntil?: number;
    /** Server-stamped epoch ms when the current snooze was set. */
    snoozedAt?: number;
    /** Timestamp (ms) when an operator client last marked the session read. */
    lastReadAt?: number;
    /** Agent-declared sidebar presence; projection drops it after expiresAt. */
    agentStatus?: SessionAgentStatus;
    /** Latest utility-model status judgment for idle session status surfaces. */
    observerDigest?: SessionObserverDigest;
    /** Versioned, reconstructible Activity recap; never authoritative task status. */
    activitySummary?: import("./activity-summary.js").SessionActivitySummary;
    /** Timestamp (ms) when an operator explicitly marked the session unread; cleared on read. */
    markedUnreadAt?: number;
    /** Timestamp (ms) of the latest completed agent run; metadata patches do not update it. */
    lastActivityAt?: number;
    /** Parent session key that spawned this session (used for sandbox session-tool scoping). */
    spawnedBy?: string;
    /** Host-captured owner status of the spawning invocation; never inferred from child launch authority. */
    spawnedBySenderIsOwner?: boolean;
    /** Parent session id captured with the spawn authority receipt; navigation uses parentSessionId. */
    spawnedBySessionId?: string;
    /** Immutable session key authorized to receive this child's completion handoff. */
    completionOwnerSessionKey?: string;
    /** Workspace inherited by spawned sessions and reused on later turns for the same child session. */
    spawnedWorkspaceDir?: string;
    /** Task working directory inherited by spawned sessions and reused on later turns. */
    spawnedCwd?: string;
    /** Content-free fingerprints for checkout changes that predate this session generation. */
    sessionDiffBaseline?: SessionDiffBaseline;
    /** Canonical existing directory owned by the user on a paired session host. */
    deviceFolder?: { deviceId: string; path: string };
    /**
     * Managed worktree bound to this session; set with spawnedCwd at worktree
     * creation and cleared together when a plain New Chat detaches the checkout.
     */
    worktree?: {
      id: string;
      branch: string;
      repoRoot: string;
      /** Durable skill workspace prepared when this session runs from a managed worktree. */
      canonicalWorkspaceDir?: string;
      githubPullRequest?: SessionGitHubPullRequestBinding;
    };
    /** Project registry id selected when this logical session node was created. */
    projectId?: string;
    /** Durable cloud repository owner; never identifies a Gateway filesystem path. */
    repositoryWorkspaceId?: string;
    /** Explicit parent session linkage for dashboard-created child sessions. */
    parentSessionKey?: string;
    /** Exact parent incarnation captured when this child was created. */
    parentSessionId?: string;
    /** Exact parent lifecycle captured for native spawn authority, including same-id resets. */
    parentSessionLifecycleRevision?: string;
    /** How this session node came to exist; written once and retained across sessionId rotations. */
    createdVia?: SessionCreatedVia;
    /** Creation-only presentation surface; stored in entry_json without a column projection. */
    createdSurface?: SessionRow["createdSurface"];
    /** Actor that caused node creation, with an optional profile, session, or sender id; written once. */
    createdActor?: SessionCreatedActor;
    /** Creation-only sandbox requirement; existing unstamped sessions always remain unstamped. */
    sandbox?: "required";
    /** Mutable responsibility, projected from SQLite; absent means createdActor owns the session. */
    owner?: SessionOwnerAssignment;
    /** Retained identities, projected from the participant table before display truncation. */
    participants?: SessionParticipant[];
    /** Raw retained identity count, including the owner, for admission-bound coverage. */
    participantCount?: number;
    /** Node creation time (ms); unlike sessionStartedAt, survives sessionId rotations. */
    createdAt?: number;
    /** Exact source generation and optional cut entry for an actual transcript-copy fork. */
    forkSource?: { sessionKey: string; sessionId: string; entryId?: string };
    /** Session id of the prior transcript generation under this same session key. */
    previousSessionId?: string;
    /** Thread parent-seeding settled marker; also set when seeding is deliberately skipped. */
    forkedFromParent?: boolean;
    /** Subagent spawn depth (0 = main, 1 = sub-agent, 2 = sub-sub-agent). */
    spawnDepth?: number;
    /** Explicit role assigned at spawn time for subagent tool policy/control decisions. */
    subagentRole?: "orchestrator" | "leaf";
    /** Explicit control scope assigned at spawn time for subagent control decisions. */
    subagentControlScope?: "children" | "none";
    /** Spawn-time blind child: its rendered prompt omits its model, identity and workspace path. */
    blindPrompt?: true;
    /** Version of the requester tool-policy snapshot captured when this child was spawned. */
    inheritedToolPolicyVersion?: 1;
    /** Sender/channel restriction provenance retained with the inherited tool snapshot. */
    inheritedToolPolicySource?: "sender";
    /** Session-scoped tool deny entries inherited from the caller that created this session. */
    inheritedToolDeny?: string[];
    /** Session-scoped tool allow entries inherited from the caller that created this session. */
    inheritedToolAllow?: string[];
    /** Host-created native execution exception; the full inherited snapshot still owns completion. */
    delegatedToolPolicy?: {
      requesterSessionKey: string;
      targetAgentId: string;
      deny: string[];
      /** The immediate parent’s effective deny snapshot, separately from revocation fallback. */
      requesterDeny: string[];
    };
    systemSent?: boolean;
    abortedLastRun?: boolean;
    /** Quota cascade protection and state-aware failover status. */
    quotaSuspension?: QuotaSuspension;
    /** Core-owned durable goal state for this thread/session. */
    goal?: SessionGoal;
    /** Timestamp (ms) when the current sessionId first became active. */
    sessionStartedAt?: number;
    /** Stable usage lineage key for transcript-backed rollups across sessionId rotations. */
    usageFamilyKey?: string;
    /** Session ids known to belong to this usage lineage, including archived predecessors. */
    usageFamilySessionIds?: string[];
    /** Timestamp (ms) of the last user/channel interaction that should extend idle lifetime. */
    lastInteractionAt?: number;
    /** Stable first-run start time for subagent sessions, persisted after completion. */
    startedAt?: number;
    /** Latest completed run end time for subagent sessions, persisted after completion. */
    endedAt?: number;
    /** Accumulated runtime across subagent follow-up runs, persisted after completion. */
    runtimeMs?: number;
    /** Final persisted subagent run status, used after in-memory run archival. */
    status?: PersistedSessionRunStatus;
    /** Compact user-facing reason for the latest failed or timed-out run. */
    lastRunError?: string;
    /** The latest failed run is diagnostic-only, not a request for the user to retry. */
    suppressErrorNotice?: boolean;
    /**
     * Session-level stop cutoff captured when /stop is received.
     * Messages at/before this boundary are skipped to avoid replaying
     * queued pre-stop backlog.
     */
    abortCutoffMessageSid?: string;
    /** Epoch ms cutoff paired with abortCutoffMessageSid when available. */
    abortCutoffTimestamp?: number;
    chatType?: SessionChatType;
    contextWindow?: string;
    thinkingLevel?: string;
    /**
     * Exact isolated-cron continuation policy. Only hidden `:run:` session rows
     * carry this while detached generated-media work may still wake the run.
     */
    cronRunContinuation?: {
      lifecycleRevision: string;
      phase: "running" | "ready" | "continuing";
      /** True only after this row's session changes were projected to the stable cron row. */
      basePersisted?: boolean;
      ownerRunId?: string;
      /** Gateway lifecycle generation that owns a continuing claim. */
      ownerLifecycleGeneration?: string;
      /** CLI backend whose native session must exist before media work detaches. */
      cliExecutionProvider?: string;
      toolsAllow?: string[];
      toolsAllowIsDefault?: boolean;
      /** Exact server-stamped authority provenance copied from the owning cron job. */
      scheduledToolPolicy?: CronScheduledToolPolicy;
      /** Restrict-only exec pin copied from the owning cron job's cap. */
      toolsAllowExecTarget?: CronToolsAllowExecTarget;
      /** Expected pin copied with the cap so detached continuation loss fails closed. */
      toolsAllowExecTargetRequirement?: CronToolsAllowExecTargetRequirement;
      /** Store-private origin paired with an account scheduled-tool policy. */
      scheduledToolCallerOrigin?: CronScheduledToolCallerOrigin;
      cliSessionBindingFacts?: {
        extraSystemPromptStatic?: string;
        sourceReplyDeliveryMode?: "automatic" | "message_tool_only";
        requireExplicitMessageTarget?: boolean;
      };
    };
    /** Explicit requested access program; omission follows the model/project default. */
    cyberAccessProgram?: SessionRow["cyberAccessProgram"];
    fastMode?: FastMode;
    toolOverrides?: SessionToolOverrides;
    /** Swarm group for collector-mode child sessions. */
    swarmGroupId?: string;
    /** Marks non-interactive collector-mode child sessions. */
    swarmCollector?: boolean;
    /** JSON Schema exposed through the synthetic structured_output tool. */
    swarmOutputSchema?: Record<string, unknown>;
    verboseLevel?: string;
    traceLevel?: string;
    reasoningLevel?: string;
    elevatedLevel?: string;
    ttsAuto?: TtsAutoMode;
    /** Hash of the latest assistant reply that was sent through `/tts latest`. */
    lastTtsReadLatestHash?: string;
    /** Timestamp (ms) when `/tts latest` last sent audio for this session. */
    lastTtsReadLatestAt?: number;
    execHost?: string;
    execNode?: string;
    /** Working directory interpreted only by the bound exec node. */
    execCwd?: string;
    responseUsage?: "on" | "off" | "tokens" | "full";
    providerOverride?: string;
    modelOverride?: string;
    /** Last submitted selection, retained when picker edits clear runtime fields. */
    lastSubmittedModel?: { provider: string; model: string };
    /** Session-scoped agent runtime/harness override selected with the model picker. */
    agentRuntimeOverride?: string;
    /**
     * Tracks whether the persisted model selection came from an explicit user
     * action (`/model`, `sessions.patch`), a temporary runtime fallback, or an
     * explicit configured-default selection that blocks parent inheritance.
     */
    modelOverrideSource?: "auto" | "user" | "default";
    /** Present only when providerOverride/modelOverride are a canonical route pair. */
    modelOverrideRouteResolution?: "resolved";
    /** Selected model that produced the current auto fallback override. */
    modelOverrideFallbackOriginProvider?: string;
    modelOverrideFallbackOriginModel?: string;
    /** One-run rollback guard for a model selected by the agent sessions tool. */
    modelFallback?: AgentPatchedSessionModelFallback;
    authProfileOverride?: string;
    authProfileOverrideSource?: "auto" | "user" | "user-link";
    authProfileOverrideCompactionCount?: number;
    /**
     * Set on explicit user-driven session model changes (for example `/model`
     * and `sessions.patch`) during an active run. The embedded runner checks
     * this flag to decide whether to throw `LiveSessionModelSwitchError`.
     * System-initiated fallbacks (rate-limit retry rotation) never set this
     * flag, so they are never mistaken for user-initiated switches.
     */
    liveModelSwitchPending?: boolean;
    groupActivation?: "mention" | "always";
    groupActivationNeedsSystemIntro?: boolean;
    sendPolicy?: "allow" | "deny";
    /** Human-selected peer messaging preferences; omitted directions inherit configuration. */
    communication?: SessionCommunicationPolicy;
    queueMode?: QueueMode;
    queueDebounceMs?: number;
    queueCap?: number;
    queueDrop?: "old" | "new" | "summarize";
    inputTokens?: number;
    outputTokens?: number;
    /** Completeness of the latest run's token and cost accounting. */
    usageReport?: { state: "available" | "unavailable" };
    totalTokens?: number;
    pendingFinalDelivery?: PendingFinalDeliveryState;
    pendingDeliveryNotice?: PendingDeliveryNoticeState;
    /**
     * Ordered durable backlog of delivered assistant finals that failed to
     * reach the canonical transcript. Session admission restores each item
     * before another turn can extend that transcript. Kept as a list so
     * independently admitted writers never overwrite an earlier reply.
     */
    pendingTranscriptRepair?: PendingTranscriptRepairState[];
    /**
     * Whether totalTokens reflects a fresh context snapshot for the latest run.
     * Undefined means legacy/unknown freshness; false forces consumers to treat
     * totalTokens as stale/unknown for context-utilization displays.
     */
    totalTokensFresh?: boolean;
    /** Version 2 includes the last response's completion and pending request additions. */
    totalTokensVersion?: 1 | typeof SESSION_TOTAL_TOKENS_VERSION;
    estimatedCostUsd?: number;
    cacheRead?: number;
    cacheWrite?: number;
    modelProvider?: string;
    model?: string;
    /**
     * Prevents OpenClaw model changes and automatic maintenance eviction until
     * the owning harness explicitly retires the session.
     */
    modelSelectionLocked?: boolean;
    /**
     * Embedded agent harness selected for this session id.
     * Prevents config/env changes from moving an existing transcript between
     * incompatible runtime harnesses.
     */
    agentHarnessId?: string;
    fallbackNotice?: FallbackNoticeState;
    contextTokens?: number;
    /** Origin of the persisted context window; `resolved` is legacy/unverified. */
    contextTokensSource?: "runtime" | "runtime-configured" | "resolved" | "resolved-v1";
    contextBudgetStatus?: SessionContextBudgetStatus;
    compactionCount?: number;
    /** A committed lossy compaction affected this history; cleared with a new session. */
    compactionQualityDegraded?: true;
    memoryFlush?: MemoryFlushState;
    cliSessionIds?: Record<string, string>;
    cliSessionBindings?: Record<string, CliSessionBinding>;
    /** Initialization fence for seeding canonical ACP metadata; cleared after creation. */
    acpSessionBinding?: AcpSessionBinding;
    claudeCliSessionId?: string;
    label?: string;
    /** Automatic device name; never claims a custom label or overrides a generated title. */
    autoLabel?: string;
    /** Persistent sidebar emoji, named glyph, or canonical SVG image data URL. */
    icon?: string;
    /** Named sidebar tint (SESSION_COLOR_IDS); palette mirrors Claude Code /color for import. */
    color?: string;
    /** User-defined organization bucket for session lists; unrelated to chat groupId/groupChannel. */
    category?: string;
    /** Preferred Control UI face when a caller opens this session without explicit face intent. */
    boardFace?: SessionBoardFace;
    /** Shared dashboard presentation default; absence uses the built-in split view. */
    boardPresentation?: NonNullable<SessionRow["boardPresentation"]>;
    displayName?: string;
    /** Canonical delivery state. Legacy delivery fields are migrated by `openclaw doctor --fix`. */
    delivery?: SessionDeliveryState;
    groupId?: string;
    subject?: string;
    /** Display-only topic name; subject remains the group name used for routing. */
    topicName?: string;
    groupChannel?: string;
    space?: string;
    /** Last ambient room message durably appended to this transcript, keyed by channel scope. */
    ambientTranscriptWatermarks?: Record<string, AmbientTranscriptWatermark>;
    skillsSnapshot?: SessionSkillSnapshot;
    /** Parent prompt preference persisted by spawn before the child can launch. */
    toolUsageRankingSeed?: import("../../agents/tool-usage-ranking.js").ToolUsageRankingSnapshot;
    /** Explicit authorized immutable library pins; current speakers never replace this selection. */
    skillLibrarySelections?: import("../../../packages/gateway-protocol/src/schema/skill-library.js").SkillLibrarySelection[];
    systemPromptReport?: SessionSystemPromptReport;
    /**
     * Generic plugin-owned runtime debug entries shown in verbose status surfaces.
     * Each plugin owns and may overwrite only its own entry between turns.
     */
    pluginDebugEntries?: SessionPluginDebugEntry[];
    acp?: SessionAcpMeta;
  };

export interface SessionEntry extends SessionEntryCore {}

/** Internal durable fields excluded from public/plugin session projections. */
export type SessionProfileInvolvement = {
  hidden: boolean;
  updatedAt: number;
  /** Original committed source ordering, retained when the person hides the session. */
  lastMention?: { generation: string; sequence: number; timestamp: number };
};

/**
 * The scheduled parent a cron `:run:` row's occurrence was admitted against: the
 * parent's exact incarnation and the occurrence's owner bit.
 */
export type SessionScheduledMemoryParent = {
  sessionKey: string;
  sessionId: string;
  /** Absent when the job's link recorded only the parent session id. */
  lifecycleRevision?: string;
  senderIsOwner: boolean;
};

export type InternalSessionEntryCore = SessionEntryCore & {
  /**
   * Written only by cron run preparation on a child-placement `:run:` row, so a
   * session the run spawns can resolve its memory audience through that parent.
   */
  scheduledMemoryParent?: SessionScheduledMemoryParent;
  /** Atomic history-cut receipt for the exact settled local projection, cleared after adoption. */
  localWorkspaceHandoff?: {
    worktreeId: string;
    fromSessionId: string;
    toSessionId: string;
    lifecycleRevision: string | null;
    projectionRevision: number;
  };
  /** Original unbound files, private to this conversation's adopted workspace. */
  priorWorkspace?: {
    worktreeId: string;
    sessionId: string;
    workspaceDir: string;
    fileRoot: string;
    through: { generation: string | null; maxSeq: number | null };
  };
  /** Personal discovery state, never participation, attribution, or sharing authority. */
  profileInvolvement?: { key: string; profiles: Record<string, SessionProfileInvolvement> };
  /** Transcript-wide account provenance; native binding replacement must not replace it. */
  cliHistoryBoundary?: import("./cli-history-boundary.js").CliHistoryBoundary;
  /** Explicit world-readable publication, bound to one transcript generation. */
  publicShare?: { id: string; sessionId: string; createdAt: number };
  /** Run that owns the current non-terminal Gateway lifecycle projection. */
  lifecycleRunId?: string;
  /** Restart resume scope the latest run started under; see session-restart-resume-scope. */
  lifecycleRestartScope?: string;
  /** Exact run that produced the latest terminal Gateway lifecycle projection. */
  lastRunId?: string;
  /** Run admitted by the session lane; overwritten at admission and checked by transcript writes. */
  activeWriterRunId?: string;
  /** Canonical remote repository awaiting preparation by this exact session generation. */
  pendingProjectGitUrl?: string;
  /** Authorized worktree intent awaiting preparation by an admitted turn. */
  pendingWorktree?: PendingSessionWorktree;
  /** Suppresses repeated byte-triggered compaction after an oversized successor was observed. */
  transcriptByteCompactionLatch?: {
    activeBytes: number;
    sessionId: string;
    maxBytes: number;
  };
  /** Private per-generation ownership for the pre-runtime checkout baseline capture. */
  sessionDiffBaselineCapture?: import("./session-diff-baseline-capture.js").SessionDiffBaselineCapture;
  /** Running root-session resume only; accepted queued input owns its own durable row. */
  resumeAfterRestart?: {
    /** A direct chat turn in a visible spawned session, not its original delegated run. */
    directChat?: true;
    /** Interrupted turn requester; revalidated before the replacement turn is admitted. */
    operatorSource?: QueuedOperatorRecoverySource;
    /** Restart resume scope of the Gateway that wrote the marker; see session-restart-resume-scope. */
    scope?: string;
  };
  /**
   * Latest authenticated source per person who sent input here, keyed by profile ID. Restored only
   * through current device, auth, profile and role revalidation; never an executable grant.
   */
  operatorSources?: Record<
    string,
    import("../../gateway/operator-run-recovery-source.codec.js").OperatorRunRecoverySnapshot
  >;
  /** Upgrade-only cycle; remove once stable includes the restart redesign (#185730). */
  mainRestartRecovery?: { cycleId: string };
};

export interface InternalSessionEntry extends InternalSessionEntryCore {}

export function isTerminalSessionStatus(status: unknown): status is PersistedSessionRunStatus {
  return (
    status === "done" ||
    status === "failed" ||
    status === "interrupted" ||
    status === "killed" ||
    status === "timeout"
  );
}

function isSessionPluginTraceLine(line: string): boolean {
  const trimmed = line.trim();
  return trimmed.startsWith("🔎 ") || /(?:^|\s)(?:Debug|Trace):/.test(trimmed);
}

function resolveSessionPluginLines(
  entry: Pick<SessionEntry, "pluginDebugEntries"> | undefined,
  includeLine: (line: string) => boolean,
): string[] {
  return Array.isArray(entry?.pluginDebugEntries)
    ? entry.pluginDebugEntries.flatMap((pluginEntry) =>
        Array.isArray(pluginEntry?.lines)
          ? pluginEntry.lines.filter(
              (line): line is string =>
                typeof line === "string" && line.trim().length > 0 && includeLine(line),
            )
          : [],
      )
    : [];
}

export function resolveSessionPluginStatusLines(
  entry: Pick<SessionEntry, "pluginDebugEntries"> | undefined,
): string[] {
  return resolveSessionPluginLines(entry, (line) => !isSessionPluginTraceLine(line));
}

export function resolveSessionPluginTraceLines(
  entry: Pick<SessionEntry, "pluginDebugEntries"> | undefined,
): string[] {
  return resolveSessionPluginLines(entry, isSessionPluginTraceLine);
}

export function normalizeSessionRuntimeModelFields(entry: SessionEntry): SessionEntry {
  const normalizedModel = normalizeOptionalString(entry.model);
  const normalizedProvider = normalizeOptionalString(entry.modelProvider);
  // A provider without a model is not durable runtime metadata.
  const modelProvider = normalizedModel ? normalizedProvider : undefined;
  if (entry.model === normalizedModel && entry.modelProvider === modelProvider) {
    return entry;
  }
  const next = { ...entry };
  if (normalizedModel) {
    next.model = normalizedModel;
  } else {
    delete next.model;
  }
  if (modelProvider) {
    next.modelProvider = modelProvider;
  } else if (!normalizedModel || entry.modelProvider !== undefined) {
    delete next.modelProvider;
  }
  return next;
}

export function setSessionRuntimeModel(
  entry: SessionEntry,
  runtime: { provider: string; model: string },
): boolean {
  const provider = runtime.provider.trim();
  const model = runtime.model.trim();
  if (!provider || !model) {
    return false;
  }
  entry.modelProvider = provider;
  entry.model = model;
  return true;
}

function resolveMergedUpdatedAt(
  existing: SessionEntry | undefined,
  patch: Partial<SessionEntry>,
  preserveActivity: boolean,
): number {
  const now = Date.now();
  const existingUpdatedAt = normalizeMergedUpdatedAt(existing?.updatedAt, now);
  const patchUpdatedAt = normalizeMergedUpdatedAt(patch.updatedAt, now);
  if (preserveActivity && existing) {
    return existingUpdatedAt ?? patchUpdatedAt ?? now;
  }
  return Math.max(existingUpdatedAt ?? 0, patchUpdatedAt ?? 0, now);
}

function normalizeMergedUpdatedAt(value: number | undefined, now: number): number | undefined {
  const normalized = asNonNegativeFiniteNumber(value);
  return normalized === undefined ? undefined : Math.min(normalized, now);
}

function mergeSessionEntryWithPolicy(
  existing: SessionEntry | undefined,
  patch: Partial<SessionEntry>,
  preserveActivity = false,
): SessionEntry {
  const sessionId = patch.sessionId ?? existing?.sessionId ?? crypto.randomUUID();
  const updatedAt = resolveMergedUpdatedAt(existing, patch, preserveActivity);
  if (!existing) {
    return stripRetiredSessionEntryLocators(
      normalizeSessionRuntimeModelFields({
        ...patch,
        sessionId,
        updatedAt,
        sessionStartedAt: patch.sessionStartedAt ?? updatedAt,
      }),
    );
  }
  const next = {
    ...existing,
    ...patch,
    sessionId,
    updatedAt,
    sessionStartedAt:
      patch.sessionStartedAt ??
      (existing.sessionId === sessionId ? existing.sessionStartedAt : updatedAt),
  };

  // Node creation and exact fork ancestry are write-once; sandbox policy cannot be added later.
  if (existing.createdVia !== undefined) {
    next.createdVia = existing.createdVia;
  }
  next.createdSurface = existing.createdSurface;
  if (existing.createdActor !== undefined) {
    next.createdActor = existing.createdActor;
  }
  next.inheritedGitContributorProfileIds = existing.inheritedGitContributorProfileIds;
  if (existing.sandbox === "required") {
    next.sandbox = existing.sandbox;
  } else {
    delete next.sandbox;
  }
  if (existing.createdAt !== undefined) {
    next.createdAt = existing.createdAt;
  }
  if (existing.projectId !== undefined) {
    next.projectId = existing.projectId;
  }
  if (existing.repositoryWorkspaceId !== undefined) {
    next.repositoryWorkspaceId = existing.repositoryWorkspaceId;
  }
  if (existing.forkSource !== undefined) {
    next.forkSource = existing.forkSource;
  }

  // Guard against stale provider carry-over when callers patch runtime model
  // without also patching runtime provider.
  if (Object.hasOwn(patch, "model") && !Object.hasOwn(patch, "modelProvider")) {
    const patchedModel = normalizeOptionalString(patch.model);
    const existingModel = normalizeOptionalString(existing.model);
    if (patchedModel && patchedModel !== existingModel) {
      delete next.modelProvider;
    }
  }
  return stripRetiredSessionEntryLocators(normalizeSessionRuntimeModelFields(next));
}

function stripRetiredSessionEntryLocators(entry: SessionEntry): SessionEntry {
  const mutable = entry as SessionEntry & { sessionFile?: unknown; transcriptPath?: unknown };
  delete mutable.sessionFile;
  delete mutable.transcriptPath;
  return entry;
}

export function mergeSessionEntry(
  existing: SessionEntry | undefined,
  patch: Partial<SessionEntry>,
): SessionEntry {
  return mergeSessionEntryWithPolicy(existing, patch);
}

export function mergeSessionEntryPreserveActivity(
  existing: SessionEntry | undefined,
  patch: Partial<SessionEntry>,
): SessionEntry {
  return mergeSessionEntryWithPolicy(existing, patch, true);
}

export function resolveSessionTotalTokens(entry?: Pick<SessionEntry, "totalTokens"> | null) {
  return asNonNegativeFiniteNumber(entry?.totalTokens);
}

export function resolveFreshSessionTotalTokens(
  entry?: Pick<SessionEntry, "totalTokens" | "totalTokensFresh" | "totalTokensVersion"> | null,
): number | undefined {
  const total = resolveSessionTotalTokens(entry);
  if (total === undefined) {
    return undefined;
  }
  if (
    entry?.totalTokensFresh !== true ||
    entry.totalTokensVersion !== SESSION_TOTAL_TOKENS_VERSION
  ) {
    return undefined;
  }
  return total;
}

export type GroupKeyResolution = {
  key: string;
  channel?: string;
  id?: string;
  chatType?: SessionChatType;
};

export type { SessionSkillPromptRef, SessionSkillSnapshot } from "./session-prompt-types.js";

export const DEFAULT_RESET_TRIGGERS = ["/new", "/reset"];
