/**
 * Stable storage-neutral session and transcript access API.
 *
 * Implementations are split by entry, lifecycle, reset, and transcript ownership.
 * Runtime callers import this barrel instead of storage-specific modules.
 */
export * from "./session-history.js";
export {
  listSessionTranscriptInstances,
  listSessionTranscriptArchivesReadOnly,
} from "./session-history-read.js";
export { readSessionPendingInputReceiptsInWorker as listSessionPendingInputReceipts } from "./session-pending-input-receipts.js";
export { recoverSessionTranscriptProjection } from "./session-transcript-projection-recovery.js";
export {
  bindSessionPendingInputSources,
  listSessionPendingInputs,
  readSessionPendingInput,
  readSessionSubmittedInput,
  stageSessionPendingInput,
  withSessionPendingInputPersistence,
  withSessionPendingInputRelocation,
  type SessionPendingInput,
  type SessionPendingInputPage,
  type SessionPendingInputReceipt,
} from "./session-accessor.pending-inputs.js";
export type {
  DeleteSessionEntryLifecycleParams,
  DeleteSessionEntryLifecycleResult,
  DeletedAgentSessionEntryPurgeParams,
  ExactSessionEntry,
  ForkSessionEntryFromParentTargetParams,
  ForkSessionEntryFromParentTargetResult,
  ForkSessionFromParentTranscriptParams,
  ForkSessionFromParentTranscriptResult,
  LatestTranscriptAssistantText,
  LogicalSessionAccessScope,
  ParentForkedSessionTranscript,
  ReplySessionInitializationCommitContext,
  ReplySessionInitializationCommitResult,
  ReplySessionInitializationSnapshot,
  ResetSessionEntryLifecycleParams,
  ResetSessionEntryLifecycleResult,
  ResolvedSessionEntryAccessTarget,
  ResolvedSessionEntryCandidateTarget,
  ResolvedSessionEntryUpdateContext,
  ResolvedSessionEntryUpdateResult,
  SessionAbortTargetContext,
  SessionAbortTargetCutoff,
  SessionAbortTargetIdentity,
  SessionAbortTargetResult,
  SessionAccessScope,
  SessionMessageCutMutationParams,
  SessionMessageCutMutationResult,
  SessionBranchListParams,
  SessionBranchListResult,
  SessionBranchSummary,
  SessionBranchSwitchMutationParams,
  SessionBranchSwitchMutationResult,
  SessionEntryCandidateAccessScope,
  SessionEntryCreateWithTranscriptContext,
  SessionEntryCreateWithTranscriptOptions,
  SessionEntryCreateWithTranscriptPrepareResult,
  SessionEntryCreateWithTranscriptResult,
  SessionEntryLifecycleMutationResult,
  SessionEntryLifecycleRemoval,
  SessionEntryLifecycleUpsert,
  SessionEntryListScope,
  SessionEntryPatchContext,
  SessionEntryPatchOptions,
  SessionEntryPatchResult,
  SessionEntryReadScope,
  SessionEntryReplacement,
  SessionEntryReplacementSnapshot,
  SessionEntryReplacementUpdate,
  SessionEntrySummary,
  SessionEntryTargetPatchScope,
  SessionEntryUpdateOptions,
  SessionLifecycleArchivedTranscript,
  SessionLifecycleArtifactCleanupParams,
  SessionLifecycleArtifactCleanupResult,
  SessionLifecycleStoreTarget,
  SessionParentForkDecision,
  SessionPatchProjectionContext,
  SessionPatchProjectionFailure,
  SessionPatchProjectionResult,
  SessionPatchProjectionSnapshot,
  SessionPatchProjectionTarget,
  SessionTranscriptAccessScope,
  SessionTranscriptEventRow,
  SessionTranscriptManualTrimPreflightResult,
  SessionTranscriptManualTrimResult,
  SessionTranscriptReadScope,
  SessionTranscriptReadTarget,
  SessionTranscriptRawDeltaLimits,
  SessionTranscriptRawDeltaResult,
  SessionTranscriptRuntimeScope,
  SessionTranscriptRuntimeTarget,
  SessionTranscriptStats,
  SessionTranscriptTurnMessageAppend,
  SessionTranscriptTurnPersistOptions,
  SessionTranscriptTurnPersistResult,
  SessionTranscriptTurnUpdateMode,
  SessionTranscriptTurnWriteContext,
  SessionTranscriptVisibleMessageDeltaLimits,
  SessionTranscriptVisibleMessageDeltaResult,
  SessionTranscriptVisibleMessageEventRow,
  SessionTranscriptWriteLockAccessorContext,
  SessionTranscriptWriteScope,
  TranscriptEvent,
  TranscriptMessageAppendOptions,
  TranscriptMessageAppendResult,
  TranscriptUpdatePayload,
} from "./session-accessor.types.js";
export { onSessionIdentityMutation } from "../../sessions/session-lifecycle-events.js";
export type {
  SessionIdentityMutation,
  SessionIdentityMutationListener,
  SessionIdentityMutationTarget,
} from "../../sessions/session-lifecycle-events.js";
export type {
  SessionTranscriptTurnExpectedState,
  SessionTranscriptTurnLifecyclePatch,
} from "./session-transcript-turn-lifecycle.types.js";
export type {
  TranscriptEntryAnchor,
  TranscriptTurnAdmission,
  TranscriptTurnBoundary,
} from "./transcript-entry-anchor.js";
export type {
  RecordInboundSessionMetaParams,
  UpdateSessionLastRouteParams,
} from "./runtime-types.js";
export {
  ensureSessionEntrySync,
  copySessionOwnedStateForCanonicalRepair,
  ensureTranscriptGenerationsForCanonicalRepair,
  listSessionGenerationIdsForCanonicalRepair,
  clearPluginOwnedSessionState,
  listSessionChildEntriesReadOnly,
  listSessionEntriesCore,
  listSessionEntriesReadOnly,
  rehomeSessionDeliveryReferencesForCanonicalRepair,
  rehomeSessionDeliveryReferencesForCanonicalRepairBatch,
  listSessionEntryKeysReadOnly,
  loadExactSessionEntry,
  loadExactSessionEntryCandidates,
  loadExactSessionEntryFromStoreReadOnly,
  loadExactSessionEntryReadOnly,
  loadSessionEntry,
  loadSessionEntryByIdReadOnly,
  loadSessionEntryReadOnly,
  patchSessionEntryCore,
  patchSessionEntryTarget,
  patchSessionEntryWithKey,
  prepareQualifiedSessionEntryTarget,
  readSessionUpdatedAtCore,
  replaceSessionEntry,
  replaceSessionEntrySync,
  resolveSessionEntryAccessTarget,
  resolveSessionEntryCandidateTarget,
  resolveSessionEntrySelection,
  updateResolvedSessionEntry,
  upsertSessionEntryCore,
  withSessionEntryReadOnlyScope,
} from "./session-accessor.entry.js";
export {
  readSessionIdentityEvidenceBatch,
  type SessionIdentityEvidenceResult,
} from "./session-accessor.sqlite-entry-availability.js";
export {
  loadSessionEntryReadOnlyInScope,
  updateSessionLastRouteInScope,
} from "./session-accessor.sqlite-entry.js";
export {
  createSessionEntryWithTranscript,
  forkSessionEntryFromParentTarget,
  forkSessionFromParentTranscript,
  markSessionAbortTarget,
  matchesSessionAbortTargetOwner,
  recordInboundSessionMeta,
  resolveSessionAbortTarget,
  resolveSessionParentForkDecision,
  updateSessionEntry,
  updateSessionLastRoute,
} from "./session-accessor.entry-mutation.js";
export { assignSessionOwner } from "./session-accessor.sqlite-owner.js";
export { updateSessionProfileInvolvementAsync } from "./session-involvement-store.js";
export { MAX_SESSION_PARTICIPANTS } from "./session-entry-provenance.js";
export type { RecordSessionParticipantResult } from "./session-accessor.sqlite-participants.native.js";
export { recordSessionParticipantInWorker as recordSessionParticipant } from "./session-sharing-store.async.js";
export { type SessionParticipantRecord } from "./session-accessor.sqlite-participant-projection.js";
export {
  listCanonicalSessionRepairFacts,
  loadCanonicalSessionRepairEntries,
  scanDoctorSessionEntriesStrict,
  scanDoctorSessionEntriesTolerant,
  type CanonicalSessionRepairFact,
} from "./session-accessor.sqlite-canonical-inventory.js";
export {
  applySessionEntryLifecycleMutation,
  applySessionEntryReplacements,
  applySessionPatchProjection,
  cleanupPluginHostSessionStore,
  cleanupSessionLifecycleArtifactsCore,
  deleteSessionEntryLifecycle,
  purgeDeletedAgentSessionEntries,
  resetSessionEntryLifecycle,
  rollbackAgentHarnessSessionEntryLifecycle,
  rollbackPluginOwnedSessionEntryLifecycle,
} from "./session-accessor.lifecycle.js";
export { listSessionBranches } from "./session-accessor.sqlite-branch-list.js";
export {
  forkSessionAtMessage,
  rewindSessionToMessage,
  switchSessionBranch,
} from "./session-accessor.sqlite-message-cut.js";
export {
  commitReplySessionInitialization,
  loadReplySessionInitializationSnapshot,
  SessionInitializationAgentScopeMismatchError,
} from "./session-accessor.reset.js";
export {
  appendTranscriptEvent,
  appendTranscriptMessage,
  appendTranscriptMessageSync,
  findTranscriptEvent,
  hasSessionTranscriptMessage,
  inspectTranscriptEventsSync,
  loadTranscriptEventRowsAfterSeqSync,
  loadTranscriptEvents,
  loadTranscriptEventsSync,
  loadTranscriptHeaderSync,
  persistCompactionBoundaryWithSessionEntryAsync,
  preflightSessionTranscriptForManualCompact,
  publishTranscriptUpdate,
  readLatestTranscriptAssistantText,
  readTranscriptEventAtSeqSync,
  readTranscriptIdentityByEventId,
  readTranscriptRawDelta,
  readTranscriptMutationAtSync,
  readTranscriptExportSnapshotReadOnlySync,
  readTranscriptStatsBatchReadOnlySync,
  readTranscriptStatsSync,
  validatePreparedAssistantAppendSync,
  replaceTranscriptSuffixEventsSync,
  rewriteTranscriptEventRowsExact,
  rewriteTranscriptMessageAtAnchor,
  rewriteAssistantTranscriptMessageForRun,
  resolveTranscriptSessionKeyBySessionId,
  resolveTranscriptSessionKeyBySessionIdAsync,
  trimSessionTranscriptForManualCompact,
  withTranscriptWriteLock,
  withTranscriptWriteSequence,
} from "./session-accessor.transcript.js";
export {
  appendTranscriptMessages,
  persistSessionTranscriptTurn,
} from "./session-accessor.transcript-turn.js";
export { readActiveTranscriptEntryAnchor } from "./session-accessor.sqlite-transcript-admitted-read.js";
export { validateSessionTranscriptContextAdmission } from "./session-accessor.sqlite-model-context.js";
export {
  isSessionTranscriptProjectionUnavailableError,
  readLatestSessionTranscriptMessageEvent,
  readRecentSessionTranscriptActiveEvents,
  readSessionTranscriptBoundedMessageTailPage,
  readRecentSessionTranscriptMessageEvents,
  readSessionTranscriptMessageEventPage,
  readSessionTranscriptMessageEvents,
  readSessionTranscriptVisibleMessageDeltaCore,
  SessionTranscriptProjectionUnavailableError,
  waitForSessionTranscriptProjection,
} from "./session-accessor.sqlite-active-events.js";
export type {
  SessionTranscriptBoundedMessageTailPage,
  SessionTranscriptMessageAnchorPage,
  SessionTranscriptMessageEvent,
  SessionTranscriptMessageEventPage,
} from "./session-accessor.sqlite-projection-read.js";
export type { SessionTranscriptWatermark } from "./session-accessor.sqlite-transcript-watermark-read.js";
export { readSessionTranscriptWatermark } from "./session-accessor.sqlite-transcript-watermark.js";
export {
  bindSessionTranscriptStoreScope,
  resolveSessionTranscriptDatabasePath,
  resolveSessionTranscriptReadTarget,
  resolveSessionTranscriptRuntimeTarget,
} from "./session-accessor.transcript-target.js";

export {
  appendSessionTranscriptReport,
  readLatestSessionTranscriptReport,
} from "./session-accessor.sqlite-transcript-reports.js";
export { listSessionParticipantsReadOnly } from "./session-accessor.sqlite-participant-read.js";
export { readSessionEntriesFromStoreInWorker } from "./session-entry-read-runtime.js";
