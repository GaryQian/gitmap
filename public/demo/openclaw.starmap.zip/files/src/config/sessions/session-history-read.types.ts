import type { AgentMessage } from "@openclaw/agent-core";
import type { UserTurnTranscriptAdmissionReceipt } from "../../sessions/user-turn-transcript.types.js";
import type { ConversationRecord } from "./conversation-registry.types.js";
import type {
  SessionTranscriptBoundedActiveContext,
  SessionTranscriptContextVersion,
  TranscriptEvent,
} from "./session-accessor.sqlite-contract.js";
import type {
  SessionTranscriptRuntimeTarget,
  SessionBranchSummary,
} from "./session-accessor.types.js";
import type { SessionTranscriptAnchorFacts } from "./session-transcript-anchor-read.types.js";
import type { SessionTranscriptWatermark } from "./session-transcript-context-version.types.js";
import type { InternalSessionEntry } from "./types.js";

export type { SessionTranscriptWatermark } from "./session-transcript-context-version.types.js";

export type SessionTitleFields = {
  firstUserMessage: string | null;
  lastMessagePreview: string | null;
};

export type SessionPreviewItem = {
  role: "user" | "assistant" | "tool" | "system" | "other";
  text: string;
};

export type SessionBranchSummarySnapshot = SessionTranscriptWatermark & {
  branches: SessionBranchSummary[];
  appendSafe?: boolean;
  source?: { sessionId: string; databaseIdentity: string };
};

export type SessionBranchSummaryReadResult =
  | ({ status: "ok" } & SessionBranchSummarySnapshot)
  | { status: "missing-session" | "failed" };

export type SessionModelContextLimits = {
  maxBytes: number;
  maxEvents: number;
  /** Model views may omit result bodies to retain earlier requests; evidence and forks stay strict. */
  toolResultOverflow?: "omit";
};

/** Compaction keeps the complete semantic window, independent of replay byte limits. */
export type SessionTranscriptContextSelection =
  | { maxBytes: number; maxEvents: number }
  | { compaction: true };

export type SessionTranscriptModelContext = {
  events: TranscriptEvent[];
  version?: SessionTranscriptContextVersion;
};

export type SessionTranscriptReadSnapshot = {
  events: TranscriptEvent[];
  eventJson?: string[];
  eventSeqs?: number[];
  version: SessionTranscriptContextVersion;
};

export type SessionTranscriptContextSnapshot = {
  messages: AgentMessage[];
  header: unknown;
  version?: SessionTranscriptContextVersion;
  seed?: {
    omittedCount: number;
    omittedNonSummary: boolean;
    retainedInputTokens: number;
    admittedUser?: AgentMessage;
    summary?: AgentMessage;
  };
};

/** Internal native-seed view; full-fidelity context reads remain unbounded. */
export type SessionContextSeedRequest = {
  maxBytes: number;
  tokenBudget: number;
  admittedKey?: string;
  beforeAdmittedUser: boolean;
};

export type SessionCompactionPreparation = {
  sessionTarget: SessionTranscriptRuntimeTarget;
  /** Gateway lifecycle and accounting retain the originally selected key. */
  entry: InternalSessionEntry | undefined;
  runtimeEntry: InternalSessionEntry | undefined;
  primaryConversation: ConversationRecord | undefined;
};

export type PreparedSessionTranscriptHydration =
  | {
      kind: "full";
      snapshot: SessionTranscriptReadSnapshot;
    }
  | {
      kind: "bounded";
      snapshot: SessionTranscriptBoundedActiveContext;
      transcript?: SessionTranscriptAnchorFacts;
      /** Byte and sequence facts for the actor's bounded context residency. */
      residentRows?: Array<{ rawSeq: number; serializedBytes: number }>;
      /** Compaction reads its session facts in the same snapshot as its bounded view. */
      compaction?: SessionCompactionPreparation;
    };

export type SessionPendingInputReceipt =
  | { runId: string; state: "pending"; cancelled?: true }
  | { runId: string; state: "consumed"; consumedByEventId: string };

export type SessionTranscriptEventMatch =
  | { kind: "latest" }
  | { kind: "custom-entry"; customType: string }
  | { kind: "canvas-widget"; docId: string }
  | { kind: "visible-final"; runId: string }
  | {
      kind: "idempotency";
      key: string;
      assistant?: boolean;
      runId?: string;
      deliveryMirror?: boolean;
    }
  | { kind: "active-assistant"; runId: string };

export type SessionTranscriptMatchCaller =
  | "background-result"
  | "internal-source-reply"
  | "committed-source-reply"
  | "subagent-final-answer"
  | "canvas-widget"
  | "public-session-widget";

/** Fixed-size attribution emitted only with an existing slow transaction hold. */
export type SessionTranscriptMatchDiagnostics = {
  caller?: SessionTranscriptMatchCaller;
  selector: SessionTranscriptEventMatch["kind"];
  outcome: "incomplete" | "hit" | "miss";
  rowsVisited: number;
  projectedRows: number;
  identityRows: number;
  coldRows: number;
};

export type SessionContextMessagesWorkerInput = {
  kind: "context-messages";
  target: SessionTranscriptRuntimeTarget;
  admission?: UserTurnTranscriptAdmissionReceipt;
  expectedIdentity?: import("../../infra/sqlite-worker-identity.js").DatabaseFileIdentity;
  seed?: SessionContextSeedRequest;
};
