import { AsyncLocalStorage } from "node:async_hooks";
import type { WorkspaceFilesystemEvidence } from "../../agents/workspace-state-guard.js";
import { throwSqliteLifecycleErrors } from "../../infra/sqlite-lifecycle-errors.js";
import { runWithAsyncStore } from "../../shared/async-store.js";
import type { SessionAdmissionTransition } from "./session-admission-transition.types.js";
import type { CapturedSessionEntryReadSource } from "./session-entry-read-source.types.js";
import type { SessionPendingInputAuthorityFacts } from "./session-pending-input-authority.js";
import type { SessionStoreReadCustody } from "./session-store-read-candidates.js";
import type { SessionTranscriptContextVersion } from "./session-transcript-context-version.types.js";
import type { InternalSessionEntry as SessionEntry } from "./types.js";

export type SessionSourceConversationPredicate = {
  conversationRef: string;
  sessionKey: string | null;
};

/** Same-store facts are compared on the writer; published foreign sources may admit once. */
export type SessionSourcePredicate = {
  source: CapturedSessionEntryReadSource;
  sessionKey: string;
  fields: (keyof SessionEntry)[];
  expected: Partial<SessionEntry> | undefined;
  members?: readonly string[];
  transcript?: { sessionId: string; version: SessionTranscriptContextVersion };
  conversationAlternatives?: readonly (readonly SessionSourceConversationPredicate[])[];
};

export type SessionSourcePredicateFacts = {
  entry: SessionEntry | undefined;
  members?: readonly string[];
};

const publishedSourceAdmissions = new WeakMap<SessionSourcePredicate, () => void>();

/** Bind the existing owner's live publication without copying authority into another cache. */
export function bindPublishedSessionSourceAdmission(
  predicate: SessionSourcePredicate,
  admit: () => void,
): void {
  publishedSourceAdmissions.set(predicate, admit);
}

/** Each durable operation admits anew; later disclosure and execution keep their live checks. */
export function admitPublishedSessionSource(predicate: SessionSourcePredicate): boolean {
  const admit = publishedSourceAdmissions.get(predicate);
  if (!admit) {
    return false;
  }
  admit();
  return true;
}

/** Current source facts supplied by the mutation's own transaction. */
export type SessionSourceTransactionGrant = {
  source: CapturedSessionEntryReadSource;
  agentId: string;
  sessionKey: string;
  assertCurrent: (facts: SessionPendingInputAuthorityFacts) => void;
};

export type SessionSourceWriteGrant = {
  assertCurrent: () => void;
  assertLifetimeCurrent: () => void;
  release: () => void | Promise<void>;
  transaction?: SessionSourceTransactionGrant;
};

export type SessionSourceValidation = {
  refusedSource?: { index: number; facts: SessionSourcePredicateFacts };
  conversationMatches: Array<{
    index: number;
    alternatives: number[];
    acceptedAlternatives?: number[];
  }>;
};

export type PreparedSessionSourceAuthority = {
  readCustody?: readonly SessionStoreReadCustody[];
  /** Original workspace targets, observed by the effect owner before its live grant. */
  workspaceEvidence?: readonly WorkspaceFilesystemEvidence[];
  transaction?: SessionSourceTransactionGrant;
  /** Process-held sources require native atomicity when writing a durable target. */
  nativeSource?: boolean;
  /** Released SDK callbacks can perform arbitrary synchronous SQLite reads. */
  opaqueCommitGuard?: boolean;
  /** Wrapper checks need a native transaction unless the caller owns a prepared commit hook. */
  hasOpaqueCheck?: boolean;
  assertCurrent: () => void;
  /** Prepared components only; the owning commit boundary must also run opaque checks. */
  assertPreparedCurrent?: () => void;
  checks: {
    predicate: SessionSourcePredicate;
    refuse: (facts: SessionSourcePredicateFacts) => never;
    /** The returned array is filled by the next host assertion. */
    acceptConversationMatches?: (alternatives: readonly number[]) => number[];
  }[];
  release?: () => void | Promise<void>;
  scopedSources?: ReadonlyMap<SessionSourceAssertion, PreparedSessionSourceAuthority>;
};

export type PreparedSessionSourceEffect = {
  readCustody?: readonly SessionStoreReadCustody[];
  workspaceEvidence?: readonly WorkspaceFilesystemEvidence[];
  assertCurrent: () => void;
  release?: () => void | Promise<void>;
  scopedSources?: ReadonlyMap<SessionSourceAssertion, PreparedSessionSourceEffect>;
};

export type SessionSourceAssertion = (() => void) & {
  nativeSource?: boolean;
  opaqueCommitGuard?: boolean;
  /** Host commit notification only; never a substitute for the normal source checks. */
  onSessionCompactionCommitted?: (
    transition: SessionAdmissionTransition,
    entry: SessionEntry,
  ) => void;
  /** Keep the source owner alive through accepted work that outlasts its request. */
  retain?: () => () => void;
  /** Checks the scope owner without invoking storage-dependent source predicates. */
  assertScopeCurrent?: () => void;
  prepareSessionSource?: () => Promise<PreparedSessionSourceAuthority>;
  prepareSessionSourceScope?: () => Promise<PreparedSessionSourceAuthority | undefined>;
  /** Prepare one external effect; legacy callbacks retain their synchronous final check. */
  prepareSessionSourceEffect?: () => Promise<PreparedSessionSourceEffect>;
  /** Preserve database custody at file effects without rechecking admitted tool policy. */
  prepareSessionSourceStorageEffect?: () => Promise<PreparedSessionSourceEffect>;
};

/** Sources supplied to worker mutation APIs must own asynchronous predicate preparation. */
export type PreparedSessionSourceAssertion = SessionSourceAssertion & {
  prepareSessionSource: () => Promise<PreparedSessionSourceAuthority>;
};

/** Public boolean callbacks stay callable; bundled owners also carry their prepared writer source. */
export type SessionSourceCheck = (() => boolean) & { sessionSource?: SessionSourceAssertion };

/** Async effect checks also expose worker predicates and a storage-free host assertion. */
export type AsyncSessionSourceCheck = (() => Promise<boolean>) & {
  sessionSource: PreparedSessionSourceAssertion & { assertScopeCurrent: () => void };
};

export function sessionEntryCommitGuardOptions(source: SessionSourceAssertion | undefined) {
  return source?.nativeSource ? { assertCommitAllowed: source } : { workerGuard: { source } };
}

/** Install transaction facts before composed host assertions recheck their live alternatives. */
export function acceptSessionSourceValidation(
  source: PreparedSessionSourceAuthority,
  validation: SessionSourceValidation | undefined,
): void {
  const refused = validation?.refusedSource;
  if (refused) {
    source.checks[refused.index]?.refuse(refused.facts);
    throw new Error("Session source refusal omitted its prepared assertion");
  }
  for (const [index, check] of source.checks.entries()) {
    if (!check.acceptConversationMatches) {
      continue;
    }
    const matched = validation?.conversationMatches.find((entry) => entry.index === index);
    if (
      !matched ||
      matched.alternatives.some(
        (alternative) =>
          !Number.isSafeInteger(alternative) ||
          alternative < 0 ||
          alternative >= (check.predicate.conversationAlternatives?.length ?? 0),
      )
    ) {
      throw new Error("Session source validation omitted its matching alternatives");
    }
    matched.acceptedAlternatives = check.acceptConversationMatches(matched.alternatives);
  }
}

const sessionSourceScopes = new AsyncLocalStorage<
  ReadonlyMap<SessionSourceAssertion, Pick<PreparedSessionSourceAuthority, "assertCurrent">>
>();

const synchronousSources = new WeakSet<SessionSourceAssertion>();
// Compositions own their dispatch; nesting must not enter the same guard twice.
const composedSources = new WeakSet<SessionSourceAssertion>();
let validatedSources: Map<SessionSourceAssertion, object> | undefined;

/** Host-owned immutable bindings only; opaque callbacks must never acquire this contract. */
export function bindSynchronousSessionSource(assertion: SessionSourceAssertion): void {
  synchronousSources.add(assertion);
}

/** Prepared consumers share validation only until this synchronous call returns. */
export function withSessionSourceValidation<T>(run: () => T): T {
  const previous = validatedSources;
  validatedSources = new Map();
  try {
    return run();
  } finally {
    previous?.clear();
    validatedSources = previous;
  }
}

function assertSessionSource(assertion: SessionSourceAssertion, run = assertion): void {
  if (!synchronousSources.has(assertion)) {
    const previous = validatedSources;
    previous?.clear();
    validatedSources = undefined;
    try {
      run();
    } finally {
      previous?.clear();
      validatedSources = previous;
    }
    return;
  }
  const validate = () => {
    // The issued closure captures the exact instance/generation/claim. A prepared
    // scope is a different binding; neither copies nor another wrapper share it.
    const key = sessionSourceScopes.getStore()?.get(assertion) ?? assertion;
    if (validatedSources!.get(assertion) !== key) {
      run();
      validatedSources!.set(assertion, key);
    }
  };
  if (validatedSources) {
    validate();
  } else {
    withSessionSourceValidation(validate);
  }
}

/** Bind prepared facts for indirect source reads made by the final effect assertion. */
export async function prepareSessionSourceEffect(
  assertion: SessionSourceAssertion,
): Promise<PreparedSessionSourceEffect> {
  const prepared = assertion.prepareSessionSourceEffect
    ? await assertion.prepareSessionSourceEffect()
    : { assertCurrent: assertion };
  const scopes = new Map([
    ...(sessionSourceScopes.getStore() ?? []),
    ...(prepared.scopedSources ?? []),
  ]);
  scopes.set(assertion, prepared);
  let active = true;
  return {
    workspaceEvidence: prepared.workspaceEvidence,
    readCustody: prepared.readCustody,
    assertCurrent: () => {
      if (!active) {
        throw new Error("Session source effect authority is released");
      }
      runWithAsyncStore(sessionSourceScopes, scopes, prepared.assertCurrent);
    },
    release: async () => {
      if (active) {
        active = false;
        await prepared.release?.();
      }
    },
  };
}

/** Classify request/SDK callbacks before adapters compose them with prepared internal authority. */
export function captureExternalSessionCommitGuard(guard: SessionSourceAssertion | undefined) {
  return guard && !guard.prepareSessionSource
    ? Object.assign(() => guard(), {
        nativeSource: true,
        opaqueCommitGuard: true,
        prepareSessionSourceStorageEffect: guard.prepareSessionSourceStorageEffect?.bind(guard),
      })
    : guard;
}

export async function releaseSessionSourceAuthorities(
  sources: readonly Pick<PreparedSessionSourceAuthority, "release">[],
  priorErrors: readonly unknown[] = [],
): Promise<void> {
  const errors: unknown[] = [...priorErrors];
  for (const source of sources.toReversed()) {
    try {
      await source.release?.();
    } catch (error) {
      errors.push(error);
    }
  }
  throwSqliteLifecycleErrors(errors, "Session source cleanup failed");
}

export async function prepareSessionSourceAuthority(
  assertion: SessionSourceAssertion | undefined,
): Promise<PreparedSessionSourceAuthority> {
  return assertion?.prepareSessionSource
    ? assertion.prepareSessionSource()
    : {
        assertCurrent: () => assertion?.(),
        checks: [],
        nativeSource: assertion?.nativeSource,
        opaqueCommitGuard: assertion?.opaqueCommitGuard,
      };
}

/** Bootstrap grants consume prepared liveness, never opaque or native source reads. */
export function assertPreparedSessionSourceCurrent(source: PreparedSessionSourceAuthority): void {
  if (source.assertPreparedCurrent) {
    source.assertPreparedCurrent();
  } else if (!source.nativeSource) {
    source.assertCurrent();
  }
}

export async function prepareSessionSourceScope(
  assertion: SessionSourceAssertion | undefined,
): Promise<PreparedSessionSourceAuthority | undefined> {
  return assertion?.prepareSessionSourceScope?.();
}

/** A fence owns its live source predicates until all work inside that scope settles. */
export async function runWithSessionSourceScope<T>(
  assertion: SessionSourceAssertion | undefined,
  run: () => Promise<T>,
  options: { checkAfter?: boolean } = {},
): Promise<T> {
  const prepared = assertion?.prepareSessionSourceScope
    ? await prepareSessionSourceScope(assertion)
    : undefined;
  if (!assertion || !prepared) {
    assertion?.assertScopeCurrent?.();
    const result = await run();
    if (options.checkAfter !== false) {
      assertion?.assertScopeCurrent?.();
    }
    return result;
  }
  const scopes = new Map([
    ...(sessionSourceScopes.getStore() ?? []),
    ...(prepared.scopedSources ?? []),
  ]);
  scopes.set(assertion, prepared);
  const errors: unknown[] = [];
  try {
    return await runWithAsyncStore(sessionSourceScopes, scopes, async () => {
      (prepared.assertPreparedCurrent ?? prepared.assertCurrent)();
      const result = await run();
      if (options.checkAfter !== false) {
        (prepared.assertPreparedCurrent ?? prepared.assertCurrent)();
      }
      return result;
    });
  } catch (error) {
    errors.push(error);
    throw error;
  } finally {
    await releaseSessionSourceAuthorities([prepared], errors);
  }
}

/** A live selector may advance between operations, never during one prepared write. */
export function createDynamicSessionSourceAssertion(
  select: () => SessionSourceAssertion | undefined,
  refuse: () => never,
): PreparedSessionSourceAssertion {
  const prepareSelected = <T>(
    prepare: (assertion: ReturnType<typeof composeSessionSourceAssertion>) => Promise<T>,
  ) => {
    const selected = select();
    return prepare(
      composeSessionSourceAssertion([selected], (assertSource) => {
        if (select() !== selected) {
          refuse();
        }
        assertSource();
      }),
    );
  };
  const assertion: PreparedSessionSourceAssertion = Object.assign(
    () => {
      const scoped = sessionSourceScopes.getStore()?.get(assertion);
      return scoped ? scoped.assertCurrent() : select()?.();
    },
    {
      onSessionCompactionCommitted: (transition: SessionAdmissionTransition, entry: SessionEntry) =>
        select()?.onSessionCompactionCommitted?.(transition, entry),
      prepareSessionSource: () => prepareSelected(prepareSessionSourceAuthority),
      prepareSessionSourceScope: () => prepareSelected(prepareSessionSourceScope),
      prepareSessionSourceEffect: () =>
        prepareSelected((source) => source.prepareSessionSourceEffect()),
      prepareSessionSourceStorageEffect: async () => {
        const selected = select();
        const prepared = await composeSessionSourceAssertion([
          selected,
        ]).prepareSessionSourceStorageEffect();
        return {
          assertCurrent: () => {
            if (select() !== selected) {
              refuse();
            }
            prepared.assertCurrent();
          },
          release: prepared.release,
        };
      },
    },
  );
  return Object.defineProperty(assertion, "nativeSource", {
    enumerable: true,
    get: () => select()?.nativeSource,
  });
}

const forwardSessionSources = (assertSources: () => void) => assertSources();

/** Preserve each owner's error/lifetime wrapper while preparing its storage-dependent sources. */
export function composeSessionSourceAssertion(
  sources: readonly (SessionSourceAssertion | undefined)[],
  check: (assertSources: () => void) => void = forwardSessionSources,
  options?: {
    preparedCheck?: (assertSources: () => void) => void;
    hasOpaqueCheck?: boolean;
    /** This wrapper only validates its captured binding; it invokes opaque work through sources. */
    synchronousCheck?: true;
  },
): PreparedSessionSourceAssertion & {
  prepareSessionSourceEffect: () => Promise<PreparedSessionSourceEffect>;
  prepareSessionSourceStorageEffect: () => Promise<PreparedSessionSourceEffect>;
} {
  function prepare(scoped: true): Promise<PreparedSessionSourceAuthority | undefined>;
  function prepare(scoped?: false): Promise<PreparedSessionSourceAuthority>;
  async function prepare(scoped = false): Promise<PreparedSessionSourceAuthority | undefined> {
    const prepared: PreparedSessionSourceAuthority[] = [];
    const scopedSources = scoped
      ? new Map<SessionSourceAssertion, PreparedSessionSourceAuthority>()
      : undefined;
    const release = () => releaseSessionSourceAuthorities(prepared);
    const assertCurrentSources = () => {
      for (const source of prepared) {
        source.assertCurrent();
      }
    };
    const assertPreparedSources = () => {
      for (const source of prepared) {
        assertPreparedSessionSourceCurrent(source);
      }
    };
    try {
      for (const source of sources) {
        const value = scoped
          ? await prepareSessionSourceScope(source)
          : await prepareSessionSourceAuthority(source);
        if (scopedSources && value && source) {
          for (const [assertion, nested] of value.scopedSources ?? []) {
            scopedSources.set(assertion, nested);
          }
          scopedSources.set(source, value);
        }
        prepared.push(
          value ?? {
            assertCurrent: () => source?.(),
            ...(scoped ? { assertPreparedCurrent: () => source?.assertScopeCurrent?.() } : {}),
            checks: [],
            nativeSource: source?.nativeSource,
            opaqueCommitGuard: source?.opaqueCommitGuard,
          },
        );
      }
      if (scopedSources?.size === 0) {
        return undefined;
      }
      return {
        workspaceEvidence: prepared.flatMap((source) => source.workspaceEvidence ?? []),
        readCustody: prepared.flatMap((source) => source.readCustody ?? []),
        nativeSource: prepared.some((source) => source.nativeSource),
        opaqueCommitGuard: prepared.some((source) => source.opaqueCommitGuard),
        hasOpaqueCheck: options?.hasOpaqueCheck || prepared.some((source) => source.hasOpaqueCheck),
        assertCurrent: () => check(assertCurrentSources),
        assertPreparedCurrent: () => (options?.preparedCheck ?? check)(assertPreparedSources),
        ...(scoped ? { scopedSources } : {}),
        checks: prepared.flatMap((source, index) =>
          source.checks.length === 0
            ? source.checks
            : source.checks.map(({ refuse, ...preparedCheck }) => ({
                ...preparedCheck,
                refuse: (facts) => {
                  check(() => {
                    prepared.slice(0, index).forEach((previous) => previous.assertCurrent());
                    refuse(facts);
                  });
                  throw new Error("Source authority refusal was suppressed");
                },
              })),
        ),
        release,
      };
    } catch (error) {
      let failure = error;
      try {
        (scoped ? (options?.preparedCheck ?? check) : check)(() => {
          if (scoped) {
            assertPreparedSources();
          } else {
            assertCurrentSources();
          }
          throw error;
        });
      } catch (translatedError) {
        failure = translatedError;
      }
      await releaseSessionSourceAuthorities(prepared, [failure]);
      throw failure;
    }
  }
  const assertSources = () => {
    for (const source of sources) {
      if (source) {
        if (composedSources.has(source)) {
          source();
        } else {
          assertSessionSource(source);
        }
      }
    }
  };
  const prepareEffect = async (): Promise<PreparedSessionSourceEffect> => {
    const prepared: PreparedSessionSourceEffect[] = [];
    const scopedSources = new Map<SessionSourceAssertion, PreparedSessionSourceEffect>();
    try {
      for (const source of sources) {
        if (!source) {
          continue;
        }
        const value = source.prepareSessionSourceEffect
          ? await source.prepareSessionSourceEffect()
          : { assertCurrent: source };
        prepared.push(value);
        for (const [nested, authority] of value.scopedSources ?? []) {
          scopedSources.set(nested, authority);
        }
        // A legacy composed assertion must not resolve itself recursively through the scope.
        if (source.prepareSessionSourceEffect) {
          scopedSources.set(source, value);
        }
      }
      return {
        workspaceEvidence: prepared.flatMap((source) => source.workspaceEvidence ?? []),
        readCustody: prepared.flatMap((source) => source.readCustody ?? []),
        assertCurrent: () =>
          check(() => {
            for (const source of prepared) {
              source.assertCurrent();
            }
          }),
        scopedSources,
        release: () => releaseSessionSourceAuthorities(prepared),
      };
    } catch (error) {
      let failure = error;
      try {
        check(() => {
          throw error;
        });
      } catch (translated) {
        failure = translated;
      }
      await releaseSessionSourceAuthorities(prepared, [failure]);
      throw failure;
    }
  };
  const synchronous = sources.every((source) => !source || synchronousSources.has(source));
  const forward = check === forwardSessionSources && synchronous;
  const run = () => {
    const scoped = sessionSourceScopes.getStore()?.get(assertion);
    return scoped ? scoped.assertCurrent() : check(assertSources);
  };
  const assertion: PreparedSessionSourceAssertion & {
    prepareSessionSourceEffect: () => Promise<PreparedSessionSourceEffect>;
    prepareSessionSourceStorageEffect: () => Promise<PreparedSessionSourceEffect>;
  } = Object.assign(
    () => (forward && validatedSources ? run() : assertSessionSource(assertion, run)),
    {
      onSessionCompactionCommitted: (
        transition: SessionAdmissionTransition,
        entry: SessionEntry,
      ) => {
        for (const source of new Set(sources)) {
          source?.onSessionCompactionCommitted?.(transition, entry);
        }
      },
      prepareSessionSource: () => prepare(),
      prepareSessionSourceScope: () => prepare(true),
      prepareSessionSourceEffect: prepareEffect,
      prepareSessionSourceStorageEffect: async () => {
        const prepared: PreparedSessionSourceEffect[] = [];
        try {
          for (const source of sources) {
            if (source?.prepareSessionSourceStorageEffect) {
              prepared.push(await source.prepareSessionSourceStorageEffect());
            }
          }
          return {
            assertCurrent: () => {
              for (const source of prepared) {
                source.assertCurrent();
              }
            },
            release: () => releaseSessionSourceAuthorities(prepared),
          };
        } catch (error) {
          await releaseSessionSourceAuthorities(prepared, [error]);
          throw error;
        }
      },
    },
  );
  composedSources.add(assertion);
  if ((options?.synchronousCheck || check === forwardSessionSources) && synchronous) {
    bindSynchronousSessionSource(assertion);
  }
  if (sources.some((source) => source?.retain)) {
    Object.assign(assertion, {
      retain: () => {
        using acquired = new DisposableStack();
        for (const source of sources) {
          const release = source?.retain?.();
          if (release) {
            acquired.defer(release);
          }
        }
        const retained = acquired.move();
        return () => retained.dispose();
      },
    });
  }
  return Object.defineProperty(assertion, "nativeSource", {
    enumerable: true,
    get: () => sources.some((source) => source?.nativeSource),
  });
}
