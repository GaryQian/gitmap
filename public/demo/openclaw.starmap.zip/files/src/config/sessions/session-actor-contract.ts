import type { PersistedUserTurnMessage } from "../../sessions/user-turn-input.types.js";
import type { SessionActivitySummary } from "./activity-summary.js";
import type { ConversationPublication } from "./session-accessor.sqlite-conversation-publication.js";
import type { SessionActorTranscriptRow } from "./session-actor-bounded-history.js";
import type { SessionActorDeliveryEvidence } from "./session-actor-delivery-evidence.types.js";
import type {
  SessionActorAuthority,
  SessionActorAuthorityFacts,
  SessionActorTarget,
  SessionActorVersion,
  SessionActorLifetime,
  SessionActorHotState,
} from "./session-actor-state.types.js";
import type {
  SessionActorStorageAuthority,
  SessionActorStorageOutcome,
  SessionActorStorageReads,
  SessionActorStorageWrites,
} from "./session-actor-storage-contract.js";
import type { SessionEntryMetadataReceipt } from "./session-entry-metadata-receipt.js";
import type { SessionEntryBookkeepingReducer } from "./session-entry-patch-operation.js";
import type {
  InitialSessionEntryCommit,
  SessionMetadataOperations,
} from "./session-manager-write-contract.js";
import type { PendingFinalDeliverySettlementInput } from "./session-pending-final-settlement.js";
import type {
  PendingInputMutation,
  PendingInputMutationReceipt,
  PendingInputSnapshot,
} from "./session-pending-input-operations.types.js";
import type { SessionPendingInputWorkerReceipt } from "./session-pending-input.types.js";
import type { SessionSourcePredicate } from "./session-source-authority.js";
import type { SessionTranscriptAuthorityReceipt } from "./session-transcript-authority.types.js";
import type { SessionTranscriptContextVersion } from "./session-transcript-context-version.types.js";
import type { SessionMessageRewriteCommitted } from "./session-transcript-mutation.types.js";
import type {
  SessionTranscriptTurnExpectedState,
  SessionTranscriptTurnLifecyclePatch,
} from "./session-transcript-turn-lifecycle.types.js";
import type { SessionTurnCommitted, SessionTurnPlan } from "./session-turn.types.js";
import type { AgentToolUsageAppend } from "./tool-usage.types.js";
import type { TranscriptEntryAnchor } from "./transcript-entry-anchor.js";
import type { InternalSessionEntry as SessionEntry } from "./types.js";

export type {
  SessionActorAuthority,
  SessionActorAuthorityFacts,
  SessionActorTarget,
  SessionActorVersion,
  SessionActorLifetime,
  SessionActorHotState,
  SessionActorSettlement,
} from "./session-actor-state.types.js";

export type { SessionActorDeliveryEvidence } from "./session-actor-delivery-evidence.types.js";

/** Serializable, pure bookkeeping. These reducers cannot change session identity or authority. */
export type SessionActorReducer = SessionEntryBookkeepingReducer;

export type SessionActorCommandContext = {
  commandId: string;
  phaseId: string;
  /** Omit to adopt the current preimage inside this command, without a preceding read. */
  expected?: SessionActorVersion;
  reducers?: readonly SessionActorReducer[];
};

/** Reuse SessionManager's prepared bytes, envelope, view limits, and admission predicates. */
export type SessionActorAppend = (
  | {
      kind: "metadata";
      input: SessionMetadataOperations["session.metadata.append"]["input"];
    }
  | {
      kind: "message";
      input: SessionMetadataOperations["session.transcript.appendMessage"]["input"];
    }
) & {
  /** First-writer ownership is verified live; a run ID alone never grants it. */
  initialization?: SessionMetadataOperations["session.metadata.initialize"]["input"];
  /** Optional prepared session header, committed atomically before this append. */
  header?: SessionMetadataOperations["session.metadata.append"]["input"];
  /** Final prompt text joins its runtime-context carrier at the same durable point. */
  modelPromptProjection?: { anchor: TranscriptEntryAnchor; text: string };
  /** Tool-only mutations share this append's transaction and final authority grant. */
  toolUsage?: AgentToolUsageAppend;
};

/** The original snapshot preserves canonical adopted IDs, parents, bytes, and versions. */
export type SessionActorAppendCommitted = (
  | {
      kind: "metadata";
      value: SessionMetadataOperations["session.metadata.append"]["output"];
    }
  | {
      kind: "message";
      value: SessionMetadataOperations["session.transcript.appendMessage"]["output"];
    }
) & {
  initialEntry?: InitialSessionEntryCommit;
  toolUsageGeneration?: number;
  header?: SessionMetadataOperations["session.metadata.append"]["output"];
  modelPromptProjection?: {
    result: NonNullable<SessionMessageRewriteCommitted["result"]> & {
      message: PersistedUserTurnMessage;
    };
    before: SessionTranscriptContextVersion;
    after: SessionTranscriptContextVersion;
    rows: SessionActorTranscriptRow[];
  };
};

export type SessionActorPendingFinalDelivery = NonNullable<SessionEntry["pendingFinalDelivery"]> & {
  intentId: string;
  deliveries: NonNullable<NonNullable<SessionEntry["pendingFinalDelivery"]>["deliveries"]>;
};

/** Input turns can select current lifecycle inside the owner; other mutations need a guard. */
type SessionActorInputTurn =
  | { turn: SessionTurnPlan; expectedState?: SessionTranscriptTurnExpectedState }
  | { turn?: never; expectedState: SessionTranscriptTurnExpectedState };

export type SessionActorPhaseInputs = {
  acceptInput: {
    lifecycle: SessionTranscriptTurnLifecyclePatch;
  } & SessionActorInputTurn &
    (
      | {
          pending: Extract<PendingInputMutation, { kind: "stage" }>;
          /** A retry adopts canonical pending/transcript identity instead of appending twice. */
          append?: SessionActorAppend;
        }
      | {
          /** Transcript custody before ACK does not require a queued-input row. */
          pending?: never;
          turn: SessionTurnPlan;
          append?: never;
        }
    );
  adoptRun: {
    sessionId: string;
    lifecycle: SessionTranscriptTurnLifecyclePatch;
    /** Explicit writer adoption; omission preserves the existing lifecycle-only command. */
    runId?: string;
  } & SessionActorInputTurn;
  appendToolResult:
    | { turn: SessionTurnPlan; append?: never }
    | { append: SessionActorAppend; turn?: never };
  appendTranscriptEvent:
    | {
        sessionId: string;
        lifecycleRevision: string | null;
        writerRunId?: string;
        ownerSources?: SessionSourcePredicate[];
        eventJson: string;
        append?: never;
      }
    | { append: SessionActorAppend; eventJson?: never };
  completeTurn: (
    | { turn: SessionTurnPlan; bookkeeping?: never }
    | {
        turn?: never;
        /** The assistant transcript is already durable; this command must not append it again. */
        bookkeeping: {
          sessionId: string;
          lifecycleRevision: string | null;
          writerRunId: string | undefined;
          expectedState: SessionTranscriptTurnExpectedState;
          lifecycle?: SessionTranscriptTurnLifecyclePatch;
        };
      }
  ) & {
    completion?: Extract<PendingInputMutation, { kind: "complete" }>;
    /** Exact delivery intent and payload IDs join terminal accounting in this commit. */
    pendingFinalDelivery?: SessionActorPendingFinalDelivery;
    activitySummary?: SessionActivitySummary;
  };
  deliverySettled: {
    settlement: PendingFinalDeliverySettlementInput;
    evidence?: SessionActorDeliveryEvidence;
  };
  patch: { reducers: readonly SessionActorReducer[] };
};

export type SessionActorPhase = keyof SessionActorPhaseInputs;

export type SessionActorPhaseResults = {
  acceptInput: {
    inputId?: string;
    turn?: SessionTurnCommitted;
    append?: SessionActorAppendCommitted;
    adoption?: Pick<PendingInputSnapshot, "existing" | "previous" | "committed">;
    pendingInputReceipt?: PendingInputMutationReceipt;
  };
  adoptRun: SessionTurnCommitted | undefined;
  appendToolResult: SessionTurnCommitted | SessionActorAppendCommitted;
  appendTranscriptEvent:
    | { anchor?: TranscriptEntryAnchor; projectionNeedsReconcile?: boolean }
    | SessionActorAppendCommitted;
  completeTurn: SessionTurnCommitted | { kind: "bookkeeping" };
  deliverySettled: { state: PendingFinalDeliverySettlementInput["state"] | "stale" };
  patch: undefined;
};

export type SessionActorReducerOutcome = {
  index: number;
  kind: SessionActorReducer["kind"];
  changed: boolean;
  /** Only pure best-effort usage preparation/reduction can be skipped. Writes remain atomic. */
  failure?: { name: string; message: string };
};

export type SessionActorReceipt = {
  kind: "session-actor-committed";
  commandId: string;
  phaseId: string;
  phase: SessionActorPhase;
  beforeVersion: SessionActorVersion;
  afterVersion: SessionActorVersion;
  transcript: {
    before: SessionTranscriptContextVersion;
    after: SessionTranscriptContextVersion;
    /** Includes idempotency adoption, not only newly inserted messages. */
    appendedMessages: SessionTurnCommitted["result"]["appendedMessages"];
    /** Complete append delta in this generation; absent when payloads are unavailable. */
    appendedEvents?: Array<{ rawSeq: number; event: unknown; serializedBytes: number }>;
    authorityReceipts?: readonly SessionTranscriptAuthorityReceipt[];
    append?: SessionActorAppendCommitted;
    projectionNeedsReconcile: boolean;
  };
  conversationPublication?: readonly ConversationPublication[];
  entryMetadata?: readonly SessionEntryMetadataReceipt[];
  pendingInputReceipt?: SessionPendingInputWorkerReceipt;
  pendingInputMutationReceipt?: PendingInputMutationReceipt;
  reducers: SessionActorReducerOutcome[];
  /** Complete postimage installed on MAIN; unchanged entries may share its frozen preimage. */
  postimage: SessionActorHotState;
};

export type SessionActorOutcome<Value> =
  | {
      kind: "committed";
      value: Value;
      receipt: SessionActorReceipt;
      /** Publication/cleanup failure cannot erase a captured durable receipt. */
      failure?: {
        name: string;
        message: string;
        /** Only the command response was lost; native settlement and publication succeeded. */
        origin?: "response";
      };
    }
  | {
      kind: "rolled-back";
      error: { name: string; message: string };
      reason?: "stale-state";
    }
  | {
      /** No mutation ran. A caller may retry once using this authorized postimage. */
      kind: "stale-version";
      expected: SessionActorVersion;
      postimage: SessionActorHotState;
      error: { name: string; message: string };
    }
  | {
      kind: "unknown";
      target: SessionActorTarget;
      commandId: string;
      error: { name: string; message: string; cause?: unknown };
    };

export type SessionActorCommitObserver<Value> = {
  /** Called once with read-only native evidence before fallible publication or cleanup. */
  committed(outcome: Extract<SessionActorOutcome<Value>, { kind: "committed" }>): void;
};

/** Private durable worker commands; the actor reconstructs outcomes from native receipts. */
export type SessionActorOperations = {
  [Phase in SessionActorPhase as `session.actor.${Phase}`]: {
    input: SessionActorCommandContext &
      SessionActorPhaseInputs[Phase] & {
        target: SessionActorTarget;
        /** Command-local immutable preimage retained by the host; never grants authority. */
        entryReference?: string;
      };
    /** Native settlement owns committed data; the reply only acknowledges it. */
    output:
      | Exclude<SessionActorOutcome<never>, { kind: "committed" }>
      | Pick<Extract<SessionActorOutcome<never>, { kind: "committed" }>, "kind" | "failure">;
  };
} & {
  "session.actor.read": {
    input: { target: SessionActorTarget };
    output: SessionActorHotState;
  };
};

type SessionActorCommands = {
  [Phase in SessionActorPhase]: (
    input: SessionActorCommandContext & SessionActorPhaseInputs[Phase],
    authority: SessionActorAuthority,
    observer?: SessionActorCommitObserver<SessionActorPhaseResults[Phase]>,
  ) => Promise<SessionActorOutcome<SessionActorPhaseResults[Phase]>>;
};

type SessionActorStorageCommitObserver<Value> = {
  beforeCommit?(
    outcome: Extract<SessionActorStorageOutcome<Value>, { kind: "committed" }>,
  ): void | Promise<void>;
  /** Memory companions settle before this owner's FIFO admits later work. */
  settled?(outcome: SessionActorStorageOutcome<Value>): void | Promise<void>;
  committed?(outcome: Extract<SessionActorStorageOutcome<Value>, { kind: "committed" }>): void;
};

/** Bound at acquisition; shares the actor's accepted work, FIFO, and state owner. */
export type SessionActorStorage = {
  /** Synchronous current facts for an actual effect; never reads an uninstalled working copy. */
  readCurrent<Key extends keyof SessionActorStorageReads>(
    query: { type: Key; input: SessionActorStorageReads[Key]["input"] },
    authority: SessionActorStorageAuthority,
  ): SessionActorStorageReads[Key]["output"];
  /** Acquire a separately releasable handle from this already-selected owner. */
  acquire(sessionKey: string, lifetime?: SessionActorLifetime): Promise<SessionActor>;

  read<Key extends keyof SessionActorStorageReads>(
    query: { type: Key; input: SessionActorStorageReads[Key]["input"] },
    authority: SessionActorStorageAuthority,
  ): Promise<SessionActorStorageReads[Key]["output"]>;
  mutate<Key extends keyof SessionActorStorageWrites>(
    command: { type: Key; input: SessionActorStorageWrites[Key]["input"] },
    authority: SessionActorStorageAuthority,
    observer?: SessionActorStorageCommitObserver<SessionActorStorageWrites[Key]["output"]>,
  ): Promise<SessionActorStorageOutcome<SessionActorStorageWrites[Key]["output"]>>;
};

/**
 * One command is one synchronous writer transaction. No mailbox hold crosses an await.
 * Unknown outcomes fence disclosure until read() reconciles; commands are never replayed.
 * A receipt is commit evidence, not live authority for the caller's next external effect.
 */
export type SessionActor = SessionActorLifetime &
  SessionActorCommands & {
    readonly target: SessionActorTarget;
    /** Present only when the selected backend owns the storage domain. */
    readonly storage?: SessionActorStorage;
    /** Read-only installed MAIN revision; copy before editing. Undefined means fenced/missing. Never dispatches a worker request. */
    snapshot(authority: SessionActorAuthority): SessionActorHotState | undefined;
    /** Entry-only receipts retain the same lifetime and reconciliation fence as full snapshots. */
    snapshotEntry(authority: SessionActorAuthority): SessionActorAuthorityFacts | undefined;
    read(authority: SessionActorAuthority): Promise<SessionActorHotState>;
    /** Drain retained attempts and accepted descendants; a teardown timeout is not settlement. */
    release(): Promise<void>;
    /**
     * Retain lifetime, not FIFO. Reducers ride the next command in this phase;
     * any remainder commits before the phase settles, including exceptional exits.
     */
    withPhase<T>(
      phaseId: string,
      authority: SessionActorAuthority,
      operation: (phase: {
        actor: SessionActor;
        patch(reducers: readonly SessionActorReducer[]): void;
      }) => Promise<T>,
    ): Promise<T>;
  };

/** Bound to the existing execution owner; acquisition never creates a parallel writer. */
export type SessionActorFactory = {
  acquire(target: SessionActorTarget, lifetime: SessionActorLifetime): Promise<SessionActor>;
};
