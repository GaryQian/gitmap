import { createHash } from "node:crypto";
import { parseDateFirstTimestampMs } from "@openclaw/normalization-core/number-coercion";
import { asOptionalRecord } from "@openclaw/normalization-core/record-coerce";
import {
  executeSqliteQuerySync,
  executeSqliteQueryTakeFirstSync,
  iterateSqliteQuerySync,
  prepareSqliteQuerySync,
} from "../../infra/kysely-sync.js";
import { coerceRequiredSqliteNumber as sqliteNumber } from "../../infra/sqlite-number.js";
import { runSqliteReadOperationSync } from "../../infra/sqlite-schema-facts.js";
import {
  assertTransactionUsable,
  runSqliteReadSnapshotSync,
} from "../../infra/sqlite-transaction.js";
import { withOpenClawAgentDatabaseReadOnly } from "../../state/openclaw-agent-db-readonly.js";
import {
  openOpenClawAgentDatabase,
  type OpenClawAgentDatabase,
} from "../../state/openclaw-agent-db.js";
import type {
  LatestTranscriptAssistantText,
  SessionTranscriptReadScope,
  SessionTranscriptEventRow,
  SessionTranscriptStats,
  TranscriptEvent,
  TranscriptEventReadOptions,
} from "./session-accessor.sqlite-contract.js";
import { readSessionStateDeleteSnapshot } from "./session-accessor.sqlite-delete-snapshot.js";
import type { SessionStateDeleteSnapshot } from "./session-accessor.sqlite-delete-snapshot.types.js";
import {
  getSessionKysely,
  resolveSqliteTranscriptReadScope,
  toDatabaseOptions,
  type ResolvedTranscriptReadScope,
} from "./session-accessor.sqlite-scope.js";
import { loadTranscriptEventRowsAfterSeqInDatabase } from "./session-accessor.sqlite-transcript-incremental-read.js";
import {
  findTranscriptEventInRows,
  readLatestAssistantTextFromDatabase,
  readTranscriptHeaderFromDatabase,
} from "./session-accessor.sqlite-transcript-metadata-read.js";
import { canRebasePreparedAssistantInTransaction } from "./session-accessor.sqlite-transcript-parent.js";
import {
  readTranscriptContextVersionInTransaction,
  readTranscriptMutationStateInTransaction,
} from "./session-accessor.sqlite-transcript-state.js";
import { readTranscriptStatsFromDatabase } from "./session-accessor.sqlite-transcript-stats.js";
import { readSessionActorTransactionState } from "./session-actor-transaction.js";
import { readHotSessionTranscriptSnapshot } from "./session-cold-storage-state.js";
import type {
  SessionTranscriptMatchDiagnostics,
  SessionTranscriptReadSnapshot,
} from "./session-history-read.types.js";
import { SqliteTranscriptMutationConflictError } from "./session-mutation-conflict-error.js";
import { SessionTranscriptColdError } from "./session-transcript-cold-error.js";
import { SessionTranscriptStorageUnavailableError } from "./session-transcript-projection-error.js";
import { assertTranscriptEventReadBudget } from "./session-transcript-read-bytes.js";
import {
  captureSessionTranscriptQuestionAnswers,
  resolveSqliteSessionTranscriptReadFence,
} from "./session-transcript-read-fence.js";
import {
  readTranscriptPayload,
  transcriptEventJsonSql,
  transcriptEventNavigationSql,
  transcriptEventResetNavigationSql,
} from "./transcript-payload.js";

export type SqliteTranscriptSnapshotRow = {
  eventJson: string;
  seq: number;
};

export type SqliteTranscriptSnapshotState =
  | { kind: "current"; rows: SqliteTranscriptSnapshotRow[] }
  | { kind: "stale" };

export type SqliteTranscriptStorageRow = SqliteTranscriptSnapshotRow & {
  createdAt: number;
};

export function createTranscriptIdentityReader(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
) {
  const actor = readSessionActorTransactionState(database, { sessionId });
  const db = getSessionKysely(database.db);
  let read: ReturnType<typeof prepareRead> | undefined;
  const prepareRead = () =>
    prepareSqliteQuerySync<
      string,
      {
        event_id: string | null;
        parent_id: string | null;
        seq: number | null;
        cold: boolean | number;
      }
    >(database.db, (parameter) =>
      db
        .selectFrom(db.selectNoFrom((eb) => eb.val(sessionId).as("session_id")).as("target"))
        .leftJoin("transcript_event_identities as identity", (join) =>
          join.onRef("identity.session_id", "=", "target.session_id").on(
            "identity.event_id",
            "=",
            parameter((eventId) => eventId),
          ),
        )
        .select(["identity.event_id", "identity.parent_id", "identity.seq"])
        .select((eb) =>
          eb
            .exists(
              eb
                .selectFrom("session_transcript_cold_archives")
                .select("session_id")
                .where("session_id", "=", sessionId),
            )
            .as("cold"),
        ),
    );
  return (eventId: string) => {
    if (actor) {
      if (actor.transcript.coldArchive) {
        throw new SessionTranscriptColdError(sessionId);
      }
      const row = actor.transcript.identities.get(eventId);
      if (row || actor.transcript.complete) {
        return row ? { eventId: row.event_id, parentId: row.parent_id, seq: row.seq } : undefined;
      }
    }
    return runSqliteReadOperationSync(database.db, () => {
      assertTransactionUsable(database.db);
      // The singleton keeps cold-state evidence even when this identity is absent.
      const row = (read ??= prepareRead())(eventId).rows[0]!;
      assertTransactionUsable(database.db);
      if (row.cold) {
        throw new SessionTranscriptColdError(sessionId);
      }
      return row.event_id !== null && row.seq !== null
        ? { eventId: row.event_id, parentId: row.parent_id, seq: row.seq }
        : undefined;
    });
  };
}

export function readTranscriptIdentityByEventId(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  eventId: string,
): { eventId: string; parentId: string | null; seq: number } | undefined {
  return createTranscriptIdentityReader(database, sessionId)(eventId);
}

export function loadTranscriptEventsSync(scope: SessionTranscriptReadScope): TranscriptEvent[] {
  return loadTranscriptReadSnapshotSync(scope).events;
}

/** Pair loaded bytes with the watermark that also fences opaque navigation edits. */
export function loadTranscriptReadSnapshotSync(
  scope: SessionTranscriptReadScope,
  options: { readOnly?: boolean; resolvedScope?: ResolvedTranscriptReadScope } = {},
): SessionTranscriptReadSnapshot {
  const resolved = options.resolvedScope ?? resolveSqliteTranscriptReadScope(scope);
  const read = (database: Pick<OpenClawAgentDatabase, "db" | "path">) =>
    runSqliteReadSnapshotSync(
      database.db,
      () => {
        const fence = resolveSqliteSessionTranscriptReadFence({ database, ...resolved });
        return {
          events: loadTranscriptEventsFromDatabase(database, resolved.sessionId, {
            beforeEventSeq: fence?.beforeRawSeq,
            maxEventBytes: scope.maxEventBytes,
          }),
          version: readTranscriptContextVersionInTransaction(database, resolved.sessionId),
        };
      },
      { databaseLabel: database.path, operationLabel: "session transcript fenced read" },
    );
  const databaseOptions = toDatabaseOptions(resolved);
  if (!options.readOnly) {
    return read(openOpenClawAgentDatabase(databaseOptions));
  }
  const result = withOpenClawAgentDatabaseReadOnly(read, databaseOptions);
  if (!result.found) {
    throw new SessionTranscriptStorageUnavailableError(result.reason);
  }
  return result.value;
}

/** Reads a complete maintenance transcript and its lifecycle snapshot from one transaction. */
export function inspectTranscriptEventsSync(scope: SessionTranscriptReadScope): {
  events: TranscriptEvent[];
  snapshot: SessionStateDeleteSnapshot;
} {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const result = withOpenClawAgentDatabaseReadOnly(
    (database) =>
      runSqliteReadSnapshotSync(
        database.db,
        () => ({
          events: readTranscriptSnapshot(database, resolved.sessionId).events,
          snapshot: readSessionStateDeleteSnapshot(database.db, resolved.sessionId),
        }),
        {
          databaseLabel: database.path,
          operationLabel: "session transcript inspection",
        },
      ),
    toDatabaseOptions(resolved),
  );
  if (!result.found) {
    throw new SessionTranscriptStorageUnavailableError(result.reason);
  }
  return result.value;
}

/** Validates a prepared assistant using indexed identities and returns its exact mutation fence. */
export function validatePreparedAssistantAppendSync(
  scope: SessionTranscriptReadScope,
  preparedParentId: string | null,
  admittedUserId?: string,
): number | null | undefined {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  const questionAnswers = captureSessionTranscriptQuestionAnswers(
    database,
    resolved.sessionId,
    admittedUserId,
  );
  return runSqliteReadSnapshotSync(
    database.db,
    () =>
      canRebasePreparedAssistantInTransaction(
        database,
        resolved.sessionId,
        preparedParentId,
        admittedUserId,
        questionAnswers?.answers,
      )
        ? readTranscriptMutationStateInTransaction(database, resolved.sessionId).updatedAt
        : undefined,
    {
      databaseLabel: database.path,
      operationLabel: "prepared assistant validation",
    },
  );
}

/** Loads only the first transcript row for header metadata hot paths. */
export function loadTranscriptHeaderSync(scope: SessionTranscriptReadScope): unknown {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  return readTranscriptHeaderFromDatabase(database, resolved.sessionId);
}

/** Loads additive transcript rows after one durable sequence checkpoint. */
export function loadTranscriptEventRowsAfterSeqSync(
  scope: SessionTranscriptReadScope,
  afterSeq: number,
): SessionTranscriptEventRow[] {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  return loadTranscriptEventRowsAfterSeqInDatabase(database, resolved.sessionId, afterSeq);
}

/** Reads one checkpoint row so incremental consumers can reject transcript rewrites. */
export function readTranscriptEventAtSeqSync(
  scope: SessionTranscriptReadScope,
  seq: number,
): SessionTranscriptEventRow | undefined {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  return readHotSessionTranscriptSnapshot(database, resolved.sessionId, "checkpoint", () => {
    return readTranscriptEventAtSeqInTransaction(database, resolved.sessionId, seq);
  });
}

/** Reads one raw row within the caller's already validated transcript snapshot. */
export function readTranscriptEventAtSeqInTransaction(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  seq: number,
): SessionTranscriptEventRow | undefined {
  const row = executeSqliteQueryTakeFirstSync(
    database.db,
    getSessionKysely(database.db)
      .selectFrom("transcript_events")
      .select(["event_json", "event_zstd", "event_utf8_bytes", "seq"])
      .where("session_id", "=", sessionId)
      .where("seq", "=", seq),
  );
  return row
    ? {
        event: JSON.parse(readTranscriptPayload(row)) as TranscriptEvent,
        seq: sqliteNumber(row.seq),
      }
    : undefined;
}

/** Select the same fenced rows for synchronous materialization and worker transfer. */
export function prepareTranscriptEventReadQuery(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  options: Omit<TranscriptEventReadOptions, "projection"> = {},
) {
  assertTranscriptEventReadBudget(database, sessionId, options);
  return getSessionKysely(database.db)
    .selectFrom("transcript_events")
    .where("session_id", "=", sessionId)
    .$if(options.afterEventSeq !== undefined, (query) =>
      query.where("seq", ">", options.afterEventSeq!),
    )
    .$if(options.beforeEventSeq !== undefined, (query) =>
      query.where("seq", "<", options.beforeEventSeq!),
    );
}

export function loadTranscriptEventsFromDatabase(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  options: TranscriptEventReadOptions = {},
): TranscriptEvent[] {
  return readTranscriptEventsFromDatabase(database, sessionId, Array.from, options);
}

/** Consume synchronously: the iterator must not outlive its fenced native snapshot. */
function readTranscriptEventsFromDatabase<T>(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  consume: (events: Iterable<TranscriptEvent>) => T,
  options: TranscriptEventReadOptions = {},
): T {
  return readHotSessionTranscriptSnapshot(database, sessionId, "events", () => {
    const rows = iterateSqliteQuerySync(
      database.db,
      prepareTranscriptEventReadQuery(database, sessionId, options)
        .select([
          options.projection === "reset-boundary"
            ? transcriptEventResetNavigationSql(database.db).as("event_json")
            : transcriptEventJsonSql(database.db).as("event_json"),
        ])
        .orderBy("seq", "asc"),
    );
    const events = (function* () {
      for (const row of rows) {
        const event: TranscriptEvent = JSON.parse(row.event_json);
        yield event;
      }
    })();
    try {
      return consume(events);
    } finally {
      events.return();
    }
  });
}

export function readTranscriptSnapshot(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
): { events: TranscriptEvent[]; rows: SqliteTranscriptSnapshotRow[] } {
  const rows = readTranscriptEventRows(database, sessionId);
  return {
    events: rows.map((row) => JSON.parse(row.eventJson) as TranscriptEvent),
    rows,
  };
}

/** Reads canonical transcript text without parsing JSON for snapshot comparison. */
export function readTranscriptEventRows(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  afterSeq?: number,
): SqliteTranscriptSnapshotRow[] {
  const rows: SqliteTranscriptSnapshotRow[] = [];
  visitTranscriptEventRows(database, sessionId, (row) => rows.push(row), afterSeq);
  return rows;
}

function visitTranscriptEventRows(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  visit: (row: SqliteTranscriptSnapshotRow) => void,
  afterSeq?: number,
): void {
  readHotSessionTranscriptSnapshot(database, sessionId, "raw rows", () => {
    let query = getSessionKysely(database.db)
      .selectFrom("transcript_events")
      .select(["event_json", "event_zstd", "event_utf8_bytes", "seq"])
      .where("session_id", "=", sessionId)
      .orderBy("seq", "asc");
    if (afterSeq !== undefined) {
      query = query.where("seq", ">", afterSeq);
    }
    for (const row of iterateSqliteQuerySync(database.db, query)) {
      visit({ eventJson: readTranscriptPayload(row), seq: sqliteNumber(row.seq) });
    }
  });
}

export type SqliteTranscriptSnapshotDigest = { count: number; sha256: string };

/** Keep byte/sequence stale-write checks without retaining the discarded transcript. */
export function readTranscriptEventRowsDigest(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  visit?: (row: SqliteTranscriptSnapshotRow) => void,
): SqliteTranscriptSnapshotDigest {
  const hash = createHash("sha256");
  let count = 0;
  visitTranscriptEventRows(database, sessionId, (row) => {
    hash.update(JSON.stringify([row.seq, row.eventJson]));
    count++;
    visit?.(row);
  });
  return { count, sha256: hash.digest("hex") };
}

export function assertSqliteTranscriptDigestUnchanged(
  database: OpenClawAgentDatabase,
  sessionId: string,
  expected: SqliteTranscriptSnapshotDigest,
): void {
  const current = readTranscriptEventRowsDigest(database, sessionId);
  if (current.count !== expected.count || current.sha256 !== expected.sha256) {
    throw new SqliteTranscriptMutationConflictError(sessionId);
  }
}

/** Reads exact transcript storage rows for guarded doctor rewrites. */
export function readTranscriptStorageRows(
  database: OpenClawAgentDatabase,
  sessionId: string,
): SqliteTranscriptStorageRow[] {
  return readHotSessionTranscriptSnapshot(database, sessionId, "storage rows", () => {
    const rows = executeSqliteQuerySync(
      database.db,
      getSessionKysely(database.db)
        .selectFrom("transcript_events")
        .select(["created_at", "event_json", "event_zstd", "event_utf8_bytes", "seq"])
        .where("session_id", "=", sessionId)
        .orderBy("seq", "asc"),
    ).rows;
    return rows.map((row) => ({
      createdAt: sqliteNumber(row.created_at),
      eventJson: readTranscriptPayload(row),
      seq: sqliteNumber(row.seq),
    }));
  });
}

/** Reads transcript freshness and byte size without materializing event rows. */
export function readTranscriptStatsSync(scope: SessionTranscriptReadScope): SessionTranscriptStats {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  return readTranscriptStatsFromDatabase(database, resolved.sessionId);
}

export function loadLatestAssistantText(
  scope: SessionTranscriptReadScope,
): LatestTranscriptAssistantText | undefined {
  const resolved = resolveSqliteTranscriptReadScope(scope);
  const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
  return readLatestAssistantTextFromDatabase(database, resolved);
}

export function findTranscriptEventInDatabase(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  match: (event: TranscriptEvent) => boolean,
  navigationMatch?: (event: TranscriptEvent) => boolean,
  {
    malformed = "skip",
    diagnostics,
  }: { malformed?: "skip" | "throw"; diagnostics?: SessionTranscriptMatchDiagnostics } = {},
): { event: TranscriptEvent } | undefined {
  return readHotSessionTranscriptSnapshot(database, sessionId, "match", () => {
    const events = getSessionKysely(database.db)
      .selectFrom("transcript_events")
      .where("session_id", "=", sessionId);
    const selection = navigationMatch
      ? transcriptEventNavigationSql(database.db)
      : transcriptEventJsonSql(database.db);
    for (const row of iterateSqliteQuerySync(
      database.db,
      events
        .select(["seq", selection.as("event_json")])
        .select((eb) => eb("navigation_json", "is not", null).as("projected"))
        .orderBy("seq", "desc"),
    )) {
      if (diagnostics) {
        diagnostics.rowsVisited++;
        if (row.projected) {
          diagnostics.projectedRows++;
        } else {
          diagnostics.identityRows++;
        }
      }
      const prefilter = row.projected ? navigationMatch : undefined;
      if (prefilter && !findTranscriptEventInRows([row], prefilter)) {
        continue;
      }
      // Identity TEXT already is the canonical payload, including exceptional JSON.
      const payload = prefilter
        ? executeSqliteQueryTakeFirstSync(
            database.db,
            events
              .select(transcriptEventJsonSql(database.db).as("event_json"))
              .where("seq", "=", row.seq),
          )
        : row;
      const found = payload && findTranscriptEventInRows([payload], match, malformed);
      if (found) {
        return found;
      }
    }
    return undefined;
  });
}

/** Match assistant identity without decoding unrelated message bodies under the writer lock. */
export function findAssistantTranscriptEventInDatabase(
  database: Pick<OpenClawAgentDatabase, "db">,
  sessionId: string,
  idempotencyKey?: string,
): { event: TranscriptEvent } | undefined {
  const matches = (event: TranscriptEvent) => {
    const message = readTranscriptEventMessage(event);
    return (
      message?.role === "assistant" &&
      (idempotencyKey === undefined || message.idempotencyKey === idempotencyKey)
    );
  };
  return findTranscriptEventInDatabase(database, sessionId, matches, matches);
}

export function readTranscriptEventMessage(
  event: TranscriptEvent,
): Record<string, unknown> | undefined {
  return asOptionalRecord(asOptionalRecord(event)?.message);
}

export function readTranscriptEventId(event: TranscriptEvent): string | undefined {
  const id = asOptionalRecord(event)?.id;
  return typeof id === "string" && id.trim() ? id : undefined;
}

export function readEventTimestamp(event: unknown): number | undefined {
  return parseDateFirstTimestampMs(asOptionalRecord(event)?.timestamp);
}

export function isSqliteTranscriptSnapshotUnchanged(
  database: OpenClawAgentDatabase,
  sessionId: string,
  expected: readonly SqliteTranscriptSnapshotRow[],
): boolean {
  const current = readTranscriptEventRows(database, sessionId);
  return (
    current.length === expected.length &&
    current.every(
      (row, index) =>
        row.seq === expected[index]?.seq && row.eventJson === expected[index]?.eventJson,
    )
  );
}

export function assertSqliteTranscriptSnapshotUnchanged(
  database: OpenClawAgentDatabase,
  sessionId: string,
  expected: readonly SqliteTranscriptSnapshotRow[],
): void {
  if (!isSqliteTranscriptSnapshotUnchanged(database, sessionId, expected)) {
    throw new SqliteTranscriptMutationConflictError(sessionId);
  }
}
