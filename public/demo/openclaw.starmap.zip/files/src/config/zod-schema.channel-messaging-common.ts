import { z, type ZodRawShape, type ZodTypeAny } from "zod";
import { NativeExecApprovalEnableModeSchema } from "./zod-schema.approvals.js";
import { ChannelHealthMonitorSchema } from "./zod-schema.channels.js";
import {
  BlockStreamingChunkSchema,
  ChannelDeliveryStreamingConfigSchema,
  ChannelStreamingBlockSchema,
  ContextVisibilityModeSchema,
  DmConfigSchema,
  DmPolicySchema,
  GroupPolicySchema,
  MarkdownConfigSchema,
  MentionPatternsPolicySchema,
  ReplyToModeSchema,
  TextChunkModeSchema,
} from "./zod-schema.core.js";
export { ChannelBotLoopProtectionSchema } from "./zod-schema.channel-bot-loop.js";

export const UnifiedStreamingModeSchema = z.enum(["off", "partial", "block", "progress"]);
/** Shared DM switches; channels can specialize their group identifier validator. */
export const ChannelGroupDmSchema = z.strictObject({
  /** If false, ignore incoming DMs. Default: true. */
  enabled: z.boolean().optional(),
  /** Allow group DMs. Default: false. */
  groupEnabled: z.boolean().optional(),
  /** Optional allowlist for group DM channels (ids or slugs). */
  groupChannels: z.array(z.union([z.string(), z.number()])).optional(),
});
export const ChannelThreadBindingsSchema = z.strictObject({
  enabled: z.boolean().optional(),
  idleHours: z.number().nonnegative().optional(),
  maxAgeHours: z.number().nonnegative().optional(),
  spawnSessions: z.boolean().optional(),
  defaultSpawnContext: z.enum(["isolated", "fork"]).optional(),
});
export const ChannelStreamingPreviewSchema = z.strictObject({
  chunk: BlockStreamingChunkSchema.optional(),
  toolProgress: z.boolean().optional(),
  commandText: z.enum(["raw", "status"]).optional(),
});
export const ChannelStreamingProgressSchema = z.strictObject({
  label: z.union([z.string(), z.literal(false)]).optional(),
  labels: z.array(z.string()).optional(),
  maxLines: z.number().int().positive().optional(),
  maxLineChars: z.number().int().positive().optional(),
  toolProgress: z.boolean().optional(),
  commandText: z.enum(["raw", "status"]).optional(),
  commentary: z.boolean().optional(),
  narration: z.boolean().optional(),
});
export const ChannelPreviewStreamingConfigSchema = z.strictObject({
  mode: UnifiedStreamingModeSchema.optional(),
  chunkMode: TextChunkModeSchema.optional(),
  preview: ChannelStreamingPreviewSchema.optional(),
  progress: ChannelStreamingProgressSchema.optional(),
  block: ChannelStreamingBlockSchema.optional(),
});

const CommonCapabilitiesSchema = z.array(z.string()).optional();
const CommonIdListSchema = z.array(z.union([z.string(), z.number()])).optional();
const CommonDefaultToSchema = z.string().optional();
const CommonMentionPatternsSchema = MentionPatternsPolicySchema.optional();
const CommonStreamingSchema = ChannelDeliveryStreamingConfigSchema.optional();
const CommonMediaMaxMbSchema = z.number().positive().optional();
const CommonReplyToModeSchema = ReplyToModeSchema.optional();

// Defaults belong only to the channel root: materializing them on an account
// shadows explicit root policy, while removing them entirely can fail open.
const ChannelAccountPolicyDefaults = {
  dmPolicy: DmPolicySchema.optional().default("pairing"),
  groupPolicy: GroupPolicySchema.optional().default("allowlist"),
};

/** Canonical optional account contract shared by bundled messaging channels. */
export const CommonChannelAccountSchema = z.strictObject({
  name: z.string().optional(),
  capabilities: CommonCapabilitiesSchema,
  markdown: MarkdownConfigSchema,
  configWrites: z.boolean().optional(),
  enabled: z.boolean().optional(),
  dmPolicy: DmPolicySchema.optional(),
  allowFrom: CommonIdListSchema,
  defaultTo: CommonDefaultToSchema,
  groupAllowFrom: CommonIdListSchema,
  groupPolicy: GroupPolicySchema.optional(),
  mentionPatterns: CommonMentionPatternsSchema,
  contextVisibility: ContextVisibilityModeSchema.optional(),
  historyLimit: z.number().int().min(0).optional(),
  dmHistoryLimit: z.number().int().min(0).optional(),
  dms: z.record(z.string(), DmConfigSchema.optional()).optional(),
  textChunkLimit: z.number().int().positive().optional(),
  streaming: CommonStreamingSchema,
  healthMonitor: ChannelHealthMonitorSchema,
  responsePrefix: z.string().optional(),
  mediaMaxMb: CommonMediaMaxMbSchema,
  replyToMode: CommonReplyToModeSchema,
});

type CommonChannelAccountField = keyof typeof CommonChannelAccountSchema.shape;

/** Build optional account leaves and separate root-only policy defaults. */
export function buildChannelAccountSchemaParts<
  TCapabilities extends ZodTypeAny = typeof CommonCapabilitiesSchema,
  TAllowFrom extends z.ZodType<Array<string | number> | undefined> = typeof CommonIdListSchema,
  TDefaultTo extends z.ZodType<string | number | undefined> = typeof CommonDefaultToSchema,
  TGroupAllowFrom extends z.ZodType<Array<string | number> | undefined> = typeof CommonIdListSchema,
  TMentionPatterns extends ZodTypeAny = typeof CommonMentionPatternsSchema,
  TStreaming extends ZodTypeAny = typeof CommonStreamingSchema,
  TMediaMaxMb extends ZodTypeAny = typeof CommonMediaMaxMbSchema,
  TReplyToMode extends ZodTypeAny = typeof CommonReplyToModeSchema,
  const TOmit extends readonly CommonChannelAccountField[] = [],
>(
  options: {
    capabilities?: TCapabilities;
    allowFrom?: TAllowFrom;
    defaultTo?: TDefaultTo;
    groupAllowFrom?: TGroupAllowFrom;
    mentionPatterns?: TMentionPatterns;
    streaming?: TStreaming;
    mediaMaxMb?: TMediaMaxMb;
    replyToMode?: TReplyToMode;
    omit?: TOmit;
  } = {},
) {
  const shape = {
    ...CommonChannelAccountSchema.shape,
    capabilities: (options.capabilities ?? CommonCapabilitiesSchema) as TCapabilities,
    allowFrom: (options.allowFrom ?? CommonIdListSchema) as TAllowFrom,
    defaultTo: (options.defaultTo ?? CommonDefaultToSchema) as TDefaultTo,
    groupAllowFrom: (options.groupAllowFrom ?? CommonIdListSchema) as TGroupAllowFrom,
    mentionPatterns: (options.mentionPatterns ?? CommonMentionPatternsSchema) as TMentionPatterns,
    streaming: (options.streaming ?? CommonStreamingSchema) as TStreaming,
    mediaMaxMb: (options.mediaMaxMb ?? CommonMediaMaxMbSchema) as TMediaMaxMb,
    replyToMode: (options.replyToMode ?? CommonReplyToModeSchema) as TReplyToMode,
  };
  const omitted = new Set<CommonChannelAccountField>(options.omit ?? []);
  const accountShape = Object.fromEntries(
    Object.entries(shape).filter(([key]) => !omitted.has(key as CommonChannelAccountField)),
  ) as Omit<typeof shape, TOmit[number]>;
  return {
    accountShape,
    rootPolicyShape: ChannelAccountPolicyDefaults,
    groupDmShape: ChannelGroupDmSchema.shape,
  };
}

export const ChannelDangerouslyAllowNameMatchingSchema = z.boolean().optional();
export const ChannelSendReadReceiptsSchema = z.boolean().optional();

/** Build the shared allowBots leaf without widening boolean-only channels. */
type ChannelAllowBotsSchema<TAllowMentions extends boolean | undefined> =
  TAllowMentions extends true
    ? z.ZodOptional<z.ZodUnion<readonly [z.ZodBoolean, z.ZodLiteral<"mentions">]>>
    : z.ZodOptional<z.ZodBoolean>;

export function buildChannelAllowBotsSchema<
  const TAllowMentions extends boolean | undefined = undefined,
>(options?: { allowMentions?: TAllowMentions }): ChannelAllowBotsSchema<TAllowMentions> {
  const schema = options?.allowMentions
    ? z.union([z.boolean(), z.literal("mentions")]).optional()
    : z.boolean().optional();
  // SAFETY: the runtime branch and conditional return type share the allowMentions discriminator.
  return schema as ChannelAllowBotsSchema<TAllowMentions>;
}

/** Build native exec-approval routing with channel-specific approver ids and extras. */
// oxlint-disable-next-line typescript/no-generated-empty-object-type -- A keyless Zod shape preserves named fields without a string index signature.
export function buildChannelExecApprovalsSchema<T extends ZodRawShape = Record<never, never>>(
  approverSchema: ZodTypeAny,
  extraShape?: T,
) {
  return z
    .strictObject({
      enabled: NativeExecApprovalEnableModeSchema.optional(),
      approvers: z.array(approverSchema).optional(),
      agentFilter: z.array(z.string()).optional(),
      sessionFilter: z.array(z.string()).optional(),
      target: z.enum(["dm", "channel", "both"]).optional(),
      ...(extraShape ?? ({} as T)),
    })
    .optional();
}

type StringEnumValues = readonly [string, string, ...string[]];

type ChannelReactionShapeOptions = {
  notificationModes?: StringEnumValues;
  reactionLevels?: StringEnumValues;
  reactionAllowlist?: boolean;
  ackReaction?: ZodTypeAny;
};

type EnumSchema<TValues extends StringEnumValues> = z.ZodEnum<{
  [TValue in TValues[number]]: TValue;
}>;

type EnumShape<TValues, TKey extends string> = TValues extends StringEnumValues
  ? { [TResultKey in TKey]: z.ZodOptional<EnumSchema<TValues>> }
  : object;
type ChannelReactionShape<TOptions extends ChannelReactionShapeOptions> = ZodRawShape &
  EnumShape<TOptions["notificationModes"], "reactionNotifications"> &
  EnumShape<TOptions["reactionLevels"], "reactionLevel"> &
  (TOptions["reactionAllowlist"] extends true
    ? { reactionAllowlist: z.ZodOptional<z.ZodArray<z.ZodUnion<[z.ZodString, z.ZodNumber]>>> }
    : object) &
  (TOptions["ackReaction"] extends ZodTypeAny ? { ackReaction: TOptions["ackReaction"] } : object);

/** Build the repeated reaction leaves while retaining each channel's exact enum. */
export function buildChannelReactionShape<const TOptions extends ChannelReactionShapeOptions>(
  options: TOptions,
): ChannelReactionShape<TOptions> {
  return {
    ...(options.notificationModes
      ? { reactionNotifications: z.enum(options.notificationModes).optional() }
      : {}),
    ...(options.reactionAllowlist
      ? {
          reactionAllowlist: z.array(z.union([z.string(), z.number()])).optional(),
        }
      : {}),
    ...(options.reactionLevels ? { reactionLevel: z.enum(options.reactionLevels).optional() } : {}),
    ...(options.ackReaction ? { ackReaction: options.ackReaction } : {}),
    // SAFETY: each conditional property is emitted only when its matching option is present.
  } as ChannelReactionShape<TOptions>;
}
