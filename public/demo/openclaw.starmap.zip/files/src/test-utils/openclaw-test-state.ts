// Creates isolated OpenClaw state directories for integration-style tests.
import fs from "node:fs/promises";
import path from "node:path";
import { hasUnjoinedWork } from "../../scripts/lib/managed-child-process.mts";
import { resolveAuthProfileDatabasePath } from "../agents/auth-profiles/sqlite.js";
import type { AuthProfileStore } from "../agents/auth-profiles/types.js";
import * as configRuntime from "../config/runtime-snapshot.js";
import { GATEWAY_STARTUP_MUTATED_ENV_KEYS } from "../gateway/test-helpers.env.js";
import { acquireStateDatabaseSchemaLease } from "../infra/gateway-state-owner.js";
import { AsyncWorkScope } from "../shared/async-work-scope.js";
import { resolveOpenClawStateSqlitePath } from "../state/openclaw-state-db.paths.js";
import { captureEnv, resolveTestTempRoot, withEnv } from "./env.js";
import { cleanupSessionStateForTest } from "./session-state-cleanup.js";

type ConfigRuntimeResettable = typeof configRuntime & {
  resetConfigRuntimeState?: () => void;
};

type OpenClawTestStateLayout = "home" | "state-only" | "split";

type OpenClawTestStateScenario =
  | "empty"
  | "minimal"
  | "update-stable"
  | "upgrade-survivor"
  | "gateway-loopback"
  | "external-service";

type OpenClawTestStateOptions = {
  prefix?: string;
  label?: string;
  layout?: OpenClawTestStateLayout;
  scenario?: OpenClawTestStateScenario;
  agentEnv?: "clear" | "main";
  applyEnv?: boolean;
  prepareProfileCatalog?: boolean;
  env?: Record<string, string | undefined>;
  verifyCleanup?: (cleanup: () => Promise<void>) => Promise<void>;
  gateway?: {
    port?: number;
    token?: string;
  };
};

export type OpenClawTestState = {
  root: string;
  home: string;
  stateDir: string;
  configPath: string;
  workspaceDir: string;
  env: NodeJS.ProcessEnv;
  envVars: Record<string, string | undefined>;
  path: (...parts: string[]) => string;
  statePath: (...parts: string[]) => string;
  agentDir: (agentId?: string) => string;
  sessionsDir: (agentId?: string) => string;
  writeConfig: (config: unknown) => Promise<string>;
  writeJson: (relativePath: string, value: unknown) => Promise<string>;
  writeText: (relativePath: string, value: string) => Promise<string>;
  writeAuthProfiles: (store: unknown, agentId?: string) => Promise<string>;
  applyEnv: () => void;
  restoreEnv: () => Promise<void>;
  cleanup: () => Promise<void>;
};

const DEFAULT_PREFIX = "openclaw-test-state-";
const ENV_KEYS = [
  "HOME",
  "USERPROFILE",
  "HOMEDRIVE",
  "HOMEPATH",
  ...GATEWAY_STARTUP_MUTATED_ENV_KEYS,
  "OPENCLAW_HOME",
  "OPENCLAW_STATE_DIR",
  "OPENCLAW_CONFIG_PATH",
  "OPENCLAW_AGENT_DIR",
  "OPENCLAW_SERVICE_REPAIR_POLICY",
  "OPENCLAW_DISABLE_BUNDLED_PLUGINS",
  "OPENCLAW_BUNDLED_PLUGINS_DIR",
] as const;

function resetConfigRuntimeStateForTest(): void {
  let reset: (() => void) | undefined;
  try {
    reset = (configRuntime as ConfigRuntimeResettable).resetConfigRuntimeState;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('No "resetConfigRuntimeState" export is defined')) {
      return;
    }
    throw error;
  }
  reset?.();
}

function normalizeLabel(value: string | undefined): string {
  return (value ?? "state").replace(/[^A-Za-z0-9_.-]+/gu, "-").replace(/^-+|-+$/gu, "") || "state";
}

function resolveWindowsHomeEnv(
  home: string,
): Partial<Pick<NodeJS.ProcessEnv, "HOMEDRIVE" | "HOMEPATH">> {
  if (process.platform !== "win32") {
    return {};
  }
  const match = home.match(/^([A-Za-z]:)(.*)$/u);
  if (!match) {
    return {};
  }
  return {
    HOMEDRIVE: match[1],
    HOMEPATH: match[2] || "\\",
  };
}

function resolveLayout(
  root: string,
  layout: OpenClawTestStateLayout,
): {
  home: string;
  stateDir: string;
  configPath: string;
  workspaceDir: string;
} {
  if (layout === "home") {
    const home = path.join(root, "home");
    const stateDir = path.join(home, ".openclaw");
    return {
      home,
      stateDir,
      configPath: path.join(stateDir, "openclaw.json"),
      workspaceDir: path.join(home, "workspace"),
    };
  }
  if (layout === "split") {
    const home = path.join(root, "home");
    const stateDir = path.join(root, "state");
    return {
      home,
      stateDir,
      configPath: path.join(root, "config", "openclaw.json"),
      workspaceDir: path.join(root, "workspace"),
    };
  }
  const stateDir = path.join(root, "state");
  return {
    home: path.join(root, "home"),
    stateDir,
    configPath: path.join(stateDir, "openclaw.json"),
    workspaceDir: path.join(root, "workspace"),
  };
}

function scenarioConfig(options: OpenClawTestStateOptions): Record<string, unknown> | undefined {
  const scenario = options.scenario ?? "empty";
  if (scenario === "minimal" || scenario === "external-service") {
    return {};
  }
  if (scenario === "update-stable") {
    return {
      update: {
        channel: "stable",
      },
      plugins: {},
    };
  }
  if (scenario === "upgrade-survivor") {
    return {
      update: {
        channel: "stable",
      },
      gateway: {
        port: options.gateway?.port ?? 18789,
        bind: "loopback",
        auth: {
          mode: "token",
          token: options.gateway?.token ?? "openclaw-test-token",
        },
        controlUi: {
          enabled: false,
        },
      },
      plugins: {
        enabled: true,
        allow: ["discord", "telegram", "whatsapp", "memory"],
        entries: {
          discord: { enabled: true },
          telegram: { enabled: true },
          whatsapp: { enabled: true },
        },
      },
    };
  }
  if (scenario === "gateway-loopback") {
    return {
      gateway: {
        port: options.gateway?.port ?? 18789,
        auth: {
          mode: "token",
          token: options.gateway?.token ?? "openclaw-test-token",
        },
        controlUi: {
          enabled: false,
        },
      },
    };
  }
  return undefined;
}

function scenarioEnv(options: OpenClawTestStateOptions): Record<string, string | undefined> {
  if ((options.scenario ?? "empty") === "external-service") {
    return {
      OPENCLAW_SERVICE_REPAIR_POLICY: "external",
    };
  }
  return {};
}

function buildEnvVars(params: {
  layout: OpenClawTestStateLayout;
  home: string;
  stateDir: string;
  configPath: string;
  agentDir: string;
  agentEnv: "clear" | "main";
  scenarioEnv: Record<string, string | undefined>;
  extraEnv: Record<string, string | undefined>;
}): Record<string, string | undefined> {
  const agentDirEnv =
    params.agentEnv === "main"
      ? {
          OPENCLAW_AGENT_DIR: params.agentDir,
        }
      : {
          OPENCLAW_AGENT_DIR: undefined,
        };
  const envVars: Record<string, string | undefined> = {
    OPENCLAW_STATE_DIR: params.stateDir,
    OPENCLAW_CONFIG_PATH: params.configPath,
    ...agentDirEnv,
    PI_CODING_AGENT_DIR: undefined,
    ...params.scenarioEnv,
    ...params.extraEnv,
  };
  if (params.layout !== "state-only") {
    Object.assign(envVars, {
      HOME: params.home,
      USERPROFILE: params.home,
      OPENCLAW_HOME: params.home,
      ...resolveWindowsHomeEnv(params.home),
    });
  }
  return envVars;
}

function createSpawnEnv(envVars: Record<string, string | undefined>): NodeJS.ProcessEnv {
  const nextEnv: NodeJS.ProcessEnv = { ...process.env };
  for (const [key, value] of Object.entries(envVars)) {
    if (value === undefined) {
      delete nextEnv[key];
    } else {
      nextEnv[key] = value;
    }
  }
  return nextEnv;
}

async function writeJsonFile(filePath: string, value: unknown): Promise<string> {
  await fs.mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 });
  await fs.chmod(path.dirname(filePath), 0o700);
  await fs.writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  return filePath;
}

export async function createOpenClawTestState(
  options: OpenClawTestStateOptions = {},
): Promise<OpenClawTestState> {
  const label = normalizeLabel(options.label ?? options.scenario);
  const prefix = options.prefix ?? `${DEFAULT_PREFIX}${label}-`;
  const layout = options.layout ?? "home";
  const config = scenarioConfig(options);
  let root = await fs.mkdtemp(path.join(resolveTestTempRoot(), prefix));
  const removeRoot = () =>
    fs.rm(root, {
      recursive: true,
      force: true,
      maxRetries: 20,
      retryDelay: 25,
    });
  let rollbackEnv: (() => void) | undefined;
  try {
    // Keep the allocated path for rollback if canonicalization fails. macOS tmpdir
    // sits behind /var -> /private/var; successful fixtures expose canonical paths.
    root = await fs.realpath(root);
    const paths = resolveLayout(root, layout);

    const mainAgentDir = path.join(paths.stateDir, "agents", "main", "agent");
    const envVars = buildEnvVars({
      layout,
      home: paths.home,
      stateDir: paths.stateDir,
      configPath: paths.configPath,
      agentDir: mainAgentDir,
      agentEnv: options.agentEnv ?? "clear",
      scenarioEnv: scenarioEnv(options),
      extraEnv: options.env ?? {},
    });
    const env = createSpawnEnv(envVars);
    const capturedEnvKeys = new Set([...ENV_KEYS, ...Object.keys(envVars)]);
    const snapshots = [captureEnv([...capturedEnvKeys])];
    let envApplied = false;
    let releasePromise: Promise<void> | undefined;
    let cleanupPromise: Promise<void> | undefined;
    let releaseProfileCatalog: (() => void) | undefined;
    const restoreAppliedEnv = () => {
      if (envApplied) {
        for (const snapshot of snapshots) {
          snapshot.restore();
        }
        resetConfigRuntimeStateForTest();
        envApplied = false;
      }
    };
    const agentDir = (agentId = "main") => path.join(paths.stateDir, "agents", agentId, "agent");
    const sessionsDir = (agentId = "main") =>
      path.join(paths.stateDir, "agents", agentId, "sessions");

    const state: OpenClawTestState = {
      root,
      ...paths,
      env,
      envVars,
      path: (...parts) => path.join(root, ...parts),
      statePath: (...parts) => path.join(paths.stateDir, ...parts),
      agentDir,
      sessionsDir,
      writeConfig: (value) => writeJsonFile(paths.configPath, value),
      writeJson: (relativePath, value) =>
        writeJsonFile(path.join(paths.stateDir, relativePath), value),
      writeText: async (relativePath, value) => {
        const filePath = path.join(paths.stateDir, relativePath);
        await fs.mkdir(path.dirname(filePath), { recursive: true, mode: 0o700 });
        await fs.chmod(path.dirname(filePath), 0o700);
        await fs.writeFile(filePath, value, "utf8");
        return filePath;
      },
      writeAuthProfiles: async (store, agentId = "main") => {
        const targetAgentDir = agentDir(agentId);
        // Fixture persistence does not need native plugin discovery.
        const [{ createAuthProfileStoreRuntime }, { createExternalAuthRuntime }] =
          await Promise.all([
            import("../agents/auth-profiles/store.js"),
            import("../agents/auth-profiles/external-auth.js"),
          ]);
        const { saveAuthProfileStore } = createAuthProfileStoreRuntime(
          createExternalAuthRuntime(
            () => [],
            async (_params, run) => run(),
          ),
        );
        withEnv(env, () => {
          const lease = acquireStateDatabaseSchemaLease(resolveOpenClawStateSqlitePath(env));
          try {
            lease.run(() =>
              saveAuthProfileStore(store as AuthProfileStore, targetAgentDir, {
                filterExternalAuthProfiles: false,
                syncExternalCli: false,
              }),
            );
          } finally {
            lease.release();
          }
        });
        return resolveAuthProfileDatabasePath(targetAgentDir);
      },
      applyEnv: () => {
        if (releasePromise || cleanupPromise) {
          throw new Error("Cannot apply a released OpenClaw test state");
        }
        resetConfigRuntimeStateForTest();
        // envVars is mutable; capture late keys before their first application.
        const newKeys = Object.keys(envVars).filter((key) => !capturedEnvKeys.has(key));
        if (newKeys.length > 0) {
          snapshots.push(captureEnv(newKeys));
          for (const key of newKeys) {
            capturedEnvKeys.add(key);
          }
        }
        // A later write can throw after earlier keys changed; restoration still owns them.
        envApplied = true;
        for (const [key, value] of Object.entries(envVars)) {
          // Test fixtures apply a fixed OpenClaw env set, not plugin-provided host env.
          if (value === undefined) {
            Reflect.deleteProperty(process.env, key);
          } else {
            Reflect.set(process.env, key, value);
          }
        }
      },
      // The caller stops external producers first. Retain the original release,
      // including failure, so no concurrent caller can restore selectors early.
      restoreEnv: () =>
        (releasePromise ??= Promise.resolve().then(async () => {
          releaseProfileCatalog?.();
          await cleanupSessionStateForTest({ stateDir: paths.stateDir, rootPath: root });
          restoreAppliedEnv();
        })),
      cleanup: () =>
        (cleanupPromise ??= Promise.resolve().then(async () => {
          await state.restoreEnv();
          await removeRoot();
        })),
    };
    rollbackEnv = restoreAppliedEnv;

    for (const dir of [
      paths.stateDir,
      paths.workspaceDir,
      ...(layout === "state-only" ? [] : [paths.home]),
    ]) {
      await fs.mkdir(dir, { recursive: true, mode: 0o700 });
      await fs.chmod(dir, 0o700);
    }
    if (config !== undefined) {
      await writeJsonFile(paths.configPath, config);
    }

    if (options.applyEnv !== false) {
      state.applyEnv();
    }

    if (options.prepareProfileCatalog) {
      try {
        const { prepareUserProfileCatalogForTest } = await import("./user-profile-catalog.js");
        const catalog = await prepareUserProfileCatalogForTest({ env });
        releaseProfileCatalog = catalog.release;
      } catch (error) {
        await state.cleanup();
        throw error;
      }
    }

    return state;
  } catch (error) {
    // Acquisition has no session/auth work to drain or close. Only undo this fixture.
    // Restore selectors synchronously before the verifier can yield.
    const rollback = (async () => {
      rollbackEnv?.();
      await removeRoot();
    })();
    if (options.verifyCleanup) {
      await options.verifyCleanup(() => rollback);
    } else {
      await rollback;
    }
    throw error;
  }
}

export async function withOpenClawTestState<T>(
  options: OpenClawTestStateOptions,
  fn: (state: OpenClawTestState) => Promise<T>,
): Promise<T> {
  const state = await createOpenClawTestState(options);
  const failures = new Set<unknown>();
  const work = new AsyncWorkScope(failures);
  const [outcome] = await Promise.allSettled([work.track(() => fn(state))]);
  await work.drain();
  if ([...failures].some(hasUnjoinedWork)) {
    // Promise settlement does not prove that an external child released its inputs.
    try {
      await state.restoreEnv();
    } catch (error) {
      failures.add(error);
    }
    const retained = [...failures];
    throw retained.length === 1
      ? retained[0]
      : new AggregateError(retained, `Fixture cleanup unverified; retained ${state.root}`);
  }
  await state.cleanup();
  if (outcome.status === "rejected") {
    throw outcome.reason;
  }
  return outcome.value;
}
