// Exposes generic path guard helpers with fs-safe defaults.
import path from "node:path";
import { isPathInside } from "@openclaw/fs-safe/path";

// Generic path guard facade for containment checks and safe relative paths.
export {
  hasNodeErrorCode,
  isNotFoundPathError,
  normalizeWindowsPathForComparison,
  safeStatSync,
} from "@openclaw/fs-safe/path";
export { isPathInside };

/** Checks a relative-path result without resolving or changing its separators. */
export function relativePathEscapesRoot(relativePath: string): boolean {
  return (
    relativePath === ".." ||
    relativePath.startsWith("../") ||
    relativePath.startsWith("..\\") ||
    path.isAbsolute(relativePath)
  );
}

/** Returns true only when target is a descendant of root, not root itself. */
export function isPathStrictlyInside(root: string, target: string): boolean {
  return isPathInside(root, target) && !isPathInside(target, root);
}

/**
 * Normalize a Windows path for boundary math whose result is handed back to callers.
 *
 * Unlike `normalizeWindowsPathForComparison`, this preserves case: `path.win32.relative`
 * already matches roots case-insensitively, so lowercasing only corrupts the returned
 * relative path — and callers create files from it on a case-preserving filesystem.
 * Extended-length prefix stripping stays, or `\\?\`-prefixed inputs read as boundary escapes.
 */
export function normalizeWindowsPathPreservingCase(input: string): string {
  // Mirrors normalizeWindowsPathForComparison step for step, minus the lowercasing,
  // so the only behavior that shifts is the case of the characters handed back.
  // fs-safe 0.5.2 keeps surrounding whitespace (it can disguise reserved names),
  // so this mirror must not trim either.
  const normalized = path.win32.normalize(input);
  if (!normalized.startsWith("\\\\?\\")) {
    return normalized;
  }
  const withoutPrefix = normalized.slice(4);
  return withoutPrefix.toUpperCase().startsWith("UNC\\")
    ? `\\\\${withoutPrefix.slice(4)}`
    : withoutPrefix;
}
