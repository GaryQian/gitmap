// Shared exec approval types and passive policy helpers.
import { isRecord } from "@openclaw/normalization-core/record-coerce";
import { normalizeOptionalLowercaseString } from "@openclaw/normalization-core/string-coerce";
import type { SchemaContract } from "../../packages/gateway-protocol/src/schema-contract.js";
import type {
  ApprovalScope,
  StreamApprovalProposal,
} from "../../packages/gateway-protocol/src/schema/approvals.js";
import type { ExecApprovalRequestParams } from "../../packages/gateway-protocol/src/schema/exec-approvals.js";
import type { CommandExplanationSummary } from "./command-analysis/explain.js";
import type { ExecApprovalPolicySnapshot } from "./exec-approval-policy-snapshot.js";
import type { ExecAllowlistEntry, McpToolGrant } from "./exec-approvals.types.js";

export type ExecHost = "sandbox" | "gateway" | "node";
export type ExecTarget = "auto" | ExecHost;
export type ExecSecurity = "deny" | "allowlist" | "full";
export type ExecAsk = "off" | "on-miss" | "always";
export type ExecMode = "deny" | "allowlist" | "ask" | "auto" | "full";
export type ExecApprovalDecision = "allow-once" | "allow-always" | "deny";
export const EXEC_APPROVAL_DECISIONS = ["allow-once", "allow-always", "deny"] as const;
export type ExecApprovalUnavailableDecision = "allow-always";

const EXEC_TARGET_VALUES: readonly ExecTarget[] = ["auto", "sandbox", "gateway", "node"];

function normalizeExecPolicyValue<T extends string>(
  value: unknown,
  values: readonly T[],
): T | null {
  const normalized = normalizeOptionalLowercaseString(value);
  return values.find((candidate) => candidate === normalized) ?? null;
}

export function normalizeExecTarget(value?: string | null): ExecTarget | null {
  return normalizeExecPolicyValue(value, EXEC_TARGET_VALUES);
}

export function requireValidExecTarget(value?: unknown): ExecTarget | null {
  if (value == null) {
    return null;
  }
  if (typeof value !== "string") {
    throw new Error(
      `Invalid exec host value type ${typeof value}. Allowed values: ${EXEC_TARGET_VALUES.join(
        ", ",
      )}.`,
    );
  }
  const normalized = normalizeOptionalLowercaseString(value);
  if (!normalized) {
    return null;
  }
  const target = normalizeExecTarget(normalized);
  if (target) {
    return target;
  }
  throw new Error(
    `Invalid exec host "${value}". Allowed values: ${EXEC_TARGET_VALUES.join(", ")}.`,
  );
}

export function normalizeExecSecurity(value?: unknown): ExecSecurity | null {
  return normalizeExecPolicyValue(value, ["deny", "allowlist", "full"]);
}

export function normalizeExecAsk(value?: unknown): ExecAsk | null {
  return normalizeExecPolicyValue(value, ["off", "on-miss", "always"]);
}

export function normalizeExecMode(value?: string | null): ExecMode | null {
  return normalizeExecPolicyValue(value, ["deny", "allowlist", "ask", "auto", "full"]);
}

export function resolveExecModeFromPolicy(params: {
  security: ExecSecurity;
  ask: ExecAsk;
}): ExecMode {
  if (params.security === "deny") {
    return "deny";
  }
  if (params.security === "allowlist" && params.ask === "off") {
    return "allowlist";
  }
  if (params.security === "full" && params.ask !== "always") {
    return "full";
  }
  return "ask";
}

// Migration, policy writes, and repair hints must preserve policies that the
// display-mode projection cannot express: always-ask and full/on-miss.
export function resolveExactExecModeFromPolicy(params: {
  security: ExecSecurity;
  ask: ExecAsk;
}): ExecMode | null {
  if (params.ask === "always" || (params.security === "full" && params.ask === "on-miss")) {
    return null;
  }
  return resolveExecModeFromPolicy(params);
}

export function resolveExecPolicyForMode(mode: ExecMode): {
  security: ExecSecurity;
  ask: ExecAsk;
  autoReview: boolean;
} {
  switch (mode) {
    case "deny":
      return { security: "deny", ask: "off", autoReview: false };
    case "allowlist":
      return { security: "allowlist", ask: "off", autoReview: false };
    case "ask":
      return { security: "allowlist", ask: "on-miss", autoReview: false };
    case "auto":
      return { security: "allowlist", ask: "on-miss", autoReview: true };
    case "full":
      return { security: "full", ask: "off", autoReview: false };
  }
  const exhaustiveMode: never = mode;
  throw new Error(`Unsupported exec mode: ${String(exhaustiveMode)}`);
}

export function resolveExecModePolicy(params: {
  mode?: ExecMode | null;
  security: ExecSecurity;
  ask: ExecAsk;
}): {
  mode: ExecMode;
  security: ExecSecurity;
  ask: ExecAsk;
  autoReview: boolean;
} {
  if (!params.mode) {
    return {
      mode: resolveExecModeFromPolicy({ security: params.security, ask: params.ask }),
      security: params.security,
      ask: params.ask,
      autoReview: false,
    };
  }
  return {
    mode: params.mode,
    ...resolveExecPolicyForMode(params.mode),
  };
}

export type SystemRunApprovalBinding = Pick<
  SystemRunApprovalPlan,
  "argv" | "cwd" | "agentId" | "sessionKey"
> & {
  envHash: string | null;
};

export type SystemRunApprovalFileOperand = NonNullable<SystemRunApprovalPlan["mutableFileOperand"]>;

export type SystemRunApprovalPlan = SchemaContract<
  Omit<NonNullable<ExecApprovalRequestParams["systemRunPlan"]>, "policySnapshot">
> & {
  policySnapshot?: ExecApprovalPolicySnapshot;
};

export type ExecApprovalCommandSpan = NonNullable<
  ExecApprovalRequestParams["commandSpans"]
>[number];

/** Cron job identity recorded at approval creation for a cron isolated run. */
type ExecApprovalCronExecutionSource = {
  jobId: string;
  jobConfigRevision: string;
};

export type ExecApprovalRequestPayload = {
  command: string;
  commandPreview?: string | null;
  commandArgv?: string[];
  // Optional UI-safe env key preview for approval prompts.
  envKeys?: string[];
  systemRunBinding?: SystemRunApprovalBinding | null;
  systemRunPlan?: SystemRunApprovalPlan | null;
  cwd?: string | null;
  nodeId?: string | null;
  host?: string | null;
  security?: string | null;
  ask?: string | null;
  warningText?: string | null;
  /** Display metadata attached by the native stream mutation owner. */
  streamProposal?: StreamApprovalProposal;
  /** Owner-declared blast-radius facts; display-only, never authorization. */
  scope?: ApprovalScope | null;
  commandAnalysis?: CommandExplanationSummary | null;
  commandSpans?: ExecApprovalCommandSpan[];
  unavailableDecisions?: readonly ExecApprovalUnavailableDecision[];
  allowedDecisions?: readonly ExecApprovalDecision[];
  agentId?: string | null;
  resolvedPath?: string | null;
  sessionKey?: string | null;
  sessionId?: string | null;
  runId?: string | null;
  toolCallId?: string | null;
  turnSourceChannel?: string | null;
  turnSourceTo?: string | null;
  turnSourceAccountId?: string | null;
  turnSourceThreadId?: string | number | null;
  /** Gateway-recorded cron source; never taken from client request params. */
  cronExecutionSource?: ExecApprovalCronExecutionSource | null;
  /** Exact operation binding prepared at creation for standing-grant minting. */
  cronOperationBinding?: string | null;
};

export type ExecApprovalRequest = {
  /** Descriptive wire metadata; readers derive it from the payload when absent. */
  approvalKind?: "exec";
  id: string;
  request: ExecApprovalRequestPayload;
  createdAtMs: number;
  expiresAtMs: number;
};

export type ExecApprovalResolved = {
  id: string;
  decision: ExecApprovalDecision;
  resolvedBy?: string | null;
  ts: number;
  request?: ExecApprovalRequest["request"];
};

export type ExecApprovalsDefaults = Partial<Omit<ExecApprovalPolicySnapshot, "allowlistRules">>;

export type ExecApprovalsAgent = ExecApprovalsDefaults & {
  allowlist?: ExecAllowlistEntry[];
  mcpTools?: McpToolGrant[];
};

export type ExecApprovalsFile = {
  version: 1;
  socket?: {
    path?: string;
    token?: string;
  };
  defaults?: ExecApprovalsDefaults;
  agents?: Record<string, ExecApprovalsAgent>;
};

export type ExecApprovalsSnapshot = {
  path: string;
  exists: boolean;
  raw: string | null;
  file: ExecApprovalsFile;
  hash: string;
};

export type ExecApprovalsResolved = {
  path: string;
  socketPath: string;
  token: string;
  defaults: Required<ExecApprovalsDefaults>;
  agent: Required<ExecApprovalsDefaults>;
  agentSources: {
    security: string | null;
    ask: string | null;
    askFallback: string | null;
  };
  allowlist: ExecAllowlistEntry[];
  file: ExecApprovalsFile;
};

// Keep CLI + gateway defaults in sync.
export const DEFAULT_EXEC_APPROVAL_TIMEOUT_MS = 1_800_000;

/** Socket credentials are local; shared policy retains only unrelated socket metadata. */
export function stripExecApprovalsSocketCredentials(file: ExecApprovalsFile): ExecApprovalsFile {
  const { path: _path, token: _token, ...metadata } = file.socket ?? {};
  return {
    ...file,
    socket: Object.keys(metadata).length ? metadata : undefined,
  };
}

/** Raw repair preserves invalid policy fields while retiring embedded credentials. */
export function stripExecApprovalsRawSocketCredentials(raw: string): string {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw) as unknown;
  } catch {
    return raw;
  }
  if (
    !isRecord(parsed) ||
    !isRecord(parsed.socket) ||
    (!Object.hasOwn(parsed.socket, "path") && !Object.hasOwn(parsed.socket, "token"))
  ) {
    return raw;
  }
  const { path: _path, token: _token, ...metadata } = parsed.socket;
  if (Object.keys(metadata).length) {
    parsed.socket = metadata;
  } else {
    delete parsed.socket;
  }
  return `${JSON.stringify(parsed, null, 2)}\n`;
}
