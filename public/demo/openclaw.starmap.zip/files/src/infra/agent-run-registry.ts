// Owns process-local agent run context, ownership, and projection state.
import { randomUUID } from "node:crypto";
import { composeSessionSourceAssertion } from "../config/sessions/session-source-authority.js";
import { registerListener } from "../shared/listeners.js";
import { recordAgentEventRouting } from "./agent-event-execution-context.js";
import {
  AgentRunApprovalLeases,
  isCurrentAgentRunApprovalAuthority,
  type AgentRunApprovalClosureReason,
} from "./agent-run-approval-leases.js";
import type { AgentRunDelegatedAuthority } from "./agent-run-authority.types.js";
import {
  areAgentRunModelsEqual,
  buildAgentRunProjectionIndex,
  projectedAgentRunInputKey,
  projectedRunIdentity,
  resolveAgentRunProjectionProgressState,
} from "./agent-run-projection.js";
import {
  getAgentRunRegistryState,
  bumpAgentRunIndexVersion,
  getAgentRunContextOwnerStatus,
  getAgentRunLifecycleGeneration,
  readAgentRunIndexVersion,
} from "./agent-run-registry-state.js";
import type {
  AgentRunContext,
  AgentRunContextOwnership,
  AgentRunModel,
  AgentRunRegistryState,
  ProjectedAgentRunIndex,
  ProjectedAgentRunState,
} from "./agent-run-registry.types.js";
import { clearAgentRunUsage, resetAgentRunUsageForTest } from "./agent-run-usage.js";
import { isOperatorAuthorityUnavailable } from "./operator-authority-error.js";

export type { AgentRunDelegatedAuthority, ProjectedAgentRunIndex };
export { listAgentRunsForSession } from "./agent-run-registry-state.js";
export { getAgentRunContextOwnerStatus, getAgentRunLifecycleGeneration, readAgentRunIndexVersion };

const delegatedAuthorityFailures = new WeakMap<AgentRunDelegatedAuthority, { cause: unknown }>();

/** Diagnostic only: a retained failure never restores a released claim. */
export function readAgentRunDelegatedAuthorityFailure(
  authority: AgentRunDelegatedAuthority,
): { cause: unknown } | undefined {
  return delegatedAuthorityFailures.get(authority);
}

export function rotateAgentRunRegistryLifecycleGeneration(): string {
  const state = getAgentRunRegistryState();
  for (const context of state.contexts.values()) {
    const authority = context.delegatedAuthority;
    if (authority) {
      delete context.delegatedAuthority;
      delete context.assertSourceCurrent;
      notifyDelegatedAuthorityClosed(state, authority);
    }
  }
  state.lifecycleGeneration = randomUUID();
  bumpAgentRunIndexVersion();
  return state.lifecycleGeneration;
}

function notifyDelegatedAuthorityClosed(
  state: AgentRunRegistryState,
  authority: AgentRunDelegatedAuthority,
  approvalReason?: AgentRunApprovalClosureReason,
): void {
  if (!approvalReason) {
    const context = state.contexts.get(authority.operationalRunInstance.runId);
    context?.approvalLeases?.close(authority);
  }
  // One observer cannot block closure or prevent other owners from canceling work.
  for (const handler of state.delegatedAuthorityClosedHandlers ?? []) {
    try {
      handler(authority, approvalReason);
    } catch {
      // Approval settlement cannot block the owner transition.
    }
  }
}

/** Observe exact delegated-authority closure without displacing other lifecycle owners. */
export function registerAgentRunDelegatedAuthorityClosedHandler(
  handler: (
    authority: AgentRunDelegatedAuthority,
    approvalReason?: AgentRunApprovalClosureReason,
  ) => void,
): () => void {
  const handlers = (getAgentRunRegistryState().delegatedAuthorityClosedHandlers ??= new Set());
  return registerListener(handlers, handler);
}

/** Connects registry cleanup to the event sequencer without reversing ownership. */
export function registerAgentRunSequenceResetHandler(handler: (runId: string) => void): void {
  getAgentRunRegistryState().sequenceResetHandler = handler;
}

function storeRunContext(runId: string, context: AgentRunContext, predecessor?: AgentRunContext) {
  // Scheduler leases and observed activity never transfer to a fresh registration.
  context.capacityWaits = undefined;
  context.executionActivity = undefined;
  context.localModelWait = undefined;
  context.eventState = { seq: 0 };
  context.modelCallSequence = { value: 0 };
  context.acceptedUserReply = undefined;
  context.registeredAt ??= Date.now();
  getAgentRunRegistryState().contexts.set(runId, context);
  recordAgentEventRouting(runId, context, predecessor);
}

/** Registers or merges per-run context used by later agent event emissions. */
export function registerAgentRunContext(
  runId: string,
  context: AgentRunContext,
  claimId?: string,
): void {
  if (!runId) {
    return;
  }
  const state = getAgentRunRegistryState();
  const lifecycleGeneration = context.lifecycleGeneration ?? state.lifecycleGeneration;
  const owners = state.owners.get(runId);
  if (
    owners?.lifecycleGeneration === lifecycleGeneration &&
    owners.exclusiveClaimId &&
    (owners.exclusiveClaimId !== claimId || owners.clearRequested)
  ) {
    return;
  }
  const existing = state.contexts.get(runId);
  if (!existing) {
    storeRunContext(runId, { ...context, lifecycleGeneration });
    bumpAgentRunIndexVersion(context);
    return;
  }
  if (
    context.lifecycleGeneration &&
    existing.lifecycleGeneration &&
    context.lifecycleGeneration !== existing.lifecycleGeneration
  ) {
    return;
  }
  const runIndexInputBefore = projectedAgentRunInputKey(existing);
  const { sessionKey, sessionId, agentId } = existing;
  for (const key of ["sessionKey", "sessionId", "agentId"] as const) {
    if (context[key] && existing[key] !== context[key]) {
      existing[key] = context[key];
    }
  }
  if (context.verboseLevel && existing.verboseLevel !== context.verboseLevel) {
    existing.verboseLevel = context.verboseLevel;
  }
  existing.completionSource ??= context.completionSource;
  if (context.sessionEventDelivery === false) {
    existing.sessionEventDelivery = false;
  }
  for (const key of [
    "isControlUiVisible",
    "projectSessionActive",
    "projectSessionLifecycle",
    "projectSessionMessages",
  ] as const) {
    if (context[key] !== undefined) {
      existing[key] = context[key];
    }
  }
  if (context.mainSessionRestartRecovery === true) {
    existing.mainSessionRestartRecovery = true;
  }
  if (context.cronRunsByJobId !== undefined) {
    existing.cronRunsByJobId ??= new Map();
    for (const [jobId, cronRun] of context.cronRunsByJobId) {
      existing.cronRunsByJobId.set(jobId, cronRun);
    }
  }
  for (const key of ["registeredAt", "lastActiveAt"] as const) {
    if (context[key] !== undefined) {
      existing[key] = context[key];
    }
  }
  recordAgentEventRouting(runId, existing);
  if (runIndexInputBefore !== projectedAgentRunInputKey(existing)) {
    bumpAgentRunIndexVersion(existing, { sessionKey, sessionId, agentId });
  }
}

/** Claims a run id for a newly admitted execution, replacing stale ownership. */
export function claimAgentRunContext(
  runId: string,
  context: AgentRunContext,
  options: {
    trackOwner?: boolean;
    ownsContext?: boolean;
    exclusive?: boolean;
    onClearRequested?: (claimId: string) => void;
    protectFromSweep?: boolean;
  } = {},
): string | undefined {
  if (!runId) {
    return undefined;
  }
  const state = getAgentRunRegistryState();
  const lifecycleGeneration = context.lifecycleGeneration ?? state.lifecycleGeneration;
  const existing = state.contexts.get(runId);
  const existingOwners = state.owners.get(runId);
  const currentOwners =
    existingOwners?.lifecycleGeneration === lifecycleGeneration ? existingOwners : undefined;
  if (
    currentOwners?.exclusiveClaimId ||
    (options.exclusive &&
      (existing?.lifecycleGeneration === lifecycleGeneration || currentOwners !== undefined))
  ) {
    return undefined;
  }
  let claimId: string | undefined;
  if (options.trackOwner) {
    claimId = randomUUID();
    if (currentOwners) {
      currentOwners.claimIds.add(claimId);
      if (options.protectFromSweep) {
        currentOwners.sweepProtectedClaimIds.add(claimId);
      }
      if (options.ownsContext) {
        currentOwners.preserveAfterRelease = false;
      }
      if (options.onClearRequested) {
        (currentOwners.clearListeners ??= new Map()).set(claimId, options.onClearRequested);
      }
    } else {
      state.owners.set(runId, {
        lifecycleGeneration,
        claimIds: new Set([claimId]),
        sweepProtectedClaimIds: new Set(options.protectFromSweep ? [claimId] : []),
        preserveAfterRelease:
          options.ownsContext !== true && existing?.lifecycleGeneration === lifecycleGeneration,
        clearRequested: false,
        ...(options.exclusive ? { exclusiveClaimId: claimId } : {}),
        ...(options.onClearRequested
          ? { clearListeners: new Map([[claimId, options.onClearRequested]]) }
          : {}),
      });
    }
  } else if (existingOwners?.lifecycleGeneration !== lifecycleGeneration) {
    // Same-generation untracked claims refresh metadata inside the tracked
    // execution. A new lifecycle replaces that ownership outright.
    state.owners.delete(runId);
  }
  if (existing?.lifecycleGeneration === lifecycleGeneration) {
    const versionBeforeRegister = readAgentRunIndexVersion();
    registerAgentRunContext(runId, { ...context, lifecycleGeneration }, claimId);
    if (readAgentRunIndexVersion() === versionBeforeRegister) {
      bumpAgentRunIndexVersion(existing);
    }
    return claimId;
  }
  storeRunContext(runId, { ...context, lifecycleGeneration }, existing);
  state.sequenceResetHandler?.(runId);
  clearAgentRunUsage(runId);
  bumpAgentRunIndexVersion(context, existing);
  return claimId;
}

/** Returns the currently registered context for a run, if it has not been cleared or swept. */
export function getAgentRunContext(runId: string): AgentRunContext | undefined {
  return getAgentRunRegistryState().contexts.get(runId);
}

/** Holds an existing run context only while its current execution awaits lane admission. */
export function retainQueuedAgentRunContext(
  runId: string,
  lifecycleGeneration: string,
): ((outcome: "admitted" | "abandoned") => void) | undefined {
  const state = getAgentRunRegistryState();
  const context = state.contexts.get(runId);
  if (
    !context ||
    context.lifecycleGeneration !== lifecycleGeneration ||
    state.lifecycleGeneration !== lifecycleGeneration
  ) {
    return undefined;
  }

  const wasLive = hasAgentRunContextExecutionOwner(runId);
  const leases = (state.queuedRunContextLeases ??= new WeakMap<AgentRunContext, number>());
  leases.set(context, (leases.get(context) ?? 0) + 1);
  if (!wasLive) {
    bumpAgentRunIndexVersion(context);
  }
  let released = false;

  return (outcome) => {
    if (released) {
      return;
    }
    released = true;
    const remaining = (leases.get(context) ?? 0) - 1;
    if (remaining > 0) {
      leases.set(context, remaining);
    } else {
      leases.delete(context);
    }

    // A recycled run id or rotated lifecycle must not inherit the old queue's activity.
    if (
      state.contexts.get(runId) === context &&
      context.lifecycleGeneration === lifecycleGeneration &&
      state.lifecycleGeneration === lifecycleGeneration
    ) {
      if (outcome === "admitted") {
        context.lastActiveAt = Date.now();
      }
      if (!hasAgentRunContextExecutionOwner(runId)) {
        bumpAgentRunIndexVersion(context);
      }
    }
  };
}

export function getAgentRunContextOwnership(runId: string): AgentRunContextOwnership | undefined {
  return getAgentRunRegistryState().owners.get(runId);
}

/** Claims approval authority for the exact admitted operational execution. */
export function claimAgentRunDelegatedAuthority(
  operationalRunInstance: Readonly<{ instanceId: string; runId: string }>,
  assertSourceCurrent?: () => void,
): AgentRunDelegatedAuthority {
  const instanceId = operationalRunInstance.instanceId.trim();
  const runId = operationalRunInstance.runId.trim();
  if (!instanceId || !runId) {
    throw new Error("agent run delegated authority requires an operational run instance");
  }
  const state = getAgentRunRegistryState();
  const currentInstance =
    operationalRunInstance.instanceId === instanceId && operationalRunInstance.runId === runId
      ? operationalRunInstance
      : Object.freeze({ instanceId, runId });
  const bound = state.contexts.get(runId);
  // Check the binding before callbacks or liveness validation can retire it.
  if (
    bound?.delegatedAuthority?.operationalRunInstance.instanceId === instanceId &&
    bound.assertSourceCurrent !== assertSourceCurrent
  ) {
    throw new Error("agent run source authority is already bound");
  }
  assertSourceCurrent?.();
  const lifecycleGeneration = state.lifecycleGeneration;
  const active = getActiveAgentRunDelegatedAuthority(currentInstance);
  if (active) {
    return active;
  }
  const existing = state.contexts.get(runId)?.delegatedAuthority;
  if (existing) {
    // Same-id replacement retires only the prior operational authority. Other
    // legitimate run-context owners continue until their own lifecycle exits.
    releaseAgentRunContext(runId, existing.claimId);
  }
  const claimId = claimAgentRunContext(
    runId,
    { lifecycleGeneration, lastActiveAt: Date.now() },
    {
      trackOwner: true,
      protectFromSweep: true,
      onClearRequested: (requestedClaimId) => {
        releaseAgentRunContext(runId, requestedClaimId);
      },
    },
  );
  if (!claimId) {
    throw new Error("agent run delegated authority could not claim the operational execution");
  }
  const authority = Object.freeze({
    operationalRunInstance: currentInstance,
    lifecycleGeneration,
    claimId,
  });
  const context = state.contexts.get(runId);
  if (!context || context.lifecycleGeneration !== lifecycleGeneration) {
    releaseAgentRunContext(runId, claimId);
    throw new Error("agent run delegated authority lost its lifecycle during admission");
  }
  context.acceptedUserReply = undefined;
  context.delegatedAuthority = authority;
  context.assertSourceCurrent = assertSourceCurrent;
  return authority;
}

/** Returns authority only while the exact lifecycle owner still holds its claim. */
export function getActiveAgentRunDelegatedAuthority(
  operationalRunInstance: Readonly<{ instanceId: string; runId: string }>,
): AgentRunDelegatedAuthority | undefined {
  return readActiveAgentRunDelegatedAuthority(operationalRunInstance, (context) =>
    context.assertSourceCurrent?.(),
  );
}

function readActiveAgentRunDelegatedAuthority(
  operationalRunInstance: Readonly<{ instanceId: string; runId: string }>,
  assertSource: (context: AgentRunContext) => void,
): AgentRunDelegatedAuthority | undefined {
  const context = getAgentRunRegistryState().contexts.get(operationalRunInstance.runId);
  const authority = context?.delegatedAuthority;
  if (
    !context ||
    !authority ||
    authority.operationalRunInstance.instanceId !== operationalRunInstance.instanceId ||
    authority.operationalRunInstance.runId !== operationalRunInstance.runId ||
    // A clear request is projection state; the exact live claim still owns authority.
    getAgentRunContextOwnerStatus(
      operationalRunInstance.runId,
      authority.claimId,
      authority.lifecycleGeneration,
    ) === undefined
  ) {
    return undefined;
  }
  try {
    assertSource(context);
    return getAgentRunContext(operationalRunInstance.runId) === context &&
      context.delegatedAuthority === authority &&
      getAgentRunContextOwnerStatus(
        operationalRunInstance.runId,
        authority.claimId,
        authority.lifecycleGeneration,
      ) !== undefined
      ? authority
      : undefined;
  } catch (error) {
    if (isOperatorAuthorityUnavailable(error)) {
      throw error;
    }
    if (!delegatedAuthorityFailures.has(authority)) {
      delegatedAuthorityFailures.set(authority, { cause: error });
    }
    // A copied approval cannot outlive its source; retire the exact owner at detection.
    releaseAgentRunContext(operationalRunInstance.runId, authority.claimId);
    return undefined;
  }
}

/** Retain the exact source binding while its storage checks prepare outside writer grants. */
export function captureAgentRunDelegatedSourceAssertion(
  authority: AgentRunDelegatedAuthority,
  refuse: () => never,
) {
  const instance = authority.operationalRunInstance;
  const context = getAgentRunContext(instance.runId);
  const source = context?.assertSourceCurrent;
  const assertActive = (assertSource: () => void) => {
    const active = readActiveAgentRunDelegatedAuthority(instance, (current) => {
      if (current !== context || current.assertSourceCurrent !== source) {
        refuse();
      }
      assertSource();
    });
    if (
      !active ||
      !isCurrentAgentRunApprovalAuthority(active, context?.approvalLeases, authority)
    ) {
      refuse();
    }
  };
  const active = readActiveAgentRunDelegatedAuthority(instance, () => {});
  if (!active || !isCurrentAgentRunApprovalAuthority(active, context?.approvalLeases, authority)) {
    return undefined;
  }
  return {
    assertBinding: () => assertActive(() => {}),
    assertCurrent: composeSessionSourceAssertion([source], assertActive, {
      synchronousCheck: true,
    }),
  };
}

export function validateAgentRunDelegatedAuthority(
  authority: AgentRunDelegatedAuthority,
  ancestor?: AgentRunDelegatedAuthority,
): boolean {
  const active = getActiveAgentRunDelegatedAuthority(authority.operationalRunInstance);
  return Boolean(
    active &&
    isCurrentAgentRunApprovalAuthority(
      active,
      getAgentRunContext(authority.operationalRunInstance.runId)?.approvalLeases,
      authority,
      ancestor,
    ),
  );
}

/** Narrows an admitted run to one live tool generation without replacing its outer claim. */
export function claimAgentRunApprovalAuthority(
  parent: AgentRunDelegatedAuthority,
  inputSignals: readonly AbortSignal[],
): AgentRunDelegatedAuthority {
  const state = getAgentRunRegistryState();
  const context = state.contexts.get(parent.operationalRunInstance.runId);
  if (!context?.delegatedAuthority || !validateAgentRunDelegatedAuthority(parent)) {
    throw new Error("agent run approval authority is no longer active");
  }
  const leases = (context.approvalLeases ??= new AgentRunApprovalLeases((authority, reason) =>
    notifyDelegatedAuthorityClosed(state, authority, reason),
  ));
  return leases.claim(context.delegatedAuthority, parent, inputSignals);
}

/** Compare-releases only the exact authority owned by one admitted execution. */
export function releaseAgentRunDelegatedAuthority(authority: AgentRunDelegatedAuthority): boolean {
  const { runId, instanceId } = authority.operationalRunInstance;
  const context = getAgentRunContext(runId);
  const active = context?.delegatedAuthority;
  // Cleanup compares ownership without asking a revoked source for permission to retire.
  if (
    !context ||
    !active ||
    active.operationalRunInstance.instanceId !== instanceId ||
    active.lifecycleGeneration !== authority.lifecycleGeneration ||
    getAgentRunContextOwnerStatus(runId, active.claimId, active.lifecycleGeneration) === undefined
  ) {
    return false;
  }
  if (active.claimId !== authority.claimId) {
    return context.approvalLeases?.release(authority.claimId) === true;
  }
  releaseAgentRunContext(runId, authority.claimId);
  return true;
}

/** Exact execution claims and scheduler queue leases, excluding UI projection metadata. */
export function hasAgentRunContextExecutionOwner(runId: string): boolean {
  const state = getAgentRunRegistryState();
  const context = state.contexts.get(runId);
  if (!context || context.lifecycleGeneration !== state.lifecycleGeneration) {
    return false;
  }
  const owners = state.owners.get(runId);
  return (
    (owners?.lifecycleGeneration === state.lifecycleGeneration && owners.claimIds.size > 0) ||
    (state.queuedRunContextLeases?.get(context) ?? 0) > 0
  );
}

/** Counts admitted executions, excluding retained display-only context. */
export function getActiveAgentRunContextCount(): number {
  let count = 0;
  for (const runId of getAgentRunRegistryState().contexts.keys()) {
    if (hasAgentRunContextExecutionOwner(runId)) {
      count += 1;
    }
  }
  return count;
}

/** Live display projection also includes a producer's active-session marker. */
export function hasLiveAgentRunContext(runId: string): boolean {
  const state = getAgentRunRegistryState();
  const context = state.contexts.get(runId);
  return (
    context?.lifecycleGeneration === state.lifecycleGeneration &&
    (hasAgentRunContextExecutionOwner(runId) || context.projectSessionActive === true)
  );
}

export function listLiveAgentRunIds(): string[] {
  return [...getAgentRunRegistryState().contexts.keys()].filter(hasLiveAgentRunContext);
}

export function recordAgentRunModel(runId: string, model: AgentRunModel | undefined): void {
  const context = getAgentRunContext(runId);
  if (!context || context.lifecycleGeneration !== getAgentRunLifecycleGeneration()) {
    return;
  }
  if (areAgentRunModelsEqual(context.activeModel, model)) {
    return;
  }
  if (model) {
    context.activeModel = model;
  } else {
    delete context.activeModel;
  }
  bumpAgentRunIndexVersion(context);
}

export function resolveProjectedAgentRunModel(params: {
  agentId: string;
  sessionId?: string;
  index?: ProjectedAgentRunIndex;
}): AgentRunModel | null | undefined {
  return params.sessionId === undefined
    ? undefined
    : (params.index ?? buildProjectedAgentRunIndex()).modelsBySessionId.get(
        projectedRunIdentity(params.agentId, params.sessionId),
      );
}

export function buildProjectedAgentRunIndex(): ProjectedAgentRunIndex {
  const { contexts, lifecycleGeneration } = getAgentRunRegistryState();
  return buildAgentRunProjectionIndex({ contexts: contexts.values(), lifecycleGeneration });
}

export function resolveProjectedAgentRunProgressState(
  params: Parameters<typeof resolveAgentRunProjectionProgressState>[0] & {
    index?: ProjectedAgentRunIndex;
  },
): ProjectedAgentRunState | undefined {
  return resolveAgentRunProjectionProgressState(
    params,
    params.index ?? buildProjectedAgentRunIndex(),
  );
}

// Both the snapshot and its prepared queries are weak: cold rows never pin old run indexes.
const preparedProgressStates = new WeakMap<
  ProjectedAgentRunIndex,
  WeakMap<object, ProjectedAgentRunState | null>
>();

/** Bind an immutable query once; each owner-published run index supplies its progress fact. */
export function prepareProjectedAgentRunProgressState(
  query: Readonly<Parameters<typeof resolveAgentRunProjectionProgressState>[0]>,
) {
  return (index: ProjectedAgentRunIndex): ProjectedAgentRunState | undefined => {
    let facts = preparedProgressStates.get(index);
    if (!facts) {
      facts = new WeakMap();
      preparedProgressStates.set(index, facts);
    }
    let progress = facts.get(query);
    if (progress === undefined) {
      progress = resolveAgentRunProjectionProgressState(query, index) ?? null;
      facts.set(query, progress);
    }
    return progress ?? undefined;
  };
}

/** Clears context state for a run that has ended or been discarded. */
export function clearAgentRunContext(
  runId: string,
  lifecycleGeneration?: string,
  claimId?: string,
): void {
  const state = getAgentRunRegistryState();
  const existing = state.contexts.get(runId);
  if (lifecycleGeneration && existing && existing.lifecycleGeneration !== lifecycleGeneration) {
    return;
  }
  const owners = state.owners.get(runId);
  if (
    claimId &&
    (!owners ||
      (lifecycleGeneration && owners.lifecycleGeneration !== lifecycleGeneration) ||
      !owners.claimIds.has(claimId))
  ) {
    return;
  }
  // A rejected claimant's cleanup must not evict the exclusive owner.
  if (owners?.exclusiveClaimId && owners.exclusiveClaimId !== claimId) {
    return;
  }
  if (owners?.claimIds.size) {
    if (!lifecycleGeneration || owners.lifecycleGeneration === lifecycleGeneration) {
      const wasClearRequested = owners.clearRequested;
      owners.clearRequested = true;
      for (const [ownerClaimId, listener] of owners.clearListeners ?? []) {
        // A run-id-only terminal projection cannot identify a reused logical
        // execution. Its exact outer close or abort owns capability revocation.
        if (ownerClaimId === existing?.delegatedAuthority?.claimId) {
          continue;
        }
        listener(ownerClaimId);
      }
      if (!wasClearRequested) {
        bumpAgentRunIndexVersion(existing);
      }
    }
    return;
  }
  const removed = state.contexts.delete(runId);
  state.sequenceResetHandler?.(runId);
  clearAgentRunUsage(runId, lifecycleGeneration ?? existing?.lifecycleGeneration);
  if (removed) {
    bumpAgentRunIndexVersion(existing);
  }
}

/** Releases one tracked owner and clears its context after the final owner exits. */
export function releaseAgentRunContext(runId: string, claimId: string | undefined): void {
  if (!runId || !claimId) {
    return;
  }
  const state = getAgentRunRegistryState();
  const owners = state.owners.get(runId);
  if (!owners?.claimIds.delete(claimId)) {
    return;
  }
  const context = state.contexts.get(runId);
  const authority = context?.delegatedAuthority;
  if (context && authority?.claimId === claimId) {
    delete context.delegatedAuthority;
    delete context.assertSourceCurrent;
    notifyDelegatedAuthorityClosed(state, authority);
  }
  owners.sweepProtectedClaimIds.delete(claimId);
  const versionBeforeRelease = readAgentRunIndexVersion();
  owners.clearListeners?.delete(claimId);
  if (owners.exclusiveClaimId === claimId) {
    owners.exclusiveClaimId = undefined;
  }
  if (owners.claimIds.size > 0) {
    bumpAgentRunIndexVersion(context);
    return;
  }
  state.owners.delete(runId);
  if (owners.clearRequested || !owners.preserveAfterRelease) {
    clearAgentRunContext(runId, owners.lifecycleGeneration);
  }
  if (readAgentRunIndexVersion() === versionBeforeRelease) {
    bumpAgentRunIndexVersion(context);
  }
}

/** Sweeps orphaned run contexts that exceeded the given TTL. */
export function sweepStaleRunContexts(maxAgeMs = 30 * 60 * 1000): number {
  const state = getAgentRunRegistryState();
  const now = Date.now();
  let swept = 0;
  for (const [runId, context] of state.contexts) {
    // Queue capacity waits are live ownership, but never protect a retired lifecycle.
    if (
      context.lifecycleGeneration === state.lifecycleGeneration &&
      (state.queuedRunContextLeases?.get(context) ?? 0) > 0
    ) {
      continue;
    }
    const owners = state.owners.get(runId);
    if (
      owners?.lifecycleGeneration === state.lifecycleGeneration &&
      owners.sweepProtectedClaimIds.size > 0
    ) {
      continue;
    }
    // Use lastActiveAt (refreshed on every event) to avoid sweeping active runs.
    // Fall back to registeredAt, then treat missing timestamps as infinitely old.
    const lastSeen = context.lastActiveAt ?? context.registeredAt;
    const age = lastSeen ? now - lastSeen : Infinity;
    if (age > maxAgeMs) {
      state.contexts.delete(runId);
      state.sequenceResetHandler?.(runId);
      clearAgentRunUsage(runId, context.lifecycleGeneration);
      state.owners.delete(runId);
      swept += 1;
    }
  }
  if (swept > 0) {
    bumpAgentRunIndexVersion();
  }
  return swept;
}

export function resetAgentRunRegistryForTest(): void {
  const state = getAgentRunRegistryState();
  const hadRunContexts = state.contexts.size > 0;
  for (const context of state.contexts.values()) {
    context.approvalLeases?.close();
  }
  resetAgentRunUsageForTest();
  state.contexts.clear();
  state.owners.clear();
  state.queuedRunContextLeases = undefined;
  if (hadRunContexts) {
    bumpAgentRunIndexVersion();
  }
}
