import { AsyncLocalStorage } from "node:async_hooks";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { isPromiseLike } from "@openclaw/normalization-core/promise-like";
import { resolveGatewayLockDir } from "../config/paths.js";
import { resolveGlobalSingleton } from "../shared/global-singleton.js";
import {
  getOpenClawDatabaseMaintenanceScope,
  type OpenClawDatabaseMaintenanceScope,
  type OpenClawStateDatabaseReadAdmission,
} from "../state/openclaw-state-db-async-lifecycle.js";
import { OPENCLAW_SQLITE_BUSY_TIMEOUT_MS } from "../state/openclaw-state-db-contract.js";
import { resolveOpenClawStateDirForDatabasePath } from "../state/openclaw-state-db.paths.js";
import type { acquireFileLockSync } from "./file-lock-manager.js";
import { describeGatewayLockHolder, type LockPayload } from "./gateway-lock-payload.js";
import {
  resolveStateOwnerIdentity,
  resolveStateOwnerIdentityAsync,
  removeCreatedProjectionDirectories,
} from "./gateway-state-owner-directory.js";
import { createGatewayStateProcessOwnerRetiredError } from "./gateway-state-owner-errors.js";
import { startGatewayStateOwnerHeartbeat } from "./gateway-state-owner-heartbeat.js";
import {
  hasPhysicalOwnership,
  loseOwner,
  observeOwnerLoss,
  owners,
  readOwnerPaths,
  verifyOwnerLock,
  type GatewayStateProjection,
  type ProcessOwner,
  type StateOwnerFile,
} from "./gateway-state-owner-lifecycle.js";
import {
  acquireGatewayStateOwnerFile,
  assertPersistedStateDatabaseAccessAllowed,
  defaultPayload,
  GatewayStateOwnerContentionError,
  StateDatabaseAdmissionPendingError,
  StateDatabaseMaintenanceScopeError,
} from "./gateway-state-owner-record.js";
import {
  resolveIdentityPathViaExistingAncestor,
  resolveIdentityPathViaExistingAncestorSync,
} from "./path-existence.js";
import { normalizeWindowsPathForComparison } from "./path-guards.js";
import { normalizeSqliteNonNegativeInteger } from "./sqlite-busy-timeout.js";
import { runWithSqliteCleanup } from "./sqlite-lifecycle-errors.js";

export type { GatewayStateProjection } from "./gateway-state-owner-lifecycle.js";
export { GatewayStateOwnerContentionError } from "./gateway-state-owner-record.js";

export type StateDatabaseSchemaLease = {
  readonly path: string;
  assertCurrent(this: void): void;
  assertDatabaseAccess(this: void, databasePath: string): void;
  run<T>(this: void, operation: () => T): T;
  release(this: void): void;
};

type StateOwnerIdentity = ReturnType<typeof resolveStateOwnerIdentity>;

const schemaOwners = resolveGlobalSingleton(
  Symbol.for("openclaw.stateDatabaseSchemaOwners"),
  () =>
    new AsyncLocalStorage<
      ReadonlyMap<string, { lease: StateDatabaseSchemaLease; active: boolean }>
    >(),
);

/** The active lexical owner is live authority, not the existence of its sidecar. */
export function getStateDatabaseSchemaLease(
  databasePath: string,
): StateDatabaseSchemaLease | undefined {
  const entry = schemaOwners.getStore()?.get(resolveStateOwnerIdentity(databasePath).key);
  if (entry && !entry.active) {
    throw new Error("State schema maintenance scope is no longer current");
  }
  entry?.lease.assertCurrent();
  return entry?.lease;
}

/** Retry cold admission only; the same budget covers opening and its first unentered write. */
export function withStateDatabaseColdAdmission<T>(
  params: { databasePath: string; busyTimeoutMs: number; canRetry?: () => boolean },
  open: (remainingBusyTimeoutMs: () => number) => T,
): T {
  const budget = normalizeSqliteNonNegativeInteger(params.busyTimeoutMs, "busyTimeoutMs");
  const deadline = performance.now() + budget;
  const canonical = resolveIdentityPathViaExistingAncestorSync(params.databasePath);
  const remainingBusyTimeoutMs = () => Math.max(0, Math.ceil(deadline - performance.now()));
  const waiting = new Int32Array(new SharedArrayBuffer(Int32Array.BYTES_PER_ELEMENT));
  for (;;) {
    try {
      assertStateDatabaseAccessAllowed(params.databasePath);
      return open(remainingBusyTimeoutMs);
    } catch (error) {
      if (
        !(error instanceof StateDatabaseAdmissionPendingError) ||
        resolveIdentityPathViaExistingAncestorSync(error.databasePath) !== canonical ||
        params.canRetry?.() === false
      ) {
        throw error;
      }
      const remaining = deadline - performance.now();
      if (remaining <= 0) {
        throw error;
      }
      Atomics.wait(waiting, 0, 0, Math.min(10, remaining));
    }
  }
}

/** State cleanup preserves this owner until destructive work and native handles settle. */
export function resolveGatewayStateOwnerPath(databasePath: string): string {
  return resolveStateOwnerIdentity(databasePath).ownerPath;
}

function leaseForFile(
  pathname: string,
  lock: ReturnType<typeof acquireFileLockSync>,
  owner: ProcessOwner,
  projection?: StateOwnerFile,
): StateDatabaseSchemaLease {
  let released = false;
  const holdsPhysicalLease = () =>
    verifyOwnerLock(owner, lock) && (!projection || projection.verifyStillHeld());
  function run<T>(operation: () => T): T;
  function run(operation: () => unknown): unknown {
    lease.assertCurrent();
    readOwnerPaths.clear();
    const inherited = new Map(schemaOwners.getStore());
    const entry = { lease, active: true };
    inherited.set(owner.key, entry);
    const leave = () => {
      entry.active = false;
      readOwnerPaths.clear();
    };
    try {
      const result = schemaOwners.run(inherited, operation);
      if (isPromiseLike(result)) {
        return Promise.resolve(result).finally(leave);
      }
      leave();
      return result;
    } catch (error) {
      leave();
      throw error;
    }
  }
  const lease: StateDatabaseSchemaLease = {
    path: pathname,
    assertCurrent() {
      if (released || !holdsPhysicalLease()) {
        throw new Error("OpenClaw state ownership is no longer current");
      }
    },
    assertDatabaseAccess(databasePath) {
      if (
        released ||
        owners.get(owner.key) !== owner ||
        resolveStateOwnerIdentity(databasePath).key !== owner.key ||
        !holdsPhysicalLease()
      ) {
        throw new Error("OpenClaw state maintenance does not own this database");
      }
    },
    run,
    release() {
      readOwnerPaths.clear();
      if (!released) {
        projection?.release();
        lock.release();
        released = true;
        owner.locks.delete(lock);
        if (projection) {
          owner.locks.delete(projection);
        }
        if (owner.locks.size === 0 && owners.get(owner.key) === owner) {
          // Final physical release also ends its worker; retained schema leases keep both alive.
          void owner.heartbeat?.stop();
          owner.accepting = false;
          owners.delete(owner.key);
          owner.onReleased?.();
        }
      }
      // A failed directory cleanup remains retryable after physical lock release.
      if (owner.locks.size === 0) {
        removeCreatedProjectionDirectories(owner.projectionDirectories);
      }
    },
  };
  return lease;
}

/** One root owns startup or maintenance; only its registered custody can lend schema access. */
export function acquireGatewayStateOwner(params: {
  databasePath: string;
  payload?: LockPayload;
  projectionPath?: string;
  getProjection?: () => GatewayStateProjection | undefined;
  /** Custody held outside this process, such as the PostgreSQL install lock; abort retires it. */
  custody?: AbortSignal;
  /** Ends that outside custody once physical custody ends, including retained leases. */
  onReleased?: () => void;
}): StateDatabaseSchemaLease {
  const identity = resolveStateOwnerIdentity(params.databasePath);
  const pathname = identity.ownerPath;
  const held = owners.get(identity.key);
  if (held) {
    throw new GatewayStateOwnerContentionError(
      params.databasePath,
      undefined,
      describeGatewayLockHolder(held.payload, pathname, "live"),
      { pid: held.payload.pid, role: held.payload.role },
    );
  }
  const payload = params.payload
    ? {
        ...(params.payload.role === "sqlite-maintenance"
          ? defaultPayload(params.databasePath)
          : {}),
        ...params.payload,
        ownerId: params.payload.ownerId ?? randomUUID(),
      }
    : defaultPayload(params.databasePath);
  const owner: ProcessOwner = {
    key: identity.key,
    path: pathname,
    kind: "process",
    payload,
    projectionPath: params.projectionPath,
    getProjection: params.getProjection,
    locks: new Set(),
    projectionDirectories: [],
    lost: new AbortController(),
    accepting: true,
    onReleased: params.onReleased,
  };
  const lock = acquireGatewayStateOwnerFile(params.databasePath, pathname, payload);
  owner.locks.add(lock);
  readOwnerPaths.clear();
  owners.set(owner.key, owner);
  const lease = leaseForFile(pathname, lock, owner);
  try {
    owner.heartbeat = startGatewayStateOwnerHeartbeat(owner.locks, (error, lockPath) =>
      observeOwnerLoss(owner, error, lockPath),
    );
    // Admission, workers and the server lifecycle all observe this owner's lost signal.
    const custody = params.custody;
    const onCustodyLost = () => {
      const reason: unknown = custody?.reason;
      loseOwner(owner, reason instanceof Error ? reason : new Error("State custody was lost"));
    };
    custody?.addEventListener("abort", onCustodyLost, { once: true });
    lease.assertCurrent();
  } catch (error) {
    return runWithSqliteCleanup(lease, "state process ownership verification", () => {
      throw error;
    });
  }
  return {
    path: pathname,
    assertCurrent() {
      owner.lost.signal.throwIfAborted();
      if (!owner.accepting || owners.get(owner.key) !== owner) {
        throw createGatewayStateProcessOwnerRetiredError();
      }
      lease.assertCurrent();
    },
    assertDatabaseAccess: lease.assertDatabaseAccess,
    run: lease.run,
    release() {
      owner.accepting = false;
      lease.release();
    },
  };
}

/** Accepted schema work retains the sidecar even when its process owner stops lending. */
export function acquireStateDatabaseSchemaLease(
  databasePath: string,
  options: { busyTimeoutMs?: number } = {},
): StateDatabaseSchemaLease {
  readOwnerPaths.clear();
  const identity = resolveStateOwnerIdentity(databasePath);
  let owner = owners.get(identity.key);
  const pathname = owner?.path ?? identity.ownerPath;
  if (owner && (!owner.accepting || !hasPhysicalOwnership(owner))) {
    throw new GatewayStateOwnerContentionError(databasePath, owner.lost.signal.reason);
  }
  if (owner) {
    assertStateDatabaseAccessAllowed(databasePath);
  }
  const payload = owner?.payload ?? {
    ...defaultPayload(databasePath),
    stateOwnerKind: "schema" as const,
  };
  let lock: ReturnType<typeof acquireFileLockSync>;
  const projectionDirectories: ProcessOwner["projectionDirectories"] = [];
  try {
    lock = acquireGatewayStateOwnerFile(
      databasePath,
      pathname,
      payload,
      owner ? 0 : (options.busyTimeoutMs ?? OPENCLAW_SQLITE_BUSY_TIMEOUT_MS),
      projectionDirectories,
    );
  } catch (error) {
    if (error instanceof GatewayStateOwnerContentionError) {
      try {
        assertStateDatabaseAccessAllowed(databasePath);
      } catch (currentOwnerError) {
        if (currentOwnerError instanceof StateDatabaseAdmissionPendingError) {
          throw currentOwnerError;
        }
      }
    }
    throw error;
  }
  const projectionPath =
    owner?.projectionPath ??
    path.join(
      resolveGatewayLockDir(
        resolveOpenClawStateDirForDatabasePath(
          resolveIdentityPathViaExistingAncestorSync(databasePath),
        ),
      ),
      "gateway.state.lock",
    );
  let projection: StateOwnerFile;
  try {
    // The process owner retains its exact sidecar even when its root path moves.
    projection =
      owner?.getProjection?.()?.retain() ??
      acquireGatewayStateOwnerFile(
        databasePath,
        projectionPath,
        {
          ...payload,
          role: payload.role === "gateway" ? "gateway" : "agent-embedded",
        },
        0,
        projectionDirectories,
      );
  } catch (error) {
    return runWithSqliteCleanup(
      {
        release() {
          lock.release();
          removeCreatedProjectionDirectories(projectionDirectories);
        },
      },
      "state schema projection admission",
      () => {
        throw error;
      },
    );
  }
  if (owner) {
    owner.locks.add(lock);
    owner.locks.add(projection);
    owner.projectionDirectories.push(...projectionDirectories);
  } else {
    owner = {
      key: identity.key,
      path: pathname,
      kind: "schema",
      payload,
      projectionPath,
      locks: new Set([lock, projection]),
      projectionDirectories,
      lost: new AbortController(),
      accepting: true,
    };
    owners.set(owner.key, owner);
  }
  const lease = leaseForFile(pathname, lock, owner, projection);
  try {
    const heartbeat = (owner.heartbeat ??= startGatewayStateOwnerHeartbeat(
      owner.locks,
      (error, lockPath) => observeOwnerLoss(owner, error, lockPath),
    ));
    lease.assertCurrent();
    heartbeat.register(projection);
    return lease;
  } catch (error) {
    return runWithSqliteCleanup(lease, "state schema ownership verification", () => {
      throw error;
    });
  }
}

/** A nested maintenance scope can retain only an already-held process root for its exact database. */
export function tryBorrowGatewayStateOwner(
  databasePath: string,
): StateDatabaseSchemaLease | undefined {
  const owner = owners.get(resolveStateOwnerIdentity(databasePath).key);
  if (!owner || owner.kind !== "process") {
    return undefined;
  }
  if (!owner.accepting || !hasPhysicalOwnership(owner)) {
    throw new GatewayStateOwnerContentionError(databasePath, owner.lost.signal.reason);
  }
  assertStateDatabaseAccessAllowed(databasePath);
  return acquireStateDatabaseSchemaLease(databasePath);
}

/** Startup recovery requires this process's retained Gateway root, not a schema loan. */
export function hasActiveGatewayStateOwner(databasePath: string): boolean {
  const owner = owners.get(resolveStateOwnerIdentity(databasePath).key);
  return (
    owner?.kind === "process" &&
    owner.accepting &&
    (owner.payload.role ?? "gateway") === "gateway" &&
    hasPhysicalOwnership(owner)
  );
}

/** Capture registered process custody; a PID or copied lock payload grants no authority. */
export function captureGatewayStateOwner(databasePath: string) {
  const identity = resolveStateOwnerIdentity(databasePath);
  const { key } = identity;
  const owner = owners.get(key);
  if (!owner || owner.kind !== "process") {
    return undefined;
  }
  // A caller's current locator must still name this retained owner, never a successor.
  const assertCurrent = (selectedPath = databasePath) => {
    owner.lost.signal.throwIfAborted();
    const canonicalPath = resolveIdentityPathViaExistingAncestorSync(selectedPath);
    const currentKey =
      process.platform === "win32"
        ? normalizeWindowsPathForComparison(canonicalPath)
        : canonicalPath;
    if (owners.get(key) !== owner || !owner.accepting || currentKey !== key) {
      throw new GatewayStateOwnerContentionError(databasePath);
    }
    assertStateDatabaseAccessAtOwnerPath(databasePath, identity, undefined);
  };
  assertCurrent();
  return {
    ownerId: owner.payload.ownerId,
    role: owner.payload.role ?? "gateway",
    assertCurrent,
    // Async preparation is for retained native handles bound to this canonical target.
    prepareAccess: createStateDatabaseAccess(identity, owner).prepareAccess,
    signal: owner.lost.signal,
  };
}

type StateOwnerAdmission = Pick<
  OpenClawStateDatabaseReadAdmission,
  "databasePath" | "identity" | "assertCurrent"
>;

export type PreparedStateDatabaseReadAccess = {
  assertReadAllowed(captured?: Parameters<typeof assertStateDatabaseAccessAllowed>[1]): void;
};

/** Native generations qualify a fresh locator while retaining their original process owner. */
export function captureGatewayStateOwnerAsync(admission: StateOwnerAdmission) {
  return captureAdmittedGatewayStateOwner(admission, true);
}

/** Warm reads consume this owner's existing path admission without another physical probe. */
export function prepareStateDatabaseReadAccess(admission: StateOwnerAdmission) {
  return captureAdmittedGatewayStateOwner(admission, false);
}

async function captureAdmittedGatewayStateOwner(admission: StateOwnerAdmission, fresh: boolean) {
  admission.assertCurrent();
  const canonicalPath = admission.identity.canonicalPath;
  const key =
    process.platform === "win32" ? normalizeWindowsPathForComparison(canonicalPath) : canonicalPath;
  const owner = owners.get(key);
  if (!owner || owner.kind !== "process") {
    return undefined;
  }
  const identity = { canonicalPath, key, ownerPath: owner.path };
  const assertRegistered = () => {
    admission.assertCurrent();
    owner.lost.signal.throwIfAborted();
    if (owners.get(key) !== owner) {
      throw createGatewayStateProcessOwnerRetiredError();
    }
  };
  const assertCurrent = () => {
    assertRegistered();
    if (!owner.accepting) {
      throw createGatewayStateProcessOwnerRetiredError();
    }
    assertStateDatabaseAccessAtOwnerPath(canonicalPath, identity, undefined);
  };
  const access = createStateDatabaseAccess(identity, owner);
  const assertReadAllowed = (captured?: Parameters<typeof assertStateDatabaseAccessAllowed>[1]) => {
    assertRegistered();
    access.assertReadAllowed(captured);
  };
  const pathname = path.resolve(admission.databasePath);
  const assertCapture = fresh ? assertCurrent : assertRegistered;
  assertCapture();
  if (fresh || readOwnerPaths.get(pathname) !== owner) {
    const observed = await resolveIdentityPathViaExistingAncestor(pathname);
    assertCapture();
    const observedKey =
      process.platform === "win32" ? normalizeWindowsPathForComparison(observed) : observed;
    if (observedKey !== key) {
      throw new GatewayStateOwnerContentionError(admission.databasePath);
    }
  }
  if (!fresh) {
    assertReadAllowed();
    if (readOwnerPaths.get(path.resolve(canonicalPath)) === owner) {
      readOwnerPaths.set(pathname, owner);
    }
  }
  return {
    ownerId: owner.payload.ownerId,
    role: owner.payload.role ?? "gateway",
    signal: owner.lost.signal,
    assertCurrent,
    assertReadAllowed,
    prepareAccess: access.prepareAccess,
  };
}

/** Reads within an admission reuse process custody; the next admission verifies the lock. */
export function assertStateDatabaseReadAllowed(
  databasePath: string,
  captured?: Parameters<typeof assertStateDatabaseAccessAllowed>[1],
): void {
  assertStateDatabaseReadAtOwnerPath(databasePath, captured);
}

function assertStateDatabaseReadAtOwnerPath(
  databasePath: string,
  captured: Parameters<typeof assertStateDatabaseAccessAllowed>[1],
  prepared?: StateOwnerIdentity,
): void {
  if (owners.size === 0) {
    assertStateDatabaseAccessAtOwnerPath(
      databasePath,
      prepared ?? resolveStateOwnerIdentity(databasePath),
      captured,
    );
    return;
  }
  const key = path.resolve(databasePath);
  const cached = readOwnerPaths.get(key);
  if (cached?.accepting) {
    return;
  }
  const identity = prepared ?? resolveStateOwnerIdentity(databasePath);
  const owner = owners.get(identity.key);
  const role = owner?.payload.role ?? "gateway";
  if (
    !owner ||
    owner.kind !== "process" ||
    !owner.accepting ||
    (role !== "gateway" && role !== "agent-embedded")
  ) {
    // Maintenance/schema authority and foreign owners keep their existing fresh checks.
    assertStateDatabaseAccessAtOwnerPath(databasePath, identity, captured);
    return;
  }
  if (!hasPhysicalOwnership(owner)) {
    // A recorded loss already names the lock and the restart step; rethrow it unwrapped.
    owner.lost.signal.throwIfAborted();
    throw new Error(
      `OpenClaw state ownership at ${databasePath} was lost: owner lock was removed or replaced; restart the Gateway.`,
    );
  }
  readOwnerPaths.set(key, owner);
}

/** Ordinary SQLite access observes maintenance; it never borrows schema authority. */
export function assertStateDatabaseAccessAllowed(
  databasePath: string,
  captured?: {
    maintenanceScope?: OpenClawDatabaseMaintenanceScope;
    schemaLease?: Pick<StateDatabaseSchemaLease, "assertDatabaseAccess">;
  },
): void {
  assertStateDatabaseAccessAtOwnerPath(
    databasePath,
    resolveStateOwnerIdentity(databasePath),
    captured,
  );
}

/** Retained handles keep their admitted paths; reopening captures a fresh identity. */
export async function captureStateDatabaseAccess(databasePath: string) {
  return createStateDatabaseAccess(await resolveStateOwnerIdentityAsync(databasePath));
}
// Cleanup pins its process owner; ordinary handles discover current custody on each request.
function createStateDatabaseAccess(identity: StateOwnerIdentity, capturedOwner?: ProcessOwner) {
  const { canonicalPath } = identity;
  const registered = owners.get(identity.key);
  return {
    canonicalPath,
    processOwner:
      registered?.kind === "process"
        ? {
            role: registered.payload.role ?? "gateway",
            signal: registered.lost.signal,
            assertCurrent() {
              registered.lost.signal.throwIfAborted();
              if (!registered.accepting || owners.get(identity.key) !== registered) {
                throw createGatewayStateProcessOwnerRetiredError();
              }
            },
          }
        : undefined,
    prepareAccess: async (scope?: Parameters<typeof assertStateDatabaseAccessAllowed>[1]) => {
      const owner = capturedOwner ?? owners.get(identity.key);
      const role = owner?.payload.role ?? "gateway";
      if (
        !owner ||
        owner.kind !== "process" ||
        !owner.accepting ||
        (role !== "gateway" && role !== "agent-embedded")
      ) {
        // Offline schema/bootstrap and native SDK owners retain their synchronous lease boundary.
        assertStateDatabaseAccessAtOwnerPath(canonicalPath, identity, scope);
        return (current = scope) => {
          if (owner && owners.get(identity.key) !== owner) {
            throw createGatewayStateProcessOwnerRetiredError();
          }
          assertStateDatabaseReadAtOwnerPath(canonicalPath, current, identity);
        };
      }
      const heartbeat = owner.heartbeat;
      const root = owner.locks.values().next().value;
      const projection = owner.getProjection?.();
      if (!heartbeat || !root) {
        throw createGatewayStateProcessOwnerRetiredError();
      }
      const assertCurrent = (current = scope) => {
        owner.lost.signal.throwIfAborted();
        heartbeat.assertActive();
        if (owners.get(identity.key) !== owner || owner.heartbeat !== heartbeat) {
          throw createGatewayStateProcessOwnerRetiredError();
        }
        if (!owner.accepting) {
          // Accepted schema work retains its native lease after the root stops lending.
          assertStateDatabaseAccessAtOwnerPath(canonicalPath, identity, current);
          return;
        }
        if (!owner.locks.has(root) || owner.getProjection?.() !== projection) {
          throw createGatewayStateProcessOwnerRetiredError();
        }
      };
      assertCurrent();
      const paths = [root.lockPath];
      if (projection) {
        paths.push(projection.lockPath);
      }
      const current = await heartbeat.verify(paths).catch((error: unknown) => {
        owner.lost.signal.throwIfAborted();
        throw error;
      });
      // A fresh physical observation belongs only to this request and owner generation.
      assertCurrent();
      if (!current) {
        const error = new Error(
          `${root.lockPath}: no longer current; lock removed/replaced; restart the Gateway.`,
        );
        loseOwner(owner, error);
        throw error;
      }
      // Read admission consumes this verified custody without another host filesystem probe.
      readOwnerPaths.set(path.resolve(canonicalPath), owner);
      return assertCurrent;
    },
    // Native close can request its original schema custody after ordinary admission retires.
    assertReadAllowed(captured?: Parameters<typeof assertStateDatabaseAccessAllowed>[1]) {
      assertStateDatabaseReadAtOwnerPath(canonicalPath, captured, identity);
    },
  };
}

function assertStateDatabaseAccessAtOwnerPath(
  databasePath: string,
  identity: StateOwnerIdentity,
  captured: Parameters<typeof assertStateDatabaseAccessAllowed>[1],
): void {
  const assertMaintenance = () => {
    const schemaLease = captured ? captured.schemaLease : getStateDatabaseSchemaLease(databasePath);
    if (schemaLease) {
      schemaLease.assertDatabaseAccess(databasePath);
      return;
    }
    const scope = captured ? captured.maintenanceScope : getOpenClawDatabaseMaintenanceScope();
    if (!scope) {
      throw new StateDatabaseMaintenanceScopeError(databasePath);
    }
    scope.assertDatabaseAccess(databasePath);
  };
  const local = owners.get(identity.key);
  if (local) {
    if (!hasPhysicalOwnership(local)) {
      local.lost.signal.throwIfAborted();
      throw new Error(
        `OpenClaw state ownership at ${databasePath} was lost: owner lock was removed or replaced; restart the Gateway.`,
      );
    }
    const role = local.payload.role ?? "gateway";
    if (!local.accepting || (role !== "gateway" && role !== "agent-embedded")) {
      assertMaintenance();
    }
    return;
  }
  assertPersistedStateDatabaseAccessAllowed({
    databasePath,
    ownerPath: identity.ownerPath,
    assertMaintenance,
  });
}

/** Cleanup must compete with local roots too; it cannot borrow a live Gateway's authority. */
export function tryAcquireGatewayStateOwner(databasePath: string): StateDatabaseSchemaLease | null {
  try {
    return acquireGatewayStateOwner({ databasePath });
  } catch (error) {
    if (error instanceof GatewayStateOwnerContentionError) {
      return null;
    }
    throw error;
  }
}
