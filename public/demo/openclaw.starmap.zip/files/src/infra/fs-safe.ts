// Re-exports fs-safe helpers with OpenClaw defaults and wrappers.
import fs from "node:fs/promises";
import path from "node:path";
import {
  ensureDirectoryWithinRoot,
  findExistingAncestor,
  readLocalFileFromRoots as readFsSafeLocalFileFromRoots,
} from "@openclaw/fs-safe/advanced";
import "@openclaw/fs-safe/errors";
import { writeExternalFileWithinRoot as writeExternalFileWithinRootBase } from "@openclaw/fs-safe/output";
import { root as fsSafeRoot, type ReadResult, type RootDefaults } from "@openclaw/fs-safe/root";
import type { CompatibleFsSafeRoot, LegacyNonBlockingReadOption } from "./fs-safe-compat.js";

export { FsSafeError, type FsSafeErrorCode } from "@openclaw/fs-safe/errors";
export {
  canonicalPathFromExistingAncestor,
  findExistingAncestor,
  resolveAbsolutePathForRead,
  resolveAbsolutePathForWrite,
} from "@openclaw/fs-safe/advanced";
export { isPathInside } from "@openclaw/fs-safe/path";
export { pathExistsSync } from "@openclaw/fs-safe/advanced";
export { movePathToTrash } from "@openclaw/fs-safe/advanced";
export { resolveLocalPathFromRootsSync } from "@openclaw/fs-safe/advanced";
export {
  appendRegularFile,
  readRegularFile,
  readRegularFileSync,
  statRegularFile,
  statRegularFileSync,
} from "@openclaw/fs-safe/advanced";
export {
  openLocalFileSafely,
  readLocalFileSafely,
  resolveOpenedFileRealPathForHandle,
  type OpenResult,
  type ReadResult,
} from "@openclaw/fs-safe/root";
export { sanitizeUntrustedFileName } from "@openclaw/fs-safe/advanced";
export { readSecureFile } from "@openclaw/fs-safe/secure-file";
export { walkDirectory, walkDirectorySync } from "@openclaw/fs-safe/walk";
export { withTimeout } from "@openclaw/fs-safe/advanced";

/** Follow links; all filesystem failures mean the optional path is unavailable. */
export async function pathExists(filePath: string): Promise<boolean> {
  try {
    let target = filePath;
    // fs-safe's async pathExists still uses statSync. Preserve its private
    // Windows namespace-root adaptation while using asynchronous stat here.
    if (process.platform === "win32" && /^[\\/]{2}[?.][\\/][A-Za-z]:[\\/]/.test(filePath)) {
      if (filePath.length === 7) {
        target = `${filePath[4]}:\\`;
      } else {
        const resolved = path.resolve(filePath);
        if (/^[\\/]{2}[?.][\\/][A-Za-z]:$/.test(resolved) && !filePath.includes(":", 6)) {
          target = `${resolved[4]}:\\`;
        }
      }
    }
    await fs.stat(target);
    return true;
  } catch {
    return false;
  }
}

// Root.walk remains core-only on this facade; temp workspace stores keep their shipped full Root.
export type Root = Omit<CompatibleFsSafeRoot, "walk">;

export const readLocalFileFromRoots: (
  options: Parameters<typeof readFsSafeLocalFileFromRoots>[0] & LegacyNonBlockingReadOption,
) => ReturnType<typeof readFsSafeLocalFileFromRoots> = readFsSafeLocalFileFromRoots;

export async function root(
  rootDir: string,
  defaults?: RootDefaults & LegacyNonBlockingReadOption,
): Promise<Root> {
  return await fsSafeRoot(rootDir, defaults);
}

export type ExternalFileWriteOptions = {
  rootDir: string;
  path: string;
  write: (tempPath: string) => Promise<void>;
  fallbackFileName?: string;
  tempPrefix?: string;
};

export type ExternalFileWriteResult = {
  path: string;
};

export async function ensureAbsoluteDirectory(
  dirPath: string,
  options?: { scopeLabel?: string; mode?: number },
): Promise<{ ok: true; path: string } | { ok: false; error: Error }> {
  const absolutePath = path.resolve(dirPath);
  const scopeLabel = options?.scopeLabel ?? "directory";
  const existingAncestor = await findExistingAncestor(absolutePath);
  if (existingAncestor && existingAncestor !== absolutePath) {
    const result = await ensureDirectoryWithinRoot({
      rootDir: existingAncestor,
      requestedPath: path.relative(existingAncestor, absolutePath),
      scopeLabel,
      mode: options?.mode,
    });
    return result.ok ? result : { ok: false, error: new Error(result.error) };
  }
  if (existingAncestor) {
    try {
      const stat = await fs.lstat(absolutePath);
      if (!stat.isSymbolicLink() && stat.isDirectory()) {
        return { ok: true, path: absolutePath };
      }
    } catch {
      // Fall through to the uniform invalid-path result below.
    }
  }
  return { ok: false, error: new Error(`Invalid path: must stay within ${scopeLabel}`) };
}

export async function writeExternalFileWithinRoot(
  options: ExternalFileWriteOptions,
): Promise<ExternalFileWriteResult> {
  const requestedPath = path.resolve(options.rootDir, options.path);
  const result = await writeExternalFileWithinRootBase({
    rootDir: options.rootDir,
    path: options.path,
    write: options.write,
    staging: "sibling",
    producerIsolation: "private-directory",
    fallbackFileName: options.fallbackFileName ?? options.tempPrefix,
  });
  // Preserve the caller-facing path spelling while carrying forward any
  // portable basename selected by fs-safe (for example, /var vs /private/var).
  return { path: path.join(path.dirname(requestedPath), path.basename(result.path)) };
}

/** @deprecated Use root(rootDir).read(relativePath, options). */
export async function readFileWithinRoot(params: {
  rootDir: string;
  relativePath: string;
  rejectHardlinks?: boolean;
  /** @deprecated Omit this hint; safe reads always use nonblocking admission where supported. */
  nonBlockingRead?: boolean;
  allowSymlinkTargetWithinRoot?: boolean;
  maxBytes?: number;
}): Promise<ReadResult> {
  const fsRoot = await fsSafeRoot(params.rootDir);
  return await fsRoot.read(params.relativePath, {
    hardlinks: params.rejectHardlinks === false ? "allow" : "reject",
    maxBytes: params.maxBytes,
    symlinks: params.allowSymlinkTargetWithinRoot === true ? "follow-within-root" : "reject",
  });
}

/** @deprecated Use root(rootDir).write(relativePath, data, options). */
export async function writeFileWithinRoot(params: {
  rootDir: string;
  relativePath: string;
  data: string | Buffer;
  encoding?: BufferEncoding;
  mkdir?: boolean;
}): Promise<void> {
  const fsRoot = await root(params.rootDir);
  await fsRoot.write(params.relativePath, params.data, {
    encoding: params.encoding,
    mkdir: params.mkdir,
  });
}
