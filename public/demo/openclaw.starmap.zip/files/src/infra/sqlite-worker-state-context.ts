import { AsyncLocalStorage } from "node:async_hooks";
import { resolveGlobalSingleton } from "../shared/global-singleton.js";
import {
  withArtifactPreservingStateReads,
  withLiveStateReads,
} from "../state/artifact-preserving-state-reads.js";
import type { OpenClawStateIntegrityAdmission } from "../state/openclaw-state-db-async-lifecycle.js";
import { withExistingOpenClawStateSchema } from "../state/openclaw-state-db-schema-policy.js";
import {
  getDatabaseEngineSelection,
  type DatabaseEngineSelection,
} from "./database-engine/context.js";
import {
  withGatewayServiceInstallation,
  type GatewayServiceInstallation,
} from "./gateway-service-installation-context.js";

/** Resolved host facts for the canonical shared-state owner, never authority. */
export type SqliteWorkerStateContext = {
  databaseEngineSelection?: DatabaseEngineSelection;
  environment: NodeJS.ProcessEnv & {
    OPENCLAW_STATE_DIR: string;
    OPENCLAW_SUPERVISOR_MODE?: "external";
  };
  /** Selected config inputs for native shared-state initialization, not command environment. */
  initializationEnvironment?: NodeJS.ProcessEnv;
  /** Original default cron selector, before initialization pins the physical state directory. */
  initializationCronDefaultStoreKey?: string;
  /** Known agent paths preserve deletion-history uncertainty during native initialization. */
  initializationAgentPaths?: readonly string[];
  existingSchemaPath?: string;
  gatewayServiceInstallation?: GatewayServiceInstallation;
  stateIntegrity?: OpenClawStateIntegrityAdmission;
  artifactPreservingReads?: true;
  liveStateReads?: true;
  /** Actor-owned exclusion for autonomous WAL work, never write authority. */
  scheduledMaintenanceSuspension?: SharedArrayBuffer;
};

export function captureSqliteWorkerStateContext(
  context: SqliteWorkerStateContext,
): SqliteWorkerStateContext {
  return {
    databaseEngineSelection: context.databaseEngineSelection ?? getDatabaseEngineSelection(),
    environment: { ...context.environment },
    initializationCronDefaultStoreKey: context.initializationCronDefaultStoreKey,
    ...(context.initializationEnvironment
      ? { initializationEnvironment: { ...context.initializationEnvironment } }
      : {}),
    ...(context.initializationAgentPaths
      ? { initializationAgentPaths: [...context.initializationAgentPaths] }
      : {}),
    existingSchemaPath: context.existingSchemaPath,
    gatewayServiceInstallation: context.gatewayServiceInstallation,
    ...(context.stateIntegrity ? { stateIntegrity: context.stateIntegrity } : {}),
    artifactPreservingReads: context.artifactPreservingReads,
    liveStateReads: context.liveStateReads,
    ...(context.scheduledMaintenanceSuspension
      ? { scheduledMaintenanceSuspension: context.scheduledMaintenanceSuspension }
      : {}),
  };
}

/** Charge captured initialization facts together with the request bytes retained by admission. */
export function sqliteWorkerRequestBytes(
  input: Uint8Array,
  context?: SqliteWorkerStateContext,
  preparation?: Uint8Array,
): number {
  const agentPathBytes =
    context?.initializationAgentPaths?.reduce(
      (bytes, agentPath) => bytes + Buffer.byteLength(agentPath, "utf8"),
      0,
    ) ?? 0;
  return [context?.environment, context?.initializationEnvironment].reduce(
    (bytes, environment) =>
      Object.entries(environment ?? {}).reduce(
        (total, [key, value]) =>
          total + Buffer.byteLength(key, "utf8") + Buffer.byteLength(value ?? "", "utf8"),
        bytes,
      ),
    input.byteLength +
      Buffer.byteLength(JSON.stringify(context?.databaseEngineSelection) ?? "", "utf8") +
      Buffer.byteLength(JSON.stringify(context?.gatewayServiceInstallation) ?? "", "utf8") +
      (preparation?.byteLength ?? 0) +
      agentPathBytes +
      Buffer.byteLength(context?.initializationCronDefaultStoreKey ?? "", "utf8") +
      (context?.scheduledMaintenanceSuspension?.byteLength ?? 0),
  );
}

// Source hosts and built backends can load separate module copies in one Worker.
const stateContexts = resolveGlobalSingleton(
  Symbol.for("openclaw.sqliteWorkerStateContext"),
  () =>
    new AsyncLocalStorage<
      SqliteWorkerStateContext & {
        existingDatabase?: { databasePath: string; identity: string };
      }
    >(),
);

/** Keep the actor's live maintenance holds after the opening command returns. */
export function captureSqliteWorkerWalMaintenanceSuspension(): (() => boolean) | undefined {
  const buffer = stateContexts.getStore()?.scheduledMaintenanceSuspension;
  if (!buffer) {
    return undefined;
  }
  const holds = new Int32Array(buffer);
  return () => Atomics.load(holds, 0) > 0;
}

/** Original selector is an initialization fact, never a path to open or write authority. */
export function getSqliteWorkerCronDefaultStoreKey(): string | undefined {
  return stateContexts.getStore()?.initializationCronDefaultStoreKey;
}

/** Preserve factory facts across later commands without changing their captured host context. */
export function withSqliteWorkerExistingDatabase<T>(
  databasePath: string,
  identity: string,
  operation: () => T,
): T {
  return stateContexts.run(
    {
      ...getSqliteWorkerStateContext(),
      existingDatabase: { databasePath, identity },
    },
    operation,
  );
}

/** Only cold writable opens need this factory's prior-existence constraint. */
export function getSqliteWorkerExistingDatabaseIdentity(databasePath: string): string | undefined {
  const existing = stateContexts.getStore()?.existingDatabase;
  return existing?.databasePath === databasePath ? existing.identity : undefined;
}

export function getSqliteWorkerStateIntegrityAdmission():
  | OpenClawStateIntegrityAdmission
  | undefined {
  return stateContexts.getStore()?.stateIntegrity;
}

export function runWithSqliteWorkerStateContext<T>(
  context: SqliteWorkerStateContext,
  operation: () => T,
): T {
  const run = () =>
    withGatewayServiceInstallation({ installation: context.gatewayServiceInstallation }, () =>
      stateContexts.run(context, () =>
        context.existingSchemaPath === undefined
          ? operation()
          : withExistingOpenClawStateSchema({ path: context.existingSchemaPath }, operation),
      ),
    );
  const inspect = () =>
    context.artifactPreservingReads
      ? withArtifactPreservingStateReads(run, { agentDatabases: true })
      : run();
  return context.liveStateReads ? withLiveStateReads(inspect) : inspect();
}

export function getSqliteWorkerStateContext(): SqliteWorkerStateContext {
  const context = stateContexts.getStore();
  if (!context) {
    throw new Error("Shared-state SQLite requires captured host context");
  }
  return context;
}
