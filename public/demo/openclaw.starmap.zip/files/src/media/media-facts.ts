import type { MediaKind } from "@openclaw/media-core/constants";
import {
  getFileExtension,
  kindFromMime,
  mimeTypeFromFilePath,
  normalizeMimeType,
} from "@openclaw/media-core/mime";
import {
  asFiniteNumberInRange,
  asPositiveSafeInteger as normalizePositiveInteger,
} from "@openclaw/normalization-core/number-coercion";
import { asNonArrayRecord } from "@openclaw/normalization-core/record-coerce";
import { normalizeOptionalString } from "@openclaw/normalization-core/string-coerce";
import { cloneTranscriptEnvelope } from "../shared/transcript-payload-ownership.js";
import type { PromptImageOrderEntry } from "./prompt-image-order.js";

/** One ordered runtime attachment; array position is its alignment identity. */
export type MediaFact = {
  path?: string;
  url?: string;
  contentType?: string;
  kind?: MediaKind;
  fileName?: string;
  /** Composer attachment provenance for display; never part of model input. */
  origin?: "paste" | "file";
  sizeBytes?: number;
  durationMs?: number;
  width?: number;
  height?: number;
  transcribed?: boolean;
  messageId?: string;
  /** Supplemental quote provenance; absent on current-message media. */
  source?: "quote";
  workspaceDir?: string;
  /** Internal proof that this exact fact was covered by a legacy staged projection. */
  staged?: boolean;
  // Declared field, not a symbol: suppression must survive every fact copy or
  // reprojection boundary; described images otherwise rehydrate or count failed.
  // Structured persistence may retain it; legacy Media* projections never emit it.
  hydrationSuppressed?: boolean;
  /** Run-only: this turn could not read the attachment. Never persisted, so later turns retry it. */
  unresolvedThisTurn?: boolean;
};

export type MediaFactInput = {
  [Key in keyof MediaFact]?: MediaFact[Key] | null;
};

const RUNTIME_PROMPT_MEDIA_FACTS = Symbol.for("openclaw.runtimePromptMediaFacts");

/** Attaches facts to a runtime prompt message without changing serialized/model-visible bytes. */
export function attachRuntimePromptMediaFacts<T extends object>(
  message: T,
  media: readonly MediaFact[],
  imageOrder?: readonly PromptImageOrderEntry[],
): T {
  const normalized = normalizeMediaFacts(media);
  if (imageOrder?.length) {
    Object.defineProperty(normalized, "imageOrder", { value: [...imageOrder] });
  }
  Object.defineProperty(message, RUNTIME_PROMPT_MEDIA_FACTS, {
    configurable: true,
    // Symbols survive in-memory projections without entering transcript JSON.
    enumerable: true,
    writable: true,
    value: normalized,
  });
  return message;
}

export function readRuntimePromptMediaFacts(message: object): MediaFact[] | undefined {
  const media = (message as Record<PropertyKey, unknown>)[RUNTIME_PROMPT_MEDIA_FACTS];
  return Array.isArray(media) ? (media as MediaFact[]) : undefined;
}

/**
 * Pair run-only skips by source and occurrence; recorded facts remain retryable.
 * Staged copies retain media:// URLs. URL-less remote restaging can miss a match
 * and retry this turn; a failed read stays visible through the existing notice.
 */
export function applyRunHydrationSuppression(
  recorded: readonly MediaFact[],
  run: readonly MediaFact[] | undefined,
): MediaFact[] {
  const runFlagsByKey = new Map<string, boolean[]>();
  for (const fact of run ?? []) {
    const key = fact.url ?? fact.path;
    if (key) {
      const flags = runFlagsByKey.get(key) ?? [];
      flags.push(fact.unresolvedThisTurn === true);
      runFlagsByKey.set(key, flags);
    }
  }
  return recorded.map((fact) => {
    const key = fact.url ?? fact.path;
    const suppressed = key ? runFlagsByKey.get(key)?.shift() : undefined;
    return suppressed ? { ...fact, hydrationSuppressed: true } : fact;
  });
}

/** Reads the canonical persisted media envelope without consulting legacy top-level fields. */
export function readPersistedMediaFacts(message: object): MediaFact[] | undefined {
  const media = readPersistedMediaFactInputs(message);
  return media?.map((entry, index) => normalizeMediaFact<MediaFactInput>(entry, index));
}

function readPersistedMediaFactInputs(message: object): Array<MediaFactInput | null> | undefined {
  const metadata = asNonArrayRecord(asNonArrayRecord(message)["__openclaw"]);
  return Array.isArray(metadata.media)
    ? (metadata.media as Array<MediaFactInput | null>)
    : undefined;
}

const LEGACY_MEDIA_CONTEXT_KEYS = [
  "MediaPath",
  "MediaPaths",
  "MediaUrl",
  "MediaUrls",
  "MediaType",
  "MediaTypes",
  "MediaDir",
  "MediaTranscribedIndexes",
  "MediaStaged",
  "MediaWorkspaceDir",
] as const;
export type LegacyMediaContextKey = (typeof LEGACY_MEDIA_CONTEXT_KEYS)[number];

export const PERSISTED_LEGACY_MEDIA_KEYS = [
  "MediaPath",
  "MediaPaths",
  "MediaUrl",
  "MediaUrls",
  "MediaType",
  "MediaTypes",
  "MediaTranscribedIndexes",
  "MediaStaged",
  "MediaWorkspaceDir",
] as const;

/** Returns whether a top-level retired carrier contains an attachment fact worth migrating. */
export function hasMeaningfulRetiredMediaCarrier(message: object): boolean {
  const record = message as Record<string, unknown>;
  const retired: Record<string, unknown> = {};
  if (Array.isArray(record.media)) {
    retired.media = record.media;
  }
  for (const key of PERSISTED_LEGACY_MEDIA_KEYS) {
    if (Object.hasOwn(record, key)) {
      retired[key] = record[key];
    }
  }
  if (resolveMediaFacts(retired as MediaFactSource).some(isMeaningfulMediaFact)) {
    return true;
  }
  const canonical = readPersistedMediaFacts(message) ?? [];
  if (canonical.length === 0) {
    return false;
  }
  const transcribedIndexes = Array.isArray(record.MediaTranscribedIndexes)
    ? record.MediaTranscribedIndexes
    : [];
  return (
    transcribedIndexes.some(
      (index) => Number.isInteger(index) && index >= 0 && index < canonical.length,
    ) ||
    Boolean(normalizeOptionalString(record.MediaWorkspaceDir)) ||
    record.MediaStaged === true
  );
}

const MEDIA_KINDS = [
  "image",
  "audio",
  "video",
  "document",
  "sticker",
  "unknown",
] as const satisfies readonly MediaKind[];

export function isMediaKind(kind: string | undefined): kind is MediaKind {
  return MEDIA_KINDS.some((candidate) => candidate === kind);
}

type CanonicalizedPersistedMediaMessage<T extends object> = {
  changed: boolean;
  message: T;
};

/** Canonicalizes persisted user-message media; ambiguous sparse legacy arrays are rejected. */
export function canonicalizePersistedUserMessageMedia<T extends object>(
  message: T,
): CanonicalizedPersistedMediaMessage<T> {
  const record = message as Record<string, unknown>;
  const hadLegacy = PERSISTED_LEGACY_MEDIA_KEYS.some((key) => Object.hasOwn(record, key));
  const hadTopLevelMedia = Object.hasOwn(record, "media");
  const canonical = readPersistedMediaFactInputs(message);
  if (!hadLegacy && !hadTopLevelMedia && canonical === undefined) {
    return { changed: false, message };
  }

  const topLevelMedia = Array.isArray(record.media)
    ? (record.media as readonly MediaFactInput[])
    : undefined;
  let source: MediaFactSource = {
    ...record,
    media: (canonical ?? topLevelMedia) as readonly MediaFactInput[] | undefined,
  };
  const paths = Array.isArray(source.MediaPaths) ? source.MediaPaths : [];
  const urls = Array.isArray(source.MediaUrls) ? source.MediaUrls : [];
  const types = Array.isArray(source.MediaTypes) ? source.MediaTypes : [];
  const slotCount = Math.max(paths.length, urls.length);
  if (types.length > 0 && types.length < slotCount) {
    const facts = normalizeMediaFacts(source.media);
    let ambiguous = false;
    for (let index = 0; index < slotCount; index += 1) {
      const meaningful =
        normalizeOptionalString(paths[index]) ?? normalizeOptionalString(urls[index]);
      const fact = facts[index];
      if (meaningful && (!(fact?.path ?? fact?.url) || !(fact?.contentType ?? fact?.kind))) {
        ambiguous = true;
        break;
      }
    }
    if (hadLegacy && ambiguous) {
      throw new Error("legacy media arrays have ambiguous sparse positional alignment");
    }
    if (!ambiguous) {
      source = { ...source, MediaType: undefined, MediaTypes: [] };
    }
  }
  const resolvedMedia = resolveMediaFacts(source);
  const stagedMedia = source.MediaStaged === true ? resolveStagedMediaFacts(source) : undefined;
  const legacyTypes = Array.isArray(source.MediaTypes) ? source.MediaTypes : [];
  const canonicalInputs = Array.isArray(source.media) ? source.media : [];
  const media: MediaFact[] = [];
  for (const [index, fact] of resolvedMedia.entries()) {
    const legacyType = normalizeOptionalString(
      legacyTypes[index] ?? (index === 0 ? source.MediaType : undefined),
    );
    const existing = canonicalInputs[index];
    const bareLegacyKind =
      legacyType &&
      isMediaKind(legacyType) &&
      !normalizeOptionalString(existing?.contentType) &&
      existing?.kind === undefined;
    const explicitKind = existing?.kind ?? (bareLegacyKind ? legacyType : undefined);
    media.push({
      ...(fact.path ? { path: fact.path } : {}),
      ...(fact.url ? { url: fact.url } : {}),
      ...(fact.contentType && !bareLegacyKind ? { contentType: fact.contentType } : {}),
      ...(explicitKind ? { kind: explicitKind } : {}),
      ...(fact.fileName ? { fileName: fact.fileName } : {}),
      ...(fact.origin ? { origin: fact.origin } : {}),
      ...(fact.sizeBytes !== undefined ? { sizeBytes: fact.sizeBytes } : {}),
      ...(fact.durationMs ? { durationMs: fact.durationMs } : {}),
      ...(fact.width ? { width: fact.width } : {}),
      ...(fact.height ? { height: fact.height } : {}),
      ...(fact.transcribed ? { transcribed: true } : {}),
      ...(fact.messageId ? { messageId: fact.messageId } : {}),
      ...(fact.workspaceDir ? { workspaceDir: fact.workspaceDir } : {}),
      ...(fact.staged || stagedMedia?.[index]?.staged ? { staged: true } : {}),
      ...(fact.hydrationSuppressed ? { hydrationSuppressed: true } : {}),
    });
  }

  const next = cloneTranscriptEnvelope(record);
  delete next.media;
  for (const key of PERSISTED_LEGACY_MEDIA_KEYS) {
    delete next[key];
  }
  const openclaw = { ...asNonArrayRecord(record["__openclaw"]) };
  if (media.length > 0 || canonical !== undefined || topLevelMedia !== undefined) {
    openclaw.media = media;
  }
  if (Object.keys(openclaw).length > 0) {
    next["__openclaw"] = openclaw;
  } else {
    delete next["__openclaw"];
  }
  return {
    changed: JSON.stringify(next) !== JSON.stringify(record),
    message: next as T,
  };
}

export function stripLegacyMediaContextFields(ctx: Record<string, unknown>): void {
  for (const key of LEGACY_MEDIA_CONTEXT_KEYS) {
    delete ctx[key];
  }
}

/** Returns whether a declared MIME only describes otherwise unclassified binary bytes. */
function isGenericBinaryMediaContentType(contentType?: string | null): boolean {
  const normalizedContentType = normalizeMimeType(contentType);
  return (
    normalizedContentType === "application/octet-stream" ||
    normalizedContentType === "binary/octet-stream"
  );
}

/** Resolves attachment kind from authoritative facts before source or filename hints. */
export function resolveMediaFactKind(fact: MediaFactInput): MediaKind | undefined {
  if (fact.kind && fact.kind !== "unknown") {
    return fact.kind;
  }
  const normalizedContentType = normalizeMimeType(fact.contentType);
  if (normalizedContentType && !isGenericBinaryMediaContentType(normalizedContentType)) {
    const mimeKind = kindFromMime(normalizedContentType);
    if (mimeKind) {
      return mimeKind;
    }
    // Legacy channel-mode projections persist bare image or sticker kind as MediaType.
    return isMediaKind(normalizedContentType) ? normalizedContentType : undefined;
  }
  const source = normalizeOptionalString(fact.path) ?? normalizeOptionalString(fact.url);
  if (!source) {
    return undefined;
  }
  for (const candidate of [fact.path, fact.url, fact.fileName, source]) {
    const inferredMime = mimeTypeFromFilePath(candidate);
    if (inferredMime !== undefined) {
      // A recognized source, including SVG, takes precedence over later filename hints.
      return inferredMime === "image/svg+xml" ? undefined : kindFromMime(inferredMime);
    }
    const extension = getFileExtension(candidate);
    if (extension === ".tif" || extension === ".tiff") {
      return "image";
    }
  }
  return undefined;
}

/** Returns whether a fact can produce native image input. */
export function isImageMediaFact(fact: MediaFactInput): boolean {
  const kind = resolveMediaFactKind(fact);
  return kind === "image" || kind === "sticker";
}

/** Returns whether a fact can produce native video input. */
export function isVideoMediaFact(fact: MediaFactInput): boolean {
  return resolveMediaFactKind(fact) === "video";
}

type MediaFactDefaults<TInput extends MediaFactInput = MediaFactInput> = {
  kind?: MediaKind;
  messageId?: string;
  workspaceDir?: string;
  transcribed?: (media: TInput, index: number) => boolean;
};

export type MediaFactLegacyProjection = {
  /** @deprecated Use `media[0]?.path`. */
  MediaPath?: string;
  /** @deprecated Use `media[0]?.url`. */
  MediaUrl?: string;
  /** @deprecated Use `media[0]?.contentType` or `.kind`. */
  MediaType?: string;
  /** @deprecated Use `media.map((entry) => entry.path)`. */
  MediaPaths?: string[];
  /** @deprecated Use `media.map((entry) => entry.url)`. */
  MediaUrls?: string[];
  /** @deprecated Use `media.map((entry) => entry.contentType ?? entry.kind)`. */
  MediaTypes?: string[];
  /** @deprecated Use each media fact's `transcribed` field. */
  MediaTranscribedIndexes?: number[];
};

type MediaFactSource = MediaFactLegacyProjection & {
  media?: readonly MediaFactInput[];
  MediaStaged?: boolean | null;
  MediaWorkspaceDir?: string | null;
};

function normalizeMediaFact<TInput extends MediaFactInput>(
  media: TInput | null,
  index: number,
  defaults: MediaFactDefaults<TInput> = {},
): MediaFact {
  // Sparse arrays serialize missing attachment positions as null; persisted
  // slots must remain empty facts instead of crashing transcript hydration.
  const input = asNonArrayRecord(media) as TInput;
  const workspaceDir = normalizeOptionalString(input.workspaceDir) ?? defaults.workspaceDir;
  const contentType = normalizeOptionalString(input.contentType);
  const durationMs = normalizePositiveInteger(input.durationMs);
  const width = normalizePositiveInteger(input.width);
  const height = normalizePositiveInteger(input.height);
  return {
    path: normalizeOptionalString(input.path),
    url: normalizeOptionalString(input.url),
    contentType,
    kind:
      (typeof input.kind === "string" ? input.kind : undefined) ??
      defaults.kind ??
      (isGenericBinaryMediaContentType(contentType) ? undefined : kindFromMime(contentType)),
    fileName: normalizeOptionalString(input.fileName),
    ...(input.origin === "paste" || input.origin === "file" ? { origin: input.origin } : {}),
    sizeBytes: asFiniteNumberInRange(input.sizeBytes, { min: 0 }),
    ...(durationMs ? { durationMs } : {}),
    ...(width ? { width } : {}),
    ...(height ? { height } : {}),
    transcribed: input.transcribed === true || defaults.transcribed?.(input, index) === true,
    messageId: normalizeOptionalString(input.messageId) ?? defaults.messageId,
    ...(input.source === "quote" ? { source: "quote" } : {}),
    ...(workspaceDir ? { workspaceDir } : {}),
    ...(input.staged === true ? { staged: true } : {}),
    ...(input.hydrationSuppressed === true ? { hydrationSuppressed: true } : {}),
  };
}

/** True when every path-bearing canonical fact has explicit staging proof. */
export function hasStagedMediaFacts(media: readonly MediaFactInput[] | null | undefined): boolean {
  const stageable = normalizeMediaFacts(media).filter((fact) => Boolean(fact.path));
  return (
    stageable.length > 0 &&
    stageable.every((fact) => Boolean(fact.workspaceDir) || fact.staged === true)
  );
}

export function normalizeMediaFacts<TInput extends MediaFactInput>(
  media: readonly TInput[] | null | undefined,
  defaults: MediaFactDefaults<TInput> = {},
): MediaFact[] {
  return Array.isArray(media)
    ? media.map((entry, index) => normalizeMediaFact(entry, index, defaults))
    : [];
}

// Empty slots exist only to keep legacy parallel-array positions aligned;
// presence/counting sites must ignore them or blank projections ({MediaPaths: [""]})
// route media-less messages into inbound-media handling.
export function isMeaningfulMediaFact(fact: MediaFact): boolean {
  return Boolean(
    fact.path?.trim() ||
    fact.url?.trim() ||
    fact.contentType ||
    (fact.kind && fact.kind !== "unknown"),
  );
}

function resolveMediaFactsWithPrecedence(
  source: MediaFactSource,
  legacyProjectionWins: boolean,
): MediaFact[] {
  const canonical = normalizeMediaFacts(source.media);
  const paths = Array.isArray(source.MediaPaths) ? source.MediaPaths : [];
  const urls = Array.isArray(source.MediaUrls) ? source.MediaUrls : [];
  const types = Array.isArray(source.MediaTypes) ? source.MediaTypes : [];
  const count = Math.max(
    canonical.length,
    paths.length,
    urls.length,
    types.length,
    source.MediaPath || source.MediaUrl || source.MediaType ? 1 : 0,
  );
  const transcribed = new Set(source.MediaTranscribedIndexes ?? []);
  const legacyHasPath =
    Boolean(normalizeOptionalString(source.MediaPath)) ||
    paths.some((value) => Boolean(normalizeOptionalString(value)));
  return Array.from({ length: count }, (_, index) => {
    const fact = canonical[index];
    const legacyPath = paths[index] ?? (index === 0 ? source.MediaPath : undefined);
    const legacyUrl = urls[index] ?? (index === 0 ? source.MediaUrl : undefined);
    const legacyContentType =
      normalizeOptionalString(types[index]) ?? (index === 0 ? source.MediaType : undefined);
    return normalizeMediaFact(
      {
        ...fact,
        path: legacyProjectionWins
          ? (normalizeOptionalString(legacyPath) ?? fact?.path)
          : (fact?.path ?? legacyPath),
        url: legacyProjectionWins
          ? (normalizeOptionalString(legacyUrl) ?? fact?.url)
          : (fact?.url ?? legacyUrl),
        contentType: legacyProjectionWins
          ? (legacyContentType ?? fact?.contentType)
          : (fact?.contentType ?? legacyContentType),
        transcribed: legacyProjectionWins
          ? fact
            ? fact.transcribed === true
            : transcribed.has(index)
          : fact?.transcribed === true || transcribed.has(index),
        workspaceDir: fact?.workspaceDir ?? normalizeOptionalString(source.MediaWorkspaceDir),
        staged:
          fact?.staged === true ||
          (legacyProjectionWins &&
            source.MediaStaged === true &&
            (!legacyHasPath || Boolean(normalizeOptionalString(legacyPath)))),
      },
      index,
    );
  });
}

/** Normalizes canonical facts or, for compatibility callers, legacy parallel fields. */
export function resolveMediaFacts(source: MediaFactSource): MediaFact[] {
  return resolveMediaFactsWithPrecedence(source, false);
}

/** Adopts staged legacy paths positionally while retaining canonical fact metadata and count. */
export function resolveStagedMediaFacts(source: MediaFactSource): MediaFact[] {
  return resolveMediaFactsWithPrecedence(source, true);
}

function projectStrings(
  values: Array<string | null | undefined>,
  compact: boolean,
  preserveEmptyLists: boolean,
): string[] | undefined {
  const projected = compact
    ? values.filter((value): value is string => Boolean(value))
    : values.map((value) => value ?? "");
  if (projected.length === 0 || (!preserveEmptyLists && !projected.some(Boolean))) {
    return undefined;
  }
  return projected;
}

export function projectMediaFacts(
  media: readonly MediaFactInput[] | null | undefined,
  mode: "channel" | "compact" = "channel",
): MediaFactLegacyProjection {
  const entries = Array.isArray(media) ? media : [];
  const preserveEmptyLists = mode !== "channel";
  const mediaUrl = (entry: MediaFactInput) =>
    (mode === "channel" ? (entry.url ?? entry.path) : entry.path) ?? undefined;
  const mediaType = (entry: MediaFactInput) =>
    entry.contentType ?? (mode === "channel" ? entry.kind : undefined) ?? undefined;
  const transcribedIndexes = entries.flatMap((entry, index) => (entry.transcribed ? [index] : []));
  return {
    MediaPath: entries[0]?.path ?? undefined,
    MediaUrl: entries[0] ? mediaUrl(entries[0]) : undefined,
    MediaType: entries[0] ? mediaType(entries[0]) : undefined,
    MediaPaths: projectStrings(
      entries.map((entry) => entry.path),
      false,
      preserveEmptyLists,
    ),
    MediaUrls: projectStrings(entries.map(mediaUrl), false, preserveEmptyLists),
    MediaTypes: projectStrings(entries.map(mediaType), mode === "compact", preserveEmptyLists),
    ...(mode !== "channel"
      ? {}
      : {
          MediaTranscribedIndexes: transcribedIndexes.length > 0 ? transcribedIndexes : undefined,
        }),
  };
}
