import type { ThemeDefinition } from "../../packages/gateway-protocol/src/theme.js";
import type {
  PluginBundleFormat,
  PluginConfigUiHint,
  PluginDiagnostic,
  PluginFormat,
  PluginManifest,
  PluginManifestChannelCommandDefaults,
  PluginManifestChannelConfig,
  PluginManifestContracts,
} from "./manifest-types.js";
import type {
  OpenClawPackageManifest,
  PluginPackageChannel,
  PluginPackageInstall,
} from "./package-manifest.types.js";
import type { PluginOrigin } from "./plugin-origin.types.js";
import type { PluginTrust } from "./plugin-trust.js";
import type { PluginDependencySpecMap } from "./status-dependencies.types.js";

export type PluginManifestContractListKey = Exclude<
  keyof PluginManifestContracts,
  "agentToolResultMiddleware" | "trustedToolPolicies" | "tools"
>;

type PluginManifestRecordStatic = Omit<
  PluginManifest,
  | "capabilityCatalogEntry"
  | "channels"
  | "cliBackends"
  | "configSchema"
  | "enabledByDefaultOnPlatforms"
  | "providerCatalogEntry"
  | "providers"
  | "requiresPlugins"
  | "skills"
  | "uiHints"
>;

export type PluginThemeArtwork = {
  icons?: Record<string, { svg: string }>;
  hats?: Record<string, { svg: string }>;
  critters?: Record<string, { svg: string; title?: string; crossMs?: number }>;
  /** Base64 keeps the bytes immutable inside frozen metadata snapshots, which cannot freeze Buffers. */
  backgrounds?: Partial<Record<"light" | "dark", { base64: string }>>;
};

export type PluginManifestRecord = PluginManifestRecordStatic & {
  /** Validated palettes and artwork captured by the immutable metadata generation. */
  themeDefinitions?: Array<{
    id: string;
    definition: ThemeDefinition;
    artwork?: PluginThemeArtwork;
  }>;
  /** Process-local source selection, never persisted in the installed index. */
  sourcePreferred?: true;
  iconPath?: string;
  activityIconPath?: string;
  toolActivityIconPaths?: Record<string, string>;
  packageName?: string;
  packageVersion?: string;
  packageDescription?: string;
  enabledByDefaultOnPlatforms?: string[];
  format?: PluginFormat;
  bundleFormat?: PluginBundleFormat;
  bundleCapabilities?: string[];
  /** Packaged, plugin-relative setup skill; invoked only by an explicit user action. */
  onboardingSkill?: string;
  channels: string[];
  providers: string[];
  providerDiscoverySource?: string;
  /** Undefined is undeclared; null retains a rejected declaration without enabling full-entry fallback. */
  capabilityCatalogSource?: string | null;
  cliBackends: string[];
  packageManifest?: OpenClawPackageManifest;
  packageDependencies?: PluginDependencySpecMap;
  packageOptionalDependencies?: PluginDependencySpecMap;
  packageChannel?: PluginPackageChannel;
  packageInstall?: PluginPackageInstall;
  trustedOfficialInstall?: boolean;
  trust?: PluginTrust;
  skills: string[];
  agentSkillsDir?: string;
  settingsFiles?: string[];
  hooks: string[];
  origin: PluginOrigin;
  workspaceDir?: string;
  rootDir: string;
  source: string;
  setupSource?: string;
  manifestPath: string;
  schemaCacheKey?: string;
  configSchema?: Record<string, unknown>;
  configUiHints?: Record<string, PluginConfigUiHint>;
  channelCatalogMeta?: {
    id: string;
    label?: string;
    blurb?: string;
    preferOver?: readonly string[];
    commands?: PluginManifestChannelCommandDefaults;
  };
};

export type PluginManifestRegistry = {
  plugins: PluginManifestRecord[];
  diagnostics: PluginDiagnostic[];
};

export type BundledChannelConfigCollector = (params: {
  pluginDir: string;
  manifest: PluginManifest;
  packageManifest?: OpenClawPackageManifest;
}) => Record<string, PluginManifestChannelConfig> | undefined;
