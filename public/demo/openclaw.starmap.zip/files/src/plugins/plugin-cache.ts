import path from "node:path";
import { fileURLToPath } from "node:url";
import { materializeErrorStack } from "../infra/error-graph-internal.js";
import { AsyncWorkScope, runOutsideAsyncWorkScope } from "../shared/async-work-scope.js";
import { createDeferredCore } from "../shared/deferred.js";
import { resolveGlobalSingleton } from "../shared/global-singleton.js";
import {
  appendPluginInstanceCleanupFailures,
  summarizePluginRetirementResults,
} from "./host-hook-cleanup-result.js";
import type { PluginHostCleanupResult } from "./host-hook-cleanup.types.js";
import type { PluginSourceCacheRecord } from "./plugin-cache-artifacts.js";
import type { PluginCacheFact } from "./plugin-cache-management.js";
import { createPluginCacheSdk } from "./plugin-cache-sdk.js";
import type { PluginCache, PluginRootCacheRecord } from "./plugin-cache.types.js";
import {
  PluginInstanceDrainTimeoutError,
  PluginInventoryRetiredError,
} from "./plugin-instance-error.js";
import {
  createPluginExecutionFrame,
  getPluginExecutionFrame,
  pluginInstanceInvocation,
  runWithPluginExecutionFrame,
} from "./plugin-instance-invocation.js";
import type { PluginInstanceResource } from "./plugin-instance.types.js";

export type { PluginCache } from "./plugin-cache.types.js";

const state = resolveGlobalSingleton<{
  current?: PluginCache;
  snapshotOwners: WeakMap<object, PluginCache>;
  retirements: Array<{
    cache: PluginCache;
    completion: Promise<PromiseSettledResult<PluginHostCleanupResult>>;
  }>;
}>(Symbol.for("openclaw.pluginCache"), () => ({
  snapshotOwners: new WeakMap(),
  retirements: [],
}));

const cacheRetainers = resolveGlobalSingleton(
  Symbol.for("openclaw.pluginCacheRetainers"),
  () =>
    new WeakMap<
      PluginCache,
      {
        references: Set<object>;
        controller: AbortController;
        settled: ReturnType<typeof createDeferredCore<void>>;
        retirement?: Promise<PluginHostCleanupResult>;
      }
    >(),
);

const instanceCacheOwners = resolveGlobalSingleton(
  Symbol.for("openclaw.pluginInstanceCacheOwners"),
  () => new WeakMap<PluginInstanceResource, Set<PluginCache>>(),
);

/** Inventories retain admitted instances until transfer or successful physical disposal. */
export function retainPluginCacheInstance(
  instance: PluginInstanceResource,
  cache = getPluginCache(),
): void {
  cache.instances.add(instance);
  let owners = instanceCacheOwners.get(instance);
  if (!owners) {
    instanceCacheOwners.set(instance, (owners = new Set()));
  }
  owners.add(cache);
}

/** A retiring inventory releases its own custody; terminal disposal releases every birth cache. */
export function releasePluginCacheInstance(
  instance: PluginInstanceResource,
  cache?: PluginCache,
): void {
  const owners = instanceCacheOwners.get(instance);
  if (cache) {
    cache.instances.delete(instance);
    owners?.delete(cache);
  } else {
    for (const owner of owners ?? []) {
      owner.instances.delete(instance);
    }
    owners?.clear();
  }
  if (owners?.size === 0) {
    instanceCacheOwners.delete(instance);
  }
}

function getPluginCacheRetainers(cache: PluginCache) {
  let retained = cacheRetainers.get(cache);
  if (!retained) {
    retained = {
      references: new Set(),
      controller: new AbortController(),
      settled: createDeferredCore(),
    };
    cacheRetainers.set(cache, retained);
  }
  return retained;
}

/** Cache retirement revokes cached publications before waiting for admitted borrowers. */
export function getPluginCacheRetirementSignal(cache: PluginCache): AbortSignal {
  return getPluginCacheRetainers(cache).controller.signal;
}

/** Admitted generations keep their exact prepared facts through publication replacement. */
export function retainPluginCache(cache: PluginCache): () => void {
  const retained = getPluginCacheRetainers(cache);
  if (cache.retirement || retained.retirement) {
    throw new PluginInventoryRetiredError();
  }
  if (retained.references.size === 0) {
    retained.settled = createDeferredCore();
  }
  const reference = {};
  retained.references.add(reference);
  return () => {
    if (retained.references.delete(reference) && retained.references.size === 0) {
      retained.settled.resolve();
    }
  };
}

export function getPluginCacheRetention(cache: PluginCache): Promise<void> | undefined {
  const retained = cacheRetainers.get(cache);
  return retained?.references.size ? retained.settled.promise : undefined;
}

function createPluginMetadataCache(): PluginCache["metadata"] {
  return {
    current: {
      snapshot: undefined,
      owner: "operation",
      configFingerprint: undefined,
      agentWorkspaceFingerprint: undefined,
      envFingerprint: undefined,
      defaultDiscoveryCompatible: false,
      compatibleConfigFingerprints: undefined,
      configIdentities: new WeakSet(),
    },
    autoEnable: new WeakMap(),
    snapshots: new Map(),
    derivedIndexes: new WeakMap(),
    preparedManifests: new WeakMap(),
    snapshotManifestFacts: new WeakMap(),
    discovery: new Map(),
    sharedDiscovery: new Map(),
    projections: new WeakMap(),
    projectionSources: new WeakMap(),
    completions: new WeakMap(),
    indexFacts: new WeakMap(),
    providerPolicyOwners: new WeakMap(),
    channelAdapters: new WeakMap(),
    bundledChannelCatalogs: new Map(),
    bundledProviderPolicySurfaces: new WeakMap(),
    staticCatalogStates: new WeakMap(),
    modelSuppressionResolvers: new WeakMap(),
    mcpAuthDeclarations: new WeakMap(),
  };
}

/** Invalidate discovery facts without retiring callbacks owned by this operation. */
export function invalidatePluginCacheMetadata(cache: PluginCache): void {
  cache.inspectionNativeEsmPolicy = undefined;
  cache.sourceAdmissions?.invalidate();
  cache.metadata = createPluginMetadataCache();
  cache.sdk.native.parents.clear();
  for (const root of cache.roots.values()) {
    root.files.clear();
    root.checkedEntries.clear();
    root.paths.clear();
    root.directory = undefined;
    root.artifacts.clear();
    root.runtimeArtifacts.clear();
    root.entryBoundaries.clear();
    root.entryPaths.clear();
  }
  cache.rootAliases.clear();
  cache.installRecords.clear();
  cache.persistedInstalledIndex.clear();
  cache.preparedBundledDiscoveryModes.clear();
  cache.dependencyStatus = new WeakMap();
}

/** Each inventory owns its acquired facts and reusable load results; publication owns activation. */
export function createPluginCache(options: { kind?: PluginCache["kind"] } = {}): PluginCache {
  return {
    async [Symbol.asyncDispose]() {
      await retirePluginCache(this);
    },
    kind: options.kind ?? "operation",
    roots: new Map(),
    rootAliases: new Map(),
    sdk: createPluginCacheSdk(),
    setupModules: new Map(),
    instances: new Set(),
    metadata: createPluginMetadataCache(),
    installRecords: new Map(),
    persistedInstalledIndex: new Map(),
    preparedBundledDiscoveryModes: new Map(),
    dependencyStatus: new WeakMap(),
    moduleLoaders: new Map(),
    sources: new Map(),
    sourceAliases: new Map(),
    runtimeRecordRoots: new WeakMap(),
  };
}

export function getProcessPluginCache(): PluginCache {
  return (state.current ??= createPluginCache({ kind: "process" }));
}

/** Startup publishes its complete owner, including facts acquired before the kernel existed. */
export function adoptProcessPluginCache(cache: PluginCache): void {
  cache.kind = "process";
  state.current = cache;
}

export function getScopedPluginCache(): PluginCache | undefined {
  return getPluginExecutionFrame()?.cacheScope?.cache;
}

/** An explicit install refreshes its enclosing command's metadata phases. */
export function getScopedPluginCaches(): PluginCache[] {
  const caches: PluginCache[] = [];
  for (let scope = getPluginExecutionFrame()?.cacheScope; scope; scope = scope.parent) {
    caches.push(scope.cache);
  }
  return caches;
}

export function getPluginCache(): PluginCache {
  return getScopedPluginCache() ?? getProcessPluginCache();
}

export function withPluginCache<T>(cache: PluginCache, run: () => T): T {
  const current = getPluginExecutionFrame();
  if (current?.cacheScope?.cache === cache) {
    // Re-entering the innermost cache would only duplicate it in the scope chain.
    return run();
  }
  return runWithPluginExecutionFrame(
    createPluginExecutionFrame(
      { ...current, cacheScope: { cache, parent: current?.cacheScope } },
      current,
    ),
    run,
  );
}

/** Coalesce reads; an invalidated in-flight read may finish without repopulating the cache. */
export async function preparePluginCacheFact<T>(
  owner: PluginCache,
  facts: Map<string, PluginCacheFact<T>>,
  key: string,
  read: () => Promise<T>,
): Promise<{ value: T; assertCurrent: () => void }> {
  const signal = getPluginCacheRetirementSignal(owner);
  signal.throwIfAborted();
  let current = facts.get(key);
  if (!current) {
    const reading = read();
    const pending: { pending: Promise<{ value: T }> } = {
      pending: reading
        .then((value) => {
          signal.throwIfAborted();
          const published = facts.get(key);
          if (published && "value" in published) {
            return published;
          }
          const ready = { value };
          if (published === pending) {
            facts.set(key, ready);
          }
          return ready;
        })
        .catch((error: unknown) => {
          if (facts.get(key) === pending) {
            facts.delete(key);
          }
          throw error;
        }),
    };
    facts.set(key, pending);
    current = pending;
  }
  const ready = "pending" in current ? await current.pending : current;
  const assertCurrent = () => {
    signal.throwIfAborted();
  };
  assertCurrent();
  return { value: ready.value, assertCurrent };
}

export function runOutsidePluginCache<T>(run: () => T): T {
  const current = getPluginExecutionFrame();
  return runWithPluginExecutionFrame(
    createPluginExecutionFrame({ ...current, cacheScope: undefined }, current),
    run,
  );
}

/** Frozen views retain their producer so deferred access fills the same generation. */
export function bindPluginMetadataSnapshotCache(snapshot: object, cache = getPluginCache()): void {
  state.snapshotOwners.set(snapshot, cache);
}

export function getPluginMetadataSnapshotCache(snapshot: object): PluginCache {
  return state.snapshotOwners.get(snapshot) ?? getPluginCache();
}

/** Only the lifecycle owner retires the process cache; operation scopes remain independent. */
export function resetPluginCache(): void {
  const previous = state.current;
  state.current = undefined;
  if (previous) {
    // Public libraries refresh synchronously; managed instances keep their separate retirement.
    for (const source of previous.sources.values()) {
      source.disposeModule?.();
    }
    state.retirements.push({
      cache: previous,
      completion: retirePluginCache(previous).then(
        (value) => ({ status: "fulfilled", value }),
        (reason: unknown) => ({ status: "rejected", reason }),
      ),
    });
  }
}

/** Failed loaders retain their real completion under the cache that admitted them. */
export function retirePluginCacheInstance(
  instance: PluginInstanceResource,
  cache = getPluginCache(),
): Promise<void> {
  retainPluginCacheInstance(instance, cache);
  // A registration caller may receive a self-retirement acknowledgment; this owner must join fully.
  const completion = pluginInstanceInvocation
    .exit(() => instance.dispose())
    .then((result) => {
      // Failed outcomes stay available to the cache's existing disposal aggregator.
      if (result.errors.length === 0) {
        releasePluginCacheInstance(instance, cache);
      }
    });
  void completion.catch(() => {});
  return completion;
}

/** Stop new setup calls immediately; the owner awaits in-flight calls and graph cleanup. */
export function retirePluginCache(
  cache: PluginCache,
  beforeRetire?: () => void,
  options?: { waitForSettlement?: boolean },
): Promise<PluginHostCleanupResult> {
  const retained = getPluginCacheRetainers(cache);
  if (retained.retirement) {
    return retained.retirement;
  }
  const completion = createDeferredCore<PluginHostCleanupResult>();
  retained.retirement = completion.promise;
  const retire = async () => {
    // Cleanup owns its work after the requesting command has closed.
    if (retained.references.size) {
      await retained.settled.promise;
    }
    const work = new AsyncWorkScope();
    try {
      return await work.track(() => beginPluginCacheRetirement(cache, beforeRetire, options));
    } finally {
      await work.drain();
    }
  };
  retained.controller.abort();
  materializeErrorStack(retained.controller.signal.reason);
  void runOutsideAsyncWorkScope(retire).then(completion.resolve, completion.reject);
  return completion.promise;
}

function beginPluginCacheRetirement(
  cache: PluginCache,
  beforeRetire?: () => void,
  options?: { waitForSettlement?: boolean },
): Promise<PluginHostCleanupResult> {
  if (cache.retirement) {
    return cache.retirement;
  }
  // Registry retirement can synchronously notify listeners; close admission before those callbacks.
  const retirement = createDeferredCore<PluginHostCleanupResult>();
  cache.retirement = retirement.promise;
  const cleanup = async () => {
    beforeRetire?.();
    const registries = cache.retireRegistryLoads?.();
    const resources = new Set([...cache.setupModules.values(), ...cache.instances]);
    for (const resource of resources) {
      resource.quiesce();
    }
    // Registry teardown owns host hooks before instance disposal; then join remaining cleanup.
    const [registry] = await Promise.allSettled([registries]);
    const outcomes = await Promise.allSettled(
      [...resources].map(async (resource) => ({
        resource,
        result: await resource.dispose(undefined, options),
      })),
    );
    const nativeAdmissions = cache.sourceAdmissions;
    if (nativeAdmissions) {
      const pending = outcomes.flatMap((outcome) =>
        outcome.status === "fulfilled"
          ? outcome.value.result.errors.flatMap((error) =>
              error instanceof PluginInstanceDrainTimeoutError ? [error.settled] : [],
            )
          : [],
      );
      if (pending.length > 0) {
        // A bounded retirement report does not release files still used by timed-out calls.
        void Promise.allSettled(pending)
          .then(() => nativeAdmissions.dispose())
          .catch((error: unknown) =>
            process.emitWarning(`Plugin native capture cleanup failed: ${String(error)}`),
          );
      } else {
        await nativeAdmissions.dispose();
      }
    }
    cache.setupModules.clear();
    for (const instance of cache.instances) {
      releasePluginCacheInstance(instance, cache);
    }
    const unexpected = [
      ...(registry.status === "rejected" ? [registry.reason] : []),
      ...outcomes.flatMap((result) => (result.status === "rejected" ? [result.reason] : [])),
    ];
    if (unexpected.length) {
      throw new AggregateError(unexpected, "Plugin cache resources failed to retire");
    }
    const host = registry.status === "fulfilled" ? registry.value : undefined;
    const failures = [...(host?.failures ?? [])];
    for (const outcome of outcomes) {
      if (outcome.status !== "fulfilled") {
        continue;
      }
      const { resource, result } = outcome.value;
      appendPluginInstanceCleanupFailures(failures, resource.pluginId, result);
    }
    return { cleanupCount: host?.cleanupCount ?? 0, failures };
  };
  void cleanup().then(retirement.resolve, retirement.reject);
  return retirement.promise;
}

/** Consume retirements initiated by synchronous config/setup cache invalidation. */
export async function waitForPluginCacheRetirement(
  includeBorrowed = false,
): Promise<PluginHostCleanupResult> {
  const ready = state.retirements.filter(
    ({ cache }) => includeBorrowed || cache.kind !== "process" || !getPluginCacheRetention(cache),
  );
  state.retirements = state.retirements.filter((retirement) => !ready.includes(retirement));
  const results = await Promise.all(ready.map((retirement) => retirement.completion));
  return summarizePluginRetirementResults(results, "Plugin cache retirement failed");
}

export function getPluginCacheRoot(rootDir: string): PluginRootCacheRecord {
  const cache = getPluginCache();
  // Alias binding can replace the canonical record while older lexical records remain.
  const cached = cache.roots.get(cache.rootAliases.get(rootDir) ?? rootDir);
  if (cached) {
    return cached;
  }
  const lexical = path.resolve(rootDir);
  const key = cache.rootAliases.get(lexical) ?? lexical;
  let root = cache.roots.get(key);
  if (!root) {
    root = {
      rootDir: key,
      files: new Map(),
      checkedEntries: new Map(),
      paths: new Map(),
      artifacts: new Map(),
      runtimeArtifacts: new Map(),
      entryBoundaries: new Map(),
      entryPaths: new Map(),
    };
    cache.roots.set(key, root);
  }
  return root;
}

function mergeRootFacts<T>(target: Map<string, T>, source: Map<string, T>): void {
  for (const [key, value] of source) {
    if (!target.has(key)) {
      target.set(key, value);
    }
  }
}

/** Bind aliases only after a checked file establishes their shared package boundary. */
export function bindPluginCacheRoot(rootDir: string, canonicalRoot: string): PluginRootCacheRecord {
  const root = getPluginCacheRoot(rootDir);
  if (root.rootDir === canonicalRoot) {
    return root;
  }
  const cache = getPluginCache();
  const lexical = path.resolve(rootDir);
  const canonical = path.resolve(canonicalRoot);
  root.rootDir = canonical;
  const existing = cache.roots.get(canonical);
  if (existing && existing !== root) {
    // Preserve the first checked facts while sharing maps with retained root references.
    mergeRootFacts(root.files, existing.files);
    mergeRootFacts(root.checkedEntries, existing.checkedEntries);
    mergeRootFacts(root.paths, existing.paths);
    mergeRootFacts(root.artifacts, existing.artifacts);
    mergeRootFacts(root.runtimeArtifacts, existing.runtimeArtifacts);
    mergeRootFacts(root.entryBoundaries, existing.entryBoundaries);
    mergeRootFacts(root.entryPaths, existing.entryPaths);
    root.directory ??= existing.directory;
    root.publicSurfaceBoundary ??= existing.publicSurfaceBoundary;
    Object.assign(existing, root);
  }
  cache.roots.set(canonical, root);
  cache.rootAliases.set(lexical, canonical);
  return root;
}

export function getPluginCacheSource(
  modulePath: string,
  cache = getPluginCache(),
): PluginSourceCacheRecord {
  const cached = cache.sources.get(cache.sourceAliases.get(modulePath) ?? modulePath);
  if (cached) {
    return cached;
  }
  const lexical = path.resolve(
    modulePath.startsWith("file:") ? fileURLToPath(modulePath) : modulePath,
  );
  const key = cache.sourceAliases.get(lexical) ?? lexical;
  let source = cache.sources.get(key);
  if (!source) {
    source = { variants: new Map(), validatedBoundaries: new Set() };
    cache.sources.set(key, source);
  }
  return source;
}
