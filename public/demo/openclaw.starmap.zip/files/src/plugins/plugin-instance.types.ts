import type { Static } from "typebox";
import type { PluginRuntimeRetentionSchema } from "../../packages/gateway-protocol/src/schema/plugin-retention.js";

export type PluginInstanceDisposalCleanup = {
  failures: unknown[];
  hostFailure?: { error: unknown };
  moduleCleanups: Array<() => void | Promise<void>>;
};

/** Payload-free facts shared with administrator inspection. */
export type PluginRetentionSnapshot = Static<typeof PluginRuntimeRetentionSchema>;
export type PluginRetainedReference = Omit<PluginRetentionSnapshot["references"][number], "ageMs">;
/** Host-authored correlation only, never invocation or authorization authority. */
export type PluginRetentionOwner = Readonly<Exclude<PluginRetainedReference["owner"], "unknown">>;
export type PluginRetentionReason = PluginRetainedReference["reason"];
export type PluginWorkRelease = (() => void) & {
  /** Updates observation only; never releases or revokes a hold. */
  setCleanupState?: (state: PluginRetainedReference["cleanupState"]) => void;
};

/** Disposal and admission shared by instance resources and registry handles. */
export type PluginInstanceLifecycle = {
  readonly signal: AbortSignal;
  onDispose: (dispose: () => void | Promise<void>) => () => void;
  /** Detach caller context while retaining this instance's current registry and host resources. */
  runInBackgroundContext: <T>(run: () => T) => T;
};

/** Execution and host cleanup retain the same instance admission. */
export type PluginInstanceExecution = {
  run<T>(run: () => T): T;
  runCleanup<T>(run: () => T): T;
};

export type PluginInstanceAdmission = {
  readonly lifecycle: PluginInstanceLifecycle;
  run<T>(run: () => T): T;
};

/** Known disposal faults are reported outcomes, never new-call admission failures. */
export type PluginInstanceDisposalResult = {
  errors: readonly unknown[];
};

/** A host-owned logical consumer retains only its exact instance's admitted operations. */
export type PluginInstanceConsumer = {
  wrap<T>(value: T): T;
  run<T>(run: () => T): T;
  close(cleanup: () => void | Promise<void>): Promise<void>;
  release(): void;
};

/** Exact call token and release operation owned by its PluginInstance. */
export type PluginInstanceCallLease = {
  token: object;
  release: () => void | Promise<unknown>;
};

/** Inventory custody owns retirement without depending on registry contributions. */
export interface PluginInstanceResource {
  readonly pluginId: string;
  quiesce(): boolean;
  dispose(
    beforeCleanup?: () => void | Promise<void>,
    options?: { waitForSettlement?: boolean },
  ): Promise<PluginInstanceDisposalResult>;
}

/** Captured code custody survives retiring a runtime until recovery consumes or releases it. */
export type PluginModuleLoaderRecovery = {
  bind(instance: PluginModuleLoaderOwner): void;
  dispose(): Promise<void>;
};

/** Runtime and setup loaders use the same instance-owned captured source. */
export interface PluginModuleLoaderOwner extends PluginInstanceResource, PluginInstanceAdmission {
  setupPreparationFailure?: Error;
  controlPlaneInitialized: boolean;
  sourceDigest?: string;
  onModuleDispose(cleanup: () => void | Promise<void>): void;
  bindModuleLoader(
    load: (source: string) => unknown,
    hasSource?: (source: string) => boolean,
  ): void;
  loadModule(source: string): unknown;
  hasModuleSource(source: string): boolean | undefined;
  bindModuleLoaderRecovery(
    capture: () => PluginModuleLoaderRecovery | Promise<PluginModuleLoaderRecovery>,
  ): void;
  captureModuleLoaderRecovery(): Promise<PluginModuleLoaderRecovery>;
}

/** Current-call helpers retain the instance itself, not a registry or plugin-id lookup. */
export interface PluginInvocationInstance extends PluginModuleLoaderOwner {
  /** The current invocation's call or retained-consumer token is still admitted. */
  readonly hasActiveCall: boolean;
  holdsPendingReplacement(token: object): boolean;
  readonly slots: Map<string | symbol, { runtime: unknown }>;
  wrap<T>(value: T): T;
}
