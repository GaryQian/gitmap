// Gateway request scope tracks request-local plugin runtime context across async work.
import type {
  GatewayContextResolver,
  GatewayRequestContext,
} from "../../gateway/server-methods/types.js";
import { resolveGlobalSingleton } from "../../shared/global-singleton.js";
import { withAgentDatabasePreparationContext } from "../../state/agent-database-preparation-context.js";
import {
  getPluginExecutionFrame,
  runWithPluginExecutionFrame,
} from "../plugin-instance-invocation.js";
import type { PluginInstanceInvocation } from "../plugin-instance-invocation.types.js";
import type { PluginOrigin } from "../plugin-origin.types.js";
import { mapPluginReturnPromise, resolvePluginReturnPromise } from "../plugin-return-value.js";
import type { DeclaredProviderOwnerIndex } from "../provider-owner-index.js";
import type { PluginRegistry } from "../registry-types.js";
import { getPluginRegistryState } from "../runtime-state.js";
import { getPluginRuntimeExecutionFrame, PluginRuntimeExecutionFrame } from "./execution-frame.js";
import type { PluginRuntimeGatewayRequestScope } from "./gateway-request-scope.types.js";
import { getPluginRuntimeLoadContextState } from "./load-context-state.js";

export {
  bindGatewayContextResolver,
  clearGatewayContextResolver,
  getCanonicalGatewayContextResolver,
  getGatewayContextLifetime,
  getGatewayContextResolver,
  getSharedGatewayContextResolver,
  hasGatewayContextOwner,
} from "./gateway-context-binding.js";

type PluginRuntimePluginScope = {
  pluginId: string;
  pluginSource?: string;
  pluginOrigin?: PluginOrigin;
  pluginTrustedOfficialInstall?: boolean;
};

function runWithPluginGatewayScope<T>(
  gatewayScope: PluginRuntimeGatewayRequestScope,
  run: () => T,
  invocation?: PluginInstanceInvocation,
): T {
  const current = getPluginExecutionFrame();
  const call = invocation ?? current?.invocation;
  const runtime = getPluginRuntimeExecutionFrame(current);
  if (runtime?.gatewayScope === gatewayScope && runtime.invocation === call) {
    return run();
  }
  return runWithPluginExecutionFrame(
    new PluginRuntimeExecutionFrame(current ?? {}, gatewayScope, runtime?.generationRegistry, call),
    run,
  );
}

const isNotWebchatConnect = () => false;

// Settled reactions may outlive the call; capture only its emptied custody holder.
function settleRegistryScope(completion: Promise<unknown>, held: PluginRegistry[]) {
  return mapPluginReturnPromise(
    completion,
    (value) => {
      held.length = 0;
      return value;
    },
    (error) => {
      held.length = 0;
      throw error;
    },
  ).value;
}

export const ExpiredPluginRegistryScopeError = resolveGlobalSingleton(
  Symbol.for("openclaw.expiredPluginRegistryScopeError"),
  () =>
    class extends Error {
      constructor() {
        super("Plugin registry scope is no longer available");
      }
    },
);

// Each binding retains its own closures; the host-owned scope is defined synchronously.
const borrowedRegistryProperty: PropertyDescriptor = { enumerable: true, configurable: true };

// Native resources inherit these views; the registry's lifecycle owner keeps the graph alive.
function bindBorrowedRegistry(
  scope: PluginRuntimeGatewayRequestScope,
  registry: PluginRegistry | undefined,
  initiallyExpired = false,
): void {
  let expired = initiallyExpired;
  let reference = registry && new WeakRef(registry);
  borrowedRegistryProperty.get = () => {
    const current = reference?.deref();
    if (expired || (reference && !current)) {
      throw new ExpiredPluginRegistryScopeError();
    }
    return current;
  };
  borrowedRegistryProperty.set = (next: PluginRegistry | undefined) => {
    reference = next && new WeakRef(next);
    expired = false;
  };
  Object.defineProperty(scope, "pluginRegistry", borrowedRegistryProperty);
}

function copyGatewayScope(
  current: PluginRuntimeGatewayRequestScope | undefined,
  inheritRegistry = true,
): PluginRuntimeGatewayRequestScope {
  const scoped: PluginRuntimeGatewayRequestScope = { isWebchatConnect: isNotWebchatConnect };
  if (!current) {
    return scoped;
  }
  // Copy enumerable values like spread, but do not read a registry that the caller replaces.
  for (const key of Object.keys(current)) {
    if (key !== "pluginRegistry") {
      Reflect.set(scoped, key, Reflect.get(current, key));
    }
  }
  for (const key of Object.getOwnPropertySymbols(current)) {
    if (Object.prototype.propertyIsEnumerable.call(current, key)) {
      Reflect.set(scoped, key, Reflect.get(current, key));
    }
  }
  if (inheritRegistry && Object.prototype.propertyIsEnumerable.call(current, "pluginRegistry")) {
    try {
      bindBorrowedRegistry(scoped, current.pluginRegistry);
    } catch (error) {
      if (!(error instanceof ExpiredPluginRegistryScopeError)) {
        throw error;
      }
      bindBorrowedRegistry(scoped, undefined, true);
    }
  }
  return scoped;
}

/** Carry only closure-bound node authorities into a nested request scope. */
export function getPluginRuntimeGatewayNodeAuthorities() {
  const scope = getPluginRuntimeGatewayRequestScope();
  return {
    invokeWithSessionNodeAuthority: scope?.invokeWithSessionNodeAuthority,
    nodePlacementGrantAuthority: scope?.nodePlacementGrantAuthority,
  };
}

/**
 * Runs plugin gateway handlers with request-scoped context that runtime helpers can read.
 */
export function withPluginRuntimeGatewayRequestScope<T>(
  scope: PluginRuntimeGatewayRequestScope,
  run: () => T,
): T {
  return runWithPluginGatewayScope(scope, run);
}

/** Runs detached work with its captured Gateway binding, including an explicitly unbound owner. */
export function withPluginRuntimeGatewayContextResolver<T>(
  resolveGatewayContext: GatewayContextResolver | undefined,
  run: () => T,
  options?: { inheritRequestScope?: boolean },
): T {
  // Scheduler-owned work must not retain the request-local client or context
  // that happened to exist when its timer was armed.
  const current =
    options?.inheritRequestScope === false ? undefined : getPluginRuntimeGatewayRequestScope();
  const scoped = copyGatewayScope(current);
  scoped.isWebchatConnect = current?.isWebchatConnect ?? isNotWebchatConnect;
  scoped.resolveGatewayContext = resolveGatewayContext;
  delete scoped.context;
  return withAgentDatabasePreparationContext(
    resolveAgentDatabasePreparation(resolveGatewayContext),
    () => runWithPluginGatewayScope(scoped, run),
  );
}

const resolveUnboundAgentDatabasePreparation = () => undefined;
const agentDatabasePreparationResolvers = new WeakMap<
  GatewayContextResolver,
  () => GatewayRequestContext["agentDatabaseStartup"]
>();

// One owner callback per resolver lets nested work reuse the preparation async frame.
function resolveAgentDatabasePreparation(
  resolveGatewayContext: GatewayContextResolver | undefined,
) {
  if (!resolveGatewayContext) {
    return resolveUnboundAgentDatabasePreparation;
  }
  let resolve = agentDatabasePreparationResolvers.get(resolveGatewayContext);
  if (!resolve) {
    resolve = () => resolveGatewayContext()?.agentDatabaseStartup;
    agentDatabasePreparationResolvers.set(resolveGatewayContext, resolve);
  }
  return resolve;
}

/** Runs work against an owned registry handle while preserving any gateway request facts. */
export function withPluginRuntimeRegistryScope<T>(
  registry: PluginRegistry | undefined,
  run: () => T,
  declaredProviderOwners?: DeclaredProviderOwnerIndex,
): T {
  if (!registry) {
    return run();
  }
  const current = getPluginRuntimeGatewayRequestScope();
  return runWithPluginGatewayScope(
    createRegistryScope(registry, current, declaredProviderOwners),
    () => {
      const value = run();
      const completion = resolvePluginReturnPromise(value);
      // SAFETY: Awaiting the callback preserves its value and rejection reason.
      return completion ? (settleRegistryScope(completion, [registry]) as T) : value;
    },
  );
}

export function createRegistryScope(
  registry: PluginRegistry,
  current: PluginRuntimeGatewayRequestScope | undefined,
  declaredProviderOwners?: DeclaredProviderOwnerIndex,
): PluginRuntimeGatewayRequestScope {
  const scoped = copyGatewayScope(current, false);
  let inheritedOwners: DeclaredProviderOwnerIndex | undefined;
  if (declaredProviderOwners === undefined && current) {
    try {
      if (current.pluginRegistry === registry) {
        inheritedOwners = current.declaredProviderOwners;
      }
    } catch (error) {
      if (!(error instanceof ExpiredPluginRegistryScopeError)) {
        throw error;
      }
    }
  }
  bindBorrowedRegistry(scoped, registry);
  scoped.declaredProviderOwners =
    declaredProviderOwners ??
    inheritedOwners ??
    getPluginRuntimeLoadContextState(registry)?.declaredProviderOwners;
  return scoped;
}

function applyPluginScope(
  scoped: PluginRuntimeGatewayRequestScope,
  scope: PluginRuntimePluginScope,
): void {
  scoped.pluginId = scope.pluginId;
  if (scope.pluginSource !== undefined) {
    scoped.pluginSource = scope.pluginSource;
  } else {
    delete scoped.pluginSource;
  }
  if (scope.pluginOrigin !== undefined) {
    scoped.pluginOrigin = scope.pluginOrigin;
  } else {
    delete scoped.pluginOrigin;
  }
  if (scope.pluginTrustedOfficialInstall !== undefined) {
    scoped.pluginTrustedOfficialInstall = scope.pluginTrustedOfficialInstall;
  } else {
    delete scoped.pluginTrustedOfficialInstall;
  }
}

/**
 * Runs work under the current gateway request scope while attaching plugin identity.
 */
export function withPluginRuntimePluginScope<T>(
  scope: PluginRuntimePluginScope,
  run: () => T,
  registry?: PluginRegistry,
  invocation?: PluginInstanceInvocation,
): T {
  const current = getPluginRuntimeGatewayRequestScope();
  // Instance calls combine registry and identity without adding a second async frame.
  const scoped: PluginRuntimeGatewayRequestScope = registry
    ? createRegistryScope(registry, current)
    : copyGatewayScope(current);
  applyPluginScope(scoped, scope);
  return runWithPluginGatewayScope(scoped, run, invocation);
}

/** Drops only generation selection; authenticated Gateway caller and authority stay attached. */
export function runOutsidePluginRuntimeRegistryScope<T>(run: () => T): T {
  const current = getPluginRuntimeGatewayRequestScope();
  if (!current) {
    return run();
  }
  // Registry selection and its declared provider index belong to the same generation.
  const scoped = copyGatewayScope(current, false);
  scoped.pluginRegistry = undefined;
  scoped.declaredProviderOwners = undefined;
  return runWithPluginGatewayScope(scoped, run);
}

export function getPluginRuntimeGatewayRequestScope():
  | PluginRuntimeGatewayRequestScope
  | undefined {
  return getPluginRuntimeExecutionFrame()?.gatewayScope;
}

/** Reads registration/request/active registry precedence without initializing a cold runtime. */
export function getPluginRegistryForContext(): PluginRegistry | null {
  const state = getPluginRegistryState();
  return (
    state?.registrationContext?.registry ??
    getPluginRuntimeGatewayRequestScope()?.pluginRegistry ??
    state?.activeRegistry ??
    null
  );
}

/** Live request context for trusted built-in tools that need direct runtime state. */
export function getInProcessGatewayRequestContext(
  resolveGatewayContext?: GatewayContextResolver,
): GatewayRequestContext | undefined {
  if (resolveGatewayContext) {
    return resolveGatewayContext();
  }
  const scope = getPluginRuntimeGatewayRequestScope();
  return scope?.resolveGatewayContext ? scope.resolveGatewayContext() : scope?.context;
}
