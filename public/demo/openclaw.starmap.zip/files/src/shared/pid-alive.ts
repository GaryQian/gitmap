// Native Node callers load this source closure without a TypeScript import resolver.
import childProcess from "node:child_process";
import fsSync from "node:fs";
import { ProcSafeError } from "@openclaw/proc-safe/errors";
import { readProcessIdentity } from "@openclaw/proc-safe/identity";
import { hasErrnoCode, isErrno } from "../infra/errno.ts";
import { resolveDiagnosticProcessEnv } from "../infra/process-env.ts";
import { readWindowsProcessStartTimeSync } from "../infra/windows-process-start.ts";
import { readFreeBsdProcessStartTime } from "./freebsd-process-identity.ts";

const PROCESS_START_TIMEOUT_MS = 1000;
declare const SEALED_RUNTIME_BUILD: boolean;
function readDarwinNativeIdentity(
  pid: number,
): { startedAt: number; startTimeMicros: number } | null | undefined {
  if (
    process.platform !== "darwin" ||
    (typeof SEALED_RUNTIME_BUILD === "boolean" && SEALED_RUNTIME_BUILD)
  ) {
    return undefined;
  }
  try {
    const identity = readProcessIdentity(pid);
    // A retained zombie is not a live owner. Do not recover it through ps.
    return identity && !identity.exited
      ? {
          // Published Darwin leases use epoch seconds, not microseconds.
          startedAt: Math.floor(identity.startTimeMicros / 1_000_000),
          startTimeMicros: identity.startTimeMicros,
        }
      : null;
  } catch {
    // Sealed or unavailable native runtimes retain the bounded diagnostic path.
    return undefined;
  }
}

/** Unknown observations never prove death; Linux keeps its thread-aware procfs policy. */
function readNativeLiveness(pid: number): boolean | undefined {
  if (
    !["darwin", "win32", "freebsd"].includes(process.platform) ||
    (typeof SEALED_RUNTIME_BUILD === "boolean" && SEALED_RUNTIME_BUILD)
  ) {
    return undefined;
  }
  try {
    const identity = readProcessIdentity(pid);
    return identity !== null && !identity.exited;
  } catch (error) {
    // Visibility policy can hide an existing PID even from kill(pid, 0).
    if (
      error instanceof ProcSafeError &&
      (error.code === "helper-unavailable" || error.code === "unsupported-platform")
    ) {
      return undefined;
    }
    return true;
  }
}
// Bound corrupted/cyclic ancestry while allowing nested service supervisors.
export const MAX_ANCESTOR_WALK_DEPTH = 32;

// Cache only a successful self read: this identity lasts for the process.
// Failed reads must retry, and foreign PIDs must stay fresh to detect PID reuse.
let selfStartTime: number | null = null;

function isValidPid(pid: number): boolean {
  return Number.isInteger(pid) && pid > 0;
}

// Android (Termux) runs the Linux kernel and reports its own process.platform.
function hasLinuxProcfs(): boolean {
  return process.platform === "linux" || process.platform === "android";
}

/**
 * Reject recycled worker TIDs and terminal leaders without live sibling threads.
 * Missing or reaped procfs snapshots require a fresh existence probe.
 */
function exitedLinuxStatus(pid: number, status: string): boolean | undefined {
  const state = status.match(/^State:\s+(\S)/m)?.[1];
  const threads = status.match(/^Threads:[ \t]+(\d+)[ \t]*$/m)?.[1];
  if (threads === "0") {
    // A read can outlive signal metadata; PID reuse or a nonleader exec may
    // still leave a live owner. The caller must repeat the kernel probe.
    return undefined;
  }
  // process.pid records a leader; kill(pid, 0) also accepts recycled worker TIDs.
  const tgid = status.match(/^Tgid:[ \t]+(\d+)[ \t]*$/m)?.[1];
  // pthread_exit can leave a terminal leader with live workers. Reaping also
  // moves the last retained task from Z to X before removing its PID.
  return (
    (tgid !== undefined && Number(tgid) !== pid) ||
    ((state === "Z" || state === "X") && threads === "1")
  );
}

function isMissingPid(pid: number): boolean {
  try {
    process.kill(pid, 0);
  } catch (error) {
    return hasErrnoCode(error, "ESRCH");
  }
  return false;
}

function isExitedLinuxProcess(pid: number): boolean {
  if (!hasLinuxProcfs()) {
    return false;
  }
  try {
    const exited = exitedLinuxStatus(pid, fsSync.readFileSync(`/proc/${pid}/status`, "utf8"));
    if (exited !== undefined) {
      return exited;
    }
  } catch {
    // Reaping can remove procfs after the caller's existence probe.
  }
  return isMissingPid(pid);
}

/** Async Linux transport retains the same terminal-leader and live-thread policy. */
export async function isPidDefinitelyDeadAsync(pid: number): Promise<boolean> {
  if (!hasLinuxProcfs()) {
    return isPidDefinitelyDead(pid);
  }
  if (!isValidPid(pid)) {
    return true;
  }
  try {
    process.kill(pid, 0);
  } catch (error) {
    return hasErrnoCode(error, "ESRCH");
  }
  try {
    const exited = exitedLinuxStatus(
      pid,
      await fsSync.promises.readFile(`/proc/${pid}/status`, "utf8"),
    );
    if (exited !== undefined) {
      return exited;
    }
  } catch {
    // A missing or unclassifiable row requires a fresh kernel absence probe.
  }
  return isMissingPid(pid);
}

/** Returns true only when a positive PID exists and is not a known terminal task. */
export function isPidAlive(pid: number): boolean {
  if (!isValidPid(pid)) {
    return false;
  }
  try {
    process.kill(pid, 0);
  } catch (error) {
    const code = isErrno(error) ? error.code : undefined;
    if (code !== "EPERM") {
      // A visibility policy can hide a live process even from the signal probe.
      return code === "ESRCH" ? (readNativeLiveness(pid) ?? false) : false;
    }
  }
  return readNativeLiveness(pid) ?? !isExitedLinuxProcess(pid);
}

/** Returns true only when the PID is invalid, missing, or a known terminal task. */
export function isPidDefinitelyDead(pid: number): boolean {
  if (!isValidPid(pid)) {
    return true;
  }
  let missing = false;
  try {
    process.kill(pid, 0);
  } catch (error) {
    const code = isErrno(error) ? error.code : undefined;
    if (code !== "ESRCH" && !(process.platform === "win32" && code === "EPERM")) {
      return false;
    }
    missing = code === "ESRCH";
  }
  const native = readNativeLiveness(pid);
  // Windows EPERM needs native exit evidence; FreeBSD ESRCH may hide a live PID.
  return native === undefined
    ? (missing && process.platform !== "freebsd") || isExitedLinuxProcess(pid)
    : !native;
}

function getDarwinProcessStartTime(
  pid: number,
  env: NodeJS.ProcessEnv,
  timeoutMs?: number,
): number | null {
  const started = performance.now();
  const native = readDarwinNativeIdentity(pid);
  if (native !== undefined) {
    return native?.startedAt ?? null;
  }
  // The default bounds ps itself; explicit deadlines also pay for native loading.
  const remainingMs =
    timeoutMs === undefined
      ? PROCESS_START_TIMEOUT_MS
      : Math.ceil(timeoutMs - (performance.now() - started));
  if (remainingMs <= 0) {
    return null;
  }
  try {
    const startedAt = childProcess
      .execFileSync("/bin/ps", ["-o", "lstart=", "-p", String(pid)], {
        encoding: "utf8",
        env: { ...resolveDiagnosticProcessEnv(env), LC_ALL: "C", TZ: "UTC" },
        stdio: ["ignore", "pipe", "ignore"],
        timeout: remainingMs,
        killSignal: "SIGKILL",
      })
      .trim();
    // Darwin's lstart output has no timezone. Force UTC for both ps and parsing so
    // a system timezone change cannot make a live lock owner look like PID reuse.
    const startedAtMs = Date.parse(`${startedAt} UTC`);
    return Number.isFinite(startedAtMs) ? Math.floor(startedAtMs / 1000) : null;
  } catch {
    return null;
  }
}

/** Parse the parent and birth identity from one Linux procfs stat snapshot. */
export function parseLinuxProcessStat(
  pid: number,
  stat: string,
): { parentPid: number; startedAt: number } | null {
  const commEndIndex = stat.lastIndexOf(")");
  if (commEndIndex < 0 || !stat.startsWith(`${pid} (`)) {
    return null;
  }
  // The comm field (field 2) is wrapped in parens and can contain spaces,
  // so split after the last ")" to get fields 3..N reliably.
  const afterComm = stat.slice(commEndIndex + 1).trimStart();
  const fields = afterComm.split(/\s+/);
  // field 22 (starttime) = index 19 after the comm-split (field 3 is index 0).
  const starttime = Number(fields[19]);
  const parentPid = Number(fields[1]);
  return Number.isSafeInteger(starttime) &&
    starttime >= 0 &&
    Number.isSafeInteger(parentPid) &&
    parentPid >= 0
    ? { parentPid, startedAt: starttime }
    : null;
}

/** Kernel parent and birth ticks share one procfs snapshot, independent of native addons. */
export function readLinuxProcessStat(pid: number): { parentPid: number; startedAt: number } | null {
  if (!isValidPid(pid) || !hasLinuxProcfs()) {
    return null;
  }
  try {
    return parseLinuxProcessStat(pid, fsSync.readFileSync(`/proc/${pid}/stat`, "utf8"));
  } catch {
    return null;
  }
}

/** Read the Linux procfs start identity used by Linux-owned runtime state. */
export function getProcessStartTime(pid: number): number | null {
  return readLinuxProcessStat(pid)?.startedAt ?? null;
}

/** Custody recovery needs native birth precision rather than the shipped lease timestamp format. */
export function getProcessInstanceStartTime(pid: number): number | null {
  if (!isValidPid(pid)) {
    return null;
  }
  if (hasLinuxProcfs()) {
    const startedAt = getProcessStartTime(pid);
    return Number.isSafeInteger(startedAt) ? startedAt : null;
  }
  const native = readDarwinNativeIdentity(pid);
  if (!native) {
    return null;
  }
  const startedAt = native.startTimeMicros;
  return Number.isSafeInteger(startedAt) ? startedAt : null;
}

/** Read a cross-platform process identity for filesystem lock ownership. */
export function getFileLockProcessStartTime(
  pid: number,
  env: NodeJS.ProcessEnv = process.env,
  timeoutMs?: number,
): number | null {
  if (!isValidPid(pid)) {
    return null;
  }
  const isSelf = pid === process.pid;
  if (isSelf && selfStartTime !== null) {
    return selfStartTime;
  }
  const startTime =
    process.platform === "darwin"
      ? getDarwinProcessStartTime(pid, env, timeoutMs)
      : process.platform === "win32"
        ? readWindowsProcessStartTimeSync(pid, timeoutMs, env)
        : process.platform === "freebsd"
          ? readFreeBsdProcessStartTime(pid)
          : getProcessStartTime(pid);
  if (isSelf && startTime !== null) {
    selfStartTime = startTime;
  }
  return startTime;
}
