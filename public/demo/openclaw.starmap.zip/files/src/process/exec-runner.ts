import process from "node:process";
import { expectDefined } from "@openclaw/normalization-core";
import { toErrorObject } from "@openclaw/normalization-core/error-coercion";
import {
  asPositiveFiniteNumber,
  clampPositiveTimerTimeoutMs,
  resolveOptionalIntegerOption,
  resolveTimerTimeoutMs,
} from "@openclaw/normalization-core/number-coercion";
import { isPromiseLike } from "@openclaw/normalization-core/promise-like";
import { hasErrnoCode } from "../infra/errno.js";
import {
  decodeWindowsOutputBuffer,
  resolveWindowsConsoleEncoding,
} from "../infra/windows-encoding.js";
import { createDeferredCore } from "../shared/deferred.js";
import { copyOwnedBuffer } from "../shared/owned-buffer.js";
import {
  EXIT_STDIO_GRACE_MS,
  hasChildProcessExited,
  releaseChildProcessOutputAfterExit,
} from "./child-process.js";
import {
  appendCapturedOutput,
  appendPreservedOutputLines,
  createCapturedOutputBuffers,
  finalizeCapturedOutput,
  flushPreservedOutputLine,
  MAX_PRESERVED_PENDING_LINE_BYTES,
  resolveMaxOutputBytes,
  resolveOutputCapture,
  shouldTerminateOnOutput,
  type CapturedOutputBuffers,
  type CommandOutputCaptureMode,
  type CommandOutputCaptureOption,
  type CommandOutputErrorOption,
  type CommandOutputLimitOption,
  type CommandOutputStream,
  type PreserveOutputLine,
} from "./exec-output.js";
import {
  createInterruptedCommandOutcome,
  createSanitizedCommandError,
  isPlainCommandExitFailure,
  isPlainCommandSignalFailure,
  recordCommandProcessCleanup,
  recordCommandProcessFailure,
  resolveProcessExitCode,
  TIMEOUT_EXIT_CODE,
  type SpawnResult,
} from "./exec-result.js";
import {
  COMMAND_PROCESS_TREE_KILL_GRACE_MS,
  resolveCommandProcessSignal,
  retainCommandProcessCleanup,
  spawnCommandWithInvocation,
  waitForCommandSpawn,
} from "./exec-spawn.js";
import { createCommandTerminationController } from "./exec-termination.js";
import type { ProcessExecutionIntent } from "./linux-exec-cgroup.js";
import { setProcessTimeout } from "./process-deadline.js";
import { BrokerChild } from "./spawn-broker/child.js";

type CommandTerminationReason = SpawnResult["termination"] | "output-limit";

export type CommandOptions = {
  executionIntent?: ProcessExecutionIntent;
  executionScopeKey?: string;
  timeoutMs?: number;
  cwd?: string;
  input?: string | Uint8Array;
  /** Borrow a caller-owned descriptor as stdin without buffering or piping its bytes. */
  stdinFileDescriptor?: number;
  /** Synchronous admission with the spawned PID and argv, before input is released. */
  beforeInput?: (pid: number, argv?: readonly string[]) => void;
  /** Prepare physical source facts after startup, before the final synchronous input grant. */
  prepareInput?: (pid: number, argv?: readonly string[]) => Promise<void>;
  baseEnv?: NodeJS.ProcessEnv;
  env?: NodeJS.ProcessEnv;
  /** Operation-owned output of resolveCommandEnv. */
  preparedEnv?: NodeJS.ProcessEnv;
  windowsVerbatimArguments?: boolean;
  noOutputTimeoutMs?: number;
  signal?: AbortSignal;
  maxOutputBytes?: number | { stdout?: number; stderr?: number };
  maxCombinedOutputBytes?: number;
  outputCapture?: CommandOutputCaptureOption;
  /** Observe raw output without owning child lifecycle. Return false to stop the command. */
  onOutputChunk?: (chunk: Buffer, stream: CommandOutputStream) => boolean | void;
  /** Accept a successful exit when only the selected diagnostic output stream failed. */
  tolerateOutputError?: { stdout?: boolean; stderr?: boolean };
  /** Terminate when the selected output stream emits an error. */
  terminateOnOutputError?: CommandOutputErrorOption;
  terminateOnOutputLimit?: CommandOutputLimitOption;
  maxPreservedOutputLines?: number;
  preserveOutputLine?: PreserveOutputLine;
  killProcessTree?: boolean;
  /** Join owned descendants even after a successful root exits. */
  requireProcessTreeExtinction?: boolean;
  /** Initial signal for direct-child and graceful process-group cancellation. */
  killSignal?: NodeJS.Signals | number;
  /** Grace between graceful termination and the force-kill fallback. */
  killGraceMs?: number;
};

export async function runCommandWithTimeout(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
): Promise<SpawnResult> {
  return await runCommandWithOutputEncoding(argv, optionsOrTimeout, false);
}

/** Run a command whose stdout and stderr are defined to be UTF-8 on every platform. */
export async function runUtf8CommandWithTimeout(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
): Promise<SpawnResult> {
  return await runCommandWithOutputEncoding(argv, optionsOrTimeout, true);
}

export type BufferSpawnResult = Omit<SpawnResult, "stdout" | "stderr"> & {
  stdout: Buffer;
  stderr: Buffer;
  windowsEncoding: string | null;
};

/** Preserve the ordinary process lifecycle while deferring decoding to its consumer. */
export async function runCommandBuffersWithTimeout(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
): Promise<BufferSpawnResult> {
  return await runCommandWithOutputEncoding(argv, optionsOrTimeout, false, true);
}

/** Retain raw bytes with UTF-8 capture boundaries, independent of the Windows console page. */
export async function runUtf8CommandBuffersWithTimeout(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
): Promise<BufferSpawnResult> {
  return await runCommandWithOutputEncoding(argv, optionsOrTimeout, true, true);
}

async function runCommandWithOutputEncoding(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
  forceUtf8: boolean,
): Promise<SpawnResult>;
async function runCommandWithOutputEncoding(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
  forceUtf8: boolean,
  raw: true,
): Promise<BufferSpawnResult>;
async function runCommandWithOutputEncoding(
  argv: string[],
  optionsOrTimeout: number | CommandOptions,
  forceUtf8: boolean,
  raw = false,
): Promise<SpawnResult | BufferSpawnResult> {
  const options: CommandOptions =
    typeof optionsOrTimeout === "number" ? { timeoutMs: optionsOrTimeout } : optionsOrTimeout;
  const {
    timeoutMs,
    cwd,
    input,
    stdinFileDescriptor,
    baseEnv,
    env,
    noOutputTimeoutMs,
    killProcessTree,
    killSignal,
    killGraceMs,
  } = options;
  const signal = resolveCommandProcessSignal(options.signal);
  const resolvedTimeoutMs =
    typeof timeoutMs === "number" ? resolveTimerTimeoutMs(timeoutMs, 1) : undefined;
  if (options.requireProcessTreeExtinction && !killProcessTree) {
    throw new Error("Process-tree extinction requires process-tree ownership");
  }
  const hasInput = input !== undefined;
  const guardedInput = options.beforeInput !== undefined || options.prepareInput !== undefined;
  if (stdinFileDescriptor !== undefined) {
    if (!Number.isInteger(stdinFileDescriptor) || stdinFileDescriptor < 0) {
      throw new Error("stdinFileDescriptor must be a nonnegative integer");
    }
    if (hasInput) {
      throw new Error("Command accepts either input or stdinFileDescriptor, not both");
    }
  }
  if (guardedInput && !hasInput) {
    throw new Error("Child input admission requires explicit input");
  }
  const resolvedKillGraceMs = resolveTimerTimeoutMs(
    killGraceMs,
    COMMAND_PROCESS_TREE_KILL_GRACE_MS,
    0,
  );

  if (signal?.aborted) {
    const interrupted = {
      code: null,
      signal: null,
      killed: false,
      termination: "signal" as const,
      cleanup: "normal" as const,
      noOutputTimedOut: false,
    };
    return raw
      ? { ...interrupted, stdout: Buffer.alloc(0), stderr: Buffer.alloc(0), windowsEncoding: null }
      : { ...interrupted, stdout: "", stderr: "" };
  }

  const stdoutCapture = createCapturedOutputBuffers();
  const stderrCapture = createCapturedOutputBuffers();
  const maxStdoutBytes = resolveMaxOutputBytes(options.maxOutputBytes, "stdout");
  const maxStderrBytes = resolveMaxOutputBytes(options.maxOutputBytes, "stderr");
  const maxCombinedOutputBytes = resolveOptionalIntegerOption(
    asPositiveFiniteNumber(options.maxCombinedOutputBytes),
    { min: 1 },
  );
  const stdoutCaptureMode = resolveOutputCapture(options.outputCapture, "stdout");
  const stderrCaptureMode = resolveOutputCapture(options.outputCapture, "stderr");
  if (maxCombinedOutputBytes !== undefined && stdoutCaptureMode !== stderrCaptureMode) {
    throw new Error("maxCombinedOutputBytes requires matching stdout and stderr capture modes");
  }
  const usesCombinedTailCapture =
    maxCombinedOutputBytes !== undefined &&
    stdoutCaptureMode === "tail" &&
    stderrCaptureMode === "tail";
  const maxPreservedPendingLineBytes = Math.min(
    Math.max(maxStdoutBytes, maxStderrBytes),
    MAX_PRESERVED_PENDING_LINE_BYTES,
  );
  const maxPreservedOutputLines = Math.max(0, Math.floor(options.maxPreservedOutputLines ?? 16));
  const windowsEncoding = forceUtf8 ? null : resolveWindowsConsoleEncoding();
  const cancelController = new AbortController();
  let termination: CommandTerminationReason | undefined;
  let childExitState: { code: number | null; signal: NodeJS.Signals | null } | undefined;
  let commandSettled = false;
  let combinedOutputBytes = 0;
  let combinedCapturedBytes = 0;
  const outputBytesByStream = { stdout: 0, stderr: 0 };
  const combinedCapturedBytesByStream = { stdout: 0, stderr: 0 };
  const combinedTailChunks: Array<{ stream: CommandOutputStream; buffer: Buffer }> = [];
  let noOutputTimer: ReturnType<typeof setProcessTimeout> | undefined;
  let eofGraceTimer: ReturnType<typeof setProcessTimeout> | undefined;
  let outputObserverError: unknown;
  let outputErrorStream: CommandOutputStream | undefined;
  let terminatingOutputError: Error | undefined;

  const { child, invocation } = spawnCommandWithInvocation(argv, {
    executionIntent: options.executionIntent,
    executionScopeKey: options.executionScopeKey,
    buffer: false,
    cancelSignal: cancelController.signal,
    inheritScopeCancellation: false,
    cwd,
    detached: Boolean(killProcessTree && process.platform !== "win32"),
    encoding: "buffer",
    executionTimeoutMs: resolvedTimeoutMs,
    baseEnv,
    env,
    preparedEnv: options.preparedEnv,
    forceKillAfterDelay: resolvedKillGraceMs,
    killSignal,
    ...(hasInput && !guardedInput ? { input } : {}),
    reject: false,
    stdio: [
      // SAFETY: Execa forwards arbitrary numeric descriptors to Node; its stdin type narrows them to fd 0.
      (options.stdinFileDescriptor as 0 | undefined) ?? (hasInput ? "pipe" : "inherit"),
      "pipe",
      "pipe",
    ],
    stripFinalNewline: false,
    windowsVerbatimArguments: options.windowsVerbatimArguments,
  });
  const startupReady =
    child.pid === undefined || process.platform === "linux" || process.platform === "android"
      ? waitForCommandSpawn(child, Boolean(killProcessTree))
      : undefined;
  let waitingForSpawn = startupReady !== undefined;
  const startupCanceled = createDeferredCore<Exclude<CommandTerminationReason, "exit">>();
  const nodeChild = child.nodeChildProcess;
  let inputReleased = guardedInput ? false : undefined;
  const failedProcess = (error: unknown, cleanup: SpawnResult["cleanup"] = "uncertain") => {
    const failure = recordCommandProcessFailure(error, {
      pid: nodeChild.pid,
      code: childExitState?.code ?? nodeChild.exitCode ?? null,
      cleanup,
      inputReleased,
      termination:
        termination === "output-limit"
          ? "signal"
          : (termination ?? (nodeChild.signalCode ? "signal" : "exit")),
    });
    return Object.assign(failure, { cleanup });
  };
  const ownsExitedProcessTree = Boolean(killProcessTree && process.platform !== "win32");
  const resolvedNoOutputTimeoutMs = clampPositiveTimerTimeoutMs(noOutputTimeoutMs);
  const ownsOutputDeadline =
    ownsExitedProcessTree &&
    (resolvedTimeoutMs !== undefined || resolvedNoOutputTimeoutMs !== undefined);
  let releaseOutput: (() => void) | undefined;
  const terminationController = createCommandTerminationController({
    child: nodeChild,
    spawned: startupReady,
    cancelController,
    baseEnv,
    env,
    processTree: killProcessTree ? { mode: "graceful" } : undefined,
    isChildExited: () => childExitState !== undefined,
    isCommandSettled: () => commandSettled,
    killGraceMs: resolvedKillGraceMs,
    killSignal,
  });
  const processCleanup = (async () => {
    await child.catch(() => undefined);
    commandSettled = true;
    await startupReady?.catch(() => {});
    return await terminationController.settle();
  })();
  retainCommandProcessCleanup(processCleanup);
  void processCleanup.catch(() => {});
  nodeChild.once("exit", (code, signalValue) => {
    childExitState = { code, signal: signalValue };
    // Successful tree output belongs to its command deadline, not the diagnostic
    // idle cutoff. Failed, terminated, and unowned output still gets a bounded drain.
    if (!ownsOutputDeadline || code !== 0 || termination) {
      releaseOutput = releaseChildProcessOutputAfterExit(nodeChild);
    }
    // An inner timeout can become an ordinary failed exit while its descendants survive.
    // Retain the existing tree owner through its drain without changing that exit result.
    if (killProcessTree && !termination && (code !== 0 || options.requireProcessTreeExtinction)) {
      terminationController.terminate();
    }
  });

  const cancel = (reason: Exclude<CommandTerminationReason, "exit">, eofGraceElapsed = false) => {
    // Failed roots already own a drain; later deadlines must preserve their exit result.
    // Successful POSIX roots retain deadline ownership of inherited descendants.
    // Output caps remain meaningful for bytes drained after either exit.
    if (
      termination ||
      commandSettled ||
      (childExitState &&
        reason !== "output-limit" &&
        (!ownsExitedProcessTree || childExitState.code !== 0))
    ) {
      return;
    }
    if (
      (reason === "timeout" || reason === "no-output-timeout") &&
      (childExitState || hasChildProcessExited(nodeChild))
    ) {
      if (!ownsOutputDeadline || (childExitState?.code ?? nodeChild.exitCode) !== 0) {
        return;
      }
      if (
        (!nodeChild.stdout || nodeChild.stdout.readableEnded) &&
        (!nodeChild.stderr || nodeChild.stderr.readableEnded)
      ) {
        return;
      }
      if (!eofGraceElapsed) {
        // EOF can follow root exit by a poll turn; bound that grace without renewing the command deadline.
        eofGraceTimer ??= setProcessTimeout(() => cancel(reason, true), EXIT_STDIO_GRACE_MS);
        return;
      }
    }
    eofGraceTimer?.clear();
    termination = reason;
    if (waitingForSpawn) {
      startupCanceled.resolve(reason);
    }
    if (childExitState) {
      // An escaped pipe holder can survive group termination; bound its final drain.
      releaseOutput ??= releaseChildProcessOutputAfterExit(nodeChild);
    }
    terminationController.cancel();
  };
  const armNoOutputTimer = () => {
    if (
      resolvedNoOutputTimeoutMs === undefined ||
      commandSettled ||
      termination ||
      (childExitState && !ownsExitedProcessTree)
    ) {
      return;
    }
    if (noOutputTimer) {
      noOutputTimer.refresh();
    } else {
      noOutputTimer = setProcessTimeout(
        () => cancel("no-output-timeout"),
        resolvedNoOutputTimeoutMs,
      );
    }
  };

  const timeoutTimer =
    resolvedTimeoutMs === undefined
      ? undefined
      : setProcessTimeout(() => cancel("timeout"), resolvedTimeoutMs);
  const onAbort = () => cancel("signal");
  signal?.addEventListener("abort", onAbort, { once: true });
  armNoOutputTimer();
  const clearTimers = () => {
    timeoutTimer?.clear();
    noOutputTimer?.clear();
    eofGraceTimer?.clear();
    noOutputTimer = undefined;
    signal?.removeEventListener("abort", onAbort);
  };
  const captureOutput = (
    capture: CapturedOutputBuffers,
    buffer: Buffer,
    maxBytes: number,
    stream: CommandOutputStream,
    captureMode: CommandOutputCaptureMode,
  ) => {
    outputBytesByStream[stream] += buffer.byteLength;
    const streamLimitExceeded = outputBytesByStream[stream] > maxBytes;
    if (maxCombinedOutputBytes === undefined) {
      appendCapturedOutput(capture, buffer, maxBytes, captureMode);
      if (streamLimitExceeded && shouldTerminateOnOutput(options.terminateOnOutputLimit, stream)) {
        cancel("output-limit");
      }
      return;
    }

    const combinedBytesBeforeChunk = combinedOutputBytes;
    combinedOutputBytes += buffer.byteLength;
    const combinedLimitExceeded = combinedOutputBytes > maxCombinedOutputBytes;
    if (usesCombinedTailCapture) {
      combinedTailChunks.push({ stream, buffer });
      combinedCapturedBytes += buffer.byteLength;
      combinedCapturedBytesByStream[stream] += buffer.byteLength;

      const removeCapturedBytes = (index: number, requestedBytes: number) => {
        const entry = expectDefined(combinedTailChunks[index], "combined tail chunk");
        const removedBytes = Math.min(requestedBytes, entry.buffer.byteLength);
        if (removedBytes === entry.buffer.byteLength) {
          combinedTailChunks.splice(index, 1);
        } else {
          entry.buffer = copyOwnedBuffer(entry.buffer.subarray(removedBytes));
        }
        combinedCapturedBytes -= removedBytes;
        combinedCapturedBytesByStream[entry.stream] -= removedBytes;
        (entry.stream === "stdout" ? stdoutCapture : stderrCapture).truncatedBytes += removedBytes;
      };

      while (combinedCapturedBytesByStream[stream] > maxBytes) {
        const index = combinedTailChunks.findIndex((entry) => entry.stream === stream);
        if (index < 0) {
          break;
        }
        removeCapturedBytes(index, combinedCapturedBytesByStream[stream] - maxBytes);
      }
      let combinedOverflow = combinedCapturedBytes - maxCombinedOutputBytes;
      while (combinedOverflow > 0) {
        removeCapturedBytes(0, combinedOverflow);
        combinedOverflow = combinedCapturedBytes - maxCombinedOutputBytes;
      }
    } else {
      const remaining = Math.max(0, maxCombinedOutputBytes - combinedBytesBeforeChunk);
      const maxCaptureBytes = Math.min(maxBytes, capture.bytes + remaining);
      appendCapturedOutput(capture, buffer, maxCaptureBytes, captureMode);
    }
    if (
      (combinedLimitExceeded &&
        shouldTerminateOnOutput(options.terminateOnOutputLimit, "combined")) ||
      (streamLimitExceeded && shouldTerminateOnOutput(options.terminateOnOutputLimit, stream))
    ) {
      cancel("output-limit");
    }
  };

  const observeOutputChunk = (chunk: Buffer | string, stream: CommandOutputStream): Buffer => {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    if (termination || !options.onOutputChunk) {
      return buffer;
    }
    try {
      if (options.onOutputChunk(buffer, stream) === false) {
        cancel("output-limit");
      }
    } catch (error) {
      outputObserverError = error;
      cancel("output-limit");
    }
    return buffer;
  };

  const onOutputError = (error: unknown, stream: CommandOutputStream) => {
    outputErrorStream ??= stream;
    if (
      termination ||
      options.tolerateOutputError?.[stream] === true ||
      !shouldTerminateOnOutput(options.terminateOnOutputError, stream)
    ) {
      return;
    }
    terminatingOutputError = toErrorObject(error, `Command ${stream} stream failed`);
    Object.assign(terminatingOutputError, { outputErrorStream: stream });
    cancel("signal");
  };
  const outputStreams = [
    { stream: "stdout", capture: stdoutCapture, maxBytes: maxStdoutBytes, mode: stdoutCaptureMode },
    { stream: "stderr", capture: stderrCapture, maxBytes: maxStderrBytes, mode: stderrCaptureMode },
  ] as const;
  const finalizeOutput = () => {
    for (const { stream, capture } of outputStreams) {
      flushPreservedOutputLine({
        capture,
        stream,
        preserveOutputLine: options.preserveOutputLine,
        maxPreservedOutputLines,
        maxPendingLineBytes: maxPreservedPendingLineBytes,
      });
    }

    if (usesCombinedTailCapture) {
      for (const entry of combinedTailChunks) {
        const capture = entry.stream === "stdout" ? stdoutCapture : stderrCapture;
        capture.chunks.push(entry.buffer);
        capture.bytes += entry.buffer.byteLength;
      }
    }

    const stdout = finalizeCapturedOutput(stdoutCapture, stdoutCaptureMode, forceUtf8);
    const stderr = finalizeCapturedOutput(stderrCapture, stderrCaptureMode, forceUtf8);
    const captured = {
      stdoutTruncatedBytes: stdoutCapture.truncatedBytes || undefined,
      stderrTruncatedBytes: stderrCapture.truncatedBytes || undefined,
      preservedStdoutLines:
        stdoutCapture.preservedLines.length > 0 ? stdoutCapture.preservedLines : undefined,
      preservedStderrLines:
        stderrCapture.preservedLines.length > 0 ? stderrCapture.preservedLines : undefined,
    };
    return raw
      ? { ...captured, stdout, stderr, windowsEncoding }
      : {
          ...captured,
          stdout: forceUtf8
            ? stdout.toString("utf8")
            : decodeWindowsOutputBuffer({ buffer: stdout, windowsEncoding }),
          stderr: forceUtf8
            ? stderr.toString("utf8")
            : decodeWindowsOutputBuffer({ buffer: stderr, windowsEncoding }),
        };
  };
  const subscribeOutput = () => {
    child.stdout?.once("error", (error) => onOutputError(error, "stdout"));
    child.stderr?.once("error", (error) => onOutputError(error, "stderr"));
    for (const { stream, capture, maxBytes, mode } of outputStreams) {
      child[stream]?.on("data", (chunk) => {
        const buffer = observeOutputChunk(chunk, stream);
        appendPreservedOutputLines({
          capture,
          chunk: buffer,
          stream,
          preserveOutputLine: options.preserveOutputLine,
          maxPreservedOutputLines,
          maxPendingLineBytes: maxPreservedPendingLineBytes,
        });
        captureOutput(capture, buffer, maxBytes, stream, mode);
        armNoOutputTimer();
      });
    }
  };
  if (nodeChild instanceof BrokerChild && nodeChild.pid === undefined) {
    nodeChild.once("spawn", subscribeOutput);
  } else {
    subscribeOutput();
  }

  const throwOutputError = (cleanup: SpawnResult["cleanup"]) => {
    if (terminatingOutputError || outputObserverError !== undefined) {
      throw failedProcess(
        terminatingOutputError ??
          toErrorObject(outputObserverError, "Command output observer failed"),
        cleanup,
      );
    }
  };
  if (startupReady) {
    let interrupted: Exclude<CommandTerminationReason, "exit"> | undefined;
    try {
      interrupted = await Promise.race([
        startupReady.then(() => undefined),
        startupCanceled.promise,
      ]);
    } catch (error) {
      clearTimers();
      throw failedProcess(
        error,
        nodeChild instanceof BrokerChild && nodeChild.notStarted ? "normal" : "uncertain",
      );
    }
    if (interrupted) {
      clearTimers();
      // The result cannot claim extinction before admission settles. Keep the same
      // termination owner through late readiness and final output drainage.
      void processCleanup.finally(() => releaseOutput?.()).catch(() => {});
      const stopped = createInterruptedCommandOutcome({
        reason: interrupted,
        pid: nodeChild.pid,
        killed: nodeChild.killed,
      });
      throwOutputError("uncertain");
      return recordCommandProcessCleanup(
        { ...stopped, ...finalizeOutput() },
        killProcessTree &&
          nodeChild.pid !== undefined &&
          (process.platform === "linux" || process.platform === "android")
          ? processCleanup
          : undefined,
      );
    }
    waitingForSpawn = false;
  }

  let inputAdmissionError: Error | undefined;
  if (guardedInput) {
    nodeChild.stdin?.once("error", (cause) => {
      // Execa preserves the child's result when it closes input early; other faults still cancel.
      if (hasErrnoCode(cause, "EPIPE")) {
        return;
      }
      inputAdmissionError ??= toErrorObject(cause, "Command input failed");
      cancel("signal");
    });
    try {
      if (nodeChild.pid === undefined || !nodeChild.stdin) {
        throw new Error("Child input admission has no spawned process");
      }
      if (options.prepareInput) {
        // Preparation retains caller resources even when the child exits first.
        await options.prepareInput(nodeChild.pid, nodeChild.spawnargs);
      }
      signal?.throwIfAborted();
      if (termination || hasChildProcessExited(nodeChild)) {
        throw new Error("Child retired before input admission");
      }
      const admitted: unknown = options.beforeInput?.(nodeChild.pid, nodeChild.spawnargs);
      if (admitted !== undefined) {
        if (isPromiseLike(admitted)) {
          void Promise.resolve(admitted).catch(() => undefined);
        }
        throw new TypeError("Child input admission must complete synchronously");
      }
      // A partial write or synchronous stream failure cannot claim withheld input.
      inputReleased = true;
      nodeChild.stdin.end(input);
    } catch (cause) {
      inputAdmissionError = toErrorObject(cause, "Child input admission failed");
      // EOF releases children blocked on input; keep it withheld until process exit.
      cancel("signal");
    }
  }

  const result = await child
    .finally(() => {
      commandSettled = true;
      clearTimers();
      releaseOutput?.();
    })
    .catch((error: unknown) => {
      throw failedProcess(error);
    });
  if (result.timedOut) {
    termination ??= "timeout";
  }
  let cleanup = await processCleanup.catch((error: unknown) => {
    throw failedProcess(error);
  });
  const resolvedSignal = result.signal ?? childExitState?.signal ?? nodeChild.signalCode ?? null;
  // An explicit POSIX tree join already confirmed extinction in the exit handler.
  if (
    cleanup === "normal" &&
    resolvedSignal &&
    !(ownsExitedProcessTree && options.requireProcessTreeExtinction)
  ) {
    cleanup = "uncertain";
  }
  if (inputAdmissionError) {
    throw failedProcess(inputAdmissionError, cleanup);
  }
  throwOutputError(cleanup);
  // Patched Node can report null/null after a cmd.exe shim exits. Execa turns
  // that into a cause-less failure; preserve the shim fallback only post-spawn.
  const isCauseLessWindowsShimResult =
    !termination &&
    invocation.usesWindowsExitCodeShim &&
    typeof nodeChild.pid === "number" &&
    result.code === undefined &&
    result.cause === undefined &&
    !result.timedOut &&
    !result.isCanceled &&
    !result.isMaxBuffer &&
    !result.isTerminated;
  if (
    result.failed &&
    !termination &&
    !isPlainCommandExitFailure(result) &&
    !isPlainCommandSignalFailure(result) &&
    !isCauseLessWindowsShimResult &&
    !(
      result.exitCode === 0 &&
      outputErrorStream !== undefined &&
      options.tolerateOutputError?.[outputErrorStream] === true
    )
  ) {
    const error = createSanitizedCommandError(result);
    const failedCleanup =
      typeof nodeChild.pid === "number" ? (cleanup === "normal" ? "uncertain" : cleanup) : "normal";
    if (outputErrorStream) {
      Object.assign(error, { outputErrorStream });
    }
    throw failedProcess(error, failedCleanup);
  }

  const killIssuedByAbort = termination === "signal" || termination === "output-limit";
  const resolvedCode = resolveProcessExitCode({
    explicitCode: result.exitCode ?? childExitState?.code,
    childExitCode: nodeChild.exitCode,
    resolvedSignal,
    usesWindowsExitCodeShim: invocation.usesWindowsExitCodeShim,
    timedOut: termination === "timeout",
    noOutputTimedOut: termination === "no-output-timeout",
    killIssuedByTimeout: termination === "timeout" || termination === "no-output-timeout",
    killIssuedByAbort,
  });
  termination ??= resolvedSignal != null || result.isTerminated ? "signal" : "exit";
  const normalizedCode =
    termination === "timeout" || termination === "no-output-timeout"
      ? resolvedCode == null || resolvedCode === 0
        ? TIMEOUT_EXIT_CODE
        : resolvedCode
      : resolvedCode;

  const settled = {
    pid: nodeChild.pid,
    code: normalizedCode,
    signal: resolvedSignal,
    killed: nodeChild.killed,
    killIssuedByAbort: killIssuedByAbort || undefined,
    cleanup,
    termination: termination === "output-limit" ? ("signal" as const) : termination,
    noOutputTimedOut: termination === "no-output-timeout",
    outputLimitExceeded: termination === "output-limit" || undefined,
    ...(outputErrorStream ? { outputErrorStream } : {}),
  };
  return { ...settled, ...finalizeOutput() };
}
