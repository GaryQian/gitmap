import { extractErrorCode } from "@openclaw/normalization-core/error-coercion";
import { throwSqliteLifecycleErrors } from "../infra/sqlite-lifecycle-errors.js";
import {
  findChangedDatabasePaths,
  readDatabasePathIdentity,
  inspectDatabasePathIdentitySync,
  readDatabasePathIdentitySync,
  type DatabasePathIdentity,
} from "../infra/sqlite-worker-identity.js";
import { createDeferredCore } from "../shared/deferred.js";
import { resolveDatabasePath } from "./openclaw-state-db.paths.js";
import {
  getOpenClawDatabaseMaintenanceScope,
  maintenanceResources,
  runMaintenance,
  type AgentSchemaMigration,
  type MaintenanceResource,
  type OpenClawDatabaseMaintenanceScope,
} from "./openclaw-state-maintenance-context.js";

export type { OpenClawDatabaseMaintenanceScope } from "./openclaw-state-maintenance-context.js";
export {
  captureOpenClawDatabaseMaintenanceResource,
  getOpenClawDatabaseMaintenanceResourceScope,
  getOpenClawDatabaseMaintenanceScope,
  isOpenClawDatabaseMaintenanceResourceOwned,
  isOpenClawDatabaseMaintenanceWorkerAccess,
  observeOpenClawDatabaseMaintenanceResource,
  runOutsideOpenClawDatabaseMaintenanceScope,
} from "./openclaw-state-maintenance-context.js";

const STATE_DATABASE_READ_ADMISSION_INVALIDATED = "STATE_DATABASE_READ_ADMISSION_INVALIDATED";

export class StateDatabaseReadAdmissionInvalidatedError extends Error {
  readonly code = STATE_DATABASE_READ_ADMISSION_INVALIDATED;
}

export function isStateDatabaseReadAdmissionInvalidatedError(error: unknown): boolean {
  return extractErrorCode(error) === STATE_DATABASE_READ_ADMISSION_INVALIDATED;
}

export type OpenClawStateDatabaseReadAdmission = {
  readonly databasePath: string;
  /** Stable across first creation and aliases; coordinates work but grants no authority. */
  readonly coordinationKey: string;
  readonly identity: DatabasePathIdentity;
  captureIntegrity?: () => OpenClawStateIntegrityAdmission;
  assertCurrent: () => void;
};
export type OpenClawStateIntegrityAdmission = {
  identity: DatabasePathIdentity;
  /** Physical-owner lifetime survives renewable schema and integrity proof. */
  readonly lifetime: { readonly revision: SharedArrayBuffer; readonly epoch: bigint };
  readonly revision: SharedArrayBuffer;
  readonly epoch: bigint;
  readonly proof: SharedArrayBuffer;
};
export type OpenClawStateDatabaseAsyncResource = {
  /** Retain the admission getter so first creation can publish its physical identity. */
  admission?: Pick<OpenClawStateDatabaseReadAdmission, "identity">;
  /** Shared execution resources close only after accepted owners settle their remaining work. */
  phase?: "after-resources";
  close: (identity?: DatabasePathIdentity) => Promise<void>;
};

type IdentityRecord = {
  readonly coordinationKey: string;
  identity: DatabasePathIdentity;
  paths: Set<string>;
  generation: { integrity: OpenClawStateIntegrityAdmission };
  admissions: Map<string, OpenClawStateDatabaseReadAdmission>;
};
type ReadSeal = { record?: IdentityRecord };
type CloseAttempt = {
  /** Absent after failed drainage released reads; the next attempt seals again. */
  seal?: ReadSeal;
  /** A published replacement keeps reads sealed until this record's native handle retires. */
  superseded?: true;
  retained: Set<OpenClawStateDatabaseAsyncResource>;
  pending?: Promise<boolean>;
  queue?: Set<OpenClawStateDatabaseAsyncResource>;
};

/** Associate lexical database work with exact resources, never all files beneath a root. */
export function createOpenClawDatabaseMaintenanceScope(
  options?:
    | {
        schemaMaintenance?: false;
        sqliteIntegrityCheck?: "quick" | "full";
        assertOwnerCurrent?: (access?: "read") => void;
        assertDatabaseAccess?: (databasePath: string) => void;
      }
    | {
        schemaMaintenance: true;
        sqliteIntegrityCheck?: "quick" | "full";
        assertOwnerCurrent: (access?: "read") => void;
        assertDatabaseAccess?: (databasePath: string) => void;
      },
): OpenClawDatabaseMaintenanceScope {
  const parent = getOpenClawDatabaseMaintenanceScope();
  const assertOwnerCurrent = options?.assertOwnerCurrent;
  const assertDatabaseAccess = options?.assertDatabaseAccess;
  const pending = new Set<Promise<unknown>>();
  const schemaMigrationChecks = new Set<(migration: AgentSchemaMigration) => void>();
  const resources = new Map<object, MaintenanceResource>();
  let closed = false;
  let checkingOwner = false;
  let closing: Promise<void> | undefined;
  const assertOpen = () => {
    if (closed) {
      throw new Error("Database maintenance resource scope is closed");
    }
  };
  const assertAdmissionLifecycle = () => {
    assertOpen();
    const inherited = maintenanceResources.current.getStore();
    if (closing && !(inherited?.scope === scope && inherited.active)) {
      throw new Error("Database maintenance resource admission is closed");
    }
  };
  const scope: OpenClawDatabaseMaintenanceScope = {
    ownsSchemaMaintenance:
      options?.schemaMaintenance === true || parent?.ownsSchemaMaintenance === true,
    sqliteIntegrityCheck: options?.sqliteIntegrityCheck ?? parent?.sqliteIntegrityCheck,
    assertOwnerCurrent(access) {
      assertOpen();
      if (checkingOwner) {
        if (access === "read") {
          return;
        }
        // Function names identify the admission without exposing stack paths or arguments.
        const callers = new Error().stack
          ?.split("\n")
          .slice(2, 6)
          .flatMap((line) => line.match(/^\s+at (?:async )?([\w$.]+) \(/u)?.[1] ?? [])
          .join(" <- ")
          .slice(0, 160);
        throw new Error(
          `Database maintenance authority check cannot admit a nested effect (access=effect; caller=${callers || "unknown"})`,
        );
      }
      checkingOwner = true;
      try {
        parent?.assertOwnerCurrent(access);
        assertOwnerCurrent?.(access);
      } finally {
        checkingOwner = false;
      }
    },
    assertAdmission() {
      assertOpen();
      scope.assertOwnerCurrent();
      assertAdmissionLifecycle();
    },
    assertReadAdmission() {
      assertAdmissionLifecycle();
      // Current authority needs policy rows from this same store. Keep its resource
      // custody, but do not recurse into a check already evaluating those rows.
      scope.assertOwnerCurrent("read");
      assertAdmissionLifecycle();
    },
    assertDatabaseAccess(databasePath) {
      scope.assertAdmission();
      if (assertDatabaseAccess) {
        assertDatabaseAccess(databasePath);
      } else if (parent) {
        parent.assertDatabaseAccess(databasePath);
      } else {
        throw new Error("Database maintenance scope does not own this database");
      }
    },
    assertCleanupDatabaseAccess(databasePath) {
      assertOpen();
      // Revoked operation authority cannot strand resources under the same physical owner.
      if (assertDatabaseAccess) {
        assertDatabaseAccess(databasePath);
      } else if (parent) {
        parent.assertCleanupDatabaseAccess(databasePath);
      } else {
        throw new Error("Database maintenance scope does not own this database");
      }
    },
    addAgentSchemaMigrationCheck(check) {
      scope.assertAdmission();
      schemaMigrationChecks.add(check);
    },
    assertAgentSchemaMigration(migration) {
      assertOpen();
      scope.assertOwnerCurrent();
      parent?.assertAgentSchemaMigration(migration);
      for (const check of schemaMigrationChecks) {
        check(migration);
      }
    },
    run(operation) {
      assertAdmissionLifecycle();
      return runMaintenance(scope, () => {
        scope.assertAdmission();
        return operation();
      });
    },
    track(operation) {
      assertOpen();
      pending.add(operation);
      const settled = () => pending.delete(operation);
      void operation.then(settled, settled);
      return operation;
    },
    own(resource, phase, close) {
      assertOpen();
      resources.set(resource, { phase, close });
      maintenanceResources.claims.set(resource, {
        scope,
        phase,
        close,
        release: () => resources.delete(resource),
      });
    },
    close(beforeResources) {
      if (closing) {
        return closing;
      }
      // A disposer can reenter admission before its first awaited cleanup.
      const completion = createDeferredCore();
      closing = completion.promise;
      void maintenanceResources.current
        .run({ scope, active: true }, async () => {
          let beforeSharedResources = beforeResources;
          while (pending.size || resources.size || beforeSharedResources) {
            while (pending.size) {
              await Promise.allSettled(pending);
            }
            // Agent lease release can create shared-state handles during cleanup.
            for (const phase of [
              "agent-resources",
              "agent-handles",
              "shared-leases",
              "shared-resources",
              "shared-references",
              "shared-handles",
            ] as const) {
              if (phase === "shared-leases" && beforeSharedResources) {
                // Retire scope-owned agent resources first, then drain any remaining
                // cached handles while their shared-state lease authority is still live.
                await beforeSharedResources();
                beforeSharedResources = undefined;
              }
              while ([...resources.values()].some((resource) => resource.phase === phase)) {
                // Earlier cleanup can start tracked work using resources in this batch.
                while (pending.size) {
                  await Promise.allSettled(pending);
                }
                const batch = [...resources].filter(([, resource]) => resource.phase === phase);
                const results = await Promise.allSettled(
                  batch.map(async ([key, resource]) => {
                    const claim = maintenanceResources.claims.get(key);
                    await resource.close();
                    if (resources.get(key) === resource) {
                      resources.delete(key);
                    }
                    if (maintenanceResources.claims.get(key) === claim) {
                      maintenanceResources.claims.delete(key);
                    }
                  }),
                );
                // A disposer can admit tracked cleanup before rejecting. Settle
                // that work before reporting failure to its process owner.
                while (pending.size) {
                  await Promise.allSettled(pending);
                }
                const errors = results.flatMap((result) =>
                  result.status === "rejected" ? [result.reason] : [],
                );
                throwSqliteLifecycleErrors(errors, "Maintenance resource cleanup failed");
              }
            }
          }
          schemaMigrationChecks.clear();
          closed = true;
        })
        .then(completion.resolve, (error: unknown) => {
          closing = undefined;
          completion.reject(error);
        });
      return completion.promise;
    },
  };
  if (parent) {
    maintenanceResources.parents.set(scope, parent);
  }
  return scope;
}

/** The cache owns physical identity and admission across drainage and file exclusion. */
export function createOpenClawStateDatabaseAsyncLifecycle() {
  const resources = new Set<OpenClawStateDatabaseAsyncResource>();
  const records = new Map<string, IdentityRecord>();
  const recordsByPath = new Map<string, IdentityRecord>();
  const seals = new Set<ReadSeal>();
  const attempts = new Map<IdentityRecord | undefined, CloseAttempt>();
  let tail = Promise.resolve();
  const proofFor = () => {
    const proof = new SharedArrayBuffer(BigInt64Array.BYTES_PER_ELEMENT);
    new BigInt64Array(proof)[0] = -1n;
    return proof;
  };
  const generationFor = (identity: DatabasePathIdentity) => {
    const revision = new SharedArrayBuffer(BigInt64Array.BYTES_PER_ELEMENT);
    const lifetime = {
      revision: new SharedArrayBuffer(BigInt64Array.BYTES_PER_ELEMENT),
      epoch: 0n,
    };
    return { integrity: { identity, lifetime, revision, epoch: 0n, proof: proofFor() } };
  };

  const publishCreatedIdentity = (record: IdentityRecord, identity: DatabasePathIdentity) => {
    // Pre-creation integrity cannot certify the newly bound physical file.
    Atomics.add(new BigInt64Array(record.generation.integrity.revision), 0, 1n);
    Atomics.add(new BigInt64Array(record.generation.integrity.lifetime.revision), 0, 1n);
    records.delete(record.identity.key);
    record.identity = identity;
    record.generation.integrity.identity = identity;
    records.set(identity.key, record);
  };

  const known = (pathname: string) =>
    recordsByPath.get(pathname) ?? recordsByPath.get(resolveDatabasePath({ path: pathname }));
  const bindPath = (record: IdentityRecord, pathname: string) => {
    record.paths.add(pathname);
    if (!recordsByPath.has(pathname)) {
      recordsByPath.set(pathname, record);
    }
  };
  const overlaps = (left: IdentityRecord, right: IdentityRecord) => {
    if (left.identity.key === right.identity.key) {
      return true;
    }
    for (const pathname of left.paths) {
      if (right.paths.has(pathname)) {
        return true;
      }
    }
    return false;
  };
  const isSealed = (record: IdentityRecord) => {
    if (seals.size === 0) {
      return false;
    }
    for (const held of seals) {
      if (held.record === undefined || overlaps(held.record, record)) {
        return true;
      }
    }
    return false;
  };
  // A failed path close keeps custody after releasing reads, so its retry still
  // targets the identity whose native handle and resources it failed to retire.
  const hasCloseCustody = (record: IdentityRecord) => isSealed(record) || attempts.has(record);
  const assertOpen = (record: IdentityRecord) => {
    if (isSealed(record)) {
      throw new StateDatabaseReadAdmissionInvalidatedError(
        "OpenClaw state database read admission is closed",
      );
    }
  };
  const findPhysicalRecord = (identity: DatabasePathIdentity): IdentityRecord | undefined => {
    const record = records.get(identity.key);
    if (!record || !identity.key.startsWith("file:") || hasCloseCustody(record)) {
      return record;
    }
    // Cold binding retires vanished paths even when another hardlink keeps the file alive.
    // Warm captures use the retained admission without polling the filesystem.
    for (const pathname of findChangedDatabasePaths(record.paths, identity)) {
      record.admissions.delete(pathname);
      record.paths.delete(pathname);
      if (recordsByPath.get(pathname) === record) {
        recordsByPath.delete(pathname);
      }
    }
    if (record.paths.size > 0) {
      if (!record.paths.has(record.identity.canonicalPath)) {
        record.identity = identity;
        record.generation.integrity.identity = identity;
      }
      return record;
    }
    invalidate(record);
    forget(record);
    return undefined;
  };
  const resolve = (
    resolvedPath: string,
    preparedIdentity?: DatabasePathIdentity,
  ): IdentityRecord => {
    const cached = recordsByPath.get(resolvedPath);
    if (cached && (!preparedIdentity || cached.identity.key === preparedIdentity.key)) {
      // Resolve first creation without replacing an established file's admission.
      return !preparedIdentity && cached.identity.key.startsWith("path:")
        ? resolve(resolvedPath, readDatabasePathIdentitySync(resolvedPath))
        : cached;
    }
    const identity = preparedIdentity ?? readDatabasePathIdentitySync(resolvedPath);
    let record = findPhysicalRecord(identity);
    if (!record && identity.key.startsWith("file:")) {
      // A first creation can become visible through an alias before publication.
      // Reconcile unresolved creation facts here, never on warmed captures.
      record = [...records.values()].find((candidate) => {
        if (!candidate.identity.key.startsWith("path:")) {
          return false;
        }
        try {
          return (
            readDatabasePathIdentitySync(candidate.identity.canonicalPath).key === identity.key
          );
        } catch {
          // Creation can still be opening in a worker. Keep its custody until
          // publication or drainage without spreading unrelated lookup failures.
          return false;
        }
      });
      if (record) {
        publishCreatedIdentity(record, identity);
      }
    }
    if (!record) {
      record = {
        coordinationKey: identity.key,
        identity,
        paths: new Set(),
        generation: generationFor(identity),
        admissions: new Map(),
      };
      records.set(identity.key, record);
    }
    bindPath(record, resolvedPath);
    bindPath(record, identity.canonicalPath);
    return record;
  };
  const resolveForNative = (pathname: string): IdentityRecord | undefined => {
    const resolvedPath = resolveDatabasePath({ path: pathname });
    const cached = recordsByPath.get(resolvedPath);
    if (cached) {
      return cached;
    }
    const identity = inspectDatabasePathIdentitySync(resolvedPath);
    return identity ? resolve(resolvedPath, identity) : undefined;
  };
  const invalidate = (record?: IdentityRecord) => {
    for (const current of record ? [record] : records.values()) {
      Atomics.store(new BigInt64Array(current.generation.integrity.revision), 0, -1n);
      Atomics.store(new BigInt64Array(current.generation.integrity.lifetime.revision), 0, -1n);
      current.generation = generationFor(current.identity);
      current.admissions.clear();
    }
  };
  const seal = (record?: IdentityRecord): ReadSeal => {
    invalidate(record);
    const held = { record };
    seals.add(held);
    return held;
  };
  const release = (attempt: CloseAttempt) => {
    if (attempt.seal) {
      seals.delete(attempt.seal);
      attempt.seal = undefined;
    }
  };
  const forget = (record: IdentityRecord) => {
    if (!hasCloseCustody(record) && records.get(record.identity.key) === record) {
      records.delete(record.identity.key);
      for (const pathname of record.paths) {
        if (recordsByPath.get(pathname) === record) {
          recordsByPath.delete(pathname);
          // A sealed predecessor keeps close custody until retirement, even if
          // publication has already recorded a replacement at the same path.
          for (const replacement of records.values()) {
            if (replacement.paths.has(pathname)) {
              recordsByPath.set(pathname, replacement);
              break;
            }
          }
        }
      }
    }
  };
  const retireReplacedRecord = (record: IdentityRecord) => {
    const failed = attempts.get(record);
    if (failed) {
      // The replaced file still has unretired native custody. Its path stays
      // bound to that record, so reads there wait for the close retry.
      failed.superseded = true;
      failed.seal ??= seal(record);
    } else {
      invalidate(record);
    }
    forget(record);
  };
  // Keep closure creation off capture's warm branch: V8 otherwise allocates its
  // captured environment even when returning an already retained admission.
  const captureRecord = (
    record: IdentityRecord,
    databasePath: string,
  ): OpenClawStateDatabaseReadAdmission => {
    const previous = record.admissions.get(databasePath);
    if (previous) {
      return previous;
    }
    const generation = record.generation;
    const admission: OpenClawStateDatabaseReadAdmission = Object.freeze({
      databasePath,
      coordinationKey: record.coordinationKey,
      get identity() {
        return record.identity;
      },
      captureIntegrity() {
        admission.assertCurrent();
        const current = generation.integrity;
        const epoch = Atomics.load(new BigInt64Array(current.revision), 0);
        const lifetimeEpoch = Atomics.load(new BigInt64Array(current.lifetime.revision), 0);
        if (epoch !== current.epoch || lifetimeEpoch !== current.lifetime.epoch) {
          generation.integrity = {
            ...current,
            identity: record.identity,
            lifetime: { revision: current.lifetime.revision, epoch: lifetimeEpoch },
            epoch,
            proof: proofFor(),
          };
        }
        return generation.integrity;
      },
      assertCurrent() {
        assertOpen(record);
        if (
          records.get(record.identity.key) !== record ||
          record.generation !== generation ||
          record.admissions.get(databasePath) !== admission
        ) {
          throw new StateDatabaseReadAdmissionInvalidatedError(
            "OpenClaw state database read admission changed",
          );
        }
      },
    });
    record.admissions.set(databasePath, admission);
    return admission;
  };
  return {
    identity(pathname: string): DatabasePathIdentity | undefined {
      return known(pathname)?.identity ?? inspectDatabasePathIdentitySync(pathname);
    },
    knownIdentity(this: void, pathname: string): DatabasePathIdentity | undefined {
      return known(pathname)?.identity;
    },
    integrity(this: void, pathname: string): OpenClawStateIntegrityAdmission | undefined {
      const record = resolveForNative(pathname);
      return record && !isSealed(record)
        ? captureRecord(record, resolveDatabasePath({ path: pathname })).captureIntegrity?.()
        : undefined;
    },
    publish(
      pathname: string,
      preparedIdentity?: DatabasePathIdentity,
    ): {
      identity: DatabasePathIdentity;
      admission: OpenClawStateDatabaseReadAdmission;
    } {
      const resolvedPath = resolveDatabasePath({ path: pathname });
      const identity = preparedIdentity ?? readDatabasePathIdentitySync(resolvedPath);
      const previous = recordsByPath.get(resolvedPath);
      // Warm worker publication keeps captured facts; cold binding still retires vanished aliases.
      let record =
        preparedIdentity && previous?.identity.key === identity.key
          ? records.get(identity.key)
          : findPhysicalRecord(identity);
      if (previous && previous.identity.key !== identity.key) {
        if (previous.identity.key.startsWith("path:") && !record) {
          // First canonical creation binds the same captured admission to its file.
          publishCreatedIdentity(previous, identity);
          record = previous;
        } else {
          retireReplacedRecord(previous);
        }
      }
      if (!record) {
        record = resolve(resolvedPath, identity);
      }
      bindPath(record, resolvedPath);
      // A retained actor's opening path cannot restore an alias retired by relocation.
      // Native publication has just observed its own canonical alias.
      bindPath(record, preparedIdentity ? record.identity.canonicalPath : identity.canonicalPath);
      // Private native binding may publish while reads are sealed. Retain its
      // generation now; every later worker use still checks the seal and lifetime.
      return { identity, admission: captureRecord(record, resolvedPath) };
    },
    async retireChangedAdmission(admission: OpenClawStateDatabaseReadAdmission): Promise<void> {
      admission.assertCurrent();
      const record = records.get(admission.identity.key);
      const observed = await readDatabasePathIdentity(admission.databasePath);
      admission.assertCurrent();
      if (record && record.identity.key !== observed.key) {
        // Failed opening retires only its predecessor; later admission qualifies the successor.
        retireReplacedRecord(record);
      }
    },
    invalidate(pathname?: string): void {
      if (pathname === undefined) {
        invalidate();
      } else {
        const record = known(pathname);
        if (record) {
          invalidate(record);
        }
      }
    },
    register(this: void, resource: OpenClawStateDatabaseAsyncResource): () => void {
      resources.add(resource);
      for (const attempt of attempts.values()) {
        attempt.queue?.add(resource);
      }
      return () => {
        resources.delete(resource);
      };
    },
    capture(
      this: void,
      pathname: string,
      preparedIdentity?: DatabasePathIdentity,
    ): OpenClawStateDatabaseReadAdmission {
      const cached = recordsByPath.get(pathname);
      const retained = cached?.admissions.get(pathname);
      if (cached && retained && cached.identity.key.startsWith("file:")) {
        retained.assertCurrent();
        return retained;
      }
      const databasePath = resolveDatabasePath({ path: pathname });
      const record = resolve(databasePath, preparedIdentity);
      assertOpen(record);
      return captureRecord(record, databasePath);
    },
    holdExclusion(pathname: string): () => void {
      const record = resolve(resolveDatabasePath({ path: pathname }));
      const held = seal(record);
      return () => {
        seals.delete(held);
        // Replacement can leave a new physical record sharing this logical path.
        for (const current of records.values()) {
          if (overlaps(record, current)) {
            forget(current);
          }
        }
      };
    },
    close(
      pathname: string | undefined,
      retireNative: (identity?: DatabasePathIdentity) => boolean | Promise<boolean>,
    ): Promise<boolean> {
      const record = pathname === undefined ? undefined : resolveForNative(pathname);
      if (pathname !== undefined && !record) {
        // No worker could enter a non-file target. Retire only the caller's exact
        // native path; undefined must not reach resource.close as a global drain.
        return Promise.resolve(retireNative());
      }
      let attempt = attempts.get(record);
      if (attempt?.pending) {
        return attempt.pending;
      }
      if (!attempt) {
        attempt = { retained: new Set() };
        attempts.set(record, attempt);
      }
      // A retry after failed drainage seals again before draining: invalidation
      // retires admissions captured while reads were open, and the drain below
      // settles resources those readers entered.
      attempt.seal ??= seal(record);
      const current = attempt;
      const pending = tail
        .then(async () => {
          const closing = new Set([...resources, ...current.retained]);
          for (const entry of attempts.values()) {
            for (const resource of entry.retained) {
              closing.add(resource);
            }
          }
          current.queue = closing;
          const errors: unknown[] = [];
          while (current.queue.size) {
            const ordinary = [...current.queue].filter(
              (resource) => resource.phase !== "after-resources",
            );
            // Failed owners retain the transports they may need during a canonical retry.
            if (!ordinary.length && errors.length) {
              for (const resource of current.queue) {
                current.retained.add(resource);
              }
              break;
            }
            const batch = ordinary.length ? ordinary : [...current.queue];
            for (const resource of batch) {
              current.queue.delete(resource);
            }
            await Promise.all(
              batch.map(async (resource) => {
                try {
                  const identity = record?.identity;
                  if (
                    !identity ||
                    !resource.admission ||
                    identity.key === resource.admission.identity.key
                  ) {
                    await resource.close(identity);
                  }
                  current.retained.delete(resource);
                } catch (error) {
                  // Unregistration cannot abandon a resource whose close failed.
                  current.retained.add(resource);
                  errors.push(error);
                }
              }),
            );
          }
          if (errors.length && !current.superseded) {
            // Native handles were not retired, so the database stays live and
            // reads can resume. Failed resources stay retained for the retry.
            release(current);
          }
          throwSqliteLifecycleErrors(errors, "OpenClaw state resource drainage failed");
          const retired = await retireNative(record?.identity);
          attempts.delete(record);
          release(current);
          if (record === undefined) {
            // A successful whole-cache retry also discharges prior failed path closes.
            for (const [key, entry] of attempts) {
              if (!entry.pending) {
                attempts.delete(key);
                release(entry);
              }
            }
            for (const entry of records.values()) {
              forget(entry);
            }
          } else {
            forget(record);
          }
          return retired;
        })
        .finally(() => {
          current.queue = undefined;
        });
      current.pending = pending;
      tail = pending.then(
        () => undefined,
        () => undefined,
      );
      void pending.catch(() => {
        // Failed native retirement keeps its seal; failed drainage released it above.
        // Both keep failed resource custody for an explicit retry.
        current.pending = undefined;
      });
      return pending;
    },
  };
}
