import { realpathSync, statSync } from "node:fs";
import path from "node:path";
import { isDeepStrictEqual } from "node:util";
import { probePathSuffixAliasesSync, resolvePathPrefixSync } from "@openclaw/fs-safe/advanced";
import { normalizeAgentId } from "@openclaw/normalization-core/agent-id";
import { resolveStateDir } from "../config/paths.js";
import { hasErrnoCode } from "../infra/errno.js";
import { isPathInside } from "../infra/path-guards.js";

type OpenClawAgentSqlitePathOptions = {
  agentId: string;
  env?: NodeJS.ProcessEnv;
  path?: string;
};

export const INCOGNITO_AGENT_SQLITE_BASENAME = "incognito-openclaw-agent.sqlite";

const agentSqlitePaths = new Map<string, string>();
// Keep the FIFO cursor so eviction never rescans deleted Map entries.
const agentSqlitePathKeys = agentSqlitePaths.keys();

export function resolveOpenClawAgentSqlitePath(options: OpenClawAgentSqlitePathOptions): string {
  if (options.path != null) {
    return path.resolve(options.path);
  }
  const agentId = normalizeAgentId(options.agentId);
  // The state-dir owner still observes env and cwd changes.
  // Only its resolved output is memoized; a changed root selects a new entry.
  const stateDir = resolveStateDir(options.env ?? process.env);
  const cacheKey = `${agentId}:${stateDir}`;
  const cached = agentSqlitePaths.get(cacheKey);
  if (cached !== undefined) {
    return cached;
  }
  const resolved = path.resolve(stateDir, "agents", agentId, "agent", "openclaw-agent.sqlite");
  agentSqlitePaths.set(cacheKey, resolved);
  if (agentSqlitePaths.size > 256) {
    const oldest = agentSqlitePathKeys.next();
    if (!oldest.done) {
      agentSqlitePaths.delete(oldest.value);
    }
  }
  return resolved;
}

/** Resolve the lexical sentinel path used by an agent's memory session owner. */
export function resolveIncognitoOpenClawAgentSqlitePath(
  options: Omit<OpenClawAgentSqlitePathOptions, "path">,
): string {
  return path.join(
    path.dirname(resolveOpenClawAgentSqlitePath(options)),
    INCOGNITO_AGENT_SQLITE_BASENAME,
  );
}

/** Identify the reserved incognito sentinel without touching its filesystem path. */
export function isIncognitoOpenClawAgentSqlitePath(
  pathname: string,
  options: Omit<OpenClawAgentSqlitePathOptions, "path">,
): boolean {
  const resolved = path.resolve(pathname);
  return (
    path.basename(resolved) === INCOGNITO_AGENT_SQLITE_BASENAME &&
    resolved === resolveIncognitoOpenClawAgentSqlitePath(options)
  );
}

/** An explicit sentinel names its physical root; ambient state cannot redirect it. */
export function resolveExplicitIncognitoAgentSqliteTarget(
  pathname: string | undefined,
  options: { agentId?: string; env?: NodeJS.ProcessEnv } = {},
): { agentId: string; env: NodeJS.ProcessEnv; path: string } | undefined {
  if (!pathname || path.basename(pathname) !== INCOGNITO_AGENT_SQLITE_BASENAME) {
    return undefined;
  }
  const resolved = path.resolve(pathname);
  const agentId = normalizeAgentId(
    options.agentId ?? path.basename(path.dirname(path.dirname(resolved))),
  );
  const env = options.env ?? { OPENCLAW_STATE_DIR: path.resolve(resolved, "../../../..") };
  if (!isIncognitoOpenClawAgentSqlitePath(resolved, { agentId, env })) {
    throw new Error("Explicit incognito database target does not match its agent and state root");
  }
  return { agentId, env, path: resolved };
}

export type AgentDatabasePathIdentity = { lexicalPath: string } & (
  | { realPath: string; device: string; inode: string }
  | {
      parentDevice: string;
      parentInode: string;
      parentRealPath: string;
      unresolvedSuffix: string;
    }
);

const missingSuffixAliasCache = new Map<string, boolean>();

function shouldProbeUnicodeCaseVariants(left: string, right: string): boolean {
  const hasNonAscii = (value: string) =>
    value.split("").some((character) => character.charCodeAt(0) > 0x7f);
  if (!hasNonAscii(left) && !hasNonAscii(right)) {
    return false;
  }
  const lowercaseEquivalent = left.toLowerCase() === right.toLowerCase();
  const uppercaseEquivalent = left.toUpperCase() === right.toUpperCase();
  // Keep lowercase-only dotted-I expansions distinct even on filesystems that collapse them.
  return (
    uppercaseEquivalent ||
    (lowercaseEquivalent && Array.from(left).length === Array.from(right).length)
  );
}

function areMissingSuffixAliases(params: {
  left: string;
  right: string;
  parentDevice: string;
  parentInode: string;
  parentRealPath: string;
}): boolean {
  if (params.left === params.right) {
    return true;
  }
  const leftSegments = params.left.split(path.sep);
  const rightSegments = params.right.split(path.sep);
  if (
    leftSegments.length !== rightSegments.length ||
    [...leftSegments, ...rightSegments].some(
      (segment) => !segment || segment === "." || segment === "..",
    )
  ) {
    return false;
  }
  const suffixPair = [params.left, params.right].toSorted();
  const cacheKey = JSON.stringify([
    params.parentDevice,
    params.parentInode,
    params.parentRealPath,
    ...suffixPair,
  ]);
  const cached = missingSuffixAliasCache.get(cacheKey);
  if (cached !== undefined) {
    return cached;
  }
  let aliases: boolean | undefined;
  let cause: unknown;
  try {
    aliases = probePathSuffixAliasesSync({
      directory: params.parentRealPath,
      left: params.left,
      right: params.right,
      maxDepth: leftSegments.length,
      shouldProbeCaseVariants: shouldProbeUnicodeCaseVariants,
    });
  } catch (error) {
    cause = error;
  }
  if (aliases === undefined) {
    throw new Error(
      `Cannot determine whether database paths alias under ${JSON.stringify(params.parentRealPath)}: ${JSON.stringify(params.left)} and ${JSON.stringify(params.right)}. Check directory access and retry.`,
      { cause },
    );
  }
  // A comparison becomes reusable only after every owned probe was removed.
  missingSuffixAliasCache.set(cacheKey, aliases);
  return aliases;
}

function anchorDatabasePathWithoutNormalizing(pathname: string): string {
  const platformPath = path.sep === "\\" ? pathname.replaceAll("/", "\\") : pathname;
  if (path.isAbsolute(platformPath)) {
    return platformPath;
  }
  if (path.sep === "\\") {
    const driveRelative = /^([A-Za-z]:)(.*)$/u.exec(platformPath);
    if (driveRelative) {
      // Resolve only the drive's current-directory anchor. Appending the raw
      // suffix preserves `..` for the component-wise filesystem walk below.
      const driveBase = path.resolve(`${driveRelative[1]}.`);
      return driveRelative[2]
        ? `${driveBase}${driveBase.endsWith(path.sep) ? "" : path.sep}${driveRelative[2]}`
        : driveBase;
    }
  }
  const cwd = process.cwd();
  return `${cwd}${cwd.endsWith(path.sep) ? "" : path.sep}${platformPath}`;
}

function resolveAgentDatabasePathIdentity(pathname: string): AgentDatabasePathIdentity {
  // `path.resolve` collapses `..` before symlinks are inspected, but the filesystem
  // resolves `link/..` from the link target. Anchor relative input without rewriting tokens.
  const lexicalPath = anchorDatabasePathWithoutNormalizing(pathname);
  try {
    const realPath = realpathSync.native(lexicalPath);
    const stat = statSync(realPath, { bigint: true });
    return {
      lexicalPath,
      realPath,
      device: stat.dev.toString(),
      inode: stat.ino.toString(),
    };
  } catch (error) {
    if (!hasErrnoCode(error, "ENOENT")) {
      throw error;
    }
    // Registry locators ignore input separator runs; expanded symlink targets
    // retain raw missing suffixes, including `missing/../live.sqlite`.
    const rootPath = path.parse(lexicalPath).root;
    const observed = resolvePathPrefixSync(
      rootPath + lexicalPath.slice(rootPath.length).split(path.sep).filter(Boolean).join(path.sep),
    );
    const parentRealPath = observed.existingPath;
    const parentStat = statSync(parentRealPath, { bigint: true });
    return {
      lexicalPath,
      parentDevice: parentStat.dev.toString(),
      parentInode: parentStat.ino.toString(),
      parentRealPath,
      unresolvedSuffix: observed.unresolvedSegments.join(path.sep),
    };
  }
}

function areSameAgentDatabasePathIdentities(
  leftIdentity: AgentDatabasePathIdentity,
  rightIdentity: AgentDatabasePathIdentity,
): boolean {
  if (leftIdentity.lexicalPath === rightIdentity.lexicalPath) {
    return true;
  }
  if ("realPath" in leftIdentity) {
    return (
      "realPath" in rightIdentity &&
      (leftIdentity.realPath === rightIdentity.realPath ||
        (leftIdentity.device === rightIdentity.device &&
          leftIdentity.inode === rightIdentity.inode))
    );
  }
  return (
    !("realPath" in rightIdentity) &&
    leftIdentity.parentDevice === rightIdentity.parentDevice &&
    leftIdentity.parentInode === rightIdentity.parentInode &&
    areMissingSuffixAliases({
      left: leftIdentity.unresolvedSuffix,
      right: rightIdentity.unresolvedSuffix,
      parentDevice: leftIdentity.parentDevice,
      parentInode: leftIdentity.parentInode,
      parentRealPath: leftIdentity.parentRealPath,
    })
  );
}

/** Create a synchronous-operation matcher that prepares each exact locator once. */
export function createOpenClawAgentDatabasePathMatcher(
  observations: readonly AgentDatabasePathIdentity[] = [],
): {
  (left: string, right: string): boolean;
  capture(pathname: string): void;
  observations(): AgentDatabasePathIdentity[];
  createIndex(): (pathname: string) => string;
  isCurrent(): boolean;
} {
  const identities = new Map<string, AgentDatabasePathIdentity>(
    observations.map((identity) => [identity.lexicalPath, identity]),
  );
  const resolveIdentity = (pathname: string): AgentDatabasePathIdentity => {
    const lexicalPath = anchorDatabasePathWithoutNormalizing(pathname);
    const cached = identities.get(lexicalPath);
    if (cached) {
      return cached;
    }
    // Cache successes only. Filesystem errors must be retried if the caller recovers.
    const identity = resolveAgentDatabasePathIdentity(lexicalPath);
    identities.set(lexicalPath, identity);
    return identity;
  };
  return Object.assign(
    (left: string, right: string) =>
      areSameAgentDatabasePathIdentities(resolveIdentity(left), resolveIdentity(right)),
    {
      capture(pathname: string) {
        resolveIdentity(pathname);
      },
      observations: () => [...identities.values()],
      // Independent groups share observations, but retain their own first path spelling.
      createIndex() {
        const keys = new Map<string, string>();
        const groups: AgentDatabasePathIdentity[] = [];
        const fileGroups = new Map<string, number>();
        const realPathGroups = new Map<string, number>();
        const missingParentGroups = new Map<string, number[]>();
        return (pathname: string) => {
          const identity = resolveIdentity(pathname);
          const cached = keys.get(identity.lexicalPath);
          if (cached !== undefined) {
            return cached;
          }
          let group: number | undefined;
          if ("realPath" in identity) {
            const fileKey = `${identity.device}:${identity.inode}`;
            const fileGroup = fileGroups.get(fileKey);
            const realPathGroup = realPathGroups.get(identity.realPath);
            group =
              fileGroup === undefined
                ? realPathGroup
                : realPathGroup === undefined
                  ? fileGroup
                  : Math.min(fileGroup, realPathGroup);
            if (group === undefined) {
              group = groups.push(identity) - 1;
              fileGroups.set(fileKey, group);
              realPathGroups.set(identity.realPath, group);
            }
          } else {
            const parentKey = `${identity.parentDevice}:${identity.parentInode}`;
            const candidates = missingParentGroups.get(parentKey) ?? [];
            group = candidates.find((index) =>
              areSameAgentDatabasePathIdentities(groups[index]!, identity),
            );
            if (group === undefined) {
              group = groups.push(identity) - 1;
              candidates.push(group);
              missingParentGroups.set(parentKey, candidates);
            }
          }
          // Only retained representatives enter the index, preserving first-match ownership.
          const key = groups[group]!.lexicalPath;
          keys.set(identity.lexicalPath, key);
          return key;
        };
      },
      isCurrent() {
        for (const previous of identities.values()) {
          const current = resolveAgentDatabasePathIdentity(previous.lexicalPath);
          // Equal locators alone cannot validate a snapshot after replacement.
          if (!isDeepStrictEqual(previous, current)) {
            return false;
          }
        }
        return true;
      },
    },
  );
}

/** Compare two database locators by canonical filesystem identity when available. */
export function isSameOpenClawAgentDatabasePath(left: string, right: string): boolean {
  return areSameAgentDatabasePathIdentities(
    resolveAgentDatabasePathIdentity(left),
    resolveAgentDatabasePathIdentity(right),
  );
}

export function includesOpenClawAgentDatabasePath(
  paths: readonly string[],
  target: string,
  samePath = isSameOpenClawAgentDatabasePath,
): boolean {
  return paths.some((pathname) => {
    try {
      return samePath(pathname, target);
    } catch {
      // An uncertain sibling cannot classify this target; its own inspection reports the failure.
      return false;
    }
  });
}

function canonicalPathForRegistryBoundary(pathname: string): string {
  const identity = resolveAgentDatabasePathIdentity(pathname);
  if ("realPath" in identity) {
    return identity.realPath;
  }
  const unresolvedSegments = identity.unresolvedSuffix.split(path.sep);
  return unresolvedSegments.includes("..")
    ? identity.parentRealPath
    : path.join(identity.parentRealPath, ...unresolvedSegments);
}

/** Named import artifacts are offline archives, not durable runtime discovery state. */
export function isPersistentOpenClawAgentDatabasePath(
  pathname: string,
  env: NodeJS.ProcessEnv = process.env,
): boolean {
  const lexicalCandidate = path.resolve(pathname);
  const lexicalImportsDir = path.join(path.resolve(resolveStateDir(env)), "imports");
  if (isPathInside(lexicalImportsDir, lexicalCandidate)) {
    return false;
  }
  const candidate = canonicalPathForRegistryBoundary(pathname);
  const stateDir = canonicalPathForRegistryBoundary(resolveStateDir(env));
  const importsDir = canonicalPathForRegistryBoundary(path.join(stateDir, "imports"));
  return !isPathInside(importsDir, candidate);
}
