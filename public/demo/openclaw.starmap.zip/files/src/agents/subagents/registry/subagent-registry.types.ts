import type {
  SessionEntryCurrentCheck,
  SessionEntryCurrentFacts,
} from "../../../config/sessions/session-entry-current.types.js";
import type { SessionEntry } from "../../../config/sessions/types.js";
import type { SubagentEndReason } from "../../../context-engine/types.js";
import type { DeliveryContext } from "../../../utils/delivery-context.types.js";
import type { AgentRunTerminalReplySnapshot } from "../../agent-run-terminal-reply.types.js";
import type { OperationalRunInstanceRef } from "../../operational-run-instance.js";
import type { AgentRunSessionTarget } from "../../run-session-target.types.js";
import type { SpawnSubagentMode } from "../spawn/subagent-spawn.types.js";
import type { SubagentRunOutcome } from "../subagent-run-outcome.types.js";
import type { SubagentLifecycleEndedReason } from "./subagent-lifecycle-events.js";
import type {
  SubagentCompletionDeliveryState,
  SubagentRunReadRecord,
} from "./subagent-registry-read.types.js";

export type SubagentSessionEffects = {
  isCurrent(): Promise<boolean>;
  assertHostCurrent(): void;
  assertCurrentEntry(this: void, facts: SessionEntryCurrentFacts | undefined): void;
  nativeCheck?: SessionEntryCurrentCheck;
};

type SubagentRecoveryCurrent = {
  prepare(): Promise<boolean>;
  isHostCurrent(): boolean;
  onPublished?(entry: SubagentRunRecord): void;
};

export type SubagentCompletionRequest = {
  runId: string;
  /** Exact in-process owner required after acquiring the terminal completion lock. */
  expectedEntry?: SubagentRunRecord;
  endedAt?: number;
  outcome: SubagentRunOutcome;
  reason: SubagentLifecycleEndedReason;
  sendFarewell?: boolean;
  accountId?: string;
  triggerCleanup: boolean;
  startedAt?: number;
  suppressSessionEffects?: boolean;
  /** Prepare database currency asynchronously; publication rechecks live host authority. */
  recoveryCurrent?: SubagentRecoveryCurrent;
  /** Child effects may be fenced while the recorded result still owes requester delivery. */
  sessionEffects?: SubagentSessionEffects;
  completionSnapshot?: { resultText: string | null; capturedAt: number };
  terminalReply?: AgentRunTerminalReplySnapshot;
  /** Explicitly settle a yielded run that no continuation can reach; kill is the only other exception. */
  settleYielded?: true;
};

export type ContextEngineSubagentEndedParams = {
  childSessionKey: string;
  reason: SubagentEndReason;
  agentDir?: string;
  workspaceDir?: string;
};

type SubagentProgressOrigin = {
  channel?: string;
  accountId?: string;
  to?: string;
  threadId?: string | number;
  channelId?: string | number;
  messageId?: string | number;
};

type SubagentExecutionState = SubagentRunReadRecord["execution"] & {
  /** Gateway lifecycle that owns child-session effects for this run. */
  lifecycleGeneration?: string;
  /** Sticky terminal policy: this run must never mutate its child session again. */
  suppressSessionEffects?: true;
  acceptedAt?: number;
  transcriptTarget?: AgentRunSessionTarget;
};

export type SubagentCompletionState = {
  required: boolean;
  resultText?: string | null;
  capturedAt?: number;
  fallbackResultText?: string | null;
  fallbackCapturedAt?: number;
  terminalReply?: AgentRunTerminalReplySnapshot;
};

type SwarmCollectorCompletion = NonNullable<SubagentRunReadRecord["collectorCompletion"]> & {
  structured?: unknown;
  schemaError?: string;
  usage?: { inputTokens: number; outputTokens: number };
  /** Set only when the registry sweeper settled a collector that yielded without a result. */
  reason?: "yielded_without_result";
};

export type SwarmStructuredOutputState = {
  structured?: unknown;
  schemaError?: string;
  invalidAttempts: number;
};

/** Durable outbox state for the top-level requester settle wake. */
export type RequesterSettleWakeState = {
  /** Pending message-wait notice; consuming it leaves the completion cohort armed. */
  pauseNotice?: { acknowledgment: string };
  status: "pending" | "dispatching";
  /** Number of delivery attempts already admitted. */
  attemptCount: number;
  /** Raw private input retained with its exact dispatch identity until this wake settles. */
  privateInput?: { runId: string; message: string };
  /** Retained retry receipt from an admitted attempt; mailbox admission owns scheduling. */
  nextAttemptAt?: number;
  /** Frozen wave membership after delivery admission or requester-yield re-admission. */
  batchRunIds?: string[];
  /** Batch frozen while its spawning requester turn was yielding. */
  requesterYieldBatch?: true;
  /** Exact parked lifecycle this cohort must settle if no continuation starts. */
  requesterRunId?: string;
  /** Present only when an idle requester needs a new turn after yielding. */
  afterRequesterYield?: true;
  /**
   * A yielded batch with private results was admitted with a deliverable requester
   * final. Absent on a dispatching private batch means an earlier build admitted it
   * as a private turn; replay keeps that policy.
   */
  yieldedFinalDeliverable?: true;
  /** Monotonic process generation protecting a newer yield from stale completion. */
  rearmGeneration?: number;
  /** Reference to the conversation receipt for this presentation, not completion credit. */
  progressOperationId?: string;
  lastError?: string | null;
  /** Cleanup wanted to retire this row; defer deletion until the outbox resolves. */
  retireAfterSettle?: boolean;
};

type SubagentKillReconciliationState = {
  /** Actual cancellation time; a yielded run may have an older execution end. */
  killedAt: number;
  /** The current lifecycle accepted a live kill claim before terminalization. */
  taskCancellationAccepted?: true;
  /** Requester aborts must not re-inject a delayed completion after queues are cleared. */
  suppressTaskDelivery?: boolean;
  /** Durable ownership boundary even after the newer registry row is released. */
  supersededAt?: number;
};

type SubagentKillIntent = {
  requestedAt: number;
  reason: string;
  lifecycleGeneration?: string;
  sessionId?: string;
  sessionLifecycleRevision?: string;
  suppressTaskDelivery?: boolean;
};

export type SubagentRunRecord = Omit<SubagentRunReadRecord, "execution" | "collectorCompletion"> & {
  /** Host-captured SDK spawn provenance; absence never establishes plugin ownership. */
  nativePluginOwner?: {
    version: 1;
    pluginId: string;
    requesterProfileId: string;
    requestId: string;
  };
  /** Exact package instructions used at child creation; not runtime authority. */
  subagentProfile?: {
    pluginId: string;
    id: string;
    instructionsFile: string;
    instructionsSha256: string;
  };
  /** Child identity stays fixed when a live turn redirects transcript writes. */
  childSessionIdentity?: Pick<SessionEntry, "sessionId" | "lifecycleRevision">;
  /** Exact requester attempt for cancellation, independent of completion messaging. */
  requesterTurnRunId?: string;
  /** Durable proof that this requester attempt invoked sessions_yield. */
  requesterTurnYielded?: true;
  /** This yield waits for its requester, rather than owned child completions. */
  waitForMessage?: true;
  /** Completion-producing row retirement deferred until requesterTurnRunId settles. */
  retireAfterRequesterTurn?: boolean;
  requesterOrigin?: DeliveryContext;
  /** Durable source locator for transport-neutral progress presentation. */
  progressOrigin?: SubagentProgressOrigin;
  requesterDisplayKey: string;
  task: string;
  taskName?: string;
  cleanup: "delete" | "keep";
  label?: string;
  agentDir?: string;
  workspaceDir?: string;
  spawnMode?: SpawnSubagentMode;
  archiveAtMs?: number;
  cleanupHandled?: boolean;
  suppressAnnounceReason?: "steer-restart" | "killed";
  /** Present only while a current-version killed run awaits bounded reconciliation. */
  killReconciliation?: SubagentKillReconciliationState;
  /** Durable operator cancellation ownership before runtime side effects complete. */
  killIntent?: SubagentKillIntent;
  /** Durable requester-delivery closure until silent completion cleanup finishes. */
  suppressCompletionDelivery?: boolean;
  expectsCompletionMessage?: boolean;
  completionTarget?: "parent";
  completionRequesterSessionId?: string;
  completionRequesterLifecycleRevision?: string;
  wakeOnDescendantSettle?: boolean;
  execution: SubagentExecutionState;
  completion?: SubagentCompletionState;
  /** Set after the subagent_ended hook has been emitted successfully once. */
  endedHookEmittedAt?: number;
  /** Set after cleanupBrowserSessionsForLifecycleEnd has been dispatched once. */
  browserCleanupDispatchedAt?: number;
  /** Set immediately before irreversible sessions.delete cleanup is dispatched. */
  deleteCleanupDispatchedAt?: number;
  /** Requester wake owned by the live child task. */
  requesterSettleWake?: RequesterSettleWakeState;
  /** Generated identity under the host-owned per-agent attachment root. */
  attachmentId?: string;
  /** Legacy persisted absolute paths are never used for cleanup. */
  attachmentsDir?: string;
  attachmentsRootDir?: string;
  retainAttachmentsOnKeep?: boolean;
  /** Spawner plus ancestor sessions authorized to wait, frozen when the collector is registered. */
  swarmWaitOwnerSessionKeys?: string[];
  /** Exact host-reserved Gateway request identity for the current collector turn. */
  swarmLaunchIdempotencyKey?: string;
  /** Canonical collector request hash paired with a host-reserved launch identity. */
  swarmLaunchRequestFingerprint?: string;
  /** True only between host reservation and accepted Gateway dispatch. */
  swarmLaunchPending?: boolean;
  outputSchema?: Record<string, unknown>;
  structuredOutput?: SwarmStructuredOutputState;
  /** Durable retry obligation for a prepared collector session whose launch failed. */
  collectorLaunchCleanupPending?: boolean;
  /** Set after failed-launch context-engine cleanup succeeds, preventing duplicate end hooks. */
  contextEngineCleanupCompletedAt?: number;
  collectorCompletion?: SwarmCollectorCompletion;
};

/** Lifecycle facts needed to protect child transcripts during session maintenance. */
export type SubagentRunMaintenanceRecord = Pick<
  SubagentRunRecord,
  | "runId"
  | "childSessionKey"
  | "childAgentId"
  | "requesterSessionKey"
  | "createdAt"
  | "cleanupCompletedAt"
  | "expectsCompletionMessage"
  | "killIntent"
  | "killReconciliation"
> & {
  execution: Pick<SubagentExecutionState, "status" | "endedAt">;
  requesterSettleWake?: Pick<RequesterSettleWakeState, "status">;
  delivery?: Pick<SubagentCompletionDeliveryState, "status" | "suspendedAt">;
};

export type SubagentRegistrationScope = {
  readonly waitForClaim: () => Promise<void> | undefined;
  readonly waitForRetirementPublication: () => Promise<void> | undefined;
  readonly canLaunch: () => boolean;
  readonly canCleanupSession: () => boolean;
  readonly canAcceptLaunch: () => boolean;
  readonly canAbortAcceptedRun: () => boolean;
  readonly canRetireReservation: () => boolean;
  readonly settleFailedLaunch: (error: string) => Promise<void>;
};

export type RegisterSubagentRunOptions = {
  /** In-process receipt owner, never persisted or recovered from a run ID. */
  requesterRunInstance?: OperationalRunInstanceRef;
  /** An accepted dispatch replay retains its original completion owner and waiter. */
  acceptedRunReplay?: true;
  assertCurrent?: () => void;
  assertPublicationCurrent?: () => void;
  retainOwnership?: (scope: SubagentRegistrationScope) => void;
  /** Retain rejection cleanup at the non-queued registration's durable commit. */
  retainAdmission?: (reject: SubagentAdmissionRejection) => void;
  admissionSessionEffects?: SubagentSessionEffects;
};

export type SubagentAdmissionRejection = (error: string) => Promise<void>;
