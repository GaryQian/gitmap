/** Canonical operational instance and optional enabled execution-identity evidence. */
import type { ProviderModelRef as ModelRef } from "@openclaw/model-catalog-core/model-catalog-refs";
import type { CyberAccessProgram } from "../../packages/gateway-protocol/src/schema/sessions-row.js";
import { isExecutionIdentityCollectionEnabled } from "../audit/audit-config.js";
import {
  createExecutionIdentityAdmissionToken,
  enqueueExecutionIdentityContextAtAdmission,
  type ExecutionIdentityAdmissionFacts,
  type ExecutionIdentityAdmissionToken,
} from "../audit/execution-identity-admission.js";
import { executionIdentitySpawnAdmission } from "../audit/execution-identity-spawn-admission.js";
import {
  composeSessionSourceAssertion,
  prepareSessionSourceScope,
  runWithSessionSourceScope,
  type SessionSourceAssertion,
} from "../config/sessions/session-source-authority.js";
import type { OpenClawConfig } from "../config/types.openclaw.js";
import {
  captureAgentRunDelegatedSourceAssertion,
  claimAgentRunDelegatedAuthority,
  getAgentRunLifecycleGeneration,
  readAgentRunDelegatedAuthorityFailure,
  releaseAgentRunDelegatedAuthority,
  validateAgentRunDelegatedAuthority,
  type AgentRunDelegatedAuthority,
} from "../infra/agent-run-registry.js";
import { scopeOperatorAccessDecisions } from "../infra/operator-access-decision.js";
import { isOperatorAuthorityUnavailable } from "../infra/operator-authority-error.js";
import { prepareGatewayContextBindingOwner } from "../plugins/runtime/gateway-context-binding-owner.js";
import { resolveGlobalSingleton } from "../shared/global-singleton.js";
import { freezeJsonSnapshot } from "../shared/immutable-data.js";
import type { AdmittedRunOperatorAuthority } from "./admitted-run-operator-authority.types.js";
import {
  createOperationalRunInstanceRef,
  type OperationalRunInstanceRef,
} from "./operational-run-instance.js";
import { isOperatorAccessProgramAllowed } from "./operator-access-program.js";

type OperatorModelSelection = ModelRef & { cyberAccessProgram?: CyberAccessProgram };

export {
  createOperationalRunInstanceRef,
  type OperationalRunInstanceRef,
} from "./operational-run-instance.js";

/** Exact context carried by one admitted execution and every retry/fallback it owns. */
export type AdmittedRunContext = Readonly<{
  operationalRunInstance: OperationalRunInstanceRef;
  /** Scheduler-authored ingress authority, independent of optional audit collection. */
  admissionSource?: "operator-schedule" | "requester-schedule";
  executionIdentityToken?: ExecutionIdentityAdmissionToken;
}>;

export type { AdmittedRunOperatorAuthority } from "./admitted-run-operator-authority.types.js";

// Source and bundled module instances must recognize the same host-issued object.
const operatorAuthorityIssuers = resolveGlobalSingleton(
  Symbol.for("openclaw.admittedRunOperatorAuthority.issuers"),
  () => new WeakSet<object>(),
);

/** Host-only construction; public reply options cannot manufacture a source capability. */
export function createAdmittedRunOperatorAuthority(
  source: AdmittedRunOperatorAuthority,
): AdmittedRunOperatorAuthority {
  const check = source.assertCurrent;
  const revocation = new AbortController();
  const signal = source.signal
    ? AbortSignal.any([source.signal, revocation.signal])
    : revocation.signal;
  const assertCurrent = composeSessionSourceAssertion(
    [check],
    scopeOperatorAccessDecisions((assertSource: () => void) => {
      signal.throwIfAborted();
      try {
        assertSource();
      } catch (error) {
        if (!isOperatorAuthorityUnavailable(error)) {
          revocation.abort(error);
        }
        throw error;
      }
    }),
    { synchronousCheck: true },
  );
  const readRoleFacts = source.readCurrentRoleFacts;
  const authority = Object.freeze({
    profileId: source.profileId,
    canonicalIdentity:
      source.canonicalIdentity &&
      Object.freeze({
        profileId: source.canonicalIdentity.profileId,
      }),
    clientId: source.clientId,
    openclawIdPrincipal: source.openclawIdPrincipal
      ? freezeJsonSnapshot(structuredClone(source.openclawIdPrincipal))
      : undefined,
    device: source.device && Object.freeze({ ...source.device }),
    deviceScopeCeiling: source.deviceScopeCeiling && Object.freeze([...source.deviceScopeCeiling]),
    authPolicy: source.authPolicy && Object.freeze({ ...source.authPolicy }),
    sharedGeneration: source.sharedGeneration,
    ingress:
      source.ingress &&
      Object.freeze({
        ...source.ingress,
        principal: Object.freeze({ ...source.ingress.principal }),
        scopeCeiling: Object.freeze([...source.ingress.scopeCeiling]),
      }),
    recoverySnapshot: source.recoverySnapshot
      ? freezeJsonSnapshot(structuredClone(source.recoverySnapshot))
      : undefined,
    recoverySnapshotUnavailableReason: source.recoverySnapshotUnavailableReason,
    channelRecoverySource: source.channelRecoverySource
      ? Object.freeze({
          reference: Object.freeze({ ...source.channelRecoverySource.reference }),
          modelPolicy: source.channelRecoverySource.modelPolicy,
        })
      : undefined,
    scopes: Object.freeze([...source.scopes]),
    requesterOwner: source.requesterOwner,
    gatewayAccessGrant: source.gatewayAccessGrant
      ? Object.freeze({ ...source.gatewayAccessGrant })
      : source.gatewayAccessGrant,
    source: source.source ?? {},
    invocation: source.invocation,
    signal,
    retain: source.retain,
    onModelPolicyChanged: source.onModelPolicyChanged,
    get modelPolicy() {
      return source.modelPolicy;
    },
    assertCurrent,
    readCurrentRoleFacts: readRoleFacts
      ? () => {
          assertCurrent();
          return readRoleFacts();
        }
      : undefined,
    rolePolicy: source.rolePolicy
      ? Object.freeze({
          ...source.rolePolicy,
          ...(source.rolePolicy.accessPrograms
            ? {
                accessPrograms: Object.freeze({
                  cyber: Object.freeze(
                    [...new Set(source.rolePolicy.accessPrograms.cyber)].toSorted(),
                  ),
                }),
              }
            : {}),
          agents:
            source.rolePolicy.agents === "*"
              ? "*"
              : Object.freeze([...new Set(source.rolePolicy.agents)].toSorted()),
        })
      : undefined,
  });
  operatorAuthorityIssuers.add(authority);
  return authority;
}

export function assertAdmittedRunOperatorAuthority(
  authority: unknown,
): asserts authority is AdmittedRunOperatorAuthority {
  if (!authority || typeof authority !== "object" || !operatorAuthorityIssuers.has(authority)) {
    throw new Error("operator run authority must be issued by the host");
  }
}

/** Selection never grants authority; callers must pass the original host-issued source. */
export function assertOperatorModelAllowed(
  authority: AdmittedRunOperatorAuthority | undefined,
  model: OperatorModelSelection | undefined,
): void {
  createOperatorModelSelectionAssertion(authority, model)();
}

/** Carry the operator's source checks into writes without rereading its store on the host. */
export function createOperatorModelSelectionAssertion(
  authority: AdmittedRunOperatorAuthority | undefined,
  model: OperatorModelSelection | undefined,
): SessionSourceAssertion {
  return composeSessionSourceAssertion([authority?.assertCurrent], (assertSource) => {
    if (!authority) {
      return;
    }
    assertAdmittedRunOperatorAuthority(authority);
    assertSource();
    const policy = authority.modelPolicy;
    if (policy && (!model || !policy.allows(model))) {
      throw new Error(
        "Your operator role cannot use this model. Choose an allowed model or ask a gateway administrator to update your role's model policy.",
      );
    }
    assertOperatorAccessProgramAllowed(authority, model?.cyberAccessProgram);
  });
}

/** Clearing a stale Access selection must not require permission to its old model. */
export function assertOperatorAccessProgramAllowed(
  authority: AdmittedRunOperatorAuthority | undefined,
  program: CyberAccessProgram | undefined,
): void {
  if (!authority) {
    return;
  }
  assertAdmittedRunOperatorAuthority(authority);
  authority.assertCurrent();
  if (!isOperatorAccessProgramAllowed(authority, program)) {
    throw new Error(
      "Your operator role cannot use this Access level. Choose Standard or ask a gateway administrator to grant this Access level to your role.",
    );
  }
}

/** Keeps one selected model current without revoking other work from the same source. */
export function bindOperatorModelExecution(
  authority: AdmittedRunOperatorAuthority | undefined,
  model: OperatorModelSelection | undefined,
  mapAuthorizationError?: (error: unknown) => Error,
): Readonly<{ signal: AbortSignal; assertCurrent: () => void; release: () => void }> | undefined {
  if (!authority) {
    return undefined;
  }
  const selected = model ? { ...model } : undefined;
  const assertModelAllowed = createOperatorModelSelectionAssertion(authority, selected);
  const mapError = (error: unknown) =>
    isOperatorAuthorityUnavailable(error) ? error : (mapAuthorizationError?.(error) ?? error);
  let releaseAuthority: (() => void) | undefined;
  try {
    assertModelAllowed();
    releaseAuthority = authority.retain?.();
  } catch (error) {
    throw mapError(error);
  }
  const revoked = new AbortController();
  let released = false;
  const assertCurrent = () => {
    if (released) {
      throw mapError(new Error("operator model execution authority is no longer active"));
    }
    revoked.signal.throwIfAborted();
    try {
      assertModelAllowed();
    } catch (error) {
      const failure = mapError(error);
      if (!isOperatorAuthorityUnavailable(error)) {
        revoked.abort(failure);
      }
      throw failure;
    }
  };
  const recheck = () => {
    try {
      assertCurrent();
    } catch {
      // The latched signal owns cancellation; notification must reach other executions.
    }
  };
  const onSourceAbort = () => revoked.abort(mapError(authority.signal?.reason));
  authority.signal?.addEventListener("abort", onSourceAbort, { once: true });
  const unsubscribe = authority.onModelPolicyChanged?.(recheck);
  recheck();
  return {
    signal: revoked.signal,
    assertCurrent,
    release: () => {
      if (!released) {
        released = true;
        unsubscribe?.();
        authority.signal?.removeEventListener("abort", onSourceAbort);
        releaseAuthority?.();
      }
    },
  };
}

/** Prepared and admitted paths share the same source throughout retries and detached work. */
export function readRunOperatorAuthority(params: {
  preparedRunAdmission?: PreparedAgentRunAdmission;
  admittedRunContext?: AdmittedRunContext;
}): AdmittedRunOperatorAuthority | undefined {
  return (
    readAdmittedRunOperatorAuthority(params.admittedRunContext) ??
    readPreparedRunOperatorAuthority(params.preparedRunAdmission)
  );
}

export type PreparedAgentRunAdmission = Readonly<{
  operationalRunInstance: OperationalRunInstanceRef;
  /** Exact post-prepare owner; repeated fallback/retry returns the same object. */
  admit: (
    runtimeKind: ExecutionIdentityAdmissionFacts["runtime"]["kind"],
    runtimeInstanceId?: string,
  ) => Promise<AdmittedRunContext>;
  /** Checks latched source revocation after normal close; never grants execution authority. */
  assertSourceCurrent: () => void;
  /** Checks open preparation and its exact admitted owner without evaluating source predicates. */
  assertCurrent: () => void;
  /** Host-only source restriction available before the runtime prepares its tools. */
  readOperatorAuthority?: () => AdmittedRunOperatorAuthority | undefined;
  /** Idempotently closes the exact delegated approval lease, if admission occurred. */
  close: () => void;
}>;

type DelegatedAuthorityLease = {
  authority: AgentRunDelegatedAuthority;
  foregroundClosed: boolean;
  assertSourceCurrent?: () => void;
  operatorAuthority?: AdmittedRunOperatorAuthority;
};

const delegatedAuthorityLeases = new WeakMap<AdmittedRunContext, DelegatedAuthorityLease>();
const admittedContextsByAuthority = new WeakMap<AgentRunDelegatedAuthority, AdmittedRunContext>();
const activeNativeHookRecoveryLeases = new Map<
  string,
  { lease: DelegatedAuthorityLease; releaseOperatorAuthority?: () => void }
>();

/** Reprepare source predicates after the caller establishes an exact transcript fence. */
export function runWithPreparedRunSourceScope<T>(
  params: {
    preparedRunAdmission?: PreparedAgentRunAdmission;
    admittedRunContext?: AdmittedRunContext;
  },
  run: () => Promise<T>,
): Promise<T> {
  let assertion = params.preparedRunAdmission?.assertSourceCurrent;
  if (params.admittedRunContext) {
    const lease = delegatedAuthorityLeases.get(params.admittedRunContext);
    const captured =
      lease && captureAdmittedRunActiveAssertion(params.admittedRunContext, lease.authority);
    if (!captured) {
      return Promise.reject(new Error("admitted run authority is no longer active"));
    }
    assertion = captured;
  }
  return runWithSessionSourceScope(assertion, run, { checkAfter: false });
}

function bindAdmittedRunDelegatedAuthority(
  context: AdmittedRunContext,
  assertSourceCurrent?: () => void,
  operatorAuthority?: AdmittedRunOperatorAuthority,
): void {
  const authority = claimAgentRunDelegatedAuthority(
    context.operationalRunInstance,
    assertSourceCurrent,
  );
  const previousRecovery = activeNativeHookRecoveryLeases.get(context.operationalRunInstance.runId);
  activeNativeHookRecoveryLeases.delete(context.operationalRunInstance.runId);
  previousRecovery?.releaseOperatorAuthority?.();
  const lease = { authority, foregroundClosed: false, assertSourceCurrent, operatorAuthority };
  delegatedAuthorityLeases.set(context, lease);
  if (!admittedContextsByAuthority.has(authority)) {
    admittedContextsByAuthority.set(authority, context);
  }
}

/** Reads the immutable outer-run authority without reviving a closed claim. */
export function getAdmittedRunDelegatedAuthority(
  context: AdmittedRunContext,
): AgentRunDelegatedAuthority | undefined {
  const lease = delegatedAuthorityLeases.get(context);
  return lease && !lease.foregroundClosed && validateAgentRunDelegatedAuthority(lease.authority)
    ? lease.authority
    : undefined;
}

/** Captures the operator's source lifetime from a live run, including for detached children. */
export function readAdmittedRunOperatorAuthority(
  context: AdmittedRunContext | undefined,
): AdmittedRunOperatorAuthority | undefined {
  if (!context) {
    return undefined;
  }
  const operatorAuthority = delegatedAuthorityLeases.get(context)?.operatorAuthority;
  if (!operatorAuthority) {
    return undefined;
  }
  if (!getAdmittedRunDelegatedAuthority(context)) {
    throw new Error("admitted run operator authority is no longer active");
  }
  return operatorAuthority;
}

/** Reads the same source ceiling used by admission without minting run authority. */
export function readPreparedRunOperatorAuthority(
  prepared: PreparedAgentRunAdmission | undefined,
): AdmittedRunOperatorAuthority | undefined {
  const authority = prepared?.readOperatorAuthority?.();
  if (authority !== undefined) {
    assertAdmittedRunOperatorAuthority(authority);
  }
  return authority;
}

/** Reads the original admission source only through its exact live authority. */
export function getAdmittedRunSource(
  authority: AgentRunDelegatedAuthority | undefined,
): AdmittedRunContext["admissionSource"] {
  const context = authority && admittedContextsByAuthority.get(authority);
  return context && getAdmittedRunDelegatedAuthority(context) === authority
    ? context.admissionSource
    : undefined;
}

/** Reads the initiating profile only from the host's exact active admission lease. */
export function getAdmittedRunOperatorProfileId(
  authority: AgentRunDelegatedAuthority,
): string | undefined {
  const context = admittedContextsByAuthority.get(authority);
  if (!context || getAdmittedRunDelegatedAuthority(context) !== authority) {
    return undefined;
  }
  const operator = readAdmittedRunOperatorAuthority(context);
  operator?.assertCurrent();
  return operator?.profileId;
}

/** Captures an exact admitted-run assertion for work that may cross an await boundary. */
export function resolveAdmittedRunActiveAssertion(
  context: AdmittedRunContext,
  signal?: AbortSignal,
): ReturnType<typeof captureAdmittedRunActiveAssertion> {
  const authority = getAdmittedRunDelegatedAuthority(context);
  return authority ? captureAdmittedRunActiveAssertion(context, authority, signal) : undefined;
}

/** Capture an already-resolved authority without repeating its source reads. */
export function captureAdmittedRunActiveAssertion(
  context: AdmittedRunContext,
  authority: AgentRunDelegatedAuthority,
  signal?: AbortSignal,
) {
  const operationalRunInstance = context.operationalRunInstance;
  const lease = delegatedAuthorityLeases.get(context);
  const refuse = (): never => {
    throw new Error(
      "admitted run authority is no longer active",
      readAgentRunDelegatedAuthorityFailure(authority),
    );
  };
  const source = captureAgentRunDelegatedSourceAssertion(authority, refuse);
  if (!lease || lease.foregroundClosed || lease.authority !== authority || !source) {
    return undefined;
  }
  const assertLocalCurrent = (assertSource: () => void) => {
    if (
      signal?.aborted ||
      context.operationalRunInstance !== operationalRunInstance ||
      delegatedAuthorityLeases.get(context) !== lease ||
      lease.foregroundClosed
    ) {
      refuse();
    }
    assertSource();
  };
  return Object.assign(
    composeSessionSourceAssertion(
      [source.assertCurrent],
      scopeOperatorAccessDecisions(assertLocalCurrent),
      { synchronousCheck: true },
    ),
    {
      assertScopeCurrent: () => assertLocalCurrent(source.assertBinding),
    },
  );
}

/** Idempotently compare-releases the authority captured by this admission. */
export function closeAdmittedRunDelegatedAuthority(context: AdmittedRunContext): boolean {
  const lease = delegatedAuthorityLeases.get(context);
  if (!lease || lease.foregroundClosed) {
    return false;
  }
  lease.foregroundClosed = true;
  releaseAgentRunDelegatedAuthority(lease.authority);
  return true;
}

type AdmittedRunBeforeToolCallRecovery = Readonly<{
  assertActive: () => void;
  release: () => void;
}>;

/** Recovery-only lease for the already-created native pre-tool policy callback. */
export function retainAdmittedRunBeforeToolCallRecovery(
  context: AdmittedRunContext,
): AdmittedRunBeforeToolCallRecovery | undefined {
  const lease = delegatedAuthorityLeases.get(context);
  const runId = context.operationalRunInstance.runId;
  if (
    !lease ||
    lease.foregroundClosed ||
    activeNativeHookRecoveryLeases.has(runId) ||
    !validateAgentRunDelegatedAuthority(lease.authority)
  ) {
    return undefined;
  }
  const recovery = {
    lease,
    releaseOperatorAuthority: lease.operatorAuthority?.retain?.(),
  };
  activeNativeHookRecoveryLeases.set(runId, recovery);
  const assertActive = () => {
    // Retaining native policy outlives the foreground claim, never its source owner.
    lease.assertSourceCurrent?.();
    if (
      getAgentRunLifecycleGeneration() !== lease.authority.lifecycleGeneration ||
      activeNativeHookRecoveryLeases.get(runId) !== recovery
    ) {
      throw new Error("admitted run native hook recovery is no longer active");
    }
  };
  return {
    assertActive,
    release: () => {
      if (activeNativeHookRecoveryLeases.get(runId) === recovery) {
        activeNativeHookRecoveryLeases.delete(runId);
        recovery.releaseOperatorAuthority?.();
      }
    },
  };
}

/** Prepares a system-owned run without selecting its eventual execution runtime early. */
export function prepareSystemAgentRunAdmission(
  cfg: OpenClawConfig,
  runId: string,
  agentId: string,
  boundary: string,
  assertSourceCurrent?: () => void,
  operatorAuthority?: AdmittedRunOperatorAuthority,
): PreparedAgentRunAdmission {
  return prepareAgentRunAdmission({
    cfg,
    operationalRunInstance: createOperationalRunInstanceRef(runId),
    assertSourceCurrent,
    operatorAuthority,
    facts: {
      runId,
      agentId,
      ingress: { kind: "system", boundary, state: "present" },
    },
  });
}

/**
 * Freezes ingress facts before preparation while deferring allocation/capture until the
 * authoritative runtime owner is selected immediately before execution.
 */
export function prepareAgentRunAdmission(params: {
  cfg: OpenClawConfig;
  admissionSource?: AdmittedRunContext["admissionSource"];
  facts: Omit<ExecutionIdentityAdmissionFacts, "runtime">;
  operationalRunInstance: OperationalRunInstanceRef;
  onAdmitted?: (context: AdmittedRunContext) => void | Promise<void>;
  assertSourceCurrent?: () => void;
  operatorAuthority?: AdmittedRunOperatorAuthority;
}): PreparedAgentRunAdmission {
  const operationalRunInstance = params.operationalRunInstance;
  if (operationalRunInstance.runId !== params.facts.runId) {
    throw new Error("operational run instance disagrees with prepared admission");
  }
  const sourceAssertion = params.assertSourceCurrent;
  const operatorAuthority = params.operatorAuthority;
  if (operatorAuthority !== undefined) {
    assertAdmittedRunOperatorAuthority(operatorAuthority);
  }
  const assertOperatorCurrent = operatorAuthority?.assertCurrent;
  const releaseOperatorAuthority = operatorAuthority?.retain?.();
  let sourceFailure: Error | undefined;
  const assertSourceCurrent =
    (sourceAssertion || assertOperatorCurrent) &&
    composeSessionSourceAssertion(
      [sourceAssertion, assertOperatorCurrent],
      scopeOperatorAccessDecisions((assertSources: () => void) => {
        if (sourceFailure) {
          throw sourceFailure;
        }
        try {
          assertSources();
        } catch (error) {
          if (!isOperatorAuthorityUnavailable(error)) {
            sourceFailure = new Error("source execution authority is no longer active", {
              cause: error,
            });
          }
          throw error;
        }
      }),
      { synchronousCheck: true },
    );
  let admittedRuntimeKind: ExecutionIdentityAdmissionFacts["runtime"]["kind"] | undefined;
  let admittedRuntimeInstanceId: string | undefined;
  let admitted: Promise<AdmittedRunContext> | undefined;
  let admittedContext: AdmittedRunContext | undefined;
  let closed = false;
  const assertPreparationOpen = () => {
    if (closed) {
      throw new Error("prepared execution context is already closed");
    }
  };
  const scopedSource = composeSessionSourceAssertion(
    [assertSourceCurrent],
    (assertSource) => {
      assertPreparationOpen();
      assertSource();
    },
    { synchronousCheck: true },
  );
  const prepared: PreparedAgentRunAdmission = Object.freeze({
    operationalRunInstance,
    assertCurrent: () => {
      assertPreparationOpen();
      if (!admittedContext) {
        return;
      }
      const lease = delegatedAuthorityLeases.get(admittedContext);
      const assertActive =
        lease && captureAdmittedRunActiveAssertion(admittedContext, lease.authority);
      if (!assertActive) {
        throw new Error("prepared execution authority is no longer active");
      }
      assertActive.assertScopeCurrent();
    },
    assertSourceCurrent: Object.assign(
      composeSessionSourceAssertion([assertSourceCurrent], undefined, { synchronousCheck: true }),
      {
        assertScopeCurrent: assertPreparationOpen,
        prepareSessionSourceScope: () => {
          assertPreparationOpen();
          return prepareSessionSourceScope(scopedSource);
        },
      },
    ),
    readOperatorAuthority: () => {
      if (operatorAuthority) {
        if (closed) {
          throw new Error("prepared operator authority is no longer active");
        }
        operatorAuthority.assertCurrent();
      }
      return operatorAuthority;
    },
    close: () => {
      if (closed) {
        return;
      }
      closed = true;
      if (admittedContext) {
        closeAdmittedRunDelegatedAuthority(admittedContext);
      } else {
        void admitted?.then(closeAdmittedRunDelegatedAuthority).catch(() => undefined);
      }
      releaseOperatorAuthority?.();
    },
    admit: (runtimeKind, runtimeInstanceId) => {
      if (closed) {
        return Promise.reject(new Error("prepared execution context is already closed"));
      }
      // The first runtime that actually executes fixes the captured runtime fact.
      // Later fallback paths reuse this exact admission instead of recapturing identity.
      const fixedRuntimeKind = (admittedRuntimeKind ??= runtimeKind);
      admittedRuntimeInstanceId ??= runtimeInstanceId?.trim() || undefined;
      admitted ??= runWithSessionSourceScope(
        assertSourceCurrent,
        async () => {
          assertSourceCurrent?.();
          const facts = executionIdentitySpawnAdmission({
            operation: "attach",
            value: { ...params.facts, runtime: { kind: fixedRuntimeKind } },
            extra: executionIdentitySpawnAdmission({ operation: "read", value: params.facts }),
          });
          const context = admitPreparedAgentRun({
            cfg: params.cfg,
            admissionSource: params.admissionSource,
            facts,
            operationalRunInstance,
            runtimeInstanceId: admittedRuntimeInstanceId,
          });
          bindAdmittedRunDelegatedAuthority(context, assertSourceCurrent, operatorAuthority);
          admittedContext = context;
          try {
            await params.onAdmitted?.(context);
            if (closed || !getAdmittedRunDelegatedAuthority(context)) {
              throw new Error("prepared execution authority closed during admission");
            }
            return context;
          } catch (error) {
            closeAdmittedRunDelegatedAuthority(context);
            throw error;
          }
        },
        { checkAfter: false },
      );
      return admitted;
    },
  });
  return prepared;
}

/** Resolves a host-only continuation or validates an already-admitted internal caller. */
export async function resolvePreparedRunAdmission(params: {
  runId: string;
  runtimeKind: ExecutionIdentityAdmissionFacts["runtime"]["kind"];
  runtimeInstanceId?: string;
  admittedRunContext?: AdmittedRunContext;
  preparedRunAdmission?: PreparedAgentRunAdmission;
}): Promise<AdmittedRunContext> {
  if (params.admittedRunContext && params.preparedRunAdmission) {
    throw new Error("run cannot carry both prepared and admitted execution contexts");
  }
  const admitted = params.preparedRunAdmission
    ? await params.preparedRunAdmission.admit(params.runtimeKind, params.runtimeInstanceId)
    : params.admittedRunContext;
  if (!admitted || admitted.operationalRunInstance.runId !== params.runId) {
    throw new Error("prepared execution context is unavailable or disagrees with the run");
  }
  const lease = delegatedAuthorityLeases.get(admitted);
  if (lease && !getAdmittedRunDelegatedAuthority(admitted)) {
    throw new Error("prepared execution authority is no longer active");
  }
  return admitted;
}

/**
 * Owns the single post-prepare allocation/adoption/capture decision for an execution.
 * Queue loss remains audit loss only; the admitted execution keeps its exact token object.
 */
function admitPreparedAgentRun(params: {
  cfg: OpenClawConfig;
  admissionSource?: AdmittedRunContext["admissionSource"];
  facts: ExecutionIdentityAdmissionFacts;
  operationalRunInstance: OperationalRunInstanceRef;
  runtimeInstanceId?: string;
}): AdmittedRunContext {
  if (params.operationalRunInstance.runId !== params.facts.runId) {
    throw new Error("operational run instance disagrees with prepared admission");
  }
  const operationalRunInstance = params.operationalRunInstance;
  const admitted = {
    operationalRunInstance,
    ...(params.admissionSource ? { admissionSource: params.admissionSource } : {}),
  };
  if (!isExecutionIdentityCollectionEnabled(params.cfg)) {
    return Object.freeze(prepareGatewayContextBindingOwner(admitted));
  }
  const executionIdentityToken = createExecutionIdentityAdmissionToken(params.facts.runId);

  enqueueExecutionIdentityContextAtAdmission(params.facts, {
    enabled: true,
    token: executionIdentityToken,
    runtimeInstanceId: params.runtimeInstanceId,
  });
  return Object.freeze(prepareGatewayContextBindingOwner({ ...admitted, executionIdentityToken }));
}
