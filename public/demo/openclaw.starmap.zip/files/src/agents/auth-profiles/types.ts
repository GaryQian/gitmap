/**
 * Shared auth profile data contracts.
 * These types describe credential payloads, runtime selection state, and repair
 * results consumed by providers, sessions, doctor, and plugin-facing seams.
 */
import type { z } from "zod";
import type { SchemaContract } from "../../../packages/gateway-protocol/src/schema-contract.js";
import type { OpenClawConfig } from "../../config/types.openclaw.js";
import type { SecretRef } from "../../config/types.secrets.js";
import type { DatabasePathIdentity } from "../../infra/sqlite-worker-identity.js";
import type { AgentDatabaseExecutionFileIdentity } from "../../state/openclaw-agent-execution-identity.types.js";
import type {
  inlineAuthProfileCredentialSchema,
  OAuthCredentialMetadata,
} from "./credential-schema.js";
import type { LegacyOAuthRef } from "./legacy-oauth-ref.js";

type InlineAuthProfileCredential = z.infer<typeof inlineAuthProfileCredentialSchema>;

export type SharedAuthStoreOwnership = { location: "legacy-main" } | { location: "state-db" };

/** Internal prepared ownership, carried through commit publication and compensation. */
export type AuthProfileStoreOwner = {
  databasePath: string;
  databaseIdentity?: DatabasePathIdentity | AgentDatabaseExecutionFileIdentity;
  sharedDatabasePath: string;
  location: SharedAuthStoreOwnership["location"];
};

export type PreparedAuthProfileStoreOwner = AuthProfileStoreOwner & { env: NodeJS.ProcessEnv };

/** Provider identifier recorded on auth profile credentials. */
export type OAuthProvider = string;

/** Refreshable OAuth credential fields persisted for provider auth profiles. */
export type OAuthCredentials = OAuthCredentialMetadata & {
  access: string;
  refresh: string;
  expires: number;
  provider?: OAuthProvider;
  email?: string;
};

export type ApiKeyCredential = SchemaContract<
  Omit<Extract<InlineAuthProfileCredential, { type: "api_key" }>, "key">
> & {
  key?: string;
  keyRef?: SecretRef;
};

/** Static token credential that OpenClaw does not refresh. */
type TokenCredential = SchemaContract<
  Omit<Extract<InlineAuthProfileCredential, { type: "token" }>, "token">
> & {
  token?: string;
  tokenRef?: SecretRef;
};

/**
 * Refreshable OAuth credential plus provider metadata and legacy references.
 * OAuth refresh tokens are not portable by default. Provider-owned flows may
 * set copyToAgents only when copying refresh material across agents is known safe.
 */
export type OAuthCredential = OAuthCredentialMetadata &
  SchemaContract<
    Omit<Extract<InlineAuthProfileCredential, { type: "oauth" }>, keyof OAuthCredentialMetadata>
  > & {
    oauthRef?: LegacyOAuthRef;
  };

export type SavedSetupCredential = {
  apiKeyHeader?: true;
  agentRuntimeId?: string;
  replacement: boolean;
  modelRef: string;
  /** Setup validates the connection config when retrying, outside auth hot paths. */
  configJson: string;
  authChoice?: string;
  pluginId?: string;
};

export type AuthProfileCredential = (ApiKeyCredential | TokenCredential | OAuthCredential) & {
  /** Replacement credentials stay unavailable until their verified connection is activated. */
  setup?: SavedSetupCredential;
};

/** Closed reasons that drive cooldown, disable, and failure counters. */
export type AuthProfileFailureReason =
  | "auth"
  | "auth_permanent"
  | "format"
  | "overloaded"
  | "rate_limit"
  | "billing"
  | "timeout"
  | "model_not_found"
  | "session_expired"
  | "empty_response"
  | "no_error_details"
  | "unclassified"
  | "unknown";

/** Optional host diagnostic attached to a canonical cooldown reason. */
export type AuthProfileCooldownClassification = "wham_token_expired" | "wham_account_dead";

/** Profile-wide blocked reason reported by provider usage probes. */
export type AuthProfileBlockedReason = "subscription_limit";
export type AuthProfileBlockedSource = "codex_rate_limits" | "wham";

/** Per-profile usage statistics for round-robin and cooldown tracking */
export type ProfileUsageStats = {
  lastUsed?: number;
  blockedUntil?: number;
  blockedReason?: AuthProfileBlockedReason;
  blockedSource?: AuthProfileBlockedSource;
  blockedModel?: string;
  blockedScope?: "model";
  cooldownUntil?: number;
  cooldownReason?: AuthProfileFailureReason;
  cooldownClassification?: AuthProfileCooldownClassification;
  cooldownModel?: string;
  disabledUntil?: number;
  disabledReason?: AuthProfileFailureReason;
  /** Counts only locally timed failures; provider timing alone bounds rate limits. */
  errorCount?: number;
  failureCounts?: Partial<Record<Exclude<AuthProfileFailureReason, "rate_limit">, number>>;
  lastFailureAt?: number;
  /** Latest provider rate limit since this profile's last successful request. */
  lastRateLimitAt?: number;
  /** Most recent quota probe or successful provider use. */
  lastProbeAt?: number;
};

export type UserModelAuthProfile = {
  credential: AuthProfileCredential;
  usageStats?: ProfileUsageStats;
};

/** Durable, non-secret auth profile selection state. */
export type AuthProfileState = {
  /**
   * Optional per-agent preferred profile order overrides.
   * This lets you lock/override auth rotation for a specific agent without
   * changing the global config.
   */
  order?: Record<string, string[]>;
  lastGood?: Record<string, string>;
  /** Usage statistics per profile for round-robin rotation */
  usageStats?: Record<string, ProfileUsageStats>;
};

export type PersistedAuthProfileStoreInspection =
  | { status: "missing"; reason: "database" | "table" | "row" }
  | { status: "readable"; raw: unknown }
  | { status: "unreadable" };

export type AuthProfileRowRead = {
  store: PersistedAuthProfileStoreInspection;
  state: PersistedAuthProfileStoreInspection;
  cacheable: boolean;
};

/** Persisted credential payload without runtime-only selection state. */
export type AuthProfileSecretsStore = {
  version: number;
  profiles: Record<string, AuthProfileCredential>;
};

export type AuthProfileStateStore = {
  version: number;
} & AuthProfileState;

/** Effective in-memory auth store combining credentials, state, and overlays. */
export type AuthProfileStore = AuthProfileSecretsStore &
  AuthProfileState & {
    /** Runtime-only provenance for credentials cloned from persisted auth stores. */
    runtimePersistedProfileIds?: string[];
    /** Runtime-only provenance for external OAuth profiles overlaid onto this store. */
    runtimeExternalProfileIds?: string[];
    /** True when the runtime external profile set was freshly resolved, even if empty. */
    runtimeExternalProfileIdsAuthoritative?: boolean;
  };

/** Physical origin of a canonical credential selected into a session read view. */
export type AuthProfileCredentialSource = {
  readonly databasePath: string;
  readonly provider: string;
};

/** Internal effective-store ownership metadata; never exposed through the plugin SDK. */
export type RuntimeAuthProfileStore = AuthProfileStore & {
  /** Physical sources of the selected rows; retained only in session read views. */
  runtimeCredentialSources?: Record<string, AuthProfileCredentialSource>;
  runtimeLocalProfileIds?: string[];
  /** Canonical local OAuth rows may be hidden by shared-store reconciliation. */
  runtimeHasLocalOAuthProfiles?: boolean;
  /** Provider orders stored by this owner; [] means no local override, even with inherited priority. */
  runtimeLocalOrderProviderIds?: string[];
  runtimeInheritsMainState?: boolean;
};

export type AuthProfileIdRepairResult = {
  config: OpenClawConfig;
  changes: string[];
  migrated: boolean;
};
