import { isRecord } from "@openclaw/normalization-core/record-coerce";
import type { SessionTranscriptContextVersion } from "../../config/sessions/session-accessor.sqlite-contract.js";
import { publishCommittedSessionIdentity } from "../../config/sessions/session-accessor.sqlite-identity.js";
import { startSessionTranscriptIndexReconcile } from "../../config/sessions/session-transcript-reconcile.js";
import { sessionStoreLane } from "../../config/sessions/session-transcript-worker-resources.js";
import { sameSessionTranscriptTargetBinding } from "../../config/sessions/transcript-target-binding.js";
import {
  captureOwnedTranscriptWriteAssertion,
  withOwnedSessionTranscriptWriterFence,
} from "../../config/sessions/transcript-write-context.js";
import { recordModelFallbackStop } from "../model-fallback-stop.js";
import { parseOpaqueLeafEntry, parseParentLinkedOpaqueEntry } from "./session-manager-codec.js";
import { createManagedSessionId, generateSessionEntryId } from "./session-manager-id.js";
import { prepareSessionManagerHydration } from "./session-manager-incognito.js";
import { SessionManagerMetadata } from "./session-manager-metadata.js";
import { receiveSessionManagerCommit } from "./session-manager-persistence-error.js";
import type {
  LabelEntry,
  PreservedOpaqueFileEntry,
  SessionEntry,
  SessionHeader,
} from "./session-manager-types.js";
import type { SessionManagerPersistenceTarget } from "./session-manager-view-types.js";
import { withSessionManagerWrite } from "./session-manager-write-admission.js";

export class SessionManagerBranching extends SessionManagerMetadata {
  /** A context-only view must not rewind past omitted, user-visible entries. */
  hasLoadedTranscriptTail(entryId: string, parentId: string | null): boolean {
    this.assertTranscriptViewAvailable();
    if (this.appendMode === "side") {
      return false;
    }
    let currentId = this.appendParentId;
    for (let remaining = this.byId.size; currentId && remaining > 0; remaining--) {
      const entry = this.byId.get(currentId);
      if (!entry) {
        return false;
      }
      const currentParentId = this.boundedParentIds.has(currentId)
        ? (this.boundedParentIds.get(currentId) ?? null)
        : entry.parentId;
      if (currentId === entryId) {
        return currentParentId === parentId;
      }
      currentId = currentParentId;
    }
    return false;
  }

  private collectBranchedSessionPath(leafId: string): {
    entries: SessionEntry[];
    opaqueEntries: PreservedOpaqueFileEntry[];
    tailId: string | null;
  } {
    type BranchNode =
      | { type: "entry"; entry: SessionEntry }
      | { type: "opaque"; id: string; record: Record<string, unknown> };

    const opaqueById = new Map<string, Record<string, unknown>>();
    for (const opaqueEntry of this.opaqueFileEntries) {
      const leafEntry = parseOpaqueLeafEntry(opaqueEntry.record);
      const link = leafEntry ?? parseParentLinkedOpaqueEntry(opaqueEntry.record);
      if (link && isRecord(opaqueEntry.record)) {
        opaqueById.set(link.id, opaqueEntry.record);
      }
    }

    const reversedNodes: BranchNode[] = [];
    const seen = new Set<string>();
    let currentId: string | null = leafId;
    while (currentId && !seen.has(currentId)) {
      seen.add(currentId);
      const entry = this.byId.get(currentId);
      if (entry) {
        reversedNodes.push({ type: "entry", entry });
        if (this.logicalParentsById.has(entry.id)) {
          let physicalId = entry.parentId;
          while (physicalId && !seen.has(physicalId)) {
            const physicalRecord = opaqueById.get(physicalId);
            if (!physicalRecord || !this.opaqueParentsById.has(physicalId)) {
              break;
            }
            seen.add(physicalId);
            reversedNodes.push({ type: "opaque", id: physicalId, record: physicalRecord });
            physicalId = this.opaqueParentsById.get(physicalId) ?? null;
          }
          currentId = this.logicalParentsById.get(entry.id) ?? null;
        } else {
          currentId = entry.parentId;
        }
        continue;
      }
      const record = opaqueById.get(currentId);
      if (!record || !this.opaqueParentsById.has(currentId)) {
        break;
      }
      reversedNodes.push({ type: "opaque", id: currentId, record });
      currentId = this.opaqueParentsById.get(currentId) ?? null;
    }

    const entries: SessionEntry[] = [];
    const opaqueEntries: PreservedOpaqueFileEntry[] = [];
    let tailId: string | null = null;
    for (const node of reversedNodes.toReversed()) {
      if (node.type === "entry") {
        if (node.entry.type === "label") {
          continue;
        }
        // This is the selected path in a new session, not an inactive side branch.
        // Its navigation controls are omitted, so copied entries must advance the leaf.
        this.ownTranscriptEntries([node.entry]);
        const branchEntry: SessionEntry = { ...node.entry, parentId: tailId };
        delete branchEntry.appendMode;
        entries.push(branchEntry);
        tailId = branchEntry.id;
        continue;
      }
      if (parseOpaqueLeafEntry(node.record)) {
        continue;
      }
      this.ownTranscriptEntries([node.record]);
      opaqueEntries.push({
        index: entries.length + 1,
        record: { ...node.record, parentId: tailId },
      });
      tailId = node.id;
    }
    return { entries, opaqueEntries, tailId };
  }

  async createBranchedSession(leafId: string): Promise<string | undefined> {
    return withSessionManagerWrite(this, async (admission) => {
      this.assertTranscriptWriteActive();
      if (this.persistenceTarget && this.boundedContextIncomplete) {
        await this.ensureCompletePersistedHistoryAsync();
      }
      this.assertTranscriptWriteActive();
      const assertNavigation = this.captureTranscriptNavigationAssertion();
      const previousSessionId = this.sessionId;
      // The source counts its active path, and its own inherited paths stay inherited;
      // copied entries off both still count in the branch.
      const countedIds = new Set(
        [
          ...this.getBranch(),
          ...(this.getHeader()?.inheritedThrough ?? []).flatMap((id) =>
            this.getEntry(id) ? this.getBranch(id) : [],
          ),
        ].map((entry) => entry.id),
      );
      const branchPath = this.collectBranchedSessionPath(leafId);
      if (branchPath.entries.length === 0) {
        throw new Error(`Entry ${leafId} not found`);
      }

      const newSessionId = createManagedSessionId();
      const timestamp = new Date().toISOString();
      const persistenceTarget = this.persistenceTarget;

      const header: SessionHeader = {
        type: "session",
        version: this.getHeader()?.version,
        id: newSessionId,
        timestamp,
        cwd: this.cwd,
        parentSession: persistenceTarget ? previousSessionId : undefined,
        inheritedThrough: branchPath.entries
          .filter((entry) => countedIds.has(entry.id))
          .slice(-1)
          .map((entry) => entry.id),
      };
      const pathEntryIds = new Set(branchPath.entries.map((entry) => entry.id));
      const labelEntries: LabelEntry[] = [];
      let parentId = branchPath.tailId;
      for (const [targetId, label] of this.labelsById) {
        if (!pathEntryIds.has(targetId)) {
          continue;
        }
        const labelEntry: LabelEntry = {
          type: "label",
          id: generateSessionEntryId(),
          parentId,
          timestamp: this.labelTimestampsById.get(targetId)!,
          targetId,
          label,
        };
        labelEntries.push(labelEntry);
        parentId = labelEntry.id;
      }

      // Build leaf controls on a detached tree: queued or failed persistence must
      // never expose a new in-memory identity paired with the old durable target.
      const branch = new SessionManagerBranching(this.cwd, undefined, [
        header,
        ...branchPath.entries,
        ...labelEntries,
      ]);
      branch.opaqueFileEntries = branchPath.opaqueEntries;
      branch.buildIndex();
      const adoptBranch = (
        target?: SessionManagerPersistenceTarget,
        version?: SessionTranscriptContextVersion,
      ) => {
        this.fileEntries = branch.fileEntries;
        this.pendingWritableTranscriptEntries = branch.pendingWritableTranscriptEntries;
        this.opaqueFileEntries = branch.opaqueFileEntries;
        this.sessionId = newSessionId;
        this.buildIndex();
        this.persistenceTarget = target;
        this.transcriptVersion = target ? version : undefined;
        this.transcriptMutationAt = target ? version?.updatedAt : undefined;
        this.persistenceHeaderPending = false;
      };
      if (persistenceTarget && admission) {
        const identity = { ...persistenceTarget };
        const version = this.transcriptVersion;
        const assertOwned = captureOwnedTranscriptWriteAssertion(identity);
        const assertDestinationOwned = captureOwnedTranscriptWriteAssertion({
          ...identity,
          sessionId: newSessionId,
        });
        const assertCurrent = () => {
          admission.assertCurrent();
          this.assertTranscriptWriteActive();
          assertOwned();
          assertNavigation();
          if (
            !sameSessionTranscriptTargetBinding(identity, this.persistenceTarget) ||
            this.transcriptVersion !== version
          ) {
            throw new Error("Session transcript changed during branch preparation");
          }
        };
        const { restoreSessionColdTranscript } =
          await import("../../config/sessions/session-cold-storage.js");
        if (!("withMetadata" in admission.database)) {
          await restoreSessionColdTranscript(persistenceTarget, assertCurrent);
        }
        const reader = prepareSessionManagerHydration(persistenceTarget, {
          lane: sessionStoreLane,
        });
        const facts = await reader.readMaintenance({ operation: "version" });
        reader.assertCurrent();
        assertCurrent();
        const { withSessionMetadataWorker } = await import("./session-manager-metadata-runtime.js");
        assertCurrent();
        const fencedTarget = withOwnedSessionTranscriptWriterFence(persistenceTarget);
        const { env: _env, ...scope } = fencedTarget;
        const assertBranchCurrent = () => {
          assertCurrent();
          assertDestinationOwned();
        };
        let adopted = false;
        const receipt = await receiveSessionManagerCommit("session.transcript.branch", () =>
          withSessionMetadataWorker(
            admission.options,
            admission.database,
            assertBranchCurrent,
            (worker) =>
              worker.execute({
                type: "session.transcript.branch",
                input: {
                  scope: { ...scope, storePath: admission.database.path },
                  branch: { sessionId: newSessionId, events: branch.getPersistedFileEntries() },
                  expectedLifecycleRevision: facts.lifecycleRevision,
                },
              }),
            {
              beforeIdentityPublication: (publication) => {
                const transcript = publication.transcriptPublication
                  .flatMap((committedReceipt) => [...committedReceipt.facts.values()])
                  .find(
                    (fact) =>
                      fact.kind === "postimage" &&
                      fact.value.sessionKey === scope.sessionKey &&
                      fact.value.sessionId === newSessionId,
                  );
                if (transcript?.kind !== "postimage") {
                  throw new Error("Committed session branch omitted its transcript postimage");
                }
                this.assertTranscriptViewAvailable();
                assertNavigation();
                if (
                  !sameSessionTranscriptTargetBinding(identity, this.persistenceTarget) ||
                  this.transcriptVersion !== version
                ) {
                  throw new Error("Session transcript changed before branch publication");
                }
                const { generation, rawSeq, updatedAt } = transcript.value;
                adoptBranch(
                  { ...fencedTarget, sessionId: newSessionId },
                  { generation, rawSeq, updatedAt },
                );
                adopted = true;
              },
            },
          ),
        );
        const committed = receipt.value;
        if (committed.projectionNeedsReconcile && !receipt.failure) {
          startSessionTranscriptIndexReconcile({
            ...admission.options,
            preferredSessionId: newSessionId,
          });
        }
        let failure: { cause: unknown } | undefined;
        try {
          if (receipt.failure) {
            throw receipt.failure;
          }
          if (!adopted) {
            assertCurrent();
            adoptBranch({ ...fencedTarget, sessionId: newSessionId }, committed.version);
          }
        } catch (cause) {
          failure = { cause };
        }
        try {
          if ("withMetadata" in admission.database) {
            publishCommittedSessionIdentity(
              scope.agentId,
              admission.database.identity.incarnation,
              committed.identity.previous,
              committed.identity.current,
            );
          }
        } catch (cause) {
          failure = {
            cause: failure
              ? new AggregateError(
                  [failure.cause, cause],
                  "Branch adoption and identity publication failed",
                  { cause: failure.cause },
                )
              : cause,
          };
        }
        if (failure) {
          const error = Object.assign(
            new Error(
              "Session branch committed, but publication did not complete; do not replay the branch",
              { cause: failure.cause },
            ),
            {
              name: "SessionBranchCommittedError",
              committedSessionId: newSessionId,
              committedTarget: { ...fencedTarget, sessionId: newSessionId },
              committedVersion: committed.version,
            },
          );
          recordModelFallbackStop(error);
          this.invalidateTranscriptView(error);
          throw error;
        }
      } else {
        adoptBranch();
      }
      return persistenceTarget ? newSessionId : undefined;
    });
  }
}
