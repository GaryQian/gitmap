import type {
  SessionTranscriptBoundedActiveContext,
  SessionTranscriptContextVersion,
} from "../../config/sessions/session-accessor.sqlite-contract.js";
import type { SessionTranscriptRuntimeTarget } from "../../config/sessions/session-accessor.types.js";
import { assertCurrentSessionTranscriptHeader } from "../../config/sessions/session-entry-codec.js";
import { captureSessionTranscriptTargetBinding } from "../../config/sessions/transcript-target-binding.js";
import { CURRENT_SESSION_VERSION } from "../../config/sessions/version.js";
import {
  buildSessionTree,
  isIndexedSessionEntry,
  migrateToCurrentVersion,
  parseOpaqueLeafEntry,
  parseParentLinkedOpaqueEntry,
  prepareSessionManagerEntries,
  prepareSessionManagerBoundedIndexes,
  ownSessionTranscriptEntries,
  interleaveSessionFileEntries,
  clampOpaqueSessionEntryIndexes,
  collectSessionEntryChildren,
  reuseResidentSessionEntryStrings,
} from "./session-manager-codec.js";
import { createManagedSessionId, generateSessionEntryId } from "./session-manager-id.js";
import {
  prepareSessionManagerSync,
  captureSessionManagerIncognitoBinding,
  installSessionManagerIncognitoBinding,
} from "./session-manager-incognito-scope.js";
import { SessionManagerNavigation } from "./session-manager-navigation.js";
import { readSessionManagerReload } from "./session-manager-reload.kernel.js";
import type {
  FileEntry,
  NewSessionOptions,
  SessionEntry,
  SessionHeader,
  SessionInfoEntry,
  SessionTreeNode,
  SessionLeafControl,
} from "./session-manager-types.js";
import type {
  SessionManagerPersistenceTarget,
  SessionManagerBoundedContextLimits,
  PreparedSessionTranscriptReload,
  SessionManagerBoundedContext,
  SessionManagerBoundedView,
} from "./session-manager-view-types.js";
import { sessionManagerReadTranscriptBranch } from "./session-manager-view-types.js";

/** @internal Fresh payload adoption and metadata consumption share one history admission. */
export const sessionManagerReloadTranscriptCohort = Symbol.for(
  "openclaw.session-manager.reload-transcript-cohort",
);

/** @internal Initial hydration and its synchronous replay decision share one admission. */
export const sessionManagerOpenTranscriptCohort = Symbol.for(
  "openclaw.session-manager.open-transcript-cohort",
);

/** @internal Compaction planning retains its transcript and metadata from one read snapshot. */

/** @internal The owner that opened this view drops its loaded transcript once its turn has settled. */
export const sessionManagerReleaseTranscript = Symbol.for(
  "openclaw.session-manager.release-transcript",
);

export class SessionManagerCore extends SessionManagerNavigation {
  protected sessionId = "";
  protected transcriptVersion: SessionTranscriptContextVersion | undefined;
  private transcriptViewFailure: Error | undefined;
  protected hydrationRevision = 0;
  protected cwd: string;
  protected pendingWritableTranscriptEntries = new Set<object>();
  protected boundedParentIds = new Map<string, string | null>();
  protected cacheTtlProjectionPrefixes: SessionTranscriptBoundedActiveContext["cacheTtlProjectionPrefixes"];
  protected persistenceTarget: SessionManagerPersistenceTarget | undefined;
  protected persistenceHeaderPending = false;
  protected boundedContextLimits: SessionManagerBoundedContextLimits | undefined;
  protected boundedContextIncomplete = false;
  protected persistedBoundaryCount: number | undefined;
  protected persistedSuffixStartSeq: number | undefined;
  protected transcriptMutationAt: number | null | undefined;

  constructor(
    cwd: string,
    persistenceTarget?: SessionManagerPersistenceTarget,
    loadedEntries?: readonly unknown[],
    boundedContext?: SessionManagerBoundedContext,
    version?: SessionTranscriptContextVersion,
  ) {
    super();
    this.cwd = cwd;
    this.persistenceTarget = persistenceTarget;
    this.boundedContextLimits = boundedContext?.limits;
    this.boundedContextIncomplete = boundedContext !== undefined;
    this.persistedBoundaryCount = boundedContext?.boundaryCount;
    this.persistedSuffixStartSeq = boundedContext?.persistedSuffixStartSeq;
    this.transcriptMutationAt =
      boundedContext !== undefined ? boundedContext.transcriptMutationAt : version?.updatedAt;
    this.transcriptVersion = version ?? boundedContext?.version;
    if (persistenceTarget || loadedEntries) {
      this.setLoadedSessionTarget(persistenceTarget, loadedEntries ?? [], boundedContext, version);
      installSessionManagerIncognitoBinding(
        this,
        captureSessionManagerIncognitoBinding(persistenceTarget),
      );
    } else {
      this.newSession();
    }
  }

  /** The source snapshot's version, including writes beyond a selected admission prefix. */
  getTranscriptSnapshotVersion(): Readonly<SessionTranscriptContextVersion> | undefined {
    return this.transcriptVersion;
  }

  /** @deprecated Await setSessionTargetAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  setSessionTarget(target: SessionTranscriptRuntimeTarget): void {
    prepareSessionManagerSync("setSessionTarget", target, this);
    this.setSessionTargetSync(target);
  }

  protected setSessionTargetSync(target: SessionTranscriptRuntimeTarget): void {
    this.assertTranscriptViewAvailable();
    this.hydrationRevision++;
    const capturedTarget = captureSessionTranscriptTargetBinding(target);
    const prepared = readSessionManagerReload(capturedTarget, this.boundedContextLimits, false);
    const bounded = prepared.kind === "bounded" ? prepared.snapshot : undefined;
    const entries = prepared.snapshot.events as FileEntry[];
    this.boundedContextIncomplete = bounded !== undefined;
    this.persistedBoundaryCount = bounded?.boundaryCount;
    this.persistedSuffixStartSeq = bounded?.persistedSuffixStartSeq;
    this.transcriptMutationAt =
      bounded !== undefined ? bounded.transcriptMutationAt : prepared.snapshot.version.updatedAt;
    const header = entries.find(
      (entry) => typeof entry === "object" && entry !== null && entry.type === "session",
    );
    this.setLoadedSessionTarget(capturedTarget, entries, bounded, prepared.snapshot.version);
    if (header?.cwd) {
      this.cwd = header.cwd;
    }
  }

  /** Active-only loads can omit sibling rows even when they fit the context limits. */
  protected ensureCompletePersistedHistory(): void {
    this.assertTranscriptViewAvailable();
    if (!this.persistenceTarget || !this.boundedContextIncomplete) {
      return;
    }
    const limits = this.boundedContextLimits;
    this.boundedContextLimits = undefined;
    this.setSessionTargetSync(this.persistenceTarget);
    this.boundedContextLimits = limits;
  }

  protected setLoadedSessionTarget(
    target: SessionManagerPersistenceTarget | undefined,
    entries: readonly unknown[],
    bounded?: SessionManagerBoundedView,
    version?: SessionTranscriptContextVersion,
  ): void {
    this.assertTranscriptViewAvailable();
    this.transcriptVersion = version ?? bounded?.version;
    this.cacheTtlProjectionPrefixes = undefined;
    this.boundedFirstKeptById.clear();
    this.boundedParentIds.clear();
    const partitioned = prepareSessionManagerEntries(entries);
    // Only a physically empty transcript may initialize lazily. Opaque persisted rows still need
    // a canonical header, or runtime would silently replace malformed history with a fresh session.
    if (partitioned.fileEntries.length === 0 && partitioned.opaqueEntries.length === 0) {
      this.persistenceTarget = target ? captureSessionTranscriptTargetBinding(target) : undefined;
      this.initializeSession({ id: target?.sessionId });
      this.persistenceHeaderPending = target !== undefined;
      return;
    }
    const header = partitioned.fileEntries.find((entry) => entry.type === "session");
    if (target) {
      assertCurrentSessionTranscriptHeader(header);
    }
    this.persistenceHeaderPending = false;
    this.persistenceTarget = target ? captureSessionTranscriptTargetBinding(target) : undefined;
    this.fileEntries = partitioned.fileEntries;
    this.opaqueFileEntries = partitioned.opaqueEntries;
    this.pendingWritableTranscriptEntries = partitioned.pendingWritableTranscriptEntries;
    this.sessionId = header?.id ?? target?.sessionId ?? createManagedSessionId();
    this.migrated = migrateToCurrentVersion(
      this.fileEntries,
      partitioned.fileEntriesByOriginalIndex,
    );
    this.buildIndex();
    if (bounded) {
      this.boundedParentIds = new Map(bounded.parents);
      for (const [id, parentId] of bounded.opaqueParents) {
        this.opaqueParentsById.set(id, parentId);
      }
      this.adoptSelectedTranscriptPath(bounded.activeLeafEntryId, bounded.parents);
      Object.assign(
        this,
        prepareSessionManagerBoundedIndexes(
          bounded,
          partitioned.fileEntriesByOriginalIndex,
          () => this[sessionManagerReadTranscriptBranch](),
          this.byId,
        ),
      );
    }
  }

  /** The loaded view only: bounded managers must never hydrate inactive history for a rewrite. */
  protected captureTranscriptView() {
    this.assertTranscriptViewAvailable();
    return {
      sessionId: this.sessionId,
      transcriptVersion: this.transcriptVersion,
      persistenceHeaderPending: this.persistenceHeaderPending,
      migrated: this.migrated,
      fileEntries: this.fileEntries,
      pendingWritableTranscriptEntries: this.pendingWritableTranscriptEntries,
      opaqueFileEntries: this.opaqueFileEntries,
      byId: this.byId,
      opaqueParentsById: this.opaqueParentsById,
      logicalParentsById: this.logicalParentsById,
      invalidLeafControlIds: this.invalidLeafControlIds,
      labelsById: this.labelsById,
      labelTimestampsById: this.labelTimestampsById,
      boundedFirstKeptById: this.boundedFirstKeptById,
      boundedParentIds: this.boundedParentIds,
      cacheTtlProjectionPrefixes: this.cacheTtlProjectionPrefixes,
      boundedContextIncomplete: this.boundedContextIncomplete,
      boundedContextLimits: this.boundedContextLimits,
      persistedBoundaryCount: this.persistedBoundaryCount,
      persistedSuffixStartSeq: this.persistedSuffixStartSeq,
      transcriptMutationAt: this.transcriptMutationAt,
      leafId: this.leafId,
      appendParentId: this.appendParentId,
      appendMode: this.appendMode,
      pendingDeliberateAppend: this.pendingDeliberateAppend,
    };
  }

  /** @deprecated Await reloadPersistedTranscriptAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  reloadPersistedTranscript(): void {
    prepareSessionManagerSync("reloadPersistedTranscript", this.persistenceTarget, this);
    this.reloadPersistedTranscriptSync();
  }

  protected reloadPersistedTranscriptSync(): void {
    this.assertTranscriptViewAvailable();
    if (this.persistenceTarget) {
      const runtimeCwd = this.cwd;
      this.setSessionTargetSync(this.persistenceTarget);
      this.cwd = runtimeCwd;
    }
  }

  /** Reloads a committed append without adopting a later user turn. */
  protected reloadPersistedTranscriptAfterAppend(
    expectedMutationAt: number | null,
    expectedEntryId: string,
    admittedUserId: string,
  ): void {
    if (!this.persistenceTarget) {
      return;
    }
    this.adoptPreparedTranscriptReload(
      readSessionManagerReload(this.persistenceTarget, this.boundedContextLimits, true),
      { expectedMutationAt, expectedEntryId, admittedUserId },
    );
  }

  /** Adopt owner-prepared bytes without reading SQLite again on the receiving thread. */
  protected adoptPreparedTranscriptReload(
    prepared: PreparedSessionTranscriptReload,
    append?: { expectedMutationAt: number | null; expectedEntryId: string; admittedUserId: string },
    target = this.persistenceTarget,
  ): void {
    if (!target) {
      return;
    }
    const { events, version } = prepared.snapshot;
    const bounded = prepared.kind === "bounded" ? prepared.snapshot : undefined;
    const mutationAt = bounded ? bounded.transcriptMutationAt : version.updatedAt;
    if (
      append &&
      mutationAt !== append.expectedMutationAt &&
      !events.some((entry) => isIndexedSessionEntry(entry) && entry.id === append.expectedEntryId)
    ) {
      throw new Error("SQLite transcript changed before adopting the committed append");
    }
    // Validate the replacement before publication; the retained view needs no rollback copy.
    const candidate = new SessionManagerCore(this.cwd);
    candidate.boundedContextLimits = this.boundedContextLimits;
    candidate.boundedContextIncomplete = bounded !== undefined;
    candidate.persistedBoundaryCount = bounded?.boundaryCount;
    candidate.persistedSuffixStartSeq = bounded?.persistedSuffixStartSeq;
    candidate.transcriptMutationAt = mutationAt;
    candidate.setLoadedSessionTarget(target, events, bounded, version);
    if (append) {
      const activeBranch = candidate[sessionManagerReadTranscriptBranch]();
      const admittedUserIndex = activeBranch.findIndex(
        (entry) => entry.id === append.admittedUserId,
      );
      const activeBranchHasNewerUser =
        admittedUserIndex < 0 ||
        activeBranch
          .slice(admittedUserIndex + 1)
          .some((entry) => entry.type === "message" && entry.message.role === "user");
      if (activeBranchHasNewerUser) {
        candidate.adoptSelectedTranscriptPath(
          append.expectedEntryId,
          [...candidate.byId].map(([id, entry]) => [id, entry.parentId]),
        );
      }
    }
    reuseResidentSessionEntryStrings(candidate.fileEntries, this.byId);
    Object.assign(this, candidate.captureTranscriptView());
    this.persistenceTarget = candidate.persistenceTarget;
  }

  newSession(options?: NewSessionOptions): string | undefined {
    if (this.persistenceTarget) {
      throw new Error("Persisted session managers cannot change session identity in place");
    }
    return this.initializeSession(options);
  }

  private initializeSession(options?: NewSessionOptions): string | undefined {
    this.sessionId = options?.id ?? this.persistenceTarget?.sessionId ?? createManagedSessionId();
    this.migrated = false;
    const header: SessionHeader = {
      type: "session",
      version: CURRENT_SESSION_VERSION,
      id: this.sessionId,
      timestamp: new Date().toISOString(),
      cwd: this.cwd,
      parentSession: options?.parentSession,
    };
    this.fileEntries = [header];
    this.pendingWritableTranscriptEntries = new Set();
    this.opaqueFileEntries = [];
    this.clearNavigation();
    this.cacheTtlProjectionPrefixes = undefined;
    this.boundedFirstKeptById.clear();
    this.boundedParentIds.clear();
    this.pendingDeliberateAppend = false;
    return this.persistenceTarget ? this.sessionId : undefined;
  }

  protected resolveBranchTargetId(branchFromId: string): string | null | undefined {
    if (this.byId.has(branchFromId)) {
      return branchFromId;
    }
    return this.opaqueParentsById.has(branchFromId)
      ? this.resolveCanonicalParentId(branchFromId)
      : undefined;
  }

  protected clampOpaqueFileEntryIndexes(): void {
    clampOpaqueSessionEntryIndexes(this.opaqueFileEntries, this.fileEntries.length);
  }

  protected createLeafControl(
    parentId: string | null,
    appendParentId: string | null = this.appendParentId,
    appendMode?: "side",
  ): SessionLeafControl {
    return {
      type: "leaf",
      id: generateSessionEntryId(),
      parentId,
      timestamp: new Date().toISOString(),
      targetId: this.leafId,
      ...(appendParentId !== this.leafId ? { appendParentId } : {}),
      ...(appendMode ? { appendMode } : {}),
    };
  }

  protected rememberLeafControl(leafEntry: SessionLeafControl): void {
    this.opaqueFileEntries.push({ index: this.fileEntries.length, record: leafEntry });
    this.opaqueParentsById.set(leafEntry.id, leafEntry.targetId);
  }

  getSessionName(): string | undefined {
    this.assertTranscriptViewAvailable();
    const sessionInfo = this.fileEntries.findLast(
      (entry): entry is SessionInfoEntry =>
        entry.type === "session_info" && this.byId.has(entry.id),
    );
    return sessionInfo?.name?.trim() || undefined;
  }

  getChildren(parentId: string): SessionEntry[] {
    this.assertTranscriptViewAvailable();
    const children = collectSessionEntryChildren(this.byId.values(), parentId, (entry) =>
      this.normalizeEntryParent(entry),
    );
    return this.ownTranscriptEntries(children.map((entry) => this.byId.get(entry.id)))
      ? children.map((entry) => this.normalizeEntryParent(this.byId.get(entry.id)!))
      : children;
  }

  getLabel(id: string): string | undefined {
    this.assertTranscriptViewAvailable();
    return this.labelsById.get(id);
  }

  getBoundaryCount(): number {
    this.assertTranscriptViewAvailable();
    return (
      this.persistedBoundaryCount ??
      this[sessionManagerReadTranscriptBranch]().filter(
        (entry) => entry.type === "compaction" || entry.type === "reset",
      ).length
    );
  }

  getHeader(): SessionHeader | null {
    this.assertTranscriptViewAvailable();
    this.ownTranscriptEntries([this.fileEntries.find((entry) => entry.type === "session")]);
    return this.fileEntries.find((entry) => entry.type === "session") ?? null;
  }

  getEntries(): SessionEntry[] {
    this.assertTranscriptViewAvailable();
    this.ownTranscriptEntries([...this.byId.values()]);
    return this.fileEntries
      .filter((entry): entry is SessionEntry => entry.type !== "session" && this.byId.has(entry.id))
      .map((entry) => this.normalizeEntryParent(entry));
  }

  getTree(): SessionTreeNode[] {
    return buildSessionTree(
      this.getEntries(),
      this.labelsById,
      this.labelTimestampsById,
      (parentId) => this.resolveCanonicalParentId(parentId),
    );
  }

  getLeafId(): string | null {
    this.assertTranscriptViewAvailable();
    return this.leafId;
  }

  getLeafEntry(): SessionEntry | undefined {
    this.assertTranscriptViewAvailable();
    return this.leafId ? this.getEntry(this.leafId) : undefined;
  }

  getEntry(id: string): SessionEntry | undefined {
    this.assertTranscriptViewAvailable();
    this.ownTranscriptEntries([this.byId.get(id)]);
    const entry = this.byId.get(id);
    return entry ? this.normalizeEntryParent(entry) : undefined;
  }

  getAppendParentId(): string | null {
    this.assertTranscriptViewAvailable();
    return this.appendParentId;
  }

  getAppendMode(): "side" | undefined {
    this.assertTranscriptViewAvailable();
    return this.appendMode;
  }

  protected getPersistedFileEntries(leafAppendMode?: "side"): unknown[] {
    this.assertTranscriptViewAvailable();
    this.clampOpaqueFileEntryIndexes();
    const entries = interleaveSessionFileEntries(this.fileEntries, this.opaqueFileEntries);

    let persistedLeafId: string | null = null;
    let persistedAppendParentId: string | null = null;
    let rawTailId: string | null = null;
    for (const entry of entries) {
      const leafEntry = parseOpaqueLeafEntry(entry);
      if (leafEntry) {
        rawTailId = leafEntry.id;
        if (this.invalidLeafControlIds.has(leafEntry.id)) {
          continue;
        }
        const targetId = this.resolveOpaqueLeafTargetId(leafEntry.targetId);
        persistedLeafId = targetId;
        persistedAppendParentId =
          leafEntry.appendParentId === undefined
            ? targetId
            : this.resolveOpaqueAppendParentId(leafEntry.appendParentId);
        continue;
      }
      if (isIndexedSessionEntry(entry)) {
        persistedLeafId = entry.id;
        persistedAppendParentId = entry.id;
        rawTailId = entry.id;
        continue;
      }
      const opaqueLink = parseParentLinkedOpaqueEntry(entry);
      if (opaqueLink) {
        persistedAppendParentId = opaqueLink.id;
        rawTailId = opaqueLink.id;
      }
    }
    if (persistedLeafId !== this.leafId || persistedAppendParentId !== this.appendParentId) {
      const leafEntry = this.createLeafControl(rawTailId, this.appendParentId, leafAppendMode);
      this.rememberLeafControl(leafEntry);
      entries.push(leafEntry);
    }
    return entries;
  }

  getPersistedEntries(): unknown[] {
    const entries = this.getPersistedFileEntries();
    this.ownTranscriptEntries(entries);
    return entries;
  }

  protected ownTranscriptEntries(entries: readonly unknown[]): boolean {
    this.assertTranscriptViewAvailable();
    return ownSessionTranscriptEntries(entries, this.pendingWritableTranscriptEntries);
  }

  clearPreservedOpaqueFileEntries(): void {
    this.assertTranscriptViewAvailable();
    for (const { record } of this.opaqueFileEntries) {
      if (record && typeof record === "object") {
        this.pendingWritableTranscriptEntries.delete(record);
      }
    }
    this.opaqueFileEntries = [];
    this.opaqueParentsById.clear();
    this.invalidLeafControlIds.clear();
    this.appendParentId = null;
    this.appendMode = undefined;
    this.pendingDeliberateAppend = false;
  }

  protected invalidateTranscriptView(error: Error): void {
    this.transcriptViewFailure = error;
    this.transcriptVersion = undefined;
  }

  protected assertTranscriptViewAvailable(): void {
    if (this.transcriptViewFailure) {
      throw this.transcriptViewFailure;
    }
  }

  /** Drop an owned, settled view without retaining its history through late callbacks. */
  [sessionManagerReleaseTranscript](): void {
    this.fileEntries = [];
    this.opaqueFileEntries = [];
    this.pendingWritableTranscriptEntries.clear();
    this.clearNavigation();
    this.boundedParentIds.clear();
    this.boundedFirstKeptById.clear();
    this.cacheTtlProjectionPrefixes = undefined;
    this.invalidateTranscriptView(
      new Error("Session transcript view was released when its turn ended"),
    );
  }

  override getBranch(fromId?: string): SessionEntry[] {
    const branch = this[sessionManagerReadTranscriptBranch](fromId);
    return this.ownTranscriptEntries(branch.map((entry) => this.byId.get(entry.id)))
      ? this[sessionManagerReadTranscriptBranch](fromId)
      : branch;
  }

  [sessionManagerReadTranscriptBranch](fromId?: string): SessionEntry[] {
    this.assertTranscriptViewAvailable();
    return super.getBranch(fromId);
  }

  isPersisted(): boolean {
    return this.persistenceTarget !== undefined;
  }

  getCwd(): string {
    return this.cwd;
  }

  getSessionId(): string {
    return this.sessionId;
  }

  getSessionTarget(): SessionManagerPersistenceTarget | undefined {
    const target = this.persistenceTarget;
    return target ? { ...target, ...(target.env ? { env: { ...target.env } } : {}) } : undefined;
  }
}
