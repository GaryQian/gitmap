/**
 * Session tree manager backed by an explicit SQLite transcript identity.
 *
 * The public facade lives here; codec, storage, persistence, and branching
 * behavior are split into focused internal modules.
 */
import { isDeepStrictEqual } from "node:util";
import { buildSessionContext as buildCoreSessionContext } from "../../../packages/agent-core/src/harness/session/session.js";
import type { AgentMessage } from "../../../packages/agent-core/src/types.js";
import type { SessionTranscriptRuntimeTarget } from "../../config/sessions/session-accessor.js";
import { readSessionTranscriptBoundedActiveContextCore } from "../../config/sessions/session-accessor.sqlite-active-context.js";
import { prepareTranscriptRewriteSync } from "../../config/sessions/session-accessor.sqlite-branch-rewrite.js";
import type { SessionTranscriptContextVersion } from "../../config/sessions/session-accessor.sqlite-contract.js";
import {
  readSessionTranscriptContextMessages,
  readSessionTranscriptModelContext,
  type SessionModelContextLimits,
} from "../../config/sessions/session-accessor.sqlite-model-context.js";
import { loadTranscriptReadSnapshotSync } from "../../config/sessions/session-accessor.sqlite-read.js";
import { sanitizeTranscriptMessageForStorage } from "../../config/sessions/session-accessor.sqlite-transcript-store.js";
import { appendTranscriptMessageSync } from "../../config/sessions/session-accessor.sqlite-transcript-write.kernel.js";
import {
  assertCurrentSessionTranscriptHeader,
  findSessionTranscriptHeader,
} from "../../config/sessions/session-entry-codec.js";
import {
  resolveSessionTranscriptReadFence,
  withSessionContextAdmission,
} from "../../config/sessions/session-transcript-read-fence.js";
import { startSessionTranscriptIndexReconcile } from "../../config/sessions/session-transcript-reconcile.js";
import type { TranscriptEntryAnchor } from "../../config/sessions/transcript-entry-anchor.js";
import { cloneTranscriptView } from "../../config/sessions/transcript-snapshot.js";
import {
  sameSessionTranscriptTargetBinding,
  captureSessionTranscriptTargetBinding,
} from "../../config/sessions/transcript-target-binding.js";
import {
  withOwnedSessionTranscriptWriterFence,
  captureOwnedTranscriptWriteAssertion,
  getOwnedSessionTranscriptReader,
} from "../../config/sessions/transcript-write-context.js";
import { CURRENT_SESSION_VERSION } from "../../config/sessions/version.js";
import {
  readSqliteDatabaseScopedWriteTokenForPath as readScopedWriteToken,
  sqliteSessionIdWriteScope,
} from "../../infra/sqlite-database-admission.js";
import type { Message } from "../../llm/types.js";
import type { UserTurnTranscriptAdmissionReceipt } from "../../sessions/user-turn-transcript.types.js";
import type { BashExecutionMessage, CustomMessage } from "./messages.js";
import { SessionManagerBranching } from "./session-manager-branching.js";
import { projectSessionModelContextEntries, buildInitialContext } from "./session-manager-codec.js";
import {
  sessionManagerOpenTranscriptCohort,
  sessionManagerReleaseTranscript,
} from "./session-manager-core.js";
import {
  sessionManagerReadInitialContext,
  sessionManagerReadTranscriptStart,
} from "./session-manager-current-turn.js";
import { prepareSessionManagerSync } from "./session-manager-incognito-scope.js";
import {
  prepareSessionManagerHydration,
  readSessionManagerContextAsync,
  readSessionManagerModelContextAsync,
} from "./session-manager-incognito.js";
import { receiveSessionManagerCommit } from "./session-manager-persistence-error.js";
import * as reload from "./session-manager-reload.js";
import type {
  SessionLeafControl,
  AppendPersistenceOptions,
  FileEntry,
  SessionEntry,
} from "./session-manager-types.js";
import type {
  SessionManagerBoundedContext,
  SessionManagerBoundedContextLimits,
  SessionManagerPersistenceTarget,
  SessionManagerTranscriptCohort,
} from "./session-manager-view-types.js";
import { sessionManagerReadTranscriptBranch } from "./session-manager-view-types.js";
import {
  appendSessionTranscriptNote,
  withSessionManagerWrite,
} from "./session-manager-write-admission.js";
import {
  runSessionPersistenceAsync,
  runSessionPersistenceSync,
  sessionPersistenceStep,
  type SessionPersistenceStep,
} from "./session-persistence-operation.js";

export { CURRENT_SESSION_VERSION };
export {
  buildSessionContext,
  getLatestCompactionEntry,
  migrateSessionEntries,
} from "./session-manager-codec.js";
export { parseSessionEntries } from "./session-manager-jsonl.js";
export type {
  BranchSummaryEntry,
  CompactionEntry,
  FileEntry,
  SessionEntry,
  SessionHeader,
  SessionLeafControl,
  SessionMessageEntry,
} from "./session-manager-types.js";

export class SessionManager extends SessionManagerBranching {
  private preparedInitialContext?: { branch: SessionEntry[]; writeToken: string; view: object };

  private constructor(
    cwd: string,
    persistenceTarget?: SessionManagerPersistenceTarget,
    loadedEntries?: readonly unknown[],
    boundedContext?: SessionManagerBoundedContext,
    version?: SessionTranscriptContextVersion,
  ) {
    super(cwd, persistenceTarget, loadedEntries, boundedContext, version);
    this.retainTranscriptWriter();
  }

  override [sessionManagerReleaseTranscript](): void {
    this.preparedInitialContext = undefined;
    super[sessionManagerReleaseTranscript]();
  }

  [sessionManagerReadTranscriptStart]() {
    this.assertTranscriptWriteActive();
    const target = this.persistenceTarget;
    const version = this.transcriptVersion;
    return target && version
      ? {
          agentId: target.agentId,
          sessionId: target.sessionId,
          sessionKey: target.sessionKey,
          storePath: target.storePath,
          generation: version.generation,
          maxSeq: version.rawSeq,
        }
      : null;
  }

  async [sessionManagerReadInitialContext]() {
    const prepared = this.preparedInitialContext;
    this.preparedInitialContext = undefined;
    if (
      !this.persistenceTarget ||
      !this.boundedContextLimits ||
      "compaction" in this.boundedContextLimits ||
      this.pendingDeliberateAppend
    ) {
      return buildInitialContext(this[sessionManagerReadTranscriptBranch]());
    }
    // A deliberate local branch owns its view; a concurrent selection must not
    // install the database's different active path into the same writer.
    const initial = this.captureTranscriptView();
    const target = this.persistenceTarget;
    const cwd = this.cwd;
    const reader = prepared && getOwnedSessionTranscriptReader(target);
    if (
      prepared &&
      reader &&
      !resolveSessionTranscriptReadFence(target) &&
      prepared.writeToken ===
        readScopedWriteToken(reader.database.path, [sqliteSessionIdWriteScope(target.sessionId)]) &&
      Object.keys(prepared.view).every(
        (key) => Reflect.get(prepared.view, key) === Reflect.get(initial, key),
      )
    ) {
      // The cohort owns these bytes. Unrelated session writes leave its receipt current;
      // materializing this snapshot need not join a later, still-pending write.
      this.assertTranscriptWriteActive();
      reader.assertCurrent();
      return buildCoreSessionContext(prepared.branch);
    }
    const context = await readSessionManagerModelContextAsync(
      target,
      { limits: this.boundedContextLimits },
      (snapshot) => SessionManager.fromSelectedEntries(snapshot.events, cwd, snapshot.version),
      this,
    );
    const current = this.captureTranscriptView();
    if (
      Object.keys(initial).some((key) => Reflect.get(initial, key) !== Reflect.get(current, key))
    ) {
      throw new Error("Session manager changed during initial context read");
    }
    return buildInitialContext(context[sessionManagerReadTranscriptBranch](), this.byId);
  }

  /** No buffered writes remain here; asynchronous metadata methods own their settlement. */
  flushPendingPersistence(): void {}

  // Worker rollback instrumentation wraps the method on this public prototype.
  /** @deprecated Await appendMessageAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  override appendMessage(
    message: Message | CustomMessage | BashExecutionMessage,
    options?: AppendPersistenceOptions,
  ): string {
    return super.appendMessage(message, options);
  }

  /** @deprecated Await appendMessageWithTranscriptAnchorAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  override appendMessageWithTranscriptAnchor(
    message: Message | CustomMessage | BashExecutionMessage,
    options?: AppendPersistenceOptions,
  ) {
    return super.appendMessageWithTranscriptAnchor(message, options);
  }

  /** @deprecated Await prepareTranscriptRewriteAsync and its commit. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  prepareTranscriptRewrite() {
    prepareSessionManagerSync("prepareTranscriptRewrite", this.persistenceTarget, this);
    this.assertTranscriptWriteActive();
    const publish = this.persistenceTarget
      ? prepareTranscriptRewriteSync(
          this.persistenceTarget,
          () => this.assertTranscriptWriteActive(),
          this.transcriptVersion,
        )
      : undefined;
    const rewrite = this.prepareTranscriptRewriteView(publish);
    return {
      sessionManager: rewrite.sessionManager,
      commit: (ids: ReadonlyMap<string, string>) => runSessionPersistenceSync(rewrite.commit(ids)),
    };
  }

  /** Preparation returns a detached branch; only its awaited commit publishes changes. */
  async prepareTranscriptRewriteAsync() {
    return withSessionManagerWrite(this, async (writeAdmission) => {
      this.assertTranscriptWriteActive();
      const assertNavigation = this.captureTranscriptNavigationAssertion();
      const target = this.persistenceTarget;
      if (!target) {
        const detachedView = cloneTranscriptView(this.captureTranscriptView());
        const assertPrepared = () => {
          assertNavigation();
          if (
            this.persistenceTarget ||
            !isDeepStrictEqual(this.captureTranscriptView(), detachedView)
          ) {
            throw new Error("Session transcript changed before rewrite publication");
          }
        };
        const rewrite = this.prepareTranscriptRewriteView(undefined, undefined, assertPrepared);
        return {
          sessionManager: rewrite.sessionManager,
          commit: async (ids: ReadonlyMap<string, string>) => {
            assertPrepared();
            return withSessionManagerWrite(this, () => {
              assertPrepared();
              return runSessionPersistenceAsync(rewrite.commit(ids));
            });
          },
        };
      }
      const identity = { ...target };
      const loadedVersion = this.transcriptVersion;
      const appendParentId = this.appendParentId;
      const assertOwned = captureOwnedTranscriptWriteAssertion(identity);
      const assertCurrent = () => {
        writeAdmission?.assertCurrent();
        this.assertTranscriptWriteActive();
        assertOwned();
        assertNavigation();
        if (
          !sameSessionTranscriptTargetBinding(identity, this.persistenceTarget) ||
          this.transcriptVersion !== loadedVersion
        ) {
          throw new Error("Session transcript changed before rewrite publication");
        }
      };
      if (!loadedVersion) {
        throw new Error("Session transcript changed before rewrite publication");
      }
      const rewrite = this.prepareTranscriptRewriteView(
        undefined,
        async (entries, sources, adopt) => {
          await withSessionManagerWrite(this, async (admission) => {
            assertCurrent();
            if (!admission) {
              throw new Error("Transcript rewrite lost its persistent owner");
            }
            const assertCommitCurrent = () => {
              admission.assertCurrent();
              assertCurrent();
            };
            for (const entry of entries) {
              if (entry.type === "message") {
                entry.message = sanitizeTranscriptMessageForStorage(entry.message);
              }
            }
            const { withSessionMetadataWorker } =
              await import("./session-manager-metadata-runtime.js");
            assertCommitCurrent();
            const { env: _env, ...scope } = withOwnedSessionTranscriptWriterFence(target);
            const receipt = await receiveSessionManagerCommit("session.transcript.rewrite", () =>
              withSessionMetadataWorker(
                admission.options,
                admission.database,
                assertCommitCurrent,
                (worker) =>
                  worker.execute({
                    type: "session.transcript.rewrite",
                    input: {
                      scope: { ...scope, storePath: admission.database.path },
                      appendParentId,
                      version: loadedVersion,
                      entries,
                      sources: [...sources],
                    },
                  }),
              ),
            );
            const committed = receipt.value;
            if (committed.projectionNeedsReconcile && !receipt.failure) {
              startSessionTranscriptIndexReconcile({
                ...admission.options,
                preferredSessionId: identity.sessionId,
              });
            }
            try {
              if (receipt.failure) {
                throw receipt.failure;
              }
              assertCommitCurrent();
              for (const [index, entry] of committed.entries.entries()) {
                Object.assign(entries[index]!, entry);
              }
              adopt(committed.version);
            } catch (cause) {
              const error = new Error(
                "Session transcript rewrite committed but view publication failed",
                { cause },
              );
              this.invalidateTranscriptView(error);
              throw error;
            }
          });
        },
      );
      return {
        sessionManager: rewrite.sessionManager,
        commit: (ids: ReadonlyMap<string, string>) =>
          withSessionManagerWrite(this, () => runSessionPersistenceAsync(rewrite.commit(ids))),
      };
    });
  }

  private prepareTranscriptRewriteView(
    publish?: (
      entries: Array<SessionEntry | SessionLeafControl>,
      sources: ReadonlyMap<string, SessionEntry>,
      adopt: (version: SessionTranscriptContextVersion) => void,
    ) => void,
    publishAsync?: (...args: Parameters<NonNullable<typeof publish>>) => Promise<void>,
    assertBeforeCommit?: () => void,
  ) {
    const prepared = SessionManager.inMemory(this.cwd);
    Object.assign(prepared, cloneTranscriptView(this.captureTranscriptView()));
    const initialEntryCount = prepared.fileEntries.length;
    const persistedBoundaryCount = prepared.persistedBoundaryCount;
    prepared.persistedBoundaryCount = undefined;
    const loadedBoundaryCount = prepared.getBoundaryCount();
    return {
      sessionManager: prepared,
      commit: function* (
        this: SessionManager,
        rewrittenEntryIds: ReadonlyMap<string, string>,
      ): Generator<SessionPersistenceStep, void, void> {
        const publication = SessionManager.inMemory(prepared.cwd);
        Object.assign(publication, cloneTranscriptView(prepared.captureTranscriptView()));
        const entries = publication.fileEntries
          .slice(initialEntryCount)
          .filter((entry) => entry.type !== "session");
        const sources = new Map<string, SessionEntry>();
        for (const [sourceId, destination] of rewrittenEntryIds) {
          const source = this.byId.get(sourceId);
          if (!source) {
            throw new Error("Transcript rewrite source is not in the loaded view");
          }
          sources.set(destination, source);
          publication.cacheTtlProjectionPrefixes = publication.cacheTtlProjectionPrefixes?.map(
            (prefix) =>
              prefix.anchorIds.includes(sourceId)
                ? { ...prefix, anchorIds: [...prefix.anchorIds, destination] }
                : prefix,
          );
        }
        const first = entries[0];
        const source = first && sources.get(first.id);
        const parentId = source ? this.boundedParentIds.get(source.id) : undefined;
        // The bounded reader owns logical ancestry, including parents outside its payload window.
        if (first?.parentId === null && parentId !== undefined) {
          first.parentId = parentId;
          publication.boundedParentIds.set(first.id, first.parentId);
        }
        // A maintenance branch may cross a reset. Side entries preserve its
        // explicit ancestry; ordinary appends would normalize onto the old leaf.
        for (const entry of entries) {
          entry.appendMode = "side";
        }
        // Reconstruct with the reader's canonical reset/leaf rules, then retain
        // the bounded reader's ancestry for payloads absent from the loaded view.
        publication.buildIndex();
        for (const [id, parent] of this.opaqueParentsById) {
          publication.opaqueParentsById.set(id, parent);
        }
        for (const [id, parent] of this.logicalParentsById) {
          publication.logicalParentsById.set(id, parent);
        }
        const last = entries.at(-1);
        const leaf = last
          ? yield* sessionPersistenceStep(
              () =>
                publication.appendLeafControlSync({ targetId: last.id, appendParentId: last.id }),
              () =>
                publication.appendLeafControlAsync({ targetId: last.id, appendParentId: last.id }),
            )
          : undefined;
        if (persistedBoundaryCount !== undefined) {
          publication.persistedBoundaryCount =
            persistedBoundaryCount + publication.getBoundaryCount() - loadedBoundaryCount;
        }
        const adopt = (version = publication.transcriptVersion) => {
          publication.transcriptVersion = version;
          publication.transcriptMutationAt = version?.updatedAt;
          Object.assign(this, publication.captureTranscriptView());
        };
        const events = leaf ? [...entries, leaf] : entries;
        assertBeforeCommit?.();
        yield* sessionPersistenceStep(
          () => (publish ? publish(events, sources, adopt) : adopt()),
          publishAsync ? () => publishAsync(events, sources, adopt) : undefined,
        );
      }.bind(this),
    };
  }

  /** Opens an existing store off-thread; empty transcripts keep lazy header initialization. */
  static async openAsync(
    target: SessionTranscriptRuntimeTarget,
    cwdOverride?: string,
    contextLimits?: SessionManagerBoundedContextLimits,
    signal?: AbortSignal,
  ): Promise<SessionManager> {
    if (contextLimits) {
      return await SessionManager.openBoundedAsync(target, {
        ...contextLimits,
        cwd: cwdOverride,
        signal,
      });
    }
    const hydration = prepareSessionManagerHydration(target, { signal });
    const cwd = cwdOverride ?? process.cwd();
    const assertOwned = captureOwnedTranscriptWriteAssertion(hydration.target);
    assertOwned();
    const prepared = await hydration.read().catch((error: unknown) => {
      assertOwned();
      throw error;
    });
    signal?.throwIfAborted();
    assertOwned();
    hydration.assertCurrent();
    if (prepared.kind !== "full") {
      throw new Error("Expected a full transcript snapshot");
    }
    const entries = prepared.snapshot.events;
    const header = findSessionTranscriptHeader(entries);
    return new SessionManager(
      cwdOverride ?? header?.cwd ?? cwd,
      hydration.target,
      entries,
      undefined,
      prepared.snapshot.version,
    );
  }

  /** @deprecated Await openAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  static open(
    target: SessionTranscriptRuntimeTarget,
    cwdOverride?: string,
    contextLimits?: SessionManagerBoundedContextLimits,
  ): SessionManager {
    prepareSessionManagerSync("open", target);
    if (contextLimits) {
      return SessionManager.openBounded(target, {
        ...contextLimits,
        ...(cwdOverride !== undefined ? { cwd: cwdOverride } : {}),
      });
    }
    const capturedTarget = captureSessionTranscriptTargetBinding(target);
    const snapshot = loadTranscriptReadSnapshotSync(capturedTarget);
    const entries = snapshot.events as FileEntry[];
    const header = entries.find(
      (entry) => typeof entry === "object" && entry !== null && entry.type === "session",
    );
    return new SessionManager(
      cwdOverride ?? header?.cwd ?? process.cwd(),
      capturedTarget,
      entries,
      undefined,
      snapshot.version,
    );
  }

  /** @deprecated Await openBoundedAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  static openBounded(
    target: SessionTranscriptRuntimeTarget,
    options: SessionManagerBoundedContextLimits & { cwd?: string; onTruncated?: () => void },
  ): SessionManager {
    prepareSessionManagerSync("openBounded", target);
    const { cwd, onTruncated, ...limits } = options;
    const capturedTarget = captureSessionTranscriptTargetBinding(target);
    const context = readSessionTranscriptBoundedActiveContextCore(capturedTarget, limits);
    if (context.truncated) {
      onTruncated?.();
    }
    // SAFETY: The accessor returns the same persisted transcript event union consumed by open().
    const entries = context.events as FileEntry[];
    const header = entries.find(
      (entry) => typeof entry === "object" && entry !== null && entry.type === "session",
    );
    return new SessionManager(cwd ?? header?.cwd ?? process.cwd(), capturedTarget, entries, {
      ...context,
      limits,
    });
  }

  /** Reads an existing store's bounded view under the history worker's database custody. */
  static async [sessionManagerOpenTranscriptCohort](
    target: SessionTranscriptRuntimeTarget,
    options: SessionManagerBoundedContextLimits & { cwd?: string; signal?: AbortSignal },
    selection: SessionManagerTranscriptCohort["selection"],
    consume: (
      manager: SessionManager,
      ...prepared: Parameters<SessionManagerTranscriptCohort["consume"]>
    ) => void,
  ): Promise<SessionManager> {
    return reload.openSessionManagerBoundedView(
      target,
      options,
      (cwd, captured, context, limits) => {
        const manager = new SessionManager(cwd, captured, context.events, { ...context, limits });
        const branch = manager[sessionManagerReadTranscriptBranch]();
        const reader = context.completeActivePath && getOwnedSessionTranscriptReader(captured);
        const writeToken =
          reader &&
          readScopedWriteToken(reader.database.path, [
            sqliteSessionIdWriteScope(captured.sessionId),
          ]);
        if (writeToken && !manager.migrated && branch.length === context.totalEvents) {
          manager.preparedInitialContext = {
            branch: projectSessionModelContextEntries(branch),
            writeToken,
            view: manager.captureTranscriptView(),
          };
        }
        return manager;
      },
      { selection, consume, captureView: (manager) => manager.captureTranscriptView() },
    );
  }

  /** Reads an existing store's bounded view under the history worker's database custody. */
  static async openBoundedAsync(
    target: SessionTranscriptRuntimeTarget,
    options: SessionManagerBoundedContextLimits & {
      cwd?: string;
      onTruncated?: () => void;
      signal?: AbortSignal;
    },
  ): Promise<SessionManager> {
    return reload.openSessionManagerBoundedView(
      target,
      options,
      (cwd, captured, context, limits) =>
        new SessionManager(cwd, captured, context.events, { ...context, limits }),
    );
  }

  private static detachBounded(source: SessionManager) {
    const detached = SessionManager.fromSelectedEntries(
      [source.getHeader(), ...source.getBranch()],
      source.getCwd(),
    );
    detached.cacheTtlProjectionPrefixes = source.cacheTtlProjectionPrefixes;
    return detached;
  }

  /** Detach the prepared bounded branch without retaining database custody. */
  static async openDetachedBoundedAsync(
    target: SessionTranscriptRuntimeTarget,
    options: Parameters<typeof SessionManager.openBoundedAsync>[1],
  ): Promise<SessionManager> {
    return SessionManager.detachBounded(await SessionManager.openBoundedAsync(target, options));
  }

  /** @deprecated Await openDetachedBoundedAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  static openDetachedBounded(
    target: SessionTranscriptRuntimeTarget,
    options: Parameters<typeof SessionManager.openBounded>[1],
  ): SessionManager {
    prepareSessionManagerSync("openDetachedBounded", target);
    return SessionManager.detachBounded(SessionManager.openBounded(target, options));
  }

  /** @deprecated Await openModelContextAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  static openModelContext(
    target: SessionTranscriptRuntimeTarget,
    options: {
      cwd?: string;
      admission?: UserTurnTranscriptAdmissionReceipt;
      through?: TranscriptEntryAnchor;
      limits?: SessionModelContextLimits;
    } = {},
  ): SessionManager {
    prepareSessionManagerSync("openModelContext", target);
    const context = withSessionContextAdmission(target, options.admission, () =>
      readSessionTranscriptModelContext(target, options.through, options.limits),
    );
    return SessionManager.fromSelectedEntries(context.events, options.cwd, context.version);
  }

  /** The same detached model view, with durable transcript scanning off the event loop. */
  static async openModelContextAsync(
    target: SessionTranscriptRuntimeTarget,
    options: {
      cwd?: string;
      admission?: UserTurnTranscriptAdmissionReceipt;
      signal?: AbortSignal;
      through?: TranscriptEntryAnchor;
      limits?: SessionModelContextLimits;
    } = {},
  ): Promise<SessionManager> {
    return readSessionManagerModelContextAsync(target, options, (context) =>
      SessionManager.fromSelectedEntries(context.events, options.cwd, context.version),
    );
  }

  private static fromSelectedEntries(
    contextEntries: unknown[],
    cwd?: string,
    version?: SessionTranscriptContextVersion,
  ): SessionManager {
    // SAFETY: The transcript owner preserves the entry union; the constructor applies the normal codec.
    const entries = contextEntries as FileEntry[];
    const header = entries.find((entry) => entry.type === "session");
    if (entries.length > 0) {
      assertCurrentSessionTranscriptHeader(header);
    }
    const manager = new SessionManager(
      cwd ?? header?.cwd ?? process.cwd(),
      undefined,
      entries,
      undefined,
      version,
    );
    manager.adoptSelectedTranscriptPath(
      manager.appendParentId,
      [...manager.byId].map(([id, entry]) => [id, entry.parentId]),
    );
    return manager;
  }

  /** @deprecated Await readSessionContextAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release. */
  static readSessionContext<T>(
    target: SessionTranscriptRuntimeTarget,
    read: (messages: Iterable<AgentMessage>, header: unknown) => T,
    options: { admission?: UserTurnTranscriptAdmissionReceipt } = {},
  ): T {
    prepareSessionManagerSync("readSessionContext", target);
    return withSessionContextAdmission(target, options.admission, () =>
      readSessionTranscriptContextMessages(target, read),
    );
  }

  /** Consume a full-fidelity snapshot while retaining its owner through the consumer. */
  static async readSessionContextAsync<T>(
    target: SessionTranscriptRuntimeTarget,
    read: (messages: Iterable<AgentMessage>, header: unknown) => T | Promise<T>,
    options: { admission?: UserTurnTranscriptAdmissionReceipt; signal?: AbortSignal } = {},
  ): Promise<T> {
    return readSessionManagerContextAsync(target, read, options);
  }

  /**
   * @deprecated Await appendMessageToTranscriptAsync. Supported through 2026-12-31. Removal in the first January 2027 stable release.
   */
  static appendMessageToTranscript(
    target: SessionTranscriptRuntimeTarget,
    message: Message | CustomMessage | BashExecutionMessage,
    options?: Pick<AppendPersistenceOptions, "config">,
  ): string {
    prepareSessionManagerSync("appendMessageToTranscript", target);
    const outcome = appendTranscriptMessageSync(target, {
      cwd: process.cwd(),
      message,
      ...(options?.config ? { config: options.config } : {}),
    });
    if (!outcome.ok) {
      throw new Error("Session transcript message was not persisted", { cause: outcome.error });
    }
    const result = outcome.value;
    if (!result) {
      throw new Error("Session transcript message was not persisted");
    }
    return result.messageId;
  }

  static async appendMessageToTranscriptAsync(
    target: SessionTranscriptRuntimeTarget,
    message: Message | CustomMessage | BashExecutionMessage,
    options?: Pick<AppendPersistenceOptions, "config">,
  ): Promise<string> {
    return (await appendSessionTranscriptNote(target, message, options)).messageId;
  }

  static inMemory(cwd: string = process.cwd()): SessionManager {
    return new SessionManager(cwd);
  }

  static fromEntries(entries: readonly unknown[], cwdOverride?: string): SessionManager {
    const fileEntries = structuredClone(entries) as FileEntry[];
    const header = fileEntries.find(
      (entry) => typeof entry === "object" && entry !== null && entry.type === "session",
    );
    return new SessionManager(cwdOverride ?? header?.cwd ?? process.cwd(), undefined, fileEntries);
  }
}

export type { ReadonlySessionManager } from "./session-manager-readonly.js";
