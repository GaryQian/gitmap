import {
  asPositiveSafeInteger,
  asSafeIntegerInRange,
  parseStrictFiniteNumber,
} from "@openclaw/normalization-core/number-coercion";
import { normalizeSingleOrTrimmedStringList } from "@openclaw/normalization-core/string-normalization";
import type { TSchema } from "typebox";
import type {
  AgentTool,
  AgentToolProgress,
  AgentToolResult,
  AgentToolUpdateCallback,
} from "../../../packages/agent-core/src/types.js";
import { readSnakeCaseParamRaw } from "../../param-key.js";
import { ToolAuthorizationError, ToolInputError } from "../tool-input-error.js";

export { ToolAuthorizationError, ToolInputError };
export { asNonArrayRecord as asToolParamsRecord } from "@openclaw/normalization-core/record-coerce";
export { jsonResult, textResult } from "./tool-results.js";

export type AgentToolWithMeta<TParameters extends TSchema, TResult> = AgentTool<
  TParameters,
  TResult
> & {
  displaySummary?: string;
  /** Keep this tool model-visible; hidden catalog bridges cannot preserve its result contract. */
  catalogMode?: "direct-only";
  /** Gateway client capabilities required before this tool can be assembled. */
  requiredClientCaps?: string[];
  /**
   * Allow a result's `details.sourceReply` to be delivered to the current source as the
   * user-visible reply, without another model turn. Only the tool author can declare this;
   * tool results alone never grant it.
   */
  canDeliverSourceReply?: boolean;
  /**
   * Tool-owned execution and transport wait budget, before any harness completion grace.
   * Embedded execution publishes this as a liveness allowance without adding a timer.
   * Its optional context supplies the remaining parent budget (the default agent
   * budget for an unlimited parent); other harnesses may resolve their own lifetime.
   */
  getExecutionTimeoutMs?: (
    args: unknown,
    context?: { parentTimeoutMs: number },
  ) => number | undefined;
  prepareBeforeToolCallParams?: (
    params: unknown,
    ctx: { toolCallId?: string; hookContext?: unknown; signal?: AbortSignal },
  ) => unknown;
  finalizeBeforeToolCallParams?: (params: unknown, preparedParams: unknown) => unknown;
};

type ErasedAgentToolExecute<TDetails> = {
  execute(
    this: void,
    toolCallId: string,
    params: unknown,
    signal?: AbortSignal,
    onUpdate?: AgentToolUpdateCallback<TDetails>,
  ): Promise<AgentToolResult<TDetails>>;
};

export type AnyAgentTool<TDetails = unknown> = Omit<
  AgentToolWithMeta<TSchema, TDetails>,
  "execute"
> &
  ErasedAgentToolExecute<TDetails>;

type StringParamOptions = {
  required?: boolean;
  trim?: boolean;
  label?: string;
  allowEmpty?: boolean;
};

export type ActionGate<T extends Record<string, boolean | undefined>> = (
  key: keyof T,
  defaultValue?: boolean,
) => boolean;

export function createActionGate<T extends Record<string, boolean | undefined>>(
  actions: T | undefined,
): ActionGate<T> {
  return (key, defaultValue = true) => {
    const value = actions?.[key];
    if (value === undefined) {
      return defaultValue;
    }
    return value !== false;
  };
}

export function readToolStringParam(
  params: Record<string, unknown>,
  key: string,
  options: StringParamOptions & { required: true },
): string;
export function readToolStringParam(
  params: Record<string, unknown>,
  key: string,
  options?: StringParamOptions,
): string | undefined;
export function readToolStringParam(
  params: Record<string, unknown>,
  key: string,
  options: StringParamOptions = {},
) {
  const { required = false, trim = true, label = key, allowEmpty = false } = options;
  const raw = readSnakeCaseParamRaw(params, key);
  const value = typeof raw === "string" ? (trim ? raw.trim() : raw) : undefined;
  if (value === undefined || (!value && !allowEmpty)) {
    if (required) {
      throw new ToolInputError(`${label} required`);
    }
    return undefined;
  }
  return value;
}

/** "default" resets a model override to its configured fallback. */
export function normalizeToolModelOverride(value: string | undefined): string | undefined {
  if (typeof value !== "string") {
    return undefined;
  }
  const trimmed = value.trim();
  if (!trimmed || trimmed.toLowerCase() === "default") {
    return undefined;
  }
  return trimmed;
}

export function readStringOrNumberParam(
  params: Record<string, unknown>,
  key: string,
  options: { required?: boolean; label?: string } = {},
): string | undefined {
  const { required = false, label = key } = options;
  const raw = readSnakeCaseParamRaw(params, key);
  if (typeof raw === "number" && Number.isFinite(raw)) {
    return String(raw);
  }
  if (typeof raw === "string") {
    const value = raw.trim();
    if (value) {
      return value;
    }
  }
  if (required) {
    throw new ToolInputError(`${label} required`);
  }
  return undefined;
}

export function readNumberParam(
  params: Record<string, unknown>,
  key: string,
  options: {
    required?: boolean;
    label?: string;
    integer?: boolean;
    strict?: boolean;
    positiveInteger?: boolean;
    nonNegativeInteger?: boolean;
  } = {},
): number | undefined {
  const {
    required = false,
    label = key,
    integer = false,
    strict = false,
    positiveInteger = false,
    nonNegativeInteger = false,
  } = options;
  const raw = readSnakeCaseParamRaw(params, key);
  let value: number | undefined;
  if (typeof raw === "number" && Number.isFinite(raw)) {
    value = raw;
  } else if (typeof raw === "string") {
    const trimmed = raw.trim();
    if (trimmed) {
      const parsed = strict ? parseStrictFiniteNumber(trimmed) : Number.parseFloat(trimmed);
      if (parsed !== undefined && Number.isFinite(parsed)) {
        value = parsed;
      }
    }
  }
  if (value === undefined) {
    if (required) {
      throw new ToolInputError(`${label} required`);
    }
    return undefined;
  }
  if (positiveInteger) {
    return asPositiveSafeInteger(value);
  }
  if (nonNegativeInteger) {
    return asSafeIntegerInRange(value, { min: 0 });
  }
  return integer ? Math.trunc(value) : value;
}

// Blank optional numbers are absent; nonblank invalid input keeps the caller's error.
function readStrictNumberParam(
  params: Record<string, unknown>,
  key: string,
  message: string,
  nonNegativeInteger = false,
): number | undefined {
  const value = readNumberParam(params, key, { strict: true, nonNegativeInteger });
  if (value === undefined) {
    const raw = readSnakeCaseParamRaw(params, key);
    if (raw != null && !(typeof raw === "string" && raw.trim() === "")) {
      throw new ToolInputError(message);
    }
  }
  return value;
}

export function readPositiveIntegerParam(
  params: Record<string, unknown>,
  key: string,
  options: {
    message?: string;
    max?: number;
  } = {},
): number | undefined {
  const message = options.message ?? `${key} must be a positive integer`;
  const value = readNonNegativeIntegerParam(params, key, { ...options, message });
  if (value === 0) {
    throw new ToolInputError(message);
  }
  return value;
}

export function readNonNegativeIntegerParam(
  params: Record<string, unknown>,
  key: string,
  options: {
    message?: string;
    max?: number;
  } = {},
): number | undefined {
  const message = options.message ?? `${key} must be a non-negative integer`;
  const value = readStrictNumberParam(params, key, message, true);
  if (value !== undefined && options.max !== undefined && value > options.max) {
    throw new ToolInputError(message);
  }
  return value;
}

export function readFiniteNumberParam(
  params: Record<string, unknown>,
  key: string,
  options: {
    message?: string;
    min?: number;
    max?: number;
    minExclusive?: boolean;
    maxExclusive?: boolean;
  } = {},
): number | undefined {
  const message = options.message ?? `${key} must be a finite number`;
  const value = readStrictNumberParam(params, key, message);
  if (value === undefined) {
    return undefined;
  }
  if (
    (options.min !== undefined &&
      (options.minExclusive ? value <= options.min : value < options.min)) ||
    (options.max !== undefined &&
      (options.maxExclusive ? value >= options.max : value > options.max))
  ) {
    throw new ToolInputError(message);
  }
  return value;
}

export function readStringArrayParam(
  params: Record<string, unknown>,
  key: string,
  options: StringParamOptions & { required: true },
): string[];
export function readStringArrayParam(
  params: Record<string, unknown>,
  key: string,
  options?: StringParamOptions,
): string[] | undefined;
export function readStringArrayParam(
  params: Record<string, unknown>,
  key: string,
  options: StringParamOptions = {},
) {
  const { required = false, label = key, allowEmpty = false } = options;
  const values = normalizeSingleOrTrimmedStringList(readSnakeCaseParamRaw(params, key));
  if (values.length > 0) {
    return values;
  }
  // Callers that replace a collection (for example Discord applied tags) need an
  // explicit empty array to survive instead of collapsing to undefined.
  if (allowEmpty && Array.isArray(readSnakeCaseParamRaw(params, key))) {
    return [];
  }
  if (required) {
    throw new ToolInputError(`${label} required`);
  }
  return undefined;
}

type ReactionParams = {
  emoji: string;
  remove: boolean;
  isEmpty: boolean;
};

export function readReactionParams(
  params: Record<string, unknown>,
  options: {
    emojiKey?: string;
    removeKey?: string;
    removeErrorMessage: string;
  },
): ReactionParams {
  const emojiKey = options.emojiKey ?? "emoji";
  const removeKey = options.removeKey ?? "remove";
  const remove = typeof params[removeKey] === "boolean" ? params[removeKey] : false;
  const emoji = readToolStringParam(params, emojiKey, {
    required: true,
    allowEmpty: true,
  });
  if (remove && !emoji) {
    throw new ToolInputError(options.removeErrorMessage);
  }
  return { emoji, remove, isEmpty: !emoji };
}

type PublicToolProgress = Pick<AgentToolProgress, "text" | "id">;

// Long-running tools can arm delayed progress and cancel it on completion or
// abort. This avoids stale "still working" lines after a fast or canceled call.
export function scheduleToolProgress(
  onUpdate: AgentToolUpdateCallback | undefined,
  progress: PublicToolProgress,
  delayMs: number,
  options: { signal?: AbortSignal } = {},
): () => void {
  if (!onUpdate || options.signal?.aborted) {
    return () => {};
  }
  const clear = () => {
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", clear);
  };
  const timer: ReturnType<typeof setTimeout> = setTimeout(() => {
    clear();
    const text = progress.text.trim();
    if (!text) {
      return;
    }
    try {
      onUpdate({
        content: [],
        details: undefined,
        progress: {
          text,
          visibility: "channel",
          privacy: "public",
          ...(progress.id ? { id: progress.id } : {}),
        },
      });
    } catch {
      // Progress is best-effort UI state; tool execution must not depend on subscribers.
    }
  }, delayMs);
  options.signal?.addEventListener("abort", clear, { once: true });
  return clear;
}

type AvailableTag = {
  id?: string;
  name: string;
  moderated?: boolean;
  emoji_id?: string | null;
  emoji_name?: string | null;
};

export function parseAvailableTags(raw: unknown): AvailableTag[] | undefined {
  if (!Array.isArray(raw)) {
    return undefined;
  }
  const result = raw
    .filter(
      (t): t is Record<string, unknown> =>
        typeof t === "object" && t !== null && typeof t.name === "string",
    )
    .map((t) =>
      Object.assign(
        {},
        typeof t.id === "string" ? { id: t.id } : {},
        { name: t.name as string },
        typeof t.moderated === `boolean` ? { moderated: t.moderated } : {},
        t.emoji_id === null || typeof t.emoji_id === `string` ? { emoji_id: t.emoji_id } : {},
        t.emoji_name === null || typeof t.emoji_name === `string`
          ? { emoji_name: t.emoji_name }
          : {},
      ),
    );
  // Return undefined instead of empty array to avoid accidentally clearing all tags
  return result.length ? result : undefined;
}
