import type { Result } from "@openclaw/normalization-core/result";
import type {
  SessionEntryCurrentCheck,
  SessionEntriesCurrentCheck,
} from "../config/sessions/session-entry-current.types.js";
import type { PluginStateStoreError } from "./plugin-state-error.js";

export {
  PluginStateStoreError,
  type PluginStateStoreErrorCode,
  type PluginStateStoreOperation,
} from "./plugin-state-error.js";

// Public plugin-state store contracts. Stores are keyed by plugin id and
// namespace, persist JSON-compatible values, and enforce per-namespace limits.
export type PluginStateEntry<T> = {
  key: string;
  value: T;
  createdAt: number;
  expiresAt?: number;
};

/** An opaque comparison of one store/key's live value and storage metadata, not ownership. */
export type PluginStateObservation<T> = {
  value: T | undefined;
  comparison: string;
};

export type PluginStateCompareIntent<T> =
  | { operation: "update"; action: "set"; value: T; ttlMs?: number }
  | { operation: "update" | "delete"; action: "keep" }
  | { operation: "delete"; action: "delete" };

export type PluginStateCompareResult<T> =
  | { status: "applied" | "unchanged" }
  | { status: "conflict"; current: PluginStateObservation<T> };

/** Additional same-plugin rows checked atomically with a conditional mutation. */
export type PluginStateComparisonCondition = {
  namespace: string;
  key: string;
  comparison: string;
};

export type PluginStateActionAuthority = {
  assertCurrent: () => void;
  sessionEntryCurrent?: SessionEntryCurrentCheck | SessionEntriesCurrentCheck;
};

export type PluginStateOperationDefinitions = Record<string, { input: unknown; output: unknown }>;

export type PluginStateOperationCommand<Operations extends PluginStateOperationDefinitions> = {
  [Type in keyof Operations & string]: { type: Type; input: Operations[Type]["input"] };
}[keyof Operations & string];

/** The worker owns this synchronous view for one invocation and invalidates it on return. */
export type PluginStateOperationTransaction = {
  lookup(store: number, key: string): unknown;
  lookupMany<T = unknown>(keys: readonly { store: number; key: string }[]): Array<T | undefined>;
  entries<T = unknown>(store: number): PluginStateEntry<T>[];
  set(store: number, key: string, value: unknown, options?: { ttlMs?: number }): void;
  delete(store: number, key: string): boolean;
};

export type PluginStateOperationHandler<Operations extends PluginStateOperationDefinitions> = (
  command: PluginStateOperationCommand<Operations>,
  transaction: PluginStateOperationTransaction,
) => Operations[keyof Operations]["output"];

export type PluginStateOperationReceipt<T> = {
  value: T;
  /** Refuses after watched state, the captured source, or live authority changes. */
  assertCurrent: () => void;
};

export type PluginStateOperation<Operations extends PluginStateOperationDefinitions> = {
  execute<Type extends keyof Operations & string>(
    command: { type: Type; input: Operations[Type]["input"] },
    options: {
      writeStores: readonly number[];
      watchStores?: readonly number[];
      /** Explicit noncreating result when a read-only source does not exist. */
      missingValue?: Operations[Type]["output"];
      /** Read-only shortcut: return this value when an autocommit namespace read is empty. */
      ifEmpty?: { store: number; value: Operations[Type]["output"] };
    },
  ): Promise<PluginStateOperationReceipt<Operations[Type]["output"]>>;
};

export type PluginStateKeyRange = {
  keyStartInclusive: string;
  keyEndExclusive: string;
  limit: number;
  order?: "asc" | "desc";
};

export type PluginStateKeyRangeParams = {
  pluginId: string;
  namespace: string;
  valueFilter?: { path: string; equals: string };
} & PluginStateKeyRange;

export type PluginStateMoveEntries = {
  /** Bounded logical source namespace belonging to the same plugin. */
  namespace: string;
  entries: Array<{ sourceKey: string; targetKey: string }>;
};

type PluginStateKeyedStoreBase<T> = {
  /** Loads a plugin-owned static handler into the existing state worker. */
  createOperation?: <Operations extends PluginStateOperationDefinitions>(
    stores: readonly Pick<PluginStateKeyedStore<unknown>, "lookup" | "entries">[],
    handler: { moduleName: string; exportName: string },
    authority?: { assertCurrent(): void; sourceReceipt?: PluginStateOperationReceipt<unknown> },
  ) => PluginStateOperation<Operations>;
  /** Uses the admitted resident view when available; writable fallback may create state. */
  observe?: (key: string) => Promise<PluginStateObservation<T>>;
  /**
   * Compares the observed row and optional same-plugin conditions atomically before applying data.
   * On conflict, reread all preparation inputs; only explicit conflicts may retry.
   */
  compareAndApply?: (
    key: string,
    comparison: string,
    intent: PluginStateCompareIntent<T>,
    options?: { conditions: readonly PluginStateComparisonCondition[] },
  ) => Promise<PluginStateCompareResult<T>>;
  register(
    key: string,
    value: T,
    opts?: { ttlMs?: number; assertCurrent?: () => void },
  ): Promise<void>;
  registerIfAbsent(key: string, value: T, opts?: { ttlMs?: number }): Promise<boolean>;
  /**
   * The updater runs synchronously in the transaction; undefined leaves the entry unchanged.
   * @deprecated Use observe and compareAndApply to prepare data outside the worker transaction.
   * This synchronous callback will be removed in the first January 2027 stable release, after the final compatibility day 2026-12-31.
   */
  update?: (
    key: string,
    updateValue: (current: T | undefined) => T | undefined,
    opts?: { ttlMs?: number },
  ) => Promise<boolean>;
  /**
   * The synchronous predicate and conditional deletion run in one transaction.
   * @deprecated Use observe and compareAndApply, or deleteIfEqual for JSON scalars.
   * This synchronous callback will be removed in the first January 2027 stable release, after the final compatibility day 2026-12-31.
   */
  deleteIf?: (key: string, predicate: (current: T) => boolean) => Promise<boolean>;
  /** Atomically deletes a live entry equal to the supplied JSON scalar, without a callback. */
  deleteIfEqual?: (key: string, expected: string | number | boolean | null) => Promise<boolean>;
  lookup(key: string): Promise<T | undefined>;
  /** Positional outcomes for at most 10,000 keys; missing/expired values are undefined. */
  lookupMany?: (
    keys: readonly string[],
  ) => Promise<Array<Result<T | undefined, PluginStateStoreError>>>;
  consume(key: string): Promise<T | undefined>;
  delete(
    key: string,
    opts?: { assertCurrent?: () => void; signal?: AbortSignal },
  ): Promise<boolean>;
  entries(): Promise<PluginStateEntry<T>[]>;
  /** Reads a lexical key range with ordering and limit applied by storage. */
  entriesInKeyRange?: (range: PluginStateKeyRange) => Promise<PluginStateEntry<T>[]>;
  /**
   * Atomically settles at most 10,000 bounded source rows into this retained store.
   * Existing targets win; live expiring sources reject the entire operation.
   */
  moveEntriesFrom?: (source: PluginStateMoveEntries) => Promise<number>;
  /** Counts live stored rows without decoding values; absent on older hosts and adapters. */
  count?: () => Promise<number>;
  clear(): Promise<void>;
};

/** Version 2 is an action-bound, data-only view; legacy stores remain source-compatible. */
export type PluginStateKeyedStore<T, Version extends 1 | 2 = 1> = Version extends 2
  ? Required<Omit<PluginStateKeyedStoreBase<T>, "update" | "deleteIf" | "createOperation">> &
      Pick<PluginStateKeyedStoreBase<T>, "createOperation">
  : PluginStateKeyedStoreBase<T> & {
      /** Bind current action authority through read completion and final write admission. */
      withCurrent?: (authority: PluginStateActionAuthority) => PluginStateKeyedStore<T, 2>;
    };

/**
 * Synchronous plugin-state compatibility contract.
 * @deprecated Use PluginStateKeyedStore<T, 2> from api.runtime.state.openKeyedStoreV2
 * and await its operations. This synchronous API will be removed in the first January 2027 stable release, after the final compatibility day 2026-12-31.
 */
export type PluginStateSyncKeyedStore<T> = {
  /** @deprecated Await PluginStateKeyedStore.register; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  register(key: string, value: T, opts?: { ttlMs?: number }): void;
  /** @deprecated Await PluginStateKeyedStore.registerIfAbsent; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  registerIfAbsent(key: string, value: T, opts?: { ttlMs?: number }): boolean;
  /**
   * Expiry options are consumed after the synchronous updater returns.
   * @deprecated Use observe and compareAndApply; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31.
   */
  update?: (
    key: string,
    updateValue: (current: T | undefined) => T | undefined,
    opts?: { ttlMs?: number },
  ) => boolean;
  /** @deprecated Use observe and compareAndApply; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  deleteIf?: (key: string, predicate: (current: T) => boolean) => boolean;
  /** @deprecated Await PluginStateKeyedStore.lookup; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  lookup(key: string): T | undefined;
  /**
   * Positional outcomes for at most 10,000 keys; missing/expired values are undefined.
   * @deprecated Await PluginStateKeyedStore.lookupMany; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31.
   */
  lookupMany?: (keys: readonly string[]) => Array<Result<T | undefined, PluginStateStoreError>>;
  /** @deprecated Await PluginStateKeyedStore.consume; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  consume(key: string): T | undefined;
  /** @deprecated Await PluginStateKeyedStore.delete; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  delete(key: string): boolean;
  /** @deprecated Await PluginStateKeyedStore.entries; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  entries(): PluginStateEntry<T>[];
  /**
   * Counts live stored rows without decoding values; absent on older hosts and adapters.
   * @deprecated Await PluginStateKeyedStore.count; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31.
   */
  count?: () => number;
  /** @deprecated Await PluginStateKeyedStore.clear; removed in the first January 2027 stable release, after the final compatibility day 2026-12-31. */
  clear(): void;
};

/** Options for opening a keyed plugin-state namespace. */
export type PluginStateOverflowPolicy = "evict-oldest" | "reject-new";

/** Published bounded-store options; also used by sync stores, imports, and journals. */
export type OpenKeyedStoreOptions = {
  namespace: string;
  maxEntries: number;
  retention?: "bounded";
  overflowPolicy?: PluginStateOverflowPolicy;
  defaultTtlMs?: number;
  env?: NodeJS.ProcessEnv;
};

/** Retained stores are available only through asynchronous keyed-store openers. */
export type OpenRetainedKeyedStoreOptions = {
  namespace: string;
  retention: "retained";
  maxEntries?: never;
  overflowPolicy?: never;
  defaultTtlMs?: never;
  env?: NodeJS.ProcessEnv;
};

export type OpenAsyncKeyedStoreOptions = OpenKeyedStoreOptions | OpenRetainedKeyedStoreOptions;
