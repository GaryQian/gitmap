import { pruneMapToMaxSize } from "../infra/map-size.js";
import { groupPluginRecords as groupRecords } from "../plugins/record-groups.js";
import { resolveGlobalSingleton } from "../shared/global-singleton.js";
import { escapeRegExp } from "../shared/regexp.js";

const MIN_SECRET_VALUE_LENGTH = 6;
const MAX_SECRET_VALUES = 512;

type SecretValueRedactor = (text: string, mask: (value: string, index: number) => string) => string;
// Native and source module copies share membership and matcher invalidation.
const state = resolveGlobalSingleton<{
  revision: number;
  registeredValues: Map<string, true>;
  registeredValueRedactor: SecretValueRedactor | undefined;
}>(Symbol.for("openclaw.secretRedactionRegistry"), () => ({
  revision: 0,
  registeredValues: new Map<string, true>(),
  registeredValueRedactor: undefined,
}));

type SecretRedactionRegistrySnapshot = { values: readonly string[] };
function invalidateMatcher(): void {
  state.revision += 1;
  state.registeredValueRedactor = undefined;
}

/** Invalidates prepared redacted facts when exact secret membership changes. */
export function getSecretRedactionRegistryRevision(): number {
  return state.revision;
}

function registerOneSecretValue(value: string): void {
  if (state.registeredValues.delete(value)) {
    state.registeredValues.set(value, true);
    return;
  }
  state.registeredValues.set(value, true);
  pruneMapToMaxSize(state.registeredValues, MAX_SECRET_VALUES);
  invalidateMatcher();
}

/** Registers one resolved secret for exact-value log redaction. */
export function registerSecretValueForRedaction(value: string): void {
  if (value.length < MIN_SECRET_VALUE_LENGTH) {
    return;
  }
  // URL egress percent-encodes injected values; redact that surface form too.
  const encoded = encodeURIComponent(value);
  if (encoded !== value) {
    registerOneSecretValue(encoded);
  }
  // Structured logs serialize credentials, so retain the JSON string-content form
  // for values with escaped characters.
  const jsonEscaped = JSON.stringify(value).slice(1, -1);
  if (jsonEscaped !== value) {
    registerOneSecretValue(jsonEscaped);
  }
  // Keep the raw value newest so bounded-registry eviction cannot drop the
  // active credential while retaining only a transformed representation.
  registerOneSecretValue(value);
}

/** Returns whether a value has SecretRef provenance in the process registry. */
export function isSecretValueRegisteredForRedaction(value: string): boolean {
  return state.registeredValues.has(value);
}

export function hasRegisteredSecretValuesForRedaction(): boolean {
  return state.registeredValues.size > 0;
}

/** Exact surface forms are already expanded; snapshots must not register them again. */
export function captureSecretRedactionRegistrySnapshot(): SecretRedactionRegistrySnapshot {
  return { values: [...state.registeredValues.keys()] };
}

/** Install the request's already-expanded membership in an isolated redaction worker. */
export function installSecretRedactionRegistrySnapshot(
  snapshot: SecretRedactionRegistrySnapshot,
): void {
  state.registeredValues = new Map(snapshot.values.map((value) => [value, true]));
  invalidateMatcher();
}

/** Replaces registered exact values while preserving the caller's mask convention. */
export function redactRegisteredSecretValues(
  text: string,
  mask: (value: string, index: number) => string,
): string {
  if (!text || state.registeredValues.size === 0) {
    return text;
  }
  state.registeredValueRedactor ??= createSecretValueRedactor([...state.registeredValues.keys()]);
  return state.registeredValueRedactor(text, mask);
}

function createSecretValueRedactor(values: readonly string[]): SecretValueRedactor {
  let compiledMatcher: { prefixes: RegExp; buckets: Map<string, string[]> } | undefined;
  let firstChars: Set<string> | undefined;
  return (text, mask) => {
    if (!text || values.length === 0) {
      return text;
    }
    let couldMatch = false;
    // Registration can add several surface forms; prepare their probe once on first use.
    firstChars ??= new Set(values.map((value) => value.charAt(0)));
    for (const firstChar of firstChars) {
      if (text.includes(firstChar)) {
        couldMatch = true;
        break;
      }
    }
    if (!couldMatch) {
      return text;
    }
    if (!compiledMatcher) {
      const buckets = groupRecords(
        values.toSorted((left, right) => right.length - left.length),
        (value) => value.slice(0, MIN_SECRET_VALUE_LENGTH),
      );
      // Supported store values can exceed the regex engine's literal span limit.
      // Compile fixed-width prefixes; verify complete values against the text.
      compiledMatcher = {
        prefixes: new RegExp([...buckets.keys()].map(escapeRegExp).join("|"), "g"),
        buckets,
      };
    }
    const { prefixes, buckets } = compiledMatcher;
    const matches: { index: number; value: string }[] = [];
    prefixes.lastIndex = 0;
    for (let match = prefixes.exec(text); match; match = prefixes.exec(text)) {
      const index = match.index;
      const value = buckets.get(match[0])?.find((candidate) => text.startsWith(candidate, index));
      if (value !== undefined) {
        matches.push({ index, value });
      }
      // A rejected prefix may overlap a real match beginning one code unit later.
      prefixes.lastIndex = index + (value?.length ?? 1);
    }
    // Global replacement fixes its matches before callbacks. Nested registration
    // must affect the next/nested call, never the remainder of this one.
    let result = "";
    let cursor = 0;
    for (const match of matches) {
      result += `${text.slice(cursor, match.index)}${mask(match.value, match.index)}`;
      cursor = match.index + match.value.length;
    }
    return result + text.slice(cursor);
  };
}

function resetSecretRedactionRegistryForTest(): void {
  state.registeredValues.clear();
  invalidateMatcher();
}

if (process.env.VITEST || process.env.NODE_ENV === "test") {
  (globalThis as Record<PropertyKey, unknown>)[
    Symbol.for("openclaw.secretRedactionRegistryTestApi")
  ] = { resetSecretRedactionRegistryForTest };
}
