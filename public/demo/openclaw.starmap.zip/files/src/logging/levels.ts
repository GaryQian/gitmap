export const ALLOWED_LOG_LEVELS = [
  "silent",
  "fatal",
  "error",
  "warn",
  "info",
  "debug",
  "trace",
] as const;

export type LogLevel = (typeof ALLOWED_LOG_LEVELS)[number];

// tslog logLevelId: silly=0, trace=1, debug=2, info=3, warn=4, error=5, fatal=6
// tslog filters: logLevelId < minLevel is dropped, so higher minLevel = more restrictive.
const MIN_LEVEL_BY_LOG_LEVEL: Record<LogLevel, number> = {
  trace: 1,
  debug: 2,
  info: 3,
  warn: 4,
  error: 5,
  fatal: 6,
  silent: Number.POSITIVE_INFINITY,
};

export function tryParseLogLevel(level?: string): LogLevel | undefined {
  if (typeof level !== "string") {
    return undefined;
  }
  const candidate = level.trim();
  return ALLOWED_LOG_LEVELS.includes(candidate as LogLevel) ? (candidate as LogLevel) : undefined;
}

export function normalizeLogLevel(level?: string, fallback: LogLevel = "info") {
  return tryParseLogLevel(level) ?? fallback;
}

export function levelToMinLevel(level: LogLevel): number {
  return MIN_LEVEL_BY_LOG_LEVEL[level];
}

export function isLogLevelEnabled(level: LogLevel, minimum: LogLevel): boolean {
  return (
    level !== "silent" && minimum !== "silent" && levelToMinLevel(level) >= levelToMinLevel(minimum)
  );
}
