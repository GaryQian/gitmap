import fs from "node:fs/promises";
import { getFsSafeNativeConfig } from "@openclaw/fs-safe/config";
import { captureWorkspaceFilesystemEvidence } from "../../agents/workspace-state-guard.js";
import type { WorktreeWorkerAuthority } from "../../agents/worktrees/types.js";
import {
  prepareSessionSourceEffect,
  composeSessionSourceAssertion,
  type SessionSourceAssertion,
} from "../../config/sessions/session-source-authority.js";
import { hasGitWorkerContext } from "../../infra/git-worker-context.js";
import type { GitWorkerCommand } from "../../infra/git-worker-contract.js";
import { runGitWorkerOperation, type GitWorkerOperationOptions } from "../../infra/git-worker.js";
import { createWorkerMutationAuthority } from "../../infra/worker-mutation-authority.js";
import type { readActualWorkspaceManifestImpl } from "./workspace-actual-manifest.js";
import { activeWorkspaceHashContext, pruneWorkspaceHashMemo } from "./workspace-hash-memo.js";
import type {
  WorkspaceComputationHashes,
  WorkspaceComputationHashResult,
  WorkspaceManifestComputationCommand,
  WorkspaceManifestComputationOperations,
  WorkspaceManifestValueInputs,
  WorkspaceStageInput,
  WorkspaceReconciliationCommand,
} from "./workspace-manifest-computation.js";
import type { WorkerWorkspaceManifest } from "./workspace-manifest.js";
import { joinStagedWorkspaceManifestRead } from "./workspace-result-git.js";

type WorkspaceCaptureArguments = Parameters<typeof readActualWorkspaceManifestImpl>[0];

function computationInputBytes(input: unknown): number {
  if (typeof input === "string") {
    return input.length * 2;
  }
  if (ArrayBuffer.isView(input)) {
    return input.byteLength;
  }
  if (input instanceof Set) {
    let bytes = 64;
    for (const value of input) {
      bytes += computationInputBytes(value);
    }
    return bytes;
  }
  if (input && typeof input === "object") {
    return Object.entries(input).reduce(
      (bytes, [key, value]) => bytes + key.length * 2 + computationInputBytes(value),
      64,
    );
  }
  return 8;
}

function transferableManifestInput(command: GitWorkerCommand): ArrayBuffer[] {
  if ("payload" in command.input) {
    return [command.input.payload.buffer];
  }
  switch (command.type) {
    case "workspace.manifest.paths":
    case "workspace.manifest.parse":
      return [command.input.raw.buffer];
    case "workspace.manifest.base-refresh":
      return [command.input.baseRaw.buffer];
    case "workspace.manifest.equal":
    case "workspace.manifest.pair":
      return [command.input.baseRaw.buffer, command.input.currentRaw.buffer];
    case "workspace.manifest.stage-input":
      return "publication" in command.input
        ? [command.input.publication.metadata.buffer]
        : [command.input.baseManifestRaw.buffer, command.input.currentManifestRaw.buffer];
    default:
      return [];
  }
}

export async function computeWorkspaceManifest<Command extends WorkspaceManifestComputationCommand>(
  command: Command,
  signal?: AbortSignal,
  git?: GitWorkerOperationOptions["git"],
  idleIoPriority?: boolean,
): Promise<WorkspaceManifestComputationOperations[Command["type"]]["output"]> {
  if (hasGitWorkerContext()) {
    const { executeWorkspaceManifestComputation } =
      await import("./workspace-manifest-computation.runtime.js");
    return await executeWorkspaceManifestComputation(command);
  }
  return await runGitWorkerOperation(command, {
    signal,
    git,
    idleIoPriority,
    inputBytes: 256 + computationInputBytes(command.input),
    transferList: transferableManifestInput,
  });
}

function computeValue<Type extends keyof WorkspaceManifestValueInputs>(
  type: Type,
  input: WorkspaceManifestValueInputs[Type],
  signal?: AbortSignal,
  idleIoPriority?: boolean,
): Promise<WorkspaceManifestComputationOperations[Type]["output"]>;
async function computeValue(
  type: keyof WorkspaceManifestValueInputs,
  input: WorkspaceManifestValueInputs[keyof WorkspaceManifestValueInputs],
  signal?: AbortSignal,
  idleIoPriority?: boolean,
) {
  signal?.throwIfAborted();
  return computeWorkspaceManifest(
    { type, input: { payload: new TextEncoder().encode(JSON.stringify(input)) } },
    signal,
    undefined,
    idleIoPriority,
  );
}

function captureHashes(includeMemo = true) {
  const context = activeWorkspaceHashContext();
  if (context && includeMemo) {
    pruneWorkspaceHashMemo(context.memo);
  }
  const hashes: WorkspaceComputationHashes | undefined = context
    ? { owner: context.owner, entries: includeMemo ? [...context.memo] : [] }
    : undefined;
  return {
    hashes,
    accept<Result extends WorkspaceComputationHashResult<unknown>>(
      result: Result,
    ): Result["value"] {
      if (context) {
        for (const [identity, digest] of result.hashes) {
          context.memo.set(identity, digest);
        }
        pruneWorkspaceHashMemo(context.memo);
        if (context.metrics) {
          context.metrics.contentHashCount += result.metrics.contentHashCount;
          context.metrics.memoHitCount += result.metrics.memoHitCount;
        }
      }
      return result.value;
    },
  };
}

type WorkspaceCaptureCommand =
  | "workspace.manifest.capture"
  | "workspace.manifest.snapshot"
  | "workspace.manifest.document"
  | "workspace.manifest.initial"
  | "workspace.manifest.reference";

function captureWorkspace<Type extends WorkspaceCaptureCommand>(
  type: Type,
  params: WorkspaceCaptureArguments,
): Promise<WorkspaceManifestComputationOperations[Type]["output"]["value"]>;
async function captureWorkspace(type: WorkspaceCaptureCommand, params: WorkspaceCaptureArguments) {
  const {
    root,
    baseCommit,
    preserveDirectories,
    includePaths,
    buildCacheInputs,
    gitIgnore,
    signal,
  } = params;
  if (hasGitWorkerContext() && type !== "workspace.manifest.initial") {
    const { readActualWorkspaceManifestImpl } = await import("./workspace-actual-manifest.js");
    const snapshot = await readActualWorkspaceManifestImpl(params);
    if (type === "workspace.manifest.document") {
      const { manifestRef, rawManifest } = snapshot;
      return { manifestRef, rawManifest };
    }
    return type === "workspace.manifest.reference"
      ? snapshot.manifestRef
      : type === "workspace.manifest.snapshot"
        ? snapshot
        : { manifest: snapshot.manifest, manifestRef: snapshot.manifestRef };
  }
  signal?.throwIfAborted();
  const hashes = captureHashes();
  return hashes.accept(
    await computeValue(
      type,
      {
        root,
        baseCommit,
        includePaths: includePaths === undefined ? undefined : [...includePaths],
        gitIgnore: gitIgnore && {
          paths: [...gitIgnore.paths],
          retainedPaths: [...gitIgnore.retainedPaths],
        },
        buildCacheInputs: buildCacheInputs === undefined ? undefined : [...buildCacheInputs],
        preserveDirectories:
          preserveDirectories === undefined ? undefined : [...preserveDirectories],
        hashes: hashes.hashes,
      },
      signal,
    ),
  );
}

export async function captureWorkspaceManifest(params: WorkspaceCaptureArguments) {
  return await captureWorkspace("workspace.manifest.capture", params);
}

export async function captureWorkspaceSnapshot(params: WorkspaceCaptureArguments) {
  return await captureWorkspace("workspace.manifest.snapshot", params);
}

/** Keep complete source inventories in the worker; only the staged document returns. */
export async function prepareWorkspaceBaseRefresh(
  input: Omit<
    WorkspaceManifestComputationOperations["workspace.manifest.base-refresh"]["input"],
    "baseRaw" | "hashes"
  > & { baseRaw: string },
  signal?: AbortSignal,
) {
  signal?.throwIfAborted();
  const hashes = captureHashes();
  return hashes.accept(
    await computeWorkspaceManifest(
      {
        type: "workspace.manifest.base-refresh",
        input: {
          ...input,
          baseRaw: new TextEncoder().encode(input.baseRaw),
          hashes: hashes.hashes,
        },
      },
      signal,
    ),
  );
}

export async function workspaceSnapshotsEqual(
  left: { rawManifest: string; manifestRef: string },
  right: { rawManifest: string; manifestRef: string },
  buildCacheInputs?: string[],
  signal?: AbortSignal,
) {
  signal?.throwIfAborted();
  const encoder = new TextEncoder();
  return await computeWorkspaceManifest(
    {
      type: "workspace.manifest.equal",
      input: {
        baseRaw: encoder.encode(left.rawManifest),
        baseRef: left.manifestRef,
        currentRaw: encoder.encode(right.rawManifest),
        currentRef: right.manifestRef,
        buildCacheInputs,
      },
    },
    signal,
  );
}

export async function captureWorkspaceManifestDocument(params: WorkspaceCaptureArguments) {
  return await captureWorkspace("workspace.manifest.document", params);
}

/** Initialization publishes these same scan identities with its baseline, before guest access. */
export async function captureInitialLocalWorkspaceManifest(params: WorkspaceCaptureArguments) {
  const result = await captureWorkspace("workspace.manifest.initial", params);
  return {
    ...result,
    projectionFingerprints:
      result.projectionFingerprints && Buffer.from(result.projectionFingerprints),
  };
}

/** Only the template owner supplies a previous generation after validating immutable source. */
export async function captureTemplateWorkspaceManifest(
  input: WorkspaceManifestValueInputs["workspace.manifest.template"],
  signal?: AbortSignal,
  idleIoPriority?: boolean,
) {
  return await computeValue("workspace.manifest.template", input, signal, idleIoPriority);
}

export async function captureWorkspaceManifestReference(params: WorkspaceCaptureArguments) {
  return await captureWorkspace("workspace.manifest.reference", params);
}

export async function preflightWorkspaceApply(
  params: Omit<WorkspaceManifestValueInputs["workspace.reconcile.preflight"], "hashes"> & {
    signal?: AbortSignal;
  },
) {
  const { signal, ...input } = params;
  if (hasGitWorkerContext()) {
    const { preflightWorkspaceApplyImpl } = await import("./workspace-reconcile-preflight.js");
    return await preflightWorkspaceApplyImpl(input);
  }
  signal?.throwIfAborted();
  const hashes = captureHashes();
  return hashes.accept(
    await computeValue(
      "workspace.reconcile.preflight",
      { ...input, hashes: hashes.hashes },
      signal,
    ),
  );
}

export async function computeWorkspaceFileSnapshot(path: string, maxBytes: number, root?: string) {
  if (hasGitWorkerContext()) {
    const { readWorkspaceFileSnapshotWithLimit } = await import("./workspace-actual-manifest.js");
    return await readWorkspaceFileSnapshotWithLimit(path, maxBytes, root);
  }
  // Bulk capture/preflight carries the memo once. A single verification must not
  // clone a placement's complete cache for every file it observes.
  const hashes = captureHashes(false);
  return hashes.accept(
    await computeValue("workspace.manifest.file", { path, maxBytes, root, hashes: hashes.hashes }),
  );
}

export async function readWorkspaceNodes(root: string, paths: string[]) {
  const hashes = captureHashes();
  return new Map(
    hashes.accept(
      await computeValue("workspace.manifest.nodes", { root, paths, hashes: hashes.hashes }),
    ),
  );
}

export async function decodeWorkspaceManifest(
  raw: string,
  expectedRef?: string,
  signal?: AbortSignal,
) {
  signal?.throwIfAborted();
  const bytes = new TextEncoder().encode(raw);
  return await computeWorkspaceManifest(
    { type: "workspace.manifest.parse", input: { raw: bytes, expectedRef } },
    signal,
  );
}

export async function workspaceManifestPaths(
  document: { rawManifest: string; manifestRef: string },
  buildCacheInputs: string[],
  signal?: AbortSignal,
) {
  signal?.throwIfAborted();
  return await computeWorkspaceManifest(
    {
      type: "workspace.manifest.paths",
      input: {
        raw: new TextEncoder().encode(document.rawManifest),
        expectedRef: document.manifestRef,
        buildCacheInputs,
      },
    },
    signal,
  );
}

export async function serializeWorkspaceManifest(
  manifest: WorkerWorkspaceManifest,
  signal?: AbortSignal,
) {
  return await computeValue("workspace.manifest.serialize", { manifest }, signal);
}

export async function overlayWorkspaceManifest(
  source: WorkerWorkspaceManifest,
  prepared: WorkerWorkspaceManifest,
  incoming: WorkerWorkspaceManifest,
  signal?: AbortSignal,
) {
  return await computeValue("workspace.manifest.overlay", { source, prepared, incoming }, signal);
}

export async function parseWorkspaceManifestPair(input: {
  buildCacheInputs?: string[];
  baseRaw: string;
  baseRef: string;
  currentRaw: string;
  currentRef: string;
}) {
  const encoder = new TextEncoder();
  return await computeWorkspaceManifest({
    type: "workspace.manifest.pair",
    input: {
      baseRef: input.baseRef,
      currentRef: input.currentRef,
      buildCacheInputs: input.buildCacheInputs,
      baseRaw: encoder.encode(input.baseRaw),
      currentRaw: encoder.encode(input.currentRaw),
    },
  });
}

export async function loadStagedWorkspaceManifest(
  root: string,
  ref: string,
  signal?: AbortSignal,
  buildCacheInputs?: string[],
) {
  const input = { root, ref, buildCacheInputs };
  const read = () => computeWorkspaceManifest({ type: "workspace.manifest.staged", input }, signal);
  // A worker's host exchange context owns its policy and authority independently.
  return hasGitWorkerContext()
    ? await read()
    : await joinStagedWorkspaceManifestRead(input, signal, read);
}

export async function prepareWorkspaceStageInput(
  input: WorkspaceStageInput<string>,
  authority?: WorkspaceFilesystemAuthority,
) {
  const encoder = new TextEncoder();
  return await runWorkspaceFilesystemComputation(
    {
      type: "workspace.manifest.stage-input",
      input: {
        inputPath: input.inputPath,
        stagingRoot: input.stagingRoot,
        stagedResultRef: input.stagedResultRef,
        buildCacheInputs: input.buildCacheInputs,
        gitHistory: input.gitHistory,
        parentCommit: input.parentCommit,
        blobsOnly: input.blobsOnly,
        ...("publication" in input
          ? {
              publication: {
                ...input.publication,
                metadata: encoder.encode(input.publication.metadata),
              },
            }
          : {
              baseManifestRef: input.baseManifestRef,
              currentManifestRef: input.currentManifestRef,
              baseManifestRaw: encoder.encode(input.baseManifestRaw),
              currentManifestRaw: encoder.encode(input.currentManifestRaw),
              existingObjects: input.existingObjects,
            }),
      },
    },
    authority,
  );
}

export async function prepareWorkspaceTreeInput(
  input: WorkspaceManifestValueInputs["workspace.manifest.tree-input"],
): Promise<null> {
  if (hasGitWorkerContext()) {
    const { buildWorkspaceTreeInput } = await import("./workspace-result-preparation.runtime.js");
    return buildWorkspaceTreeInput(input);
  }
  return computeValue("workspace.manifest.tree-input", input);
}

/** Patch construction and its output observers belong to the existing Git worker. */
export async function prepareWorkspacePatch(
  input: WorkspaceManifestValueInputs["workspace.reconcile.patch"],
) {
  return computeValue("workspace.reconcile.patch", input);
}

type WorkspaceFilesystemAuthority = {
  assertCurrent?: SessionSourceAssertion;
  workerAuthority?: WorktreeWorkerAuthority;
};
type WorkspaceFilesystemCommand =
  | WorkspaceReconciliationCommand
  | Extract<WorkspaceManifestComputationCommand, { type: "workspace.manifest.stage-input" }>;

export async function prepareWorkspaceTemporaryDirectory(
  prefix: string,
  authority?: WorkspaceFilesystemAuthority,
): Promise<string> {
  const preparedPrefix = await runWorkspaceFilesystemComputation(
    { type: "workspace.reconcile.temporary", input: { prefix } },
    authority,
  );
  // Creation returns directly to the caller that owns its cleanup, without another authority gate.
  return await fs.mkdtemp(preparedPrefix);
}

/** Keep physical observations in the existing worker and logical custody on its host. */
export function runWorkspaceFilesystemComputation<Command extends WorkspaceFilesystemCommand>(
  command: Command,
  options?: WorkspaceFilesystemAuthority,
): Promise<WorkspaceManifestComputationOperations[Command["type"]]["output"]>;
export async function runWorkspaceFilesystemComputation(
  command: WorkspaceFilesystemCommand,
  options: WorkspaceFilesystemAuthority = {},
): Promise<void | string | null> {
  const source = await prepareSessionSourceEffect(
    composeSessionSourceAssertion([options.assertCurrent, options.workerAuthority?.assertCurrent]),
  );
  await using _ = { [Symbol.asyncDispose]: async () => await source.release?.() };
  const filesystem = [
    ...new Set([
      ...(source.workspaceEvidence ?? []),
      ...(options.workerAuthority?.workspaceEvidence ?? []),
    ]),
  ];
  if ("root" in command.input) {
    const root = command.input.root;
    let target = filesystem.find((evidence) => evidence.workspaceDir === root);
    if (!target) {
      target = await captureWorkspaceFilesystemEvidence(command.input.root);
      filesystem.push(target);
    }
    command.input.root = target.canonical;
  }
  const assertCurrent = source.assertCurrent;
  assertCurrent();
  const authority = createWorkerMutationAuthority(assertCurrent, options.workerAuthority?.signal);
  try {
    const operation = {
      ...command,
      mutation: {
        decision: authority.buffer,
        filesystem,
        stateOwnerPath: options.workerAuthority?.stateOwnerPath,
        nativeMode: getFsSafeNativeConfig().mode,
      },
    };
    const result = await runGitWorkerOperation(operation, {
      assertCurrent,
      signal: options.workerAuthority?.signal,
      onNotification: authority.onNotification,
      inputBytes:
        256 + computationInputBytes(command.input) + computationInputBytes(operation.mutation),
      transferList: transferableManifestInput,
    });
    authority.throwIfRefused();
    return result;
  } catch (error) {
    authority.throwIfRefused();
    throw error;
  } finally {
    authority.dispose();
  }
}
