import fsp from "node:fs/promises";
import type { IncomingMessage } from "node:http";
import path from "node:path";
import { resolveStateDir } from "../../config/paths.js";
import { generateSecureToken } from "../../infra/secure-random.js";
import { KeyedAsyncQueue } from "../../plugin-sdk/keyed-async-queue.js";
import type { NodeWorkspaceTransferHttpRoute } from "./node-workspace-transfer-http-contract.js";
import {
  isNodeWorkspaceTransferOwnerCurrent,
  type NodeWorkspaceTransferOwner,
} from "./node-workspace-transfer-owner.js";
import {
  nodeWorkspaceTransferEntryPath as entryPath,
  prepareNodeWorkspaceTransferSnapshot,
  type NodeWorkspaceTransferSnapshot,
} from "./node-workspace-transfer-snapshot.js";
import {
  readNodeWorkspaceUpload,
  removeNodeWorkspaceUpload,
  type NodeWorkspaceTransferUpload,
} from "./node-workspace-upload-reader.js";
import { prepareWorkerWorkspaceGitPack } from "./workspace-git-base.js";
import { MAX_WORKSPACE_INVENTORY_TOTAL_BYTES } from "./workspace-inventory-limits.js";
import {
  captureWorkspaceSnapshot,
  computeWorkspaceFileSnapshot,
} from "./workspace-manifest-worker.js";

const TRANSFER_TIMEOUT_MS = 10 * 60_000;
const MANIFEST_REF_PATTERN = /^sha256:[a-f0-9]{64}$/u;

type TransferBinding = {
  environmentId: string;
  ownerEpoch: number;
  sessionId: string;
};

type DownloadCapability = {
  direction: "download";
  token: string;
  manifestRef: string;
  expiresAtMs: number;
  isAuthorized: () => boolean;
  signal?: AbortSignal;
};

type UploadOperation = {
  direction: "upload";
  token: string;
  baseManifestRef: string;
  resultVersion?: 2;
  expiresAtMs: number;
  state: "ready" | "receiving" | "completed";
  isAuthorized: () => boolean;
  uploaded?: NodeWorkspaceTransferUpload;
  abortController: AbortController;
  receiving?: { result: Promise<{ manifestRef: string }>; signal: AbortSignal };
  disposal?: Promise<void>;
};

type TransferContext = TransferBinding & {
  localPath?: string;
  temporaryRoot: string;
  currentManifestRef: string;
  snapshots: Map<string, NodeWorkspaceTransferSnapshot>;
  baseCommit: string | null;
  pack?: Promise<string>;
  downloads: Map<string, DownloadCapability>;
  upload?: UploadOperation;
  abortController: AbortController;
  signal: AbortSignal;
  isAuthorized: () => boolean;
};

type TransferAuthorization = {
  context: TransferContext;
  capability: DownloadCapability | UploadOperation;
  route: NodeWorkspaceTransferHttpRoute;
};

type TransferPreparation = Pick<
  TransferContext,
  "environmentId" | "ownerEpoch" | "sessionId" | "isAuthorized"
> & { signal?: AbortSignal; authorize?: () => void };
type RepositoryPreparation = TransferPreparation & { baseCommit: string; baseManifestRef: string };
type SyncPreparation = TransferPreparation & { localPath: string };

function isOperationAuthorized(authorize: (() => void) | undefined): boolean {
  try {
    authorize?.();
    return true;
  } catch {
    return false;
  }
}

export function createNodeWorkspaceTransferService(options: {
  getOwner: (environmentId: string) => NodeWorkspaceTransferOwner | undefined;
  now?: () => number;
  temporaryRoot?: string;
}) {
  const contexts = new Map<string, TransferContext>();
  const contextOperations = new KeyedAsyncQueue();
  const now = options.now ?? Date.now;
  const temporaryBaseRoot =
    options.temporaryRoot ?? path.join(resolveStateDir(), "tmp", "node-workspace-transfer");
  let temporaryRootReady: Promise<void> | undefined;

  const ensureTemporaryRoot = () => {
    temporaryRootReady ??= (async () => {
      // The Gateway state lock proves no previous process still owns this private namespace.
      await fsp.rm(temporaryBaseRoot, { recursive: true, force: true });
      await fsp.mkdir(temporaryBaseRoot, { recursive: true, mode: 0o700 });
    })();
    return temporaryRootReady;
  };

  const isCurrentContext = (context: TransferContext): boolean =>
    contexts.get(context.environmentId) === context &&
    !context.signal.aborted &&
    context.isAuthorized() &&
    isNodeWorkspaceTransferOwnerCurrent(context, options.getOwner(context.environmentId));

  const discardUpload = (context: TransferContext, operation: UploadOperation): Promise<void> => {
    if (!operation.disposal) {
      operation.abortController.abort(new Error("Node workspace upload discarded"));
      operation.disposal = (async () => {
        const receiving = operation.receiving;
        try {
          await receiving?.result.catch((error: unknown) => {
            if (!receiving.signal.aborted || error !== receiving.signal.reason) {
              throw error;
            }
          });
        } finally {
          try {
            if (operation.uploaded) {
              await removeNodeWorkspaceUpload(operation.uploaded);
            }
          } finally {
            // Keep the slot until cleanup settles, including errors. Duplicate discard
            // and context close join the same owner before a replacement can start.
            if (context.upload === operation) {
              context.upload = undefined;
            }
          }
        }
      })();
    }
    return operation.disposal;
  };

  const closeContext = async (context: TransferContext) => {
    context.abortController.abort(new Error("Node workspace transfer context closed"));
    // Readers and pack processes must release scratch before its parent is removed.
    const settled = await Promise.allSettled([
      context.pack?.catch(() => undefined),
      context.upload ? discardUpload(context, context.upload) : undefined,
    ]);
    await fsp.rm(context.temporaryRoot, { recursive: true, force: true });
    if (contexts.get(context.environmentId) === context) {
      contexts.delete(context.environmentId);
    }
    const failed = settled.find((result) => result.status === "rejected");
    if (failed) {
      throw failed.reason;
    }
  };

  const closeEnvironment = (environmentId: string) =>
    contextOperations.enqueue(environmentId, async () => {
      const context = contexts.get(environmentId);
      if (context) {
        await closeContext(context);
      }
    });

  const mintDownload = (
    context: TransferContext,
    manifestRef: string,
    isAuthorized: () => boolean,
    signal?: AbortSignal,
  ): string => {
    signal?.throwIfAborted();
    if (!isCurrentContext(context) || !isAuthorized()) {
      throw new Error("Node workspace transfer owner is no longer current");
    }
    const token = generateSecureToken({ bytes: 32, redact: true });
    context.downloads.set(token, {
      direction: "download",
      token,
      manifestRef,
      expiresAtMs: now() + TRANSFER_TIMEOUT_MS,
      isAuthorized,
      ...(signal ? { signal } : {}),
    });
    return token;
  };

  const pruneSnapshots = (context: TransferContext): void => {
    const retained = new Set([
      context.currentManifestRef,
      ...[...context.downloads.values()].map((download) => download.manifestRef),
    ]);
    for (const manifestRef of context.snapshots.keys()) {
      if (!retained.has(manifestRef)) {
        context.snapshots.delete(manifestRef);
      }
    }
  };

  const authorizationCurrent = (authorization: TransferAuthorization): boolean => {
    const { capability, context } = authorization;
    if (!isCurrentContext(context) || capability.expiresAtMs <= now()) {
      return false;
    }
    // Exact object membership binds the capability to this live context's owner.
    return capability.direction === "download"
      ? context.downloads.get(capability.token) === capability &&
          !capability.signal?.aborted &&
          capability.isAuthorized()
      : context.upload === capability &&
          capability.isAuthorized() &&
          !capability.abortController.signal.aborted &&
          (capability.state === "receiving" || capability.state === "completed");
  };

  const assertAuthorizationCurrent = (authorization: TransferAuthorization): void => {
    if (!authorizationCurrent(authorization)) {
      throw new Error("Workspace transfer authority closed");
    }
  };

  const routeMatchesDownload = (
    context: TransferContext,
    capability: DownloadCapability,
    route: NodeWorkspaceTransferHttpRoute,
  ): boolean => {
    if (route.direction !== "download" || route.environmentId !== context.environmentId) {
      return false;
    }
    return route.kind === "blob"
      ? Boolean(
          context.snapshots
            .get(capability.manifestRef)
            ?.manifest.entries.some(
              (entry) => entry.type === "file" && entry.sha256 === route.sha256,
            ),
        )
      : route.manifestRef === capability.manifestRef;
  };

  function replaceContext(params: RepositoryPreparation & { kind: "repository" }): Promise<void>;
  function replaceContext(
    params: SyncPreparation & { kind: "sync" },
  ): Promise<{ snapshot: NodeWorkspaceTransferSnapshot; token: string }>;
  async function replaceContext(
    params: (RepositoryPreparation & { kind: "repository" }) | (SyncPreparation & { kind: "sync" }),
  ): Promise<void | { snapshot: NodeWorkspaceTransferSnapshot; token: string }> {
    const { authorize, ...owner } = params;
    const getOwner = options.getOwner;
    const assertCurrent = () => {
      owner.signal?.throwIfAborted();
      authorize?.();
      if (
        !owner.isAuthorized() ||
        !isNodeWorkspaceTransferOwnerCurrent(owner, getOwner(owner.environmentId))
      ) {
        throw new Error("Node workspace transfer owner is no longer current");
      }
    };
    return await contextOperations.enqueue(params.environmentId, async () => {
      assertCurrent();
      const previous = contexts.get(params.environmentId);
      if (previous) {
        await closeContext(previous);
        assertCurrent();
      }
      await ensureTemporaryRoot();
      assertCurrent();
      const abortController = new AbortController();
      const context: TransferContext = {
        ...owner,
        temporaryRoot: await fsp.mkdtemp(path.join(temporaryBaseRoot, "context-")),
        currentManifestRef: params.kind === "repository" ? params.baseManifestRef : "",
        baseCommit: params.kind === "repository" ? params.baseCommit : null,
        snapshots: new Map(),
        downloads: new Map(),
        abortController,
        signal: params.signal
          ? AbortSignal.any([params.signal, abortController.signal])
          : abortController.signal,
      };
      try {
        assertCurrent();
        let snapshot: NodeWorkspaceTransferSnapshot | undefined;
        if (params.kind === "sync") {
          snapshot = await prepareNodeWorkspaceTransferSnapshot({
            localPath: params.localPath,
            temporaryRoot: context.temporaryRoot,
            signal: AbortSignal.any([context.signal, AbortSignal.timeout(TRANSFER_TIMEOUT_MS)]),
          });
          assertCurrent();
          context.snapshots.set(snapshot.manifestRef, snapshot);
          context.localPath = snapshot.root;
          context.baseCommit = snapshot.manifest.baseCommit;
          context.currentManifestRef = snapshot.manifestRef;
        }
        contexts.set(context.environmentId, context);
        // Only this download retains initiating-turn authority; future workspace
        // operations keep their independent placement owner.
        return snapshot
          ? {
              snapshot,
              token: mintDownload(context, snapshot.manifestRef, () =>
                isOperationAuthorized(authorize),
              ),
            }
          : undefined;
      } catch (error) {
        await closeContext(context);
        throw error;
      }
    });
  }

  return {
    initialize: ensureTemporaryRoot,

    async prepareAttachments(params: {
      environmentId: string;
      localPath: string;
      isAuthorized: () => boolean;
      signal: AbortSignal;
    }) {
      params.signal.throwIfAborted();
      const context = contexts.get(params.environmentId);
      if (!context || !isCurrentContext(context) || !params.isAuthorized()) {
        throw new Error("Worker attachment transfer authority closed");
      }
      const root = await fsp.realpath(params.localPath);
      params.signal.throwIfAborted();
      const actual = await captureWorkspaceSnapshot({
        root,
        baseCommit: null,
        signal: params.signal,
      });
      params.signal.throwIfAborted();
      if (!isCurrentContext(context) || !params.isAuthorized()) {
        throw new Error("Worker attachment transfer authority closed");
      }
      // Attachment snapshots are claim-scoped and must not advance the workspace base.
      const snapshot = {
        ...actual,
        root,
      };
      context.snapshots.set(snapshot.manifestRef, snapshot);
      return {
        snapshot,
        token: mintDownload(context, snapshot.manifestRef, params.isAuthorized, params.signal),
      };
    },

    prepareRepository: (params: RepositoryPreparation) =>
      replaceContext({ ...params, kind: "repository" }),

    prepareSync: (params: SyncPreparation) => replaceContext({ ...params, kind: "sync" }),

    prepareUpload(
      environmentId: string,
      baseManifestRef: string,
      authorize?: () => void,
      resultVersion?: 2,
    ): string {
      authorize?.();
      const context = contexts.get(environmentId);
      if (!context || !MANIFEST_REF_PATTERN.test(baseManifestRef) || !isCurrentContext(context)) {
        throw new Error("Node workspace transfer context is unavailable");
      }
      if (context.upload) {
        throw new Error("Node workspace transfer upload is already active");
      }
      const token = generateSecureToken({ bytes: 32, redact: true });
      context.upload = {
        direction: "upload",
        token,
        baseManifestRef,
        ...(resultVersion ? { resultVersion } : {}),
        expiresAtMs: now() + TRANSFER_TIMEOUT_MS,
        state: "ready",
        isAuthorized: () => isOperationAuthorized(authorize),
        abortController: new AbortController(),
      };
      return token;
    },

    takeUpload(environmentId: string, baseManifestRef: string): NodeWorkspaceTransferUpload {
      const context = contexts.get(environmentId);
      const operation = context?.upload;
      if (
        !context ||
        !operation ||
        operation.state !== "completed" ||
        !operation.isAuthorized() ||
        operation.abortController.signal.aborted ||
        operation.baseManifestRef !== baseManifestRef ||
        !operation.uploaded ||
        !isCurrentContext(context)
      ) {
        throw new Error("Node workspace transfer upload did not complete");
      }
      context.upload = undefined;
      return operation.uploaded;
    },

    async discardUpload(environmentId: string, token: string): Promise<void> {
      const context = contexts.get(environmentId);
      const operation = context?.upload;
      if (context && operation?.token === token) {
        await discardUpload(context, operation);
      }
    },

    getSnapshot(
      environmentId: string,
      manifestRef: string,
    ): NodeWorkspaceTransferSnapshot | undefined {
      return contexts.get(environmentId)?.snapshots.get(manifestRef);
    },

    publishSnapshot(
      environmentId: string,
      snapshot: NodeWorkspaceTransferSnapshot,
      authorize?: () => void,
      advanceWorkspace = true,
    ): string {
      authorize?.();
      const context = contexts.get(environmentId);
      if (!context || !isCurrentContext(context)) {
        throw new Error("Node workspace transfer context is unavailable");
      }
      context.snapshots.set(snapshot.manifestRef, snapshot);
      if (advanceWorkspace) {
        context.currentManifestRef = snapshot.manifestRef;
      }
      const token = mintDownload(context, snapshot.manifestRef, () =>
        isOperationAuthorized(authorize),
      );
      pruneSnapshots(context);
      return token;
    },

    async revoke(environmentId: string, token: string): Promise<void> {
      const context = contexts.get(environmentId);
      context?.downloads.delete(token);
      if (context) {
        pruneSnapshots(context);
      }
      const upload = context?.upload;
      if (context && upload?.token === token) {
        // Join the receiver before releasing its slot and staging data.
        await discardUpload(context, upload);
      }
    },

    authorize(params: {
      route: NodeWorkspaceTransferHttpRoute;
      token: string;
    }): TransferAuthorization | undefined {
      const context = contexts.get(params.route.environmentId);
      if (!context) {
        return undefined;
      }
      const download = context.downloads.get(params.token);
      if (download) {
        const authorization = { context, capability: download, route: params.route };
        if (
          !authorizationCurrent(authorization) ||
          !routeMatchesDownload(context, download, params.route)
        ) {
          return undefined;
        }
        return authorization;
      }
      const upload = context.upload;
      if (
        !upload ||
        !isCurrentContext(context) ||
        upload.token !== params.token ||
        upload.state !== "ready" ||
        !upload.isAuthorized() ||
        upload.expiresAtMs <= now() ||
        params.route.kind !== "reconcile" ||
        params.route.environmentId !== context.environmentId ||
        params.route.baseManifestRef !== upload.baseManifestRef
      ) {
        return undefined;
      }
      // Claim before body streaming. A retry must mint a fresh operation instead of replaying bytes.
      upload.state = "receiving";
      return { context, capability: upload, route: params.route };
    },

    isAuthorizationCurrent: authorizationCurrent,

    authorizationSignal(authorization: TransferAuthorization): AbortSignal {
      const signal = authorization.context.signal;
      const capability = authorization.capability;
      return capability.direction === "download" && capability.signal
        ? AbortSignal.any([signal, capability.signal])
        : capability.direction === "upload"
          ? AbortSignal.any([signal, capability.abortController.signal])
          : signal;
    },

    snapshot(authorization: TransferAuthorization): NodeWorkspaceTransferSnapshot | undefined {
      if (
        authorization.capability.direction !== "download" ||
        (authorization.route.kind !== "manifest" && authorization.route.kind !== "pack") ||
        !authorizationCurrent(authorization)
      ) {
        return undefined;
      }
      return authorization.context.snapshots.get(authorization.capability.manifestRef);
    },

    async pack(authorization: TransferAuthorization): Promise<string | undefined> {
      if (authorization.route.kind !== "pack" || !authorizationCurrent(authorization)) {
        return undefined;
      }
      const { context, route } = authorization;
      const snapshot = context.snapshots.get(route.manifestRef);
      if (snapshot?.gitPackPath) {
        return snapshot.gitPackPath;
      }
      const { baseCommit } = context;
      if (!context.localPath || !baseCommit || snapshot?.manifest.baseCommit !== baseCommit) {
        return undefined;
      }
      if (!context.pack) {
        // Origin/seed sync needs only the manifest. Materialize its immutable Git base
        // on first download; accepted manifests share this context-owned operation.
        context.pack = prepareWorkerWorkspaceGitPack({
          root: context.localPath,
          baseCommit,
          temporaryRoot: context.temporaryRoot,
          signal: AbortSignal.any([context.signal, AbortSignal.timeout(TRANSFER_TIMEOUT_MS)]),
        }).catch((error: unknown) => {
          context.pack = undefined;
          throw error;
        });
      }
      const packPath = await context.pack;
      return authorizationCurrent(authorization) ? packPath : undefined;
    },

    blob(
      authorization: TransferAuthorization,
    ): { path: string; size: number; sha256: string } | undefined {
      if (
        authorization.capability.direction !== "download" ||
        authorization.route.kind !== "blob" ||
        !authorizationCurrent(authorization)
      ) {
        return undefined;
      }
      const snapshot = authorization.context.snapshots.get(authorization.capability.manifestRef);
      const sha256 = authorization.route.sha256;
      const entry = snapshot?.manifest.entries.find(
        (candidate) =>
          candidate.type === "file" &&
          candidate.sha256 === sha256 &&
          (!snapshot.blobPaths || snapshot.blobPaths.has(candidate.path)),
      );
      return snapshot && entry?.type === "file"
        ? { path: entryPath(snapshot.root, entry.path), size: entry.size, sha256: entry.sha256 }
        : undefined;
    },

    async receiveUpload(params: {
      authorization: TransferAuthorization;
      request: IncomingMessage;
      signal: AbortSignal;
    }): Promise<{ manifestRef: string }> {
      const { authorization } = params;
      const operation = authorization.capability;
      if (
        operation.direction !== "upload" ||
        authorization.route.kind !== "reconcile" ||
        operation.state !== "receiving"
      ) {
        throw new Error("Workspace transfer upload owner is unavailable");
      }
      const signal = AbortSignal.any([params.signal, operation.abortController.signal]);
      const result = (async () => {
        const assertCurrent = () => {
          signal.throwIfAborted();
          assertAuthorizationCurrent(authorization);
        };
        let uploaded: NodeWorkspaceTransferUpload | undefined;
        try {
          signal.throwIfAborted();
          uploaded = await readNodeWorkspaceUpload({
            request: params.request,
            baseManifestRef: operation.baseManifestRef,
            resultVersion: operation.resultVersion,
            temporaryRoot: authorization.context.temporaryRoot,
            signal,
            assertCurrent,
            isAuthorized: () => authorizationCurrent(authorization),
          });
          assertCurrent();
          const context = authorization.context;
          if (context.localPath && !context.snapshots.has(uploaded.baseManifestRef)) {
            if (context.baseCommit !== uploaded.base.baseCommit) {
              await context.pack?.catch(() => undefined);
              assertCurrent();
              context.pack = undefined;
              context.baseCommit = uploaded.base.baseCommit;
            }
            // Reconnect may snapshot newer local files. Retain the authenticated original
            // base before upload-token revocation; accepted publication needs its exact pack.
            context.snapshots.set(uploaded.baseManifestRef, {
              manifest: uploaded.base,
              manifestRef: uploaded.baseManifestRef,
              rawManifest: uploaded.baseRaw,
              root: context.localPath,
            });
            context.currentManifestRef = uploaded.baseManifestRef;
          }
          operation.uploaded = uploaded;
          operation.state = "completed";
          return { manifestRef: uploaded.currentManifestRef };
        } catch (error) {
          if (uploaded) {
            await removeNodeWorkspaceUpload(uploaded);
          }
          if (authorization.context.upload === operation && !operation.disposal) {
            authorization.context.upload = undefined;
          }
          throw error;
        }
      })();
      operation.receiving = { result, signal };
      return await result;
    },

    async verifyBlob(params: { path: string; size: number; sha256: string }): Promise<boolean> {
      const snapshot = await computeWorkspaceFileSnapshot(
        params.path,
        Math.min(params.size, MAX_WORKSPACE_INVENTORY_TOTAL_BYTES),
      );
      return (
        snapshot.type === "file" &&
        snapshot.size === params.size &&
        snapshot.sha256 === params.sha256
      );
    },

    fenceEnvironment(environmentId: string, reason?: Error): void {
      const context = contexts.get(environmentId);
      // Abort synchronously so every in-flight response and capability for this owner is
      // fenced at once; cleanup (scratch removal, map entry) settles behind the queue.
      if (context) {
        context.abortController.abort(reason ?? new Error("Worker environment credential revoked"));
      }
      void closeEnvironment(environmentId).catch(() => undefined);
    },

    close: closeEnvironment,

    async closeAll(): Promise<void> {
      await temporaryRootReady;
      const closed = await Promise.allSettled([...contexts.keys()].map(closeEnvironment));
      // Shared scratch outlives every transfer context, including failed sibling cleanup.
      closed.push(
        ...(await Promise.allSettled([
          fsp.rm(temporaryBaseRoot, { recursive: true, force: true }),
        ])),
      );
      const failure = closed.find((result) => result.status === "rejected");
      if (failure) {
        throw failure.reason;
      }
    },
  };
}

export type NodeWorkspaceTransferService = ReturnType<typeof createNodeWorkspaceTransferService>;
