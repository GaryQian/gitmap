import type { CanvasDocumentViewResult } from "../../packages/gateway-protocol/src/schema/canvas.js";
import type { PluginControlUiModule } from "../../packages/gateway-protocol/src/schema/plugins.js";

/** HTTP path for the Control UI bootstrap config payload. */
export const CONTROL_UI_BOOTSTRAP_CONFIG_PATH = "/control-ui-config.json";

export function matchesControlUiBootstrapConfigPath(pathname: string, basePath: string): boolean {
  // The default SPA infers this namespace before it receives its bootstrap config.
  return (
    pathname === `${basePath}${CONTROL_UI_BOOTSTRAP_CONFIG_PATH}` ||
    (basePath === "" && pathname === `/__openclaw__${CONTROL_UI_BOOTSTRAP_CONFIG_PATH}`)
  );
}

/** Authenticated document copy of the canonical bootstrap payload. */
export const CONTROL_UI_BOOTSTRAP_CONFIG_ATTRIBUTE = "data-openclaw-bootstrap-config";

/** Fragment marker selecting the host-authorized browser-owner bootstrap profile. */
export const CONTROL_UI_BOOTSTRAP_PROFILE_FRAGMENT_PARAM = "bootstrapProfile";
export const CONTROL_UI_OWNER_BOOTSTRAP_PROFILE_HINT = "owner";
export type ControlUiBootstrapProfileHint = typeof CONTROL_UI_OWNER_BOOTSTRAP_PROFILE_HINT;

/** Operator access a signed-in Control UI asks for; browser code pairing approves the same set. */
export const CONTROL_UI_OPERATOR_SCOPES = [
  "operator.admin",
  "operator.read",
  "operator.write",
  "operator.approvals",
  "operator.questions",
  "operator.pairing",
] as const;

/** Carries the gateway-configured Control UI mount path into browser bootstrap. */
export const CONTROL_UI_BASE_PATH_ATTRIBUTE = "data-openclaw-control-ui-base-path";

/** Marks whether the served document CSP permits the terminal WASM runtime. */
export const CONTROL_UI_TERMINAL_ENABLED_ATTRIBUTE = "data-openclaw-terminal-enabled";

/** Public feature opt-in for callback/loader startup; never carries viewer data or authority. */
export const CONTROL_UI_ID_LABS_ATTRIBUTE = "data-openclaw-id-enabled";

export const CONTROL_UI_ENVIRONMENT_ATTRIBUTE = "data-openclaw-environment";
export const CONTROL_UI_ENVIRONMENT_COLORS = [
  "teal",
  "amber",
  "purple",
  "coral",
  "pink",
  "blue",
  "green",
  "red",
  "gray",
] as const;
export type ControlUiEnvironment = {
  label: string;
  color: (typeof CONTROL_UI_ENVIRONMENT_COLORS)[number];
};

/** Sandbox policy for assistant-provided embed surfaces inside Control UI. */
export type ControlUiEmbedSandboxMode = NonNullable<CanvasDocumentViewResult["embedSandbox"]>;

/** Route grant successfully issued during authenticated Control UI bootstrap. */
export type ControlUiPluginFrameGrantAck = {
  pluginId: string;
  path: string;
  match: "exact" | "prefix";
};

/** Runtime config consumed by the browser Control UI during bootstrap. */
export type ControlUiBootstrapConfig = {
  /** Viewer-scoped display projection, never an editable config snapshot. */
  preferences?: {
    profileId?: string;
    config?: Record<string, unknown>;
    entries?: Record<string, unknown>;
  };
  basePath: string;
  assistantName: string;
  assistantAvatar: string;
  assistantAvatarSource?: string | null;
  assistantAvatarStatus?: "none" | "local" | "remote" | "data" | null;
  assistantAvatarReason?: string | null;
  assistantAgentId?: string;
  serverVersion?: string;
  /** Exact immutable build serving this Control UI when available. */
  serverBuildId?: string;
  /**
   * Git branch of a source-checkout (non-release) gateway install. Omitted for
   * package installs and mainline (main/master) checkouts so the UI only flags
   * gateways running unreleased branch code.
   */
  devGitBranch?: string;
  embedSandbox?: ControlUiEmbedSandboxMode;
  allowExternalEmbedUrls?: boolean;
  automaticallyFetchFavicons?: boolean;
  /** Whether experimental speech-bubble presentation is available. */
  chatBubblesEnabled?: boolean;
  /** Explicit Labs opt-in; absence leaves every OpenClaw ID surface inert. */
  openclawIdEnabled?: boolean;
  /** Whether optional composer prediction inference is enabled. */
  composerPredictionsEnabled?: boolean;
  seamColor?: string;
  environment?: ControlUiEnvironment;
  /** Whether this Gateway blocks writes to its configuration file. */
  configReadOnly?: boolean;
  /** Optional operator guidance shown alongside the read-only policy. */
  configReadOnlyNotice?: string;
  /** Whether this Gateway's served UI may show the Discord community invitation. */
  communityInvite?: boolean;
  /** Fresh-draft model, runtime and reasoning preference policy; never a selection restriction. */
  newSessionModelDefaults?: "last-used" | "configured";
  /**
   * Whether the operator terminal surface is enabled (`gateway.terminal.enabled`).
   * The Control UI hides the terminal entirely when false so a disabled kill
   * switch removes the surface rather than showing a button that errors on open.
   */
  terminalEnabled?: boolean;
  /** Whether clients may upload files and images (`gateway.uploads.enabled`). */
  uploadsEnabled?: boolean;
  /** Whether the Labs-gated CLI agents model-picker group is enabled. */
  cliAgentsEnabled?: boolean;
  /** Only explicit no-auth Gateways permit native asset loading without scoped cookies. */
  pluginAssetsRequireAuth?: boolean;
  pluginFrameGrants?: ControlUiPluginFrameGrantAck[];
  pluginControlUiModules?: PluginControlUiModule[];
};
