import { isNativeAppUiClient } from "../../packages/gateway-protocol/src/client-info.js";

export const ADMIN_SCOPE = "operator.admin" as const;
export const READ_SCOPE = "operator.read" as const;
export const WRITE_SCOPE = "operator.write" as const;
export const CRON_SCOPE = "operator.cron" as const;
export const SESSION_READ_SCOPE = "operator.sessions.read" as const;
export const PUBLICATION_READ_SCOPE = "operator.session-share.read" as const;
export const PUBLICATION_STEER_SCOPE = "operator.session-share.steer" as const;
export const SESSION_WRITE_SCOPE = "operator.sessions.write" as const;
export const APPROVALS_SCOPE = "operator.approvals" as const;
export const QUESTIONS_SCOPE = "operator.questions" as const;
export const PAIRING_SCOPE = "operator.pairing" as const;
export const TALK_SCOPE = "operator.talk" as const;
export const TALK_SECRETS_SCOPE = "operator.talk.secrets" as const;

const KNOWN_OPERATOR_SCOPE_VALUES = [
  ADMIN_SCOPE,
  READ_SCOPE,
  WRITE_SCOPE,
  CRON_SCOPE,
  SESSION_READ_SCOPE,
  PUBLICATION_READ_SCOPE,
  PUBLICATION_STEER_SCOPE,
  SESSION_WRITE_SCOPE,
  APPROVALS_SCOPE,
  QUESTIONS_SCOPE,
  PAIRING_SCOPE,
  TALK_SCOPE,
  TALK_SECRETS_SCOPE,
] as const;

export type OperatorScope = (typeof KNOWN_OPERATOR_SCOPE_VALUES)[number];

const KNOWN_OPERATOR_SCOPES: ReadonlySet<string> = new Set(KNOWN_OPERATOR_SCOPE_VALUES);

export function hasGatewayAdminScope(
  client: { connect?: { scopes?: readonly string[] } } | null | undefined,
): boolean {
  return client?.connect?.scopes?.includes(ADMIN_SCOPE) ?? false;
}

/** Narrows untrusted auth-token scope entries to the gateway's closed scope set. */
export function isOperatorScope(value: unknown): value is OperatorScope {
  return typeof value === "string" && KNOWN_OPERATOR_SCOPES.has(value);
}

export function normalizeOperatorScopeList(
  scopes: string[] | undefined,
): OperatorScope[] | undefined {
  if (!Array.isArray(scopes)) {
    return undefined;
  }
  return [...new Set(scopes.filter(isOperatorScope))];
}

/** Authenticated UI administration is separate from browser identity and local execution. */
export function resolveGatewayUiAdminSource(
  client:
    | {
        connect: { scopes?: readonly string[]; client: { id?: string; mode?: string } };
        internal?: { controlUiAdmin?: boolean; authenticatedOperator?: boolean };
      }
    | null
    | undefined,
): "control-ui-admin" | "native-app-admin" | undefined {
  if (!hasGatewayAdminScope(client)) {
    return undefined;
  }
  if (client?.internal?.controlUiAdmin === true) {
    return "control-ui-admin";
  }
  return client?.internal?.authenticatedOperator === true &&
    isNativeAppUiClient(client.connect.client)
    ? "native-app-admin"
    : undefined;
}
