import type { GatewayClientCap } from "../../../packages/gateway-protocol/src/client-info.js";
import type {
  SessionApprovalReplay,
  SystemAgentChatQuestion,
  SystemAgentWizardCancel,
  WizardAnswer,
} from "../../../packages/gateway-protocol/src/index.js";
import type {
  ConnectParams,
  RequestFrame,
} from "../../../packages/gateway-protocol/src/schema/frames.js";
import type { ModelCatalogEntry } from "../../agents/model-catalog.types.js";
import type { CliDeps } from "../../cli/deps.types.js";
import type { OpenClawConfig } from "../../config/types.openclaw.js";
import type { AgentRunDelegatedAuthority } from "../../infra/agent-run-authority.types.js";
import type { DiffReadTiming } from "../../infra/diff-read-timing.js";
import type { ExecApprovalRequest, ExecApprovalResolved } from "../../infra/exec-approvals.js";
import type {
  PluginApprovalRequest,
  PluginApprovalRequestPayload,
} from "../../infra/plugin-approvals.js";
import type {
  SystemAgentApprovalRequest,
  SystemAgentApprovalRequestPayload,
  SystemAgentApprovalResolved,
} from "../../infra/system-agent-approvals.js";
import type { SubsystemLogger } from "../../logging/subsystem.js";
import type { PluginRuntimeCore } from "../../plugins/runtime/types-core.js";
import type { SystemAgentOperatorProposal } from "../../system-agent/operation-types.js";
import type { WizardSession } from "../../wizard/session.js";
import type { AgentRuntimeApprovalAuthorityValidator } from "../agent-runtime-approval-authority.js";
import type { InternalAgentTurnFacadeFactory } from "../agent-turn/internal-facade.types.js";
import type {
  GatewayDeferredChannelReload,
  GatewayHotReloadStatus,
} from "../config-reload-status.types.js";
import type { GatewayConfigRevisionProjector } from "../config-revision-token.js";
import type { ScopeUpgradeCoordinator } from "../device-scope-upgrade.js";
import type { ExecApprovalManager, ExecApprovalRecord } from "../exec-approval-manager.js";
import type { HealthSummary, ReadinessChecker } from "../health/types.js";
import type { LiveTextProjectionText } from "../live-text-continuity.js";
import type { MentionInbox } from "../mention-inbox.contracts.js";
import type { GatewayMethodRegistryView } from "../methods/descriptor.js";
import type { NodeRegistry } from "../node-registry.js";
import type { PlacementStandingGrantRuntime } from "../operator-approval-placement-grants.js";
import type { GatewayOperatorRoleActor } from "../operator-role-actor.js";
import type { GatewayPortalService } from "../portals/portal-service.js";
import type { QuestionManager } from "../question-manager.js";
import type {
  ChannelAccountStartOutcome,
  ChannelRuntimeSnapshot,
  ChannelRuntimeSnapshotOptions,
  StartChannelOptions,
} from "../server-channel-runtime.types.js";
import type {
  ChatRunEntry,
  ChatRunRegistration,
  ChatRunState,
  SessionMessageSubscriberRegistry,
} from "../server-chat-state.js";
import type { GatewayCronServiceContract } from "../server-cron-contract.js";
import type {
  GatewayApprovalEventPublisher,
  GatewayLifecycleRuntime,
} from "../server-instance-runtime.types.js";
import type {
  GatewayModelCatalogSnapshot,
  PreparedGatewayModelCatalog,
  PreparedGatewayModelCatalogReadResult,
} from "../server-model-catalog.types.js";
import type { GatewayPluginReloadStatus } from "../server-plugin-reload-status.types.js";
import type { DedupeEntry } from "../server-shared.js";
import type { GatewayEventLoopHealth } from "../server/event-loop-health.js";
import type { ConnectionSessionRows } from "../session-ancestor-references.js";
import type { SessionMutationTarget } from "../session-mutation-authorization-error.js";
import type { SessionObserverService } from "../session-observer-contract.js";
import type { TerminalLaunchResolution } from "../terminal/launch.js";
import type { TerminalSessionManager } from "../terminal/session-manager.js";
import type {
  WorkerPlacementDiskSpaceReader,
  WorkerPlacementRunnerAvailabilityReader,
  WorkerPlacementRuntimeInstallReader,
  WorkerSessionPlacementReader,
} from "../worker-environments/placement-projector.js";
import type {
  WorkerSessionPlacementRetirementService,
  WorkerSessionPlacementStore,
} from "../worker-environments/placement-store.js";
import type {
  WorkerEnvironmentServiceContract,
  WorkerPlacementDispatchContract,
} from "../worker-environments/service-contract.js";
import type { ChatMetadataReadParams, ChatMetadataResult } from "./chat-metadata-contract.js";
import type {
  ChatStartupProjectionReadParams,
  ChatStartupProjectionResult,
} from "./chat-startup-projection-contract.js";
import type { GatewayClient } from "./client-types.js";
import type { RespondFn } from "./response-types.js";

export type {
  GatewayAgentRunTaskOwner,
  GatewayClient,
  GatewayNodeInvokeStream,
  TrustedAgentToolCaller,
} from "./client-types.js";

/** Host-minted role authority; leaf contract re-exported for method handlers. */
export type { GatewayOperatorRoleActor };

export type { RespondFn } from "./response-types.js";

export type PreparedSessionApprovalReplay = {
  replay: SessionApprovalReplay;
  /** Check in the response frame; a publication may race promise delivery. */
  isCurrent: () => boolean;
  /** Retain publication fencing through the response, then release the replay scope. */
  release: () => void;
};

/**
 * Structural mirror of the engine's SystemAgentAssistantTurn. Kept local as a
 * leaf contract: importing the assistant module here closes a madge cycle
 * through the agents/config cluster.
 */
type SystemAgentHistoryTurn = {
  role: "user" | "assistant";
  text: string;
};

type SystemAgentReply = {
  text: string;
  action: "none" | "exit" | "open-tui" | "open-setup";
  sensitive?: boolean;
  question?: SystemAgentChatQuestion;
};

/** Minimal hosted OpenClaw contract retained by the gateway request router. */
export type GatewaySystemAgentSession = {
  engine: {
    handle: (
      message: string,
      options?: { uiContext?: { page: string } },
    ) => Promise<SystemAgentReply>;
    answerWizard: (answer: WizardAnswer) => Promise<SystemAgentReply>;
    cancelWizard: (cancel: SystemAgentWizardCancel) => Promise<SystemAgentReply>;
    decorateRejoinReply: (reply: { text: string; action: "none" }) => SystemAgentReply & {
      wizardInputPending?: boolean;
      step?: import("../../wizard/session.js").WizardStep;
    };
    noteAssistantMessage: (text: string) => void;
    seedHistory: (turns: readonly SystemAgentHistoryTurn[]) => void;
    historyLength: () => number;
    historySince: (index: number) => SystemAgentHistoryTurn[];
    getPendingOperatorProposal: () => SystemAgentOperatorProposal | null;
    resolveOperatorApproval: (
      decision: "allow-once" | "allow-always" | "deny" | null,
      proposalHash: string,
      beforePersistentApply?: () => void,
      terminalStatus?: "expired" | "cancelled",
    ) => Promise<{
      text: string;
      action: "none" | "exit" | "open-tui" | "open-setup";
      applied?: boolean;
    } | null>;
    dispose: () => Promise<void>;
  };
  welcome: string;
  /** Recorded with the welcome; external-edit notices and setup are not optional. */
  optionalWelcome?: boolean;
  /** Passive creation entry, retained so reconnects do not append duplicate history. */
  newAgentWelcome?: string;
  welcomeQuestion?: SystemAgentChatQuestion;
  /** Audit cursor captured with the pending caretaker welcome; cleared after delivery. */
  welcomeAuditSequence?: number;
  lastUsedAt: number;
  ownerKey: string;
  pendingApproval?: {
    id: string;
    proposalHash: string;
    completion: Promise<
      NonNullable<
        Awaited<ReturnType<GatewaySystemAgentSession["engine"]["resolveOperatorApproval"]>>
      >
    >;
  };
};

/** Kernel-owned services and state that can be constructed without binding sockets. */
type GatewayKernelContext = {
  deps: CliDeps;
  /** Host-bound plugin ingress; the transport owns its shared hook dispatch queue. */
  dispatchHookAgentTurn?: (
    pluginId: string,
    params: Parameters<PluginRuntimeCore["hooks"]["dispatchHookAgentTurn"]>[0],
  ) => ReturnType<PluginRuntimeCore["hooks"]["dispatchHookAgentTurn"]>;
  configRevisionProjector: GatewayConfigRevisionProjector;
  cron: GatewayCronServiceContract;
  cronStorePath: string;
  getRuntimeConfig: () => OpenClawConfig;
  /** Instance-owned startup observation; never lends preparation or write authority. */
  agentDatabaseStartup?: import("../../state/agent-database-preparation-context.js").AgentDatabasePreparation;
  restartResumeWindows?: import("../../infra/gateway-boot-lifecycle.js").GatewayRestartResumeWindows;
  channelAdmissionAudit?: import("../../channels/message-access/admission-evidence.js").ChannelAdmissionAudit;
  /** Last serving policy committed by this Gateway, excluding tentative secret activation. */
  getCommittedRuntimeConfig?: () => OpenClawConfig;
  sessionRowProjectionOwner?: object;
  ensureSessionRowProjection?: () => Promise<void>;
  /** Live reload owner, including same-config restart work and shutdown. */
  isConfigReloadSettled: () => boolean;
  /** Prepared listener certificate pin; undefined when Gateway TLS is disabled. */
  gatewayTlsFingerprint?: string;
  sessionCompanion?: import("../session-companion.js").SessionCompanionService;
  sessionObserver?: SessionObserverService;
  sessionActivitySummaries?: import("../session-activity-summaries.js").SessionActivitySummaryService;
  /** Temporary profile-owned mentions for this exact Gateway lifetime. */
  mentionInbox?: MentionInbox;
  resolveTerminalLaunchPolicy: (agentId?: string) => TerminalLaunchResolution;
  isTerminalEnabled: () => boolean;
  execApprovalManager?: ExecApprovalManager;
  questionManager?: QuestionManager;
  scopeUpgradeCoordinator?: ScopeUpgradeCoordinator;
  /** Exact authority cancels bound approvals; legacy run ids cancel only unbound exec requests. */
  cancelRunBoundApprovals?: (target: string | AgentRunDelegatedAuthority) => Promise<number>;
  pluginApprovalManager?: ExecApprovalManager<PluginApprovalRequestPayload>;
  placementStandingGrants?: PlacementStandingGrantRuntime;
  systemAgentApprovalManager?: ExecApprovalManager<SystemAgentApprovalRequestPayload>;
  forwardPluginApprovalRequest?: (request: PluginApprovalRequest) => Promise<boolean>;
  forwardExecApprovalRequest?: (request: ExecApprovalRequest) => Promise<boolean>;
  forwardSystemAgentApprovalRequest?: (request: SystemAgentApprovalRequest) => Promise<boolean>;
  forwardSystemAgentApprovalResolved?: (resolved: SystemAgentApprovalResolved) => Promise<void>;
  execApprovalIosPushDelivery?: {
    handleRequested?: (record: ExecApprovalRecord) => Promise<boolean>;
    handleResolved?: (resolved: ExecApprovalResolved) => Promise<void>;
    handleExpired?: (request: ExecApprovalRequest) => Promise<void>;
  };
  approvalWebPushDelivery?: {
    handleRequested: <TPayload>(record: ExecApprovalRecord<TPayload>) => boolean | Promise<boolean>;
    handleResolved: (resolved: { id: string }) => Promise<void>;
    handleExpired: (request: { id: string }) => Promise<void>;
  };
  pluginApprovalIosPushDelivery?: {
    handleRequested?: (
      record: ExecApprovalRecord<PluginApprovalRequestPayload>,
    ) => Promise<boolean>;
    handleExpired?: (request: PluginApprovalRequest) => Promise<void>;
  };
  listSessionPendingApprovals?: (
    sessionKey: string,
    client: GatewayClient | null,
  ) => Promise<PreparedSessionApprovalReplay>;
  loadGatewayModelCatalog: (params?: {
    agentId?: string;
    agentDir?: string;
    readOnly?: boolean;
    workspaceDir?: string;
  }) => Promise<ModelCatalogEntry[]>;
  loadGatewayModelCatalogSnapshot: (params?: {
    agentId?: string;
    agentDir?: string;
    readOnly?: boolean;
    workspaceDir?: string;
  }) => Promise<GatewayModelCatalogSnapshot>;
  readPreparedGatewayModelCatalog?: (params?: {
    agentId?: string;
    agentDir?: string;
    workspaceDir?: string;
    /** Display-only consumers can omit the eager session-row invalidation snapshot. */
    includeSessionRowPolicy?: boolean;
  }) => Promise<PreparedGatewayModelCatalog | undefined>;
  readPreparedGatewayModelCatalogBatch?: (
    agentIds: readonly string[],
    options?: { includeSessionRowPolicy?: boolean },
  ) => Promise<PreparedGatewayModelCatalogReadResult[]>;
  readChatMetadata: (params: ChatMetadataReadParams) => Promise<ChatMetadataResult>;
  readPreparedModelsList?: (
    params: import("./models-list-context.js").PreparedModelsListRequest,
  ) => Promise<
    | import("../../../packages/gateway-protocol/src/schema/model-catalog.js").ModelsListResult
    | undefined
  >;
  readChatStartupProjection?: (
    params: ChatStartupProjectionReadParams,
  ) => Promise<ChatStartupProjectionResult | undefined>;
  getHealthCache: () => HealthSummary | null;
  getReadiness?: ReadinessChecker;
  logHealth: { error: (message: string) => void };
  logGateway: SubsystemLogger;
  publishPresence: () => void;
  /** Current live transports, independent of the bounded legacy beacon cache. */
  getPresenceSnapshot: () => import("../../../packages/gateway-protocol/src/schema/snapshot.js").PresenceEntry[];
  /** Instance-local native approval subscribers; never derived from a network client. */
  approvalEvents?: GatewayApprovalEventPublisher;
  lifecycleRuntime?: GatewayLifecycleRuntime;
  sharedGatewaySessionGenerationState?: import("../server-shared-auth-generation.js").SharedGatewaySessionGenerationState;
  /** Uses the lifecycle owner's module graph for plugin and detached agent turns. */
  createAgentTurnFacade?: InternalAgentTurnFacadeFactory;
  /** Live target facts stay with the instance owner, outside tool dispatch's import graph. */
  resolveSessionRequestTargets?: (request: {
    method: string;
    requestParams: unknown;
    connId?: string;
  }) => SessionMutationTarget[] | undefined;
  enforceSharedGatewayAuthGenerationForConfigWrite?: (
    nextConfig: OpenClawConfig,
    previousConfig: OpenClawConfig,
  ) => void;
  nodeRegistry: NodeRegistry;
  agentRunSeq: Map<string, number>;
  chatRunState: ChatRunState;
  addChatRun: (sessionId: string, entry: ChatRunRegistration) => void;
  removeChatRun: (
    sessionId: string,
    clientRunId: string,
    sessionKey?: string,
  ) => ChatRunEntry | undefined;
  dedupe: Map<string, DedupeEntry>;
  wizardSessions: Map<string, WizardSession>;
  systemAgentSessions: Map<string, GatewaySystemAgentSession>;
  findRunningWizard: () => string | null;
  purgeWizardSession: (id: string) => void;
  wizardRunner: import("./wizard.js").SetupWizardRunner;
  channelWizardRunner: import("./wizard.js").ChannelSetupWizardRunner;
  unavailableGatewayMethods?: ReadonlySet<string>;
};

/** Socket-bound services and connection state supplied by the Gateway transports. */
type GatewayTransportContext = {
  portalService?: GatewayPortalService;
  getMcpAppSandboxPort?: () => number | undefined;
  ensureSandboxHostPort?: () => Promise<number>;
  broadcast: GatewayBroadcastFn;
  broadcastToConnIds: GatewayBroadcastToConnIdsFn;
  getClientConnIds?: (filter?: (client: GatewayClient) => boolean) => ReadonlySet<string>;
  nodeSendToSession: (
    sessionKey: string,
    event: string,
    payload: unknown,
    opts?: GatewayBroadcastOpts,
  ) => void;
  nodeSendToAllSubscribed: (event: string, payload: unknown) => void;
  nodeSubscribe: (nodeId: string, sessionKey: string, connId?: string) => void;
  nodeUnsubscribe: (nodeId: string, sessionKey: string, connId?: string) => void;
  nodeUnsubscribeAll: (nodeId: string) => void;
  hasConnectedTalkNode: () => Promise<boolean>;
  isConnectionActive?: (connId: string) => boolean;
  /** Server-stamped activity from an accepted request on the exact live person connection. */
  recordClientActivity?: (client: GatewayClient | null) => void;
  hasExecApprovalClients?: (excludeConnId?: string) => boolean;
  getApprovalClientConnIds?: <TPayload>(params?: {
    approvalKind?: "exec" | "plugin" | "system-agent";
    excludeConnId?: string;
    filter?: (client: GatewayClient, record?: ExecApprovalRecord<TPayload>) => boolean;
    record?: ExecApprovalRecord<TPayload>;
  }) => ReadonlySet<string>;
  disconnectClientsForDevice?: (deviceId: string, opts?: { role?: string }) => void;
  /** With `roleOnly`, current owner devices stay: their certificate, not the role, bounds them. */
  disconnectClientsForUserProfile?: (profileId: string, opts?: { roleOnly?: boolean }) => void;
  invalidateClientsForDevice?: (
    deviceId: string,
    opts?: { role?: string; reason?: string },
  ) => void;
  hasConnectedClientsForDevice?: (deviceId: string) => boolean;
  refreshConnectedUserProfile?: (profile?: {
    id: string;
    displayName: string | null;
    avatarRevision: string;
    hasAvatar: boolean;
    updatedAt: number;
  }) => void;
  disconnectClientsUsingSharedGatewayAuth?: () => void;
  // Operator terminal session store. Absent in local/in-process contexts where
  // no PTY surface is served.
  terminalSessions?: TerminalSessionManager;
  subscribeSessionEvents: (connId: string) => void;
  unsubscribeSessionEvents: (connId: string) => void;
  forgetConnectionAncestors: (connId: string) => void;
  subscribeSessionMessageEvents: SessionMessageSubscriberRegistry["subscribe"];
  unsubscribeSessionMessageEvents: SessionMessageSubscriberRegistry["unsubscribe"];
  unsubscribeAllSessionEvents: (connId: string) => void;
  getSessionEventSubscriberConnIds: () => ReadonlySet<string>;
  getSessionMessageSubscriberConnIds?: (sessionKey: string) => ReadonlySet<string>;
  registerToolEventRecipient: (runId: string, connId: string) => void;
};

/** Resident-owned services bridged into request handling by the server lifecycle. */
type GatewayResidentBridgeContext = {
  getGatewayMethodRegistry?: () => import("../methods/registry.js").GatewayMethodRegistry;
  controlUiSessionPullRequests?: ReturnType<
    typeof import("../control-ui-session-pr-subscriptions.js").createControlUiSessionPullRequestSubscriptions
  >;
  sessionViewerPresence?: ReturnType<
    typeof import("../session-viewer-presence.js").createSessionViewerPresenceDeclarations
  >;
  applyPluginLifecycleChange?: import("../../plugins/lifecycle.js").PluginLifecycleRuntimeApply;
  refreshHealthSnapshot: (opts?: {
    probe?: boolean;
    includeSensitive?: boolean;
  }) => Promise<HealthSummary>;
  /** Durable cloud-worker lifecycle; absent from lightweight in-process contexts. */
  workerEnvironmentService?: WorkerEnvironmentServiceContract;
  /** Gateway-host desktop acquisition and observation; present only after enabled startup. */
  hostDesktopService?: import("../desktop/host-source.js").HostDesktopService;
  /** Experimental OpenClaw ID remote access owner; inert while its Labs switch is off. */
  openclawIdService?: import("../openclaw-id/service.js").OpenClawIdService;
  /** Local computer provider shared with the node host, owned by this Gateway lifetime. */
  gatewayComputerService?: import("../desktop/computer-service.js").GatewayComputerService;
  /** Durable per-session worker placement; absent only from lightweight in-process contexts. */
  workerSessionPlacementService?: WorkerSessionPlacementReader &
    Partial<WorkerSessionPlacementRetirementService> &
    Partial<
      Pick<WorkerSessionPlacementStore, "withWorkspaceExclusion" | "withLocalWorkspaceReservation">
    >;
  /** Process-local health samples fenced to the exact active placement owner. */
  workerPlacementDiskSpaceReader?: WorkerPlacementDiskSpaceReader;
  /** Process-current paired-device runner proof for active placement projection. */
  workerPlacementRunnerAvailabilityReader?: WorkerPlacementRunnerAvailabilityReader;
  /** Process-local installation progress for the placement's session-host node. */
  workerPlacementRuntimeInstallReader?: WorkerPlacementRuntimeInstallReader;
  /** Use-time approval authority validation over the live run/worker owners. */
  validateAgentRuntimeApprovalAuthority?: AgentRuntimeApprovalAuthorityValidator;
  /** One-way local-to-worker dispatch; absent when cloud workers are disabled. */
  workerPlacementDispatchService?: WorkerPlacementDispatchContract;
  workerRepositoryWorkspaceMutationService?: ReturnType<
    typeof import("../worker-environments/repository-workspace-mutation.js").createRepositoryWorkspaceMutationService
  >;
  githubPublicationService?: import("../github-publication.js").GitHubPublicationCoordinator;
  githubOAuthService?: ReturnType<
    typeof import("../github-oauth-lifecycle.js").createGitHubOAuthLifecycle
  >;
  modelAccountConnectService?: ReturnType<
    typeof import("../model-account-connect.js").createModelAccountConnectService
  >;
  getRuntimeSnapshot: (options?: ChannelRuntimeSnapshotOptions) => ChannelRuntimeSnapshot;
  getEventLoopHealth?: () => GatewayEventLoopHealth | undefined;
  getConfigReloaderHotReloadStatus?: () => GatewayHotReloadStatus | undefined;
  getPluginReloadStatus?: () => GatewayPluginReloadStatus | undefined;
  getDeferredChannelReloads?: () => readonly GatewayDeferredChannelReload[];
  startChannel: (
    channel: import("../../channels/plugins/types.public.js").ChannelId,
    accountId?: string,
    opts?: StartChannelOptions,
  ) => Promise<ReadonlyMap<string, ChannelAccountStartOutcome>>;
  stopChannel: (
    channel: import("../../channels/plugins/types.public.js").ChannelId,
    accountId?: string,
  ) => Promise<void>;
  markChannelLoggedOut: (
    channelId: import("../../channels/plugins/types.public.js").ChannelId,
    cleared: boolean,
    accountId?: string,
  ) => void;
  broadcastVoiceWakeChanged: (triggers: string[]) => void;
  broadcastVoiceWakeRoutingChanged: (
    config: import("../../infra/voicewake-routing.js").VoiceWakeRoutingConfig,
  ) => void;
};

export type GatewayContextResolver = () => GatewayRequestContext | undefined;
export type GatewayRequestContext = GatewayKernelContext &
  GatewayTransportContext &
  GatewayResidentBridgeContext & {
    /** Retains original execution while callers may receive an early response. */
    trackExecution: typeof import("../../shared/async-work-scope.js").trackAsyncWork;
    /** Local commands can dispatch methods without owning a Gateway server. */
    localEmbedded?: true;
    /** Live instance routing only; never authorization or wire state. */
    resolveGatewayContext?: GatewayContextResolver;
    hostLifecycle?: import("../server-public.js").GatewayHostLifecycle;
    /** Entry-only access; the kernel owns closure. Absent in embedded-only contexts. */
    requestEntryLifetime?: Pick<
      import("../server-request-entry.js").GatewayRequestEntryLifetime,
      "enter" | "signal" | "retainedSignal"
    >;
  };

/** Full dispatch context for raw request frames before params are normalized. */
export type GatewayRequestOptions = {
  /** Transport can forward trusted worker JSON without materializing it. */
  acceptsSerializedJson?: boolean;
  /** Transport can reuse worker-produced raw deflate with the default 15-bit window. */
  acceptsDeflatedSegments?: boolean;
  req: RequestFrame;
  client: GatewayClient | null;
  isWebchatConnect: (params: ConnectParams | null | undefined) => boolean;
  respond: RespondFn;
  context: GatewayRequestContext;
  methodRegistry?: GatewayMethodRegistryView;
  /** Shared entry/publication precondition; never retained as accepted-run authority. */
  expectedProfileBinding?: import("../expected-profile.js").ExpectedProfileBinding;
  /** In-process source refresh before handler entry; never retained by the handler. */
  prepareDispatchCurrent?: () => Promise<void>;
  /**
   * In-process Gateway lifetime guard composed into durable session mutations.
   * @deprecated For approval persistence use api.runtime.gateway.request with host-bound authority;
   * opaque approval commit callbacks are removed after an announced ordinary stable release window.
   */
  sessionMutationCommitGuard?: () => void;
  /** In-process caller lifetime; never serialized into a Gateway request frame. */
  signal?: AbortSignal;
  /** Live transport authority; in-process only and never derived from request data. */
  hasCurrentClientAuthority?: () => boolean;
};

/** Commit-time guard captured by the pre-dispatch session participation check. */
export type SessionMutationAuthorization = {
  /** Reuse the exact retained target's membership at synchronous mutation fences. */
  readTargetSharing?: (target: {
    sessionKey: string;
    agentId?: string;
  }) => import("../session-sharing-read.js").PreparedMutationSharing;
  /** Release the request's retained sharing facts after its final effect. */
  release?: () => void;
  /** Retain these facts until a detached effect settles, independently of the request. */
  retain?: () => () => void;
  /** Retain published sharing facts for a run, independently of request and writer guards. */
  retainForRun?: () => { assertCurrent: () => void; release: () => void };
  /** Transfer retained facts to admitted work; request cleanup then leaves them with that owner. */
  takeRelease?: () => () => void;
  bindCreation?: (
    target: { sessionKey?: string; key?: string; agentId?: string },
    operation: import("../../config/sessions/session-accessor.sqlite-entry-cache.types.js").SessionEntryCreationOperation,
  ) => void;
  /** Follow only the selected creator execution's own registry receipts. */
  followRegistration?: (
    target: { sessionKey: string; agentId: string },
    change: import("../../state/openclaw-agent-db-contract.js").AgentDatabaseRegistryChange,
  ) => void;
  /** Consume fresh durable facts while their physical reader remains retained. */
  withCurrent?: <T>(consume: () => T) => Promise<T>;
  withPreparedCurrent?: <T>(
    facts: {
      agentId: string;
      storePath: string;
      sessionKey: string;
      entry: import("../../config/sessions/types.js").SessionEntry | undefined;
      readSource?: import("../../config/sessions/session-entry-read-source.types.js").CapturedSessionEntryReadSource;
      members: readonly import("../../config/sessions/session-membership-facts.types.js").SessionMember[];
    },
    consume: () => T,
    assertSourceCurrent: () => void,
  ) => T;
  talkSessionTarget?: import("../talk/session-target.types.js").PreparedTalkSessionTarget;
  /** Original materialized target; Stop must match producer facts, not a later row lookup. */
  admittedTarget?: Readonly<{ agentId: string; sessionKey: string; sessionId: string }>;
  assertCurrent: () => void;
  /** Prepare captured agent-store reads before a shared-state worker takes its write lock. */
  prepareWorkerGrant?: (
    target?: Omit<
      import("../../config/sessions/session-source-authority.js").SessionSourceTransactionGrant,
      "assertCurrent"
    >,
  ) => Promise<{
    assertCurrent: () => void;
    assertLifetimeCurrent: () => void;
    release: () => void | Promise<void>;
    transaction?: import("../../config/sessions/session-source-authority.js").SessionSourceTransactionGrant;
  }>;
  /** Original host/session authority for committed input custody, without the selection precondition. */
  assertAdmittedInputCurrent?: () => void;
  /** Original host/operator authority; forwarded input owns its current session policy. */
  assertAdmittedSourceCurrent?: () => void;
  /** Fresh sharing facts for runtime custody; synchronous methods retain the released SDK contract. */
  admittedInputAuthority?: import("../../config/sessions/session-pending-input-authority.js").SessionPendingInputAuthority;
  /** Creation-owner notification after COMMIT; binds only this request's previously absent row. */
  recordCreatedSession?: (target: {
    entry?: import("../../config/sessions/types.js").SessionEntry;
    agentId: string;
    sessionKey: string;
    storePath: string;
    sessionId: string;
    lifecycleRevision?: string;
    readSource?: import("../../config/sessions/session-entry-read-source.types.js").CapturedSessionEntryReadSource;
  }) => void;
  assertTargetCurrent: (target: {
    sessionKey: string;
    agentId?: string;
    /** Internal ensure result: may materialize a previously id-less Talk target, never replace it. */
    ensuredSessionId?: string;
  }) => void;
};

/** Normalized method invocation options passed to registered handlers. */
export type GatewayRequestHandlerOptions = Omit<
  GatewayRequestOptions,
  "methodRegistry" | "expectedProfileBinding" | "prepareDispatchCurrent"
> & {
  params: Record<string, unknown>;
  /** Plugin registrations receive a live owner fence; recheck after awaits and before effects. */
  assertHandlerCurrent?: () => void;
  sessionMutationAuthorization?: SessionMutationAuthorization;
  /** Source-authorized plugin adoption; bound to this request's caller and lifetime. */
  copySessionCatalogToGateway?: (source: {
    provider: import("../../plugins/session-catalog.js").SessionCatalogProvider;
    request: import("../../../packages/gateway-protocol/src/index.js").SessionsCatalogContinueParams;
    assertCurrent: () => void;
    /** Resolve an existing handoff under read policy; never imports, creates, or binds. */
    resolveOnly?: true;
  }) => Promise<void>;
  sessionCreationOperation?: import("../../config/sessions/session-creation-operation.js").SessionCreationOperation;
  /** Synchronously consume current chat.send authority without starting a turn. */
  withSessionTurnAuthority?: <T>(
    target: { sessionKey: string; agentId?: string; sessionId: string },
    consume: (entry: import("../../config/sessions/types.js").InternalSessionEntry) => T,
  ) => Promise<T>;
  diffTiming?: DiffReadTiming;
  markSessionSubscribePhase?: (
    phase: import("../slow-request-diagnostics.js").SessionSubscribePhase,
  ) => void;
  /** Host-prepared session resource authority; services explicitly retain their own borrow. */
  sessionAccessAuthority?: import("../session-access-authority.js").GatewaySessionAccessAuthority;
};

export type GatewayRequestHandler = ((
  opts: GatewayRequestHandlerOptions,
) => Promise<void> | void) & {
  prepareRead?: import("./prepared-read.js").GatewayReadPreparation;
  onReadError?: import("./prepared-read.js").GatewayReadErrorHandler;
};

export type GatewayRequestHandlers = Record<string, GatewayRequestHandler>;

export type SessionEventProjection = {
  payload: unknown;
  /** Delivery-owned UTF-8 session field, including the closing payload brace. */
  serializeSession?: () => Buffer;
  /** Publication-owned UTF-8 message field, including its trailing comma. */
  serializeMessage?: () => Buffer;
  /** Producer-owned payload fragments preserve shared message and session byte identity. */
  serializePayload?: () => readonly Buffer[];
  delivered?: (client: GatewayClient) => void;
};

type SessionEventProjectionScope = {
  sessionKeys: readonly string[];
  agentId?: string;
};

/** Connection-owned receipts and run display facts, consumed within one publication. */
type SessionEventProjectionContext = {
  isCurrentProjection: (owner: object) => boolean;
  resolveAgentScope: (
    key: string,
    agentId?: string,
  ) => readonly [string | undefined, string | undefined, string | undefined] | null;
  forgetAncestors: (key?: string) => void;
  references: (client: GatewayClient) => ConnectionSessionRows;
  createRunProjector: () => VisibleActiveSessionRunProjector;
};

export type PrepareSessionEventProjection = (
  event: string,
  payload: unknown,
  scope: SessionEventProjectionScope,
  context: SessionEventProjectionContext,
) => ((client: GatewayClient) => SessionEventProjection | undefined) | undefined;

type GatewayBroadcastStateVersion = {
  presence?: number;
  health?: number;
};

export type GatewayBroadcastOpts = {
  /** Agent scope for agent-relative keys such as `global`. */
  agentId?: string;
  dropIfSlow?: boolean;
  /** Omit a redundant projection for clients that advertise this capability. */
  excludeClientCapability?: GatewayClientCap;
  /** Canonical subscription keys for session-scoped delivery. */
  sessionKeys?: readonly string[];
  /** Producer-resolved exact subscription keys for traffic attribution; never changes recipients. */
  sessionEventSubscriptionKeys?: readonly string[];
  /** Prepared facts remain valid only during this synchronous publication. */
  prepareSessionProjection?: PrepareSessionEventProjection;
  /** Target recipients were selected from subscriptions at ingress. */
  sessionSubscriptionVerified?: boolean;
  /** Question owner authorizes ordinary own-run recipients without a broad question grant. */
  questionRecipient?: (client: GatewayClient) => boolean;
  stateVersion?: GatewayBroadcastStateVersion;
  /** Private live-text ownership; omitting coalesce flushes this group's progress. */
  liveText?: {
    group: AbortSignal;
    /** Source continuity changes without revoking already queued publications. */
    sourceEpoch?: object;
    /** Accepted terminal barrier; drain current queued text before retiring its group. */
    settle?: true;
    isCurrent?: () => boolean;
    coalesce?: { key: string; merge: (previous: unknown, next: unknown) => unknown };
    /** Full internal payloads become append-only only after this socket has a baseline. */
    projection?: {
      key: string;
      delta: (payload: unknown) => unknown;
      /** Upper bound for encoded full payload bytes, without encoding cumulative text. */
      snapshotBytes?: (payload: unknown, deltaPayloadBytes: number) => number;
      version?: unknown;
      snapshot?: boolean;
      /** Verify transformed snapshots against the prior publication before omitting them. */
      text?: LiveTextProjectionText;
    };
  };
};

export type GatewayBroadcastFn = (
  event: string,
  payload: unknown,
  opts?: GatewayBroadcastOpts,
) => void;

export type GatewayBroadcastToConnIdsFn = (
  event: string,
  payload: unknown,
  connIds: ReadonlySet<string>,
  opts?: GatewayBroadcastOpts,
) => void;

/** Current queued outbound bytes for one live gateway connection. */
export type GatewayBufferedAmountFn = (connId: string) => number | undefined;

export type GatewayPluginEventScope = "operator.read" | "operator.write" | "operator.admin";

/** Broadcasts a namespaced plugin event under an explicit operator scope. */
export type GatewayPluginEventBroadcastFn = (
  event: string,
  payload: unknown,
  scope: GatewayPluginEventScope,
) => void;

export type SessionRuntimeScope = {
  storePath: string;
  physicalPaths?: (locator: string, agentId?: string) => readonly string[];
  resolveGatewayContext?: GatewayContextResolver;
};

export type VisibleActiveSessionRunState = {
  active: boolean;
  /** Complete exact active set. Omitted when another active owner exposes only liveness. */
  runIds?: string[];
  status?: "queued";
};

export type VisibleActiveSessionRunSelection = Omit<SessionRuntimeScope, "storePath"> & {
  storePath?: string;
  requestedKey: string;
  canonicalKey: string;
  sessionId?: string;
  agentId?: string;
  defaultAgentId?: string;
};

export type VisibleActiveSessionRunProjector = (
  params: Omit<VisibleActiveSessionRunSelection, "physicalPaths">,
) => VisibleActiveSessionRunState;
