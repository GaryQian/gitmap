import { z } from "zod";
import { GatewayOperatorRoleDefinitionSchema } from "../config/zod-schema.gateway-roles.js";
import { freezeJsonSnapshot } from "../shared/immutable-data.js";
import { userChannelAuthorizationReferenceSchema } from "../state/user-channel-authorization-reference.js";
import { openClawIdRecoveryPrincipalSchema } from "./openclaw-id/tunnel-principal-schema.js";

const MAX_RECOVERY_SOURCE_BYTES = 65_536;
const boundedString = z.string().min(1).max(4096);
const refs = z.strictObject({
  exact: z.array(boundedString).max(4096),
  wildcards: z.array(boundedString).max(256),
});
const handshakeRecoverySnapshotSchema = z.strictObject({
  profileId: boundedString,
  openclawIdPrincipal: openClawIdRecoveryPrincipalSchema.optional(),
  scopes: z.array(boundedString).max(64),
  assignedRole: boundedString.nullable(),
  githubLogin: boundedString.nullable(),
  rolePolicy: GatewayOperatorRoleDefinitionSchema.omit({ modelPolicy: true }).optional(),
  modelPolicy: z
    .strictObject({
      models: z.array(z.strictObject({ provider: boundedString, model: boundedString })).max(4096),
      allowed: refs,
      denied: refs,
    })
    .optional(),
  grant: z.strictObject({ pluginId: boundedString, grantId: boundedString }).nullable(),
  aliasBindingIds: z.array(boundedString).max(256),
  authPolicy: z.strictObject({
    generation: z.literal(""),
    grantGeneration: boundedString,
    role: z.literal("operator"),
    authMethod: z.enum(["token", "password", "device-token", "tailscale", "trusted-proxy"]),
    authModeOverride: z.enum(["none", "token", "password", "trusted-proxy"]).optional(),
    verifiedIdentity: boundedString.optional(),
    fallbackCredentialGeneration: boundedString.optional(),
    browserOrigin: z
      .strictObject({
        requestHost: boundedString.optional(),
        origin: boundedString.optional(),
        isLocalClient: z.boolean().optional(),
        openclawIdTunnel: z.boolean().optional(),
      })
      .optional(),
  }),
  sharedGeneration: boundedString.optional(),
  device: z
    .strictObject({ deviceId: boundedString, key: z.string().regex(/^[a-f0-9]{64}$/) })
    .optional(),
  // Optional for persisted pre-native-parity sources; browser grants keep their original meaning.
  automationAdmin: z.boolean().optional(),
  controlUiAdmin: z.boolean(),
  localOperator: z.boolean(),
  sourceIngress: z.enum(["control-ui", "internal"]),
});
const principalRecoverySnapshotSchema = handshakeRecoverySnapshotSchema.extend({
  sourceIngress: z.literal("principal"),
  ingress: z.strictObject({
    pluginId: boundedString,
    audienceId: boundedString,
    recoveryId: boundedString,
  }),
  authPolicy: z.undefined().optional(),
  sharedGeneration: z.undefined().optional(),
  device: z.undefined().optional(),
  automationAdmin: z.undefined().optional(),
  controlUiAdmin: z.literal(false),
  localOperator: z.literal(false),
});
const operatorRunRecoverySnapshotSchema = z.discriminatedUnion("sourceIngress", [
  handshakeRecoverySnapshotSchema,
  principalRecoverySnapshotSchema,
]);
const parentSourceSchema = z.strictObject({
  kind: z.undefined().optional(),
  version: z.literal(1),
  agentId: boundedString,
  sessionKey: boundedString,
  // Older sources also recorded the conversation's transcript id and revision; both are ignored.
  sessionId: boundedString.optional(),
  lifecycleRevision: boundedString.optional(),
  sourceRunId: boundedString,
  snapshot: operatorRunRecoverySnapshotSchema,
});

// Existing parent-bound sources retain their stored shape. Device-backed jobs need no parent.
const sourceSchema = z.union([
  parentSourceSchema,
  z.strictObject({
    version: z.literal(1),
    kind: z.literal("gateway"),
    agentId: boundedString,
    sourceRunId: boundedString,
    snapshot: operatorRunRecoverySnapshotSchema,
  }),
]);

const channelSnapshotSchema = z.strictObject({
  reference: userChannelAuthorizationReferenceSchema,
  profileId: boundedString,
  scopes: handshakeRecoverySnapshotSchema.shape.scopes,
  modelPolicy: handshakeRecoverySnapshotSchema.shape.modelPolicy,
});
const recoveryUnavailableReasonSchema = z.enum([
  "remote-ingress-no-source",
  "unauthenticated",
  "no-auth-method",
  "no-grant",
  "device-no-token",
  "shared-auth-no-generation",
  "model-policy",
  "channel-model-policy",
  "decode-failed",
  "no-source",
]);
export type OperatorRecoveryUnavailableReason = z.infer<typeof recoveryUnavailableReasonSchema>;

const queuedSourceSchema = z.discriminatedUnion("kind", [
  z.strictObject({ kind: z.literal("gateway"), snapshot: operatorRunRecoverySnapshotSchema }),
  z.strictObject({ kind: z.literal("channel"), snapshot: channelSnapshotSchema }),
  z.strictObject({
    kind: z.literal("unavailable"),
    reason: recoveryUnavailableReasonSchema.optional(),
  }),
]);

/** Private accepted-input basis; only its current input owner may restore authority. */
export type QueuedOperatorRecoverySource = z.infer<typeof queuedSourceSchema>;

export function decodeQueuedOperatorRecoverySource(value: unknown): QueuedOperatorRecoverySource {
  const json = JSON.stringify(value);
  if (!json || Buffer.byteLength(json, "utf8") > MAX_RECOVERY_SOURCE_BYTES) {
    throw new Error("Queued operator recovery source exceeds its storage bound.");
  }
  const parsed = queuedSourceSchema.safeParse(value);
  if (!parsed.success) {
    throw new Error("Queued operator recovery source is invalid; submit a new request.");
  }
  return freezeJsonSnapshot(parsed.data);
}

/** Original authenticated basis, not an executable grant or a transport credential. */
export type OperatorRunRecoverySnapshot = z.infer<typeof operatorRunRecoverySnapshotSchema>;

/** Private input custody; copied attribution or another session cannot authorize recovery. */
export type RestartRecoveryOperatorSource = z.infer<typeof sourceSchema>;

export function decodeGatewayOperatorRecoverySource(value: unknown): RestartRecoveryOperatorSource {
  const json = JSON.stringify(value);
  if (!json || Buffer.byteLength(json, "utf8") > MAX_RECOVERY_SOURCE_BYTES) {
    throw new Error("Restart recovery operator source exceeds its storage bound.");
  }
  const parsed = sourceSchema.safeParse(value);
  if (!parsed.success) {
    throw new Error("Restart recovery operator source is invalid; start a new user turn.");
  }
  return freezeJsonSnapshot(parsed.data);
}

/** Canonical bounded evidence shared by admission and durable recovery. */
export function normalizeGatewayOperatorRecoverySnapshot(
  value: unknown,
): OperatorRunRecoverySnapshot | undefined {
  const json = JSON.stringify(value);
  if (!json || Buffer.byteLength(json, "utf8") > MAX_RECOVERY_SOURCE_BYTES) {
    return undefined;
  }
  // Admission must capture the same optional-field shape the durable claim
  // reloads; canonicalization belongs here, not in a permissive comparison.
  const parsed = operatorRunRecoverySnapshotSchema.safeParse(JSON.parse(json));
  return parsed.success ? freezeJsonSnapshot(parsed.data) : undefined;
}

/** Legacy browser sources retain delegation; other historical sources never gain it. */
export function hasAutomationAdminDelegation(snapshot: OperatorRunRecoverySnapshot): boolean {
  return (
    snapshot.sourceIngress !== "principal" &&
    (snapshot.automationAdmin ?? snapshot.controlUiAdmin) &&
    snapshot.scopes.includes("operator.admin")
  );
}
