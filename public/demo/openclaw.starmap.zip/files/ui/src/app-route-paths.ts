import { normalizeAtHashSlug } from "@openclaw/normalization-core/string-normalization";
import {
  inferControlUiFocusBasePath,
  matchControlUiCatalogSharePath,
  SESSION_UUID_SUFFIX_RE,
} from "@openclaw/session-url-contract";
import {
  normalizeRouteBasePath as normalizeBasePath,
  normalizeRoutePath as normalizePath,
} from "@openclaw/uirouter";
import type { RouteLocation } from "@openclaw/uirouter";
import { isValidWorkboardBoardId } from "@openclaw/workboard-contract";
import {
  pluginCatalogIdFromRouteSuffix,
  pluginCatalogRouteSuffix,
} from "../../packages/plugin-package-contract/src/catalog-route.ts";
import { DEFAULT_AGENT_PANEL, isAgentsPanel, type AgentsPanel } from "./lib/agents/panels.ts";
import type { BoardFace } from "./lib/board/settings.ts";
import { takeGraphemes } from "./lib/graphemes.ts";

export const INTERNAL_AGENT_PATH_PARAM = "__openclawAgentPath";
export const INTERNAL_ACTIVITY_PATH_PARAM = "__openclawActivityPath";
export const INTERNAL_TERMINAL_PATH_PARAM = "__openclawTerminalPath";
export const INTERNAL_SESSION_PATH_PARAM = "__openclawSessionPath";
export const INTERNAL_MEMORY_PATH_PARAM = "__openclawMemoryPath";
export const INTERNAL_PLUGINS_PATH_PARAM = "__openclawPluginsPath";
export const INTERNAL_PLUGIN_SETTINGS_PATH_PARAM = "__openclawPluginSettingsPath";
export const INTERNAL_SKILLS_PATH_PARAM = "__openclawSkillsPath";
export const INTERNAL_SKILL_SETTINGS_PATH_PARAM = "__openclawSkillSettingsPath";
export const INTERNAL_TEMPLATES_PATH_PARAM = "__openclawTemplatesPath";
export const INTERNAL_WORKBOARD_PATH_PARAM = "__openclawWorkboardPath";
export const CONTROL_UI_DOCUMENT_ROUTE_PATHS = {
  approval: "/approve",
  question: "/ask",
} as const;

export type MemoryRouteTab = "overview" | "memories" | "dreams" | "settings";

type AgentRoutePath = {
  agentId: string;
  panel: AgentsPanel;
  panelSegment: AgentsPanel | null;
  invalidPanel: boolean;
};

const APP_ROUTE_DEFINITIONS = {
  settings: { path: "/settings" },
  chat: { path: "/chat" },
  terminal: { path: "/terminal" },
  dashboard: { path: "/dashboard" },
  dashboards: { path: "/dashboards" },
  custodian: { path: "/custodian" },
  "new-session": { path: "/new" },
  activity: { path: "/activity" },
  meetings: { path: "/meetings" },
  apps: { path: "/apps" },
  portals: { path: "/portals" },
  templates: { path: "/templates" },
  agents: { path: "/settings/agents" },
  channels: { path: "/settings/channels", aliases: ["/channels"] },
  connection: { path: "/settings/connection" },
  config: { path: "/settings/general", aliases: ["/config"] },
  profile: { path: "/settings/profile", aliases: ["/profile"] },
  communications: { path: "/settings/communications", aliases: ["/communications"] },
  appearance: { path: "/settings/appearance", aliases: ["/appearance"] },
  lobsterdex: { path: "/settings/lobsterdex", aliases: ["/lobsterdex"] },
  device: { path: "/settings/device" },
  "device-permissions": { path: "/settings/device/permissions" },
  notifications: { path: "/settings/notifications" },
  security: { path: "/settings/security" },
  secrets: { path: "/settings/secrets" },
  advanced: { path: "/settings/advanced" },
  approvals: { path: "/settings/approvals" },
  automation: { path: "/settings/automation", aliases: ["/automation"] },
  mcp: { path: "/settings/mcp", aliases: ["/mcp"] },
  memory: { path: "/settings/memory" },
  search: { path: "/settings/search" },
  talk: { path: "/settings/talk" },
  infrastructure: { path: "/settings/infrastructure", aliases: ["/infrastructure"] },
  labs: { path: "/settings/labs" },
  updates: { path: "/settings/updates" },
  about: { path: "/settings/about" },
  "ai-agents": { path: "/settings/ai-agents", aliases: ["/ai-agents"] },
  "model-setup": { path: "/settings/model-setup", aliases: ["/model-setup"] },
  "model-providers": { path: "/settings/model-providers", aliases: ["/model-providers"] },
  // Memory import, sessions, and worktrees are workspace destinations; the
  // /settings/* aliases keep pre-restructure bookmarks and deep links working.
  "memory-import": { path: "/memory-import", aliases: ["/settings/memory-import"] },
  workboard: { path: "/workboard" },
  worktrees: { path: "/worktrees", aliases: ["/settings/worktrees"] },
  sessions: { path: "/sessions", aliases: ["/settings/sessions"] },
  systems: { path: "/systems" },
  usage: { path: "/usage" },
  debug: { path: "/debug" },
  logs: { path: "/logs" },
  "skill-workshop": { path: "/skills/workshop" },
  skills: { path: "/skills" },
  "skill-settings": { path: "/settings/skills" },
  plugins: { path: "/plugins" },
  "plugin-settings": { path: "/settings/plugins" },
  // Automations is the product name; /cron stays as a legacy alias for
  // pre-rename bookmarks and deep links.
  cron: { path: "/automations", aliases: ["/cron"] },
  devices: { path: "/settings/devices", aliases: ["/nodes"] },
  "cloud-workers": { path: "/settings/cloud-workers" },
  plugin: { path: "/plugin" },
} as const;

export type RouteId = keyof typeof APP_ROUTE_DEFINITIONS;
// SAFETY: Object.keys returns only the own keys of this closed route catalog.
export const APP_ROUTE_IDS = Object.keys(APP_ROUTE_DEFINITIONS) as RouteId[];
export const APP_ROUTE_PATHS: string[] = [];
const ROUTE_ID_BY_PATH = new Map<string, RouteId>();
// Static paths and aliases share one prepared index; earlier declarations keep priority.
for (const routeId of APP_ROUTE_IDS) {
  const definition = APP_ROUTE_DEFINITIONS[routeId];
  const paths: readonly string[] =
    "aliases" in definition ? [definition.path, ...definition.aliases] : [definition.path];
  for (const path of paths) {
    const normalizedPath = normalizePath(path);
    APP_ROUTE_PATHS.push(normalizedPath);
    if (!ROUTE_ID_BY_PATH.has(normalizedPath)) {
      ROUTE_ID_BY_PATH.set(normalizedPath, routeId);
    }
  }
}

const NATIVE_ROUTE_SEGMENTS = new Set(APP_ROUTE_PATHS.map((path) => path.split("/")[1]));

const INTERNAL_PLUGIN_PATH_PARAM = "__openclawPluginPath";
export type PluginTab = { pluginId: string; id: string; slug?: string; placement?: string };
const tabsBySlug = new Map<string, PluginTab>();
const warnedSlugs = new Set<string>();

function pluginTabSlug(tab: PluginTab): string | undefined {
  const slug = tab.slug;
  if (!slug) {
    return undefined;
  }
  if (NATIVE_ROUTE_SEGMENTS.has(slug)) {
    if (!warnedSlugs.has(slug)) {
      warnedSlugs.add(slug);
      console.warn(`[openclaw] /${slug} is a native route; using /plugin.`);
    }
    return undefined;
  }
  return slug;
}

export function setPluginTabSlugs(tabs: readonly PluginTab[] = []): void {
  tabsBySlug.clear();
  for (const tab of tabs) {
    const slug = pluginTabSlug(tab);
    if (slug && !tabsBySlug.has(slug)) {
      tabsBySlug.set(slug, tab);
    }
  }
}

export function pluginSlugCandidate(pathname: string, basePath = ""): string | null {
  const path = normalizePath(pathname);
  const base = normalizeBasePath(basePath);
  if (!path.startsWith(`${base}/`)) {
    return null;
  }
  const slug = path.slice(base.length + 1);
  return slug.length <= 64 &&
    /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug) &&
    !NATIVE_ROUTE_SEGMENTS.has(slug)
    ? slug
    : null;
}

export function pluginTabSlugFromPath(pathname: string, basePath = ""): PluginTab | null {
  return tabsBySlug.get(pluginSlugCandidate(pathname, basePath) ?? "") ?? null;
}

export function pluginTabRefFromSearch(
  search: string,
  pathname = "",
  basePath = "",
): Pick<PluginTab, "pluginId" | "id"> {
  const params = new URLSearchParams(search);
  const tab = pluginTabSlugFromPath(params.get(INTERNAL_PLUGIN_PATH_PARAM) ?? pathname, basePath);
  return {
    pluginId: tab?.pluginId ?? params.get("plugin")?.trim() ?? "",
    id: tab?.id ?? params.get("id")?.trim() ?? "",
  };
}

/** Stable key for one tab; ids are only unique per plugin, so both parts matter. */
export function pluginTabKey(ref: Pick<PluginTab, "pluginId" | "id">): string {
  return `${ref.pluginId}/${ref.id}`;
}

/** The advertised tab owns navigation placement, including direct sign-in links. */
export function pluginTabForLocation<T extends PluginTab>(
  tabs: readonly T[] | undefined,
  location: Pick<RouteLocation, "pathname" | "search"> | undefined,
  basePath = "",
): T | undefined {
  const key = pluginTabKey(
    pluginTabRefFromSearch(location?.search ?? "", location?.pathname, basePath),
  );
  return tabs?.find((tab) => pluginTabKey(tab) === key);
}

export function pluginTabLocation(tab: PluginTab, basePath = ""): RouteLocation {
  const slug = pluginTabSlug(tab);
  return {
    pathname: slug ? `${normalizeBasePath(basePath)}/${slug}` : pathForRoute("plugin", basePath),
    search: slug ? "" : `?${new URLSearchParams({ plugin: tab.pluginId, id: tab.id })}`,
    hash: "",
  };
}

export function canonicalPluginTabLocation(location: RouteLocation, basePath = ""): RouteLocation {
  if (normalizePath(location.pathname) !== pathForRoute("plugin", basePath)) {
    return location;
  }
  const search = new URLSearchParams(location.search);
  const tab = [...tabsBySlug.values()].find(
    (entry) => entry.pluginId === search.get("plugin") && entry.id === search.get("id"),
  );
  if (!tab) {
    return location;
  }
  const params = new URLSearchParams([...search].filter(([key]) => key.startsWith("p.")));
  return {
    ...pluginTabLocation(tab, basePath),
    search: params.size ? `?${params}` : "",
    hash: location.hash,
  };
}

export function isRouteId(routeId: string): routeId is RouteId {
  return Object.hasOwn(APP_ROUTE_DEFINITIONS, routeId);
}

// Single source for page definitions: ui/src/pages/*/route.ts spreads this
// into definePage so router matching can never drift from the table that
// drives routeIdFromPath and base-path inference.
export function routePageSpec<Id extends RouteId>(
  routeId: Id,
): { id: Id; path: string; aliases?: readonly string[] } {
  return { id: routeId, ...APP_ROUTE_DEFINITIONS[routeId] };
}

export { normalizeBasePath };

export function isApplicationEntryPath(pathname: string, basePath: string): boolean {
  const path = normalizePath(pathname);
  const base = normalizeBasePath(basePath);
  // The served index document and mount root share startup ownership. Other
  // index.html suffixes remain explicit destinations within this configured mount.
  return (
    path === (base || "/") ||
    (path.startsWith(`${base}/`) && path.slice(base.length).toLowerCase() === "/index.html")
  );
}

export function pathForRoute(routeId: RouteId, basePath = ""): string {
  return `${normalizeBasePath(basePath)}${APP_ROUTE_DEFINITIONS[routeId].path}`;
}

function routePathSuffix(pathname: string, routeId: RouteId, basePath: string): string | null {
  const normalizedPath = normalizePath(pathname);
  const routePath = pathForRoute(routeId, basePath);
  if (normalizedPath === routePath) {
    return "";
  }
  const prefix = `${routePath}/`;
  return normalizedPath.startsWith(prefix) ? normalizedPath.slice(prefix.length) || null : null;
}

/** Legacy person query accepted by existing Activity links. */
export const ACTIVITY_PERSON_PARAM = "person";
const ACTIVITY_PERSON_SHORT_REF_RE = /(?:^|-)([0-9a-f]{8,32})$/u;

function isProfileUuid(id: string): boolean {
  return id.length === 36 && SESSION_UUID_SUFFIX_RE.test(id);
}

/** Activity feed scoped to one person, for every surface that shows an identity. */
export function activityPersonLocation(
  personId: string,
  basePath = "",
  label?: string,
  minimumRefLength = 12,
): { pathname: string; search: string; href: string } {
  const uuid = isProfileUuid(personId);
  const slug = takeGraphemes(normalizeAtHashSlug(label), 48).replace(/-+$/u, "");
  const reference = uuid
    ? `${slug ? `${slug}-` : ""}${personId.replaceAll("-", "").slice(0, minimumRefLength).toLowerCase()}`
    : personId;
  // A decorative name must not turn its short reference into another exact UUID.
  let encodedReference = encodeURIComponent(
    isProfileUuid(reference) ? `person-${reference}` : reference,
  ).replaceAll(".", "%2E");
  // Retained protocol identities can be literal strings; escape their short-ref delimiter.
  if (!uuid) {
    encodedReference = encodedReference.replace(/-(?=[0-9a-f]{8,32}$)/u, "%2D");
  }
  const pathname = `${pathForRoute("activity", basePath)}/${encodedReference}`;
  return { pathname, search: "", href: pathname };
}

export function activityPersonFromPath(pathname: string, basePath = ""): string | null {
  const reference = routePathSuffix(pathname, "activity", basePath);
  const personId = decodeRouteSegment(reference);
  if (!personId?.trim() || personId === "." || personId === "..") {
    return null;
  }
  // A full UUID is an exact identifier; its final group is not a short prefix.
  return isProfileUuid(personId)
    ? personId
    : (reference?.match(ACTIVITY_PERSON_SHORT_REF_RE)?.[1] ?? personId);
}

export function pathForWorkboardBoard(boardId: string, basePath = ""): string {
  if (!isValidWorkboardBoardId(boardId)) {
    throw new Error("Invalid Workboard board id.");
  }
  const encodedBoardId = encodeURIComponent(boardId).replaceAll(".", "%2E");
  return `${pathForRoute("workboard", basePath)}/${encodedBoardId}`;
}

export function pathForAgentPanel(
  agentId: string,
  panel: AgentsPanel | null = null,
  basePath = "",
): string {
  if (!agentId || agentId.includes("/") || agentId === "." || agentId === "..") {
    throw new Error("Invalid agent id for a route path.");
  }
  const encodedAgentId = encodeURIComponent(agentId).replaceAll(".", "%2E");
  const agentPath = `${pathForRoute("agents", basePath)}/${encodedAgentId}`;
  return panel ? `${agentPath}/${panel}` : agentPath;
}

export function agentRouteFromPath(pathname: string, basePath = ""): AgentRoutePath | null {
  const suffix = routePathSuffix(pathname, "agents", basePath);
  if (!suffix) {
    return null;
  }
  const segments = suffix.split("/");
  if (segments.length > 2 || !segments[0]) {
    return null;
  }
  const agentId = decodeRouteSegment(segments[0]);
  if (!agentId || agentId.includes("/") || agentId === "." || agentId === "..") {
    return null;
  }
  const rawPanel = segments[1] ?? null;
  const panelSegment = rawPanel && isAgentsPanel(rawPanel) ? rawPanel : null;
  return {
    agentId,
    panel: panelSegment ?? DEFAULT_AGENT_PANEL,
    panelSegment,
    invalidPanel: rawPanel !== null && panelSegment === null,
  };
}

export function pathForMemoryTab(tab: MemoryRouteTab, basePath = ""): string {
  const memoryPath = pathForRoute("memory", basePath);
  return tab === "overview" ? memoryPath : `${memoryPath}/${tab}`;
}

export function memoryTabFromPath(pathname: string, basePath = ""): MemoryRouteTab | null {
  const segment = routePathSuffix(pathname, "memory", basePath);
  if (segment === "") {
    return "overview";
  }
  return segment === "memories" || segment === "dreams" || segment === "settings" ? segment : null;
}

function isLegacyPluginsDiscoveryPath(pathname: string, basePath = ""): boolean {
  const normalizedPath = normalizePath(pathname);
  return normalizedPath === `${pathForRoute("plugin-settings", basePath)}/discover`;
}

function isPluginCatalogId(id: string): boolean {
  return /^[A-Za-z0-9_-]+$/u.test(id);
}

export function pathForPluginCatalogEntry(id: string, basePath = ""): string {
  if (!isPluginCatalogId(id)) {
    throw new Error("Invalid plugin catalog id for a route path.");
  }
  return `${pathForRoute("plugins", basePath)}/${pluginCatalogRouteSuffix(id)}`;
}

export function pluginCatalogIdFromPath(pathname: string, basePath = ""): string | null {
  const id = routePathSuffix(pathname, "plugins", basePath);
  return id ? pluginCatalogIdFromRouteSuffix(id) : null;
}

export function pathForTemplateCatalogEntry(packageName: string, basePath = ""): string {
  if (!isClawCatalogPackageName(packageName)) {
    throw new Error("Invalid Template package name for a route path.");
  }
  return `${pathForRoute("templates", basePath)}/packages/${encodeURIComponent(packageName)}`;
}

function isClawCatalogPackageName(value: string): boolean {
  return /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/u.test(value);
}

export function templateCatalogPackageNameFromPath(pathname: string, basePath = ""): string | null {
  const slug = routePathSuffix(pathname, "templates", basePath);
  if (slug?.startsWith("packages/")) {
    const packageName = decodeRouteSegment(slug.slice("packages/".length));
    return packageName && isClawCatalogPackageName(packageName) ? packageName : null;
  }
  // Preserve the original official-only detail links.
  return slug && /^[a-z0-9][a-z0-9._-]*$/u.test(slug) ? `@openclaw/${slug}` : null;
}

export function pathForPluginSettings(pluginId: string, basePath = ""): string {
  if (!pluginId || pluginId === "." || pluginId === "..") {
    throw new Error("Invalid plugin id for a route path.");
  }
  const encodedPluginId =
    pluginId === "discover" ? "%64iscover" : encodeURIComponent(pluginId).replaceAll(".", "%2E");
  return `${pathForRoute("plugin-settings", basePath)}/${encodedPluginId}`;
}

export function pluginSettingsIdFromPath(pathname: string, basePath = ""): string | null {
  const encodedPluginId = routePathSuffix(pathname, "plugin-settings", basePath);
  // This exact retired discovery route belongs to the Plugins workspace.
  if (encodedPluginId === "discover") {
    return null;
  }
  const pluginId = decodeRouteSegment(encodedPluginId);
  return pluginId && pluginId !== "." && pluginId !== ".." ? pluginId : null;
}

/** One skill's page: an installed skill by its key, or a ClawHub skill by its registry reference. */
export type SkillPageRef =
  | { kind: "installed"; skillKey: string }
  | { kind: "clawhub"; ref: string };

function encodeSkillSegment(value: string): string {
  return encodeURIComponent(value).replaceAll(".", "%2E");
}

function decodeSkillSegment(encoded: string | undefined): string | null {
  const value = decodeRouteSegment(encoded ?? null);
  return value?.trim() && value !== "." && value !== ".." ? value : null;
}

/** An installed skill opens under the list it was opened from: Skills or Settings › Skills. */
export function pathForInstalledSkill(
  skillKey: string,
  surface: "discovery" | "settings",
  basePath = "",
): string {
  if (!skillKey.trim() || skillKey === "." || skillKey === "..") {
    throw new Error("Invalid skill key for a route path.");
  }
  return surface === "settings"
    ? `${pathForRoute("skill-settings", basePath)}/${encodeSkillSegment(skillKey)}`
    : `${pathForRoute("skills", basePath)}/installed/${encodeSkillSegment(skillKey)}`;
}

/** A ClawHub reference keeps its own segments, so `@owner/slug` reads as it is written. */
export function pathForClawHubSkill(ref: string, basePath = ""): string {
  const segments = ref.split("/");
  if (!ref.trim() || segments.some((segment) => !segment || segment === "." || segment === "..")) {
    throw new Error("Invalid ClawHub skill reference for a route path.");
  }
  const encoded = segments.map((segment) =>
    encodeSkillSegment(segment).replaceAll("%40", "@").replaceAll("%3A", ":"),
  );
  return `${pathForRoute("skills", basePath)}/clawhub/${encoded.join("/")}`;
}

export function skillPageFromPath(pathname: string, basePath = ""): SkillPageRef | null {
  const settingsKey = routePathSuffix(pathname, "skill-settings", basePath);
  if (settingsKey) {
    const skillKey = decodeSkillSegment(settingsKey);
    return skillKey ? { kind: "installed", skillKey } : null;
  }
  const suffix = routePathSuffix(pathname, "skills", basePath);
  if (!suffix) {
    return null;
  }
  const [namespace, ...rest] = suffix.split("/");
  if (namespace === "installed" && rest.length === 1) {
    const skillKey = decodeSkillSegment(rest[0]);
    return skillKey ? { kind: "installed", skillKey } : null;
  }
  if (namespace === "clawhub" && rest.length > 0) {
    const segments = rest.map(decodeSkillSegment);
    return segments.every((segment) => segment !== null)
      ? { kind: "clawhub", ref: segments.join("/") }
      : null;
  }
  return null;
}

function isSkillsPagePath(pathname: string, basePath = ""): boolean {
  return (
    routePathSuffix(pathname, "skill-settings", basePath) === null &&
    skillPageFromPath(pathname, basePath) !== null
  );
}

function isSkillSettingsPagePath(pathname: string, basePath = ""): boolean {
  return (
    routePathSuffix(pathname, "skill-settings", basePath) !== null &&
    skillPageFromPath(pathname, basePath) !== null
  );
}

export function isSessionRouteId(routeId: string | null | undefined): routeId is BoardFace {
  return routeId === "chat" || routeId === "dashboard";
}

export function sessionRouteNamespaceFromPath(pathname: string, basePath = ""): BoardFace | null {
  const normalizedPath = normalizePath(pathname);
  const normalizedBasePath = normalizeBasePath(basePath);
  if (
    normalizedBasePath &&
    normalizedPath !== normalizedBasePath &&
    !normalizedPath.startsWith(`${normalizedBasePath}/`)
  ) {
    return null;
  }
  const routePath = normalizedPath.slice(normalizedBasePath.length);
  if (routePath.startsWith("/chat/")) {
    return "chat";
  }
  if (routePath.startsWith("/dashboard/")) {
    return "dashboard";
  }
  // The shared matcher reserves every built-in route and document namespace.
  const catalogShare = matchControlUiCatalogSharePath({
    pathname: normalizedPath,
    basePath: normalizedBasePath,
  });
  return catalogShare ? "chat" : null;
}

export function pathForTerminalSession(sessionId: string, basePath = ""): string {
  return `${pathForRoute("terminal", basePath)}/${encodeURIComponent(sessionId)}`;
}

function decodeRouteSegment(encoded: string | null): string | null {
  if (!encoded || encoded.includes("/")) {
    return null;
  }
  try {
    return decodeURIComponent(encoded);
  } catch {
    return null;
  }
}

export function terminalSessionIdFromPath(pathname: string, basePath = ""): string | null {
  return decodeRouteSegment(routePathSuffix(pathname, "terminal", basePath))?.trim() || null;
}

export function workboardBoardIdFromPath(pathname: string, basePath = ""): string | null {
  const boardId = decodeRouteSegment(routePathSuffix(pathname, "workboard", basePath));
  return isValidWorkboardBoardId(boardId) ? boardId : null;
}

const DYNAMIC_ROUTE_PATH_PARAMS = {
  terminal: INTERNAL_TERMINAL_PATH_PARAM,
  plugin: INTERNAL_PLUGIN_PATH_PARAM,
  agents: INTERNAL_AGENT_PATH_PARAM,
  activity: INTERNAL_ACTIVITY_PATH_PARAM,
  workboard: INTERNAL_WORKBOARD_PATH_PARAM,
  memory: INTERNAL_MEMORY_PATH_PARAM,
  plugins: INTERNAL_PLUGINS_PATH_PARAM,
  templates: INTERNAL_TEMPLATES_PATH_PARAM,
  "plugin-settings": INTERNAL_PLUGIN_SETTINGS_PATH_PARAM,
  skills: INTERNAL_SKILLS_PATH_PARAM,
  "skill-settings": INTERNAL_SKILL_SETTINGS_PATH_PARAM,
  chat: INTERNAL_SESSION_PATH_PARAM,
  dashboard: INTERNAL_SESSION_PATH_PARAM,
} as const;

// These namespaces belong to app documents. /plugins and /plugin also own Gateway
// HTTP routes (plugin tabs use /<slug> or /plugin?…), so offline admission there
// stays limited to the exact roots.
const GATEWAY_SHARED_ROUTE_IDS: ReadonlySet<RouteId> = new Set(["plugins", "plugin"]);
export const APP_ROUTE_OFFLINE_PREFIXES = APP_ROUTE_IDS.filter(
  (routeId) =>
    !GATEWAY_SHARED_ROUTE_IDS.has(routeId) && Object.hasOwn(DYNAMIC_ROUTE_PATH_PARAMS, routeId),
).map((routeId) => `${pathForRoute(routeId)}/`);

const DYNAMIC_ROUTE_MATCHERS = [
  ["terminal", terminalSessionIdFromPath],
  ["plugin", pluginTabSlugFromPath],
  ["agents", agentRouteFromPath],
  ["activity", activityPersonFromPath],
  ["workboard", workboardBoardIdFromPath],
  ["memory", memoryTabFromPath],
  ["plugins", pluginCatalogIdFromPath],
  ["plugins", isLegacyPluginsDiscoveryPath],
  ["plugin-settings", pluginSettingsIdFromPath],
  ["skills", isSkillsPagePath],
  ["skill-settings", isSkillSettingsPagePath],
] as const;

function dynamicRouteIdFromPath(
  pathname: string,
  basePath = "",
): keyof typeof DYNAMIC_ROUTE_PATH_PARAMS | null {
  if (templateCatalogPackageNameFromPath(pathname, basePath)) {
    return "templates";
  }
  return (
    DYNAMIC_ROUTE_MATCHERS.find(([, matches]) => matches(pathname, basePath))?.[0] ??
    sessionRouteNamespaceFromPath(pathname, basePath)
  );
}

export function dynamicRouteFromPath(pathname: string, basePath: string) {
  const routeId = pluginCatalogIdFromPath(pathname, basePath)
    ? "plugins"
    : templateCatalogPackageNameFromPath(pathname, basePath)
      ? "templates"
      : dynamicRouteIdFromPath(pathname, basePath);
  // The overview is a static route; only its subpages need the pathname bridge.
  return routeId && !(routeId === "memory" && memoryTabFromPath(pathname, basePath) === "overview")
    ? ([routeId, DYNAMIC_ROUTE_PATH_PARAMS[routeId], pathname] as const)
    : null;
}

export function routeIdFromPath(pathname: string, basePath = ""): RouteId | null {
  const normalizedPath = normalizePath(pathname);
  const normalizedBasePath = normalizeBasePath(basePath);
  const isWithinBasePath =
    !normalizedBasePath ||
    normalizedPath === normalizedBasePath ||
    normalizedPath.startsWith(`${normalizedBasePath}/`);
  if (!isWithinBasePath) {
    return null;
  }
  const routePath = normalizedBasePath
    ? normalizedPath.slice(normalizedBasePath.length) || "/"
    : normalizedPath;
  if (pluginCatalogIdFromPath(normalizedPath, normalizedBasePath)) {
    return "plugins";
  }
  if (templateCatalogPackageNameFromPath(normalizedPath, normalizedBasePath)) {
    return "templates";
  }
  // uirouter matches static paths case-insensitively (pathKey lowercases), so
  // this pre-gate must too — otherwise /Usage is rewritten to /chat before the
  // router, which would have matched it, ever starts.
  return (
    ROUTE_ID_BY_PATH.get(routePath.toLowerCase()) ??
    dynamicRouteIdFromPath(normalizedPath, normalizedBasePath)
  );
}

// A candidate mount base that is a registered route ("/custodian"), or that
// sits at or below a multi-segment route namespace ("/settings", including
// "/settings/other"), is really a root-mounted deep link whose suffix happens
// to match a route path or alias. Descendants of leaf routes stay valid mount
// directories so "/apps/openclaw" keeps working. Inference is a last-resort
// fallback for pages served without the injected base path (vite dev, static
// hosting); accepted tradeoff: namespaces nested under a real mount prefix
// ("/ui/settings/other/config") are not rescued here.
function isRouteOwnedBasePath(basePath: string): boolean {
  if (APP_ROUTE_PATHS.includes(basePath)) {
    return true;
  }
  const namespace = basePath.split("/").find(Boolean);
  return APP_ROUTE_PATHS.some((path) => path.startsWith(`/${namespace}/`));
}

export function inferBasePathFromPathname(pathname: string): string {
  const focusBasePath = inferControlUiFocusBasePath(pathname);
  if (focusBasePath !== null) {
    return focusBasePath;
  }
  const isMountRoot = pathname.trim().endsWith("/");
  const normalizedPath = normalizePath(pathname);
  if (normalizedPath.toLowerCase().endsWith("/index.html")) {
    return normalizeBasePath(normalizedPath.slice(0, -"/index.html".length));
  }
  if (normalizedPath === "/") {
    return "";
  }
  const segments = normalizedPath.split("/").filter(Boolean);
  for (let index = 0; index < segments.length; index += 1) {
    const candidate = `/${segments.slice(index).join("/")}`;
    const routePath = ROUTE_ID_BY_PATH.has(candidate) ? candidate : undefined;
    const documentRoutePath = Object.values(CONTROL_UI_DOCUMENT_ROUTE_PATHS).find(
      (path) => candidate === path || candidate.startsWith(`${path}/`),
    );
    const dynamicRouteId = dynamicRouteIdFromPath(candidate);
    if (!routePath && !documentRoutePath && !dynamicRouteId) {
      continue;
    }
    const previousSegment = segments[index - 1];
    const dynamicRoutePath =
      documentRoutePath ?? (dynamicRouteId ? APP_ROUTE_DEFINITIONS[dynamicRouteId].path : null);
    const firstRouteSegment = (routePath ?? dynamicRoutePath ?? "").split("/")[1];
    if (index === 0 || previousSegment === firstRouteSegment) {
      return "";
    }
    const basePath = `/${segments.slice(0, index).join("/")}`;
    // Mis-inferring a route-owned base ("/settings/config" -> "/settings" via
    // the "/config" alias) rescopes stored gateway settings and asset URLs, so
    // a connected browser deep-links straight into the login gate.
    return isRouteOwnedBasePath(basePath) ? "" : basePath;
  }
  if (!isMountRoot || segments.length === 0) {
    return "";
  }
  const mountRootBase = `/${segments.join("/")}`;
  return isRouteOwnedBasePath(mountRootBase) ? "" : mountRootBase;
}

export function locationForRoute(routeId: RouteId, basePath: string): RouteLocation {
  return {
    pathname: pathForRoute(routeId, basePath),
    search: "",
    hash: "",
  };
}

export function restoreBridgedRouteLocation(
  location: RouteLocation,
  pathParam: string,
): RouteLocation {
  const params = new URLSearchParams(location.search);
  const pathname = params.get(pathParam) ?? location.pathname;
  params.delete(pathParam);
  const search = params.toString();
  return {
    pathname,
    search: search ? `?${search}` : "",
    hash: location.hash,
  };
}

export function sameRouteLocation(
  left: RouteLocation | undefined,
  right: RouteLocation | undefined,
): boolean {
  return (
    left?.pathname === right?.pathname &&
    left?.search === right?.search &&
    left?.hash === right?.hash
  );
}
