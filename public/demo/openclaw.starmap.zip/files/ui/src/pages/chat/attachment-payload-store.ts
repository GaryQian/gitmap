import { estimateBase64DecodedBytes, isValidBase64 } from "@openclaw/media-core/base64";
import { base64ToBytes } from "../../lib/bytes-base64.ts";
import type { ChatAttachment } from "../../lib/chat/chat-types.ts";
import {
  payloads,
  releaseChatAttachmentPayload,
  releaseChatAttachmentPayloads,
  releaseVideoPoster,
  revokeObjectUrl,
  type AttachmentPayload,
} from "./attachment-payload-lifecycle.ts";

export {
  releaseChatAttachmentPayload,
  releaseChatAttachmentPayloads,
} from "./attachment-payload-lifecycle.ts";

function createObjectUrl(blob: Blob): string | undefined {
  if (typeof URL === "undefined" || typeof URL.createObjectURL !== "function") {
    return undefined;
  }
  return URL.createObjectURL(blob);
}

export function registerChatAttachmentPayload(params: {
  attachment: ChatAttachment;
  dataUrl: string;
  file: File;
}): ChatAttachment {
  releaseChatAttachmentPayload(params.attachment.id);
  payloads.set(params.attachment.id, {
    blob: params.file,
    dataUrl: params.dataUrl,
  });
  return params.attachment;
}

export function getChatAttachmentDataUrl(attachment: ChatAttachment): string | null {
  return attachment.dataUrl ?? payloads.get(attachment.id)?.dataUrl ?? null;
}

export function getChatAttachmentVideoPosterUrl(
  attachment: ChatAttachment,
): Promise<string | null> | null {
  const payload = payloads.get(attachment.id);
  if (payload?.videoPoster) {
    return payload.videoPoster.promise;
  }
  // Use retained Files; never reconstruct a data URL just for a poster.
  if (!(payload?.blob instanceof File) || payload.blob.size > 512 * 1024 * 1024) {
    return null;
  }
  const file = payload.blob;
  const src = createObjectUrl(file);
  if (!src) {
    return null;
  }
  const controller = new AbortController();
  const poster: NonNullable<AttachmentPayload["videoPoster"]> = {
    controller,
    promise: import("../../lib/media/video-poster.ts")
      .then(
        ({ requestVideoPoster }) =>
          requestVideoPoster({
            key: file,
            src,
            width: 54,
            height: 54,
            signal: controller.signal,
          }),
        () => null,
      )
      .then((blob) => {
        if (!blob || payloads.get(attachment.id)?.videoPoster !== poster) {
          return null;
        }
        poster.url = createObjectUrl(blob);
        return poster.url ?? null;
      })
      .finally(() => revokeObjectUrl(src)),
  };
  payload.videoPoster = poster;
  return poster.promise;
}

function blobFromDataUrl(dataUrl: string): Blob | null {
  const match = /^data:([^,]*),(.*)$/s.exec(dataUrl);
  if (!match) {
    return null;
  }
  const metadata = match[1] ?? "";
  const payload = match[2] ?? "";
  try {
    const content = metadata.toLowerCase().includes(";base64")
      ? base64ToBytes(payload.replace(/\s+/gu, ""))
      : decodeURIComponent(payload.replace(/\+/gu, "%20"));
    return new Blob([content], { type: metadata.split(";", 1)[0] });
  } catch {
    return null;
  }
}

export function getChatAttachmentBlob(attachment: ChatAttachment): Blob | null {
  const stored = payloads.get(attachment.id);
  if (stored?.blob) {
    return stored.blob;
  }
  const dataUrl = getChatAttachmentDataUrl(attachment);
  if (!dataUrl) {
    return null;
  }
  const blob = blobFromDataUrl(dataUrl);
  if (blob) {
    payloads.set(attachment.id, { ...stored, blob, dataUrl });
  }
  return blob;
}

// Recovery prepares bytes without owning URLs. Allocate once when presented, so
// stale reads cannot leak previews or replace a URL another pane still uses.
export function getChatAttachmentPreviewUrl(attachment: ChatAttachment): string | null {
  const preview = attachment.previewUrl ?? payloads.get(attachment.id)?.previewUrl;
  if (preview) {
    return preview;
  }
  const blob = getChatAttachmentBlob(attachment);
  const objectUrl = blob && createObjectUrl(blob);
  if (objectUrl) {
    payloads.set(attachment.id, { ...payloads.get(attachment.id), previewUrl: objectUrl });
  }
  return objectUrl ?? getChatAttachmentDataUrl(attachment);
}

/** Gives another mounted composer payload ownership independent of the source. */
export function cloneChatAttachmentsForIndependentOwner(
  attachments: readonly ChatAttachment[],
): ChatAttachment[] {
  return attachments.map((attachment) => {
    const { id: _id, previewUrl: _previewUrl, ...metadata } = attachment;
    const dataUrl = getChatAttachmentDataUrl(attachment);
    return { ...metadata, id: generateAttachmentId(), ...(dataUrl ? { dataUrl } : {}) };
  });
}

/**
 * Releases displaced attachments except ids still referenced by a retained
 * owner (live composer, surviving fallbacks). Attachments are backups of
 * composer state, so shared ids across owners are the norm — dropping one
 * owner must never revoke another owner's payload.
 */
export function releaseDisplacedChatAttachmentPayloads(
  displaced: readonly ChatAttachment[],
  retained: ReadonlyArray<readonly ChatAttachment[]>,
): void {
  const retainedIds = new Set(retained.flat().map((attachment) => attachment.id));
  releaseChatAttachmentPayloads(displaced.filter((attachment) => !retainedIds.has(attachment.id)));
}

export function generateAttachmentId(): string {
  return `att-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

// Same admission contract as the Swift/Android restore paths: only well-formed,
// size-bounded inline images come back; a corrupt transcript entry is skipped,
// never fatal. 5 MiB decoded matches the gateway media cap (MEDIA_MAX_BYTES).
const RESTORED_IMAGE_MIME = /^image\/[\w.+-]+$/u;
const RESTORED_ATTACHMENT_MAX_BYTES = 5 * 1024 * 1024;
const RESTORED_ATTACHMENT_MAX_BASE64_CHARS = Math.ceil(RESTORED_ATTACHMENT_MAX_BYTES / 3) * 4;

export function replaceChatAttachmentsFromEditor(
  current: readonly ChatAttachment[],
  restored: readonly { mimeType: string; data: string }[] = [],
): ChatAttachment[] {
  releaseChatAttachmentPayloads(current);
  return restored.flatMap(({ mimeType, data }) =>
    RESTORED_IMAGE_MIME.test(mimeType) &&
    data.length <= RESTORED_ATTACHMENT_MAX_BASE64_CHARS &&
    isValidBase64(data) &&
    estimateBase64DecodedBytes(data) <= RESTORED_ATTACHMENT_MAX_BYTES
      ? [
          {
            id: generateAttachmentId(),
            mimeType,
            dataUrl: `data:${mimeType};base64,${data}`,
          },
        ]
      : [],
  );
}

export function discardChatAttachmentDataUrls(attachments: readonly ChatAttachment[] = []): void {
  for (const { id } of attachments) {
    const payload = payloads.get(id);
    if (!payload) {
      continue;
    }
    releaseVideoPoster(payload);
    if (payload.previewUrl) {
      payloads.set(id, { previewUrl: payload.previewUrl });
    } else {
      payloads.delete(id);
    }
  }
}
