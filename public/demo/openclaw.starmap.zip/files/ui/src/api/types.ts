import type { ChannelsStatusResult } from "@openclaw/gateway-client/browser";
import type { FastMode } from "@openclaw/normalization-core/string-coerce";
import type {
  ArtifactSummary as ProtocolArtifactSummary,
  CronJob as ProtocolCronJob,
  CronListParams,
  CronRunLogEntry as ProtocolCronRunLogEntry,
  CronRunsParams,
  ErrorShape,
  SessionsFilesListResult as ProtocolSessionsFilesListResult,
} from "../../../packages/gateway-protocol/src/index.js";
import type {
  SessionEntryArchiveReason,
  SessionRow,
} from "../../../packages/gateway-protocol/src/schema/sessions-row.js";
import type { projectCronRunHistoryPage } from "../../../src/cron/run-history.js";
import type { CronListPageResult } from "../../../src/cron/service/list-page-types.js";
import type { CronStatusSummary } from "../../../src/cron/service/state.js";
import type { ModelAuthStatusResult } from "../../../src/gateway/server-methods/models-auth-status.types.js";
import type {
  GatewaySessionRow as GatewayWireSessionRow,
  GatewaySessionsDefaults as GatewayWireSessionsDefaults,
  SessionsPatchResult as GatewayWireSessionsPatchResult,
} from "../../../src/gateway/session-utils.types.js";
import type {
  GatewayContextWindowOption,
  SessionsListResultBase,
  SessionsPatchResultBase,
} from "../../../src/shared/session-types.js";
export type {
  AgentIdentityResult,
  ArtifactsDownloadResult as ArtifactDownloadResult,
  ConfigSchemaResponse,
  ModelsListResult as ModelCatalogResult,
  AgentsFileEntry as AgentFileEntry,
  AgentsFilesListResult,
  AgentsFilesGetResult,
  AgentsFilesSetResult,
  SessionsFilesGetResult as SessionWorkspaceGetResult,
  SessionsFilesSetResult as SessionWorkspaceSetResult,
  SessionsFilesStatResult as SessionWorkspaceStatResult,
  CronJob,
  CronRunLogEntry,
  CronScratchGetResult,
  CronScratchSetResult,
  UpdateAvailable,
  UpdateHoldResult,
  UpdateReportResult,
  UpdateScheduleState,
  ChannelsPairingAccount,
  ChannelsPairingApproveResult,
  ChannelsPairingListResult,
  ChannelsPairingRequest,
  SessionVisibility,
  SessionMembersListEvidenceResult,
  SessionsRewindResult,
  SessionsForkResult,
  SessionBranch,
  SessionsBranchesListResult,
  SessionsBranchesSwitchResult,
  CronCompactJob,
  ToolCatalogProfile,
  ToolsCatalogResult,
  ToolsGitHubStatusResult,
  ToolsGitHubAuthorizeStartResult,
  ToolsGitHubAuthorizePollResult,
  ToolsEffectiveEntry,
  ToolsEffectiveResult,
  ModelsProbeResult,
  SystemAgentSetupActivateParams,
  SystemAgentSetupActivateResult,
  SystemAgentSetupDetectResult,
  SystemAgentSetupVerifyResult,
  WizardNextResult,
  WizardStep,
} from "../../../packages/gateway-protocol/src/index.js";
export type { ConfigUiHint, ConfigUiHints } from "../../../src/shared/config-ui-hints-types.js";
export type { SessionGoal } from "../../../src/config/sessions/types.js";
export type { FastMode } from "@openclaw/normalization-core/string-coerce";
export type {
  AgentsCreateResult,
  AgentsListResult,
  ModelChoice as ModelCatalogEntry,
  ModelCatalogProviderOutcome,
} from "../../../packages/gateway-protocol/src/schema/agents-models-skills.js";
export type { SessionRunStatus } from "../../../packages/gateway-protocol/src/schema/sessions-row.js";
export type ChannelsStatusSnapshot = ChannelsStatusResult;
export type ChannelAccountSnapshot = ChannelsStatusResult["channelAccounts"][string][number];

export type ChannelStatus = Omit<ChannelAccountSnapshot, "accountId" | "probe"> & {
  probe?: { ok?: boolean; status?: number | string | null; error?: string | null } | null;
};

export type ConfigSnapshot = {
  writeError?: ErrorShape;
  path?: string | null;
  exists?: boolean | null;
  raw?: string | null;
  hash?: string | null;
  configRevisionHash?: string | null;
  appliedConfigHash?: string | null;
  parsed?: unknown;
  valid?: boolean | null;
  sourceConfig?: Record<string, unknown> | null;
  resolved?: Record<string, unknown> | null;
  runtimeConfig?: Record<string, unknown> | null;
  config?: Record<string, unknown> | null;
  issues?: { path: string; message: string }[] | null;
  warnings?: { path: string; message: string }[] | null;
  /** Files reached through $include, when the config uses any. */
  includedPaths?: string[] | null;
};

export type { PresenceEntry } from "../../../packages/gateway-protocol/src/schema/snapshot.js";
export type { GatewayWireSessionsDefaults as GatewaySessionsDefaults };
export type { GatewayAgentRow } from "../../../src/shared/session-types.js";
export type { GatewayContextWindowOption };

// The workspace view joins file results with separately fetched artifacts.
export type SessionWorkspaceListResult = ProtocolSessionsFilesListResult & {
  artifacts?: ProtocolArtifactSummary[];
};

export type CyberAccessProgram = NonNullable<GatewayWireSessionRow["cyberAccessProgram"]>;

export type GatewaySessionRow = Omit<GatewayWireSessionRow, "archivedBy" | "updatedAt"> &
  Pick<SessionRow, "archivedBy" | "updatedAt"> & {
    /** Transient UI-owned Swarm note overlays, not persisted session fields. */
    swarmPhase?: string;
    swarmPhaseRank?: number;
    swarmLog?: string;
    icon?: string;
    channelAvatarUrl?: string;
    surface?: string;
    room?: string;
    /** UI-local timestamp for the runtimeMs sample; absent on raw Gateway rows. */
    runtimeSampledAt?: number;
  };

export type SessionsListResult = SessionsListResultBase<
  GatewayWireSessionsDefaults,
  GatewaySessionRow
>;

export type SessionsPatchResult = SessionsPatchResultBase<{
  sessionId: string;
  label?: GatewaySessionRow["label"];
  icon?: GatewaySessionRow["icon"];
  color?: GatewaySessionRow["color"];
  category?: GatewaySessionRow["category"];
  updatedAt?: number;
  createdAt?: number;
  pinnedAt?: number;
  lastReadAt?: number;
  lastActivityAt?: number;
  lastInteractionAt?: number;
  agentStatus?: GatewayWireSessionsPatchResult["entry"]["agentStatus"];
  permissionMode?: GatewaySessionRow["permissionMode"];
  nativeRuntimeConsent?: string;
  modelOverrideSource?: GatewayWireSessionsPatchResult["entry"]["modelOverrideSource"];
  boardFace?: GatewaySessionRow["boardFace"];
  boardPresentation?: GatewaySessionRow["boardPresentation"];
  archivedAt?: number;
  archivedBy?: GatewaySessionRow["archivedBy"];
  archiveReason?: SessionEntryArchiveReason;
  /** Present only while an explicit mark-unread marker owns the row. */
  markedUnreadAt?: number;
  contextWindow?: string;
  thinkingLevel?: string;
  fastMode?: FastMode;
  cyberAccessProgram?: CyberAccessProgram;
  verboseLevel?: string;
  reasoningLevel?: string;
  elevatedLevel?: string;
}> &
  Pick<GatewayWireSessionsPatchResult, "resolved">;

export type { SessionsUsageResult } from "../pages/usage/data-types.ts";

export type CronRunStatus = NonNullable<ProtocolCronRunLogEntry["status"]>;
export type CronDeliveryStatus = NonNullable<ProtocolCronRunLogEntry["deliveryStatus"]>;
export type CronJobsEnabledFilter = NonNullable<CronListParams["enabled"]>;
export type CronJobsScheduleKindFilter = NonNullable<CronListParams["scheduleKind"]>;
export type CronJobsTriggerFilter = NonNullable<CronListParams["trigger"]>;
export type CronJobsSortBy = NonNullable<CronListParams["sortBy"]>;
export type CronRunScope = NonNullable<CronRunsParams["scope"]>;
export type CronRunsStatusValue = NonNullable<CronRunsParams["statuses"]>[number];
export type CronSortDir = NonNullable<CronListParams["sortDir"]>;
export type CronPayload = ProtocolCronJob["payload"];

export type CronStatus = Pick<CronStatusSummary, "enabled" | "triggersEnabled" | "jobs"> &
  Partial<Pick<CronStatusSummary, "nextWakeAtMs">>;

export type { CronServiceRunResult as CronRunResult } from "../../../src/cron/service-contract.js";

export type CronJobsListResult<Row = ProtocolCronJob> = Omit<CronListPageResult, "jobs"> & {
  jobs: Row[];
};

export type CronRunsResult = ReturnType<typeof projectCronRunHistoryPage>;

export type {
  SkillStatusEntry,
  SkillStatusReport,
} from "../../../src/skills/discovery/status.types.js";
export type { ClawHubSkillStatusLink as SkillClawHubLink } from "../../../src/skills/lifecycle/workspace-types.js";

export type StatusSummary = Record<string, unknown>;

export type HealthSnapshot = Record<string, unknown>;

export type {
  ModelAuthStatusProvider,
  ModelAuthStatusProfile,
  ModelAuthStatusResult,
} from "../../../src/gateway/server-methods/models-auth-status.types.js";
export type ProviderLoginOption = NonNullable<
  NonNullable<ModelAuthStatusResult["providerCapabilities"]>[number]["loginOptions"]
>[number];
