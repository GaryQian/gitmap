import type { RouteLocation, Router } from "@openclaw/uirouter";
import type { HumanMention } from "../../../packages/gateway-protocol/src/index.js";
import type { ThemeBranding } from "../../../packages/gateway-protocol/src/theme.ts";
import type { AgentsListResult } from "../api/types.ts";
import type { RouteId } from "../app-route-paths.ts";
import type { AgentIdentityCapability } from "../lib/agents/identity.ts";
import type { AgentCapability } from "../lib/agents/index.ts";
import type { ChannelCapability, createChannelCapability } from "../lib/channels/index.ts";
import type {
  ChatAttachment,
  ChatComposerMemoryFallback,
  ChatGoalDraftMode,
  ChatReplyTarget,
} from "../lib/chat/chat-types.ts";
import type { RuntimeConfigCapability } from "../lib/config/runtime-config-capability.ts";
import type { SessionCapability } from "../lib/sessions/index.ts";
import type { reviewPrivateComposerDraft } from "../pages/chat/components/private-composer-recovery-dialog.tsx";
import type { NewSessionDraftHandoff } from "../pages/new-session/draft-persistence.ts";
import type { ControlUiPluginCapability } from "../plugins/control-ui-capability.ts";
import type { AgentSelectionCapability } from "./agent-selection.ts";
import type { AssistantDock } from "./assistant-dock.ts";
import type { ApplicationChatSubmissions } from "./chat-submissions.ts";
import type { ApplicationConfigCapability } from "./config.ts";
import type { ConnectionBootstrapCoordinator } from "./connection-bootstrap.ts";
import type { ControlUiReadinessOutlet } from "./control-ui-readiness.ts";
import type { ScopeUpgradeCapability } from "./device-scope-upgrade.ts";
import type { ApplicationGateway } from "./gateway.ts";
import type { GuestWelcomeHandle } from "./guest-welcome-handle.ts";
import type { NativeChatDrafts } from "./native-bridge.ts";
import type { NativeConversationBridge } from "./native-conversation-types.ts";
import type { NativeDeviceSettingsCapability } from "./native-device-settings.ts";
import type { NativeNotificationsCapability } from "./native-notifications.ts";
import type { ApplicationOverlays } from "./overlays-types.ts";
import type { ApplicationPlacementStartup } from "./session-placement-startup.ts";
import type { UiPreferences } from "./settings.ts";
import type { SidebarAttentionStore } from "./sidebar-attention-store.ts";
import type { ThemeCatalogSnapshot } from "./theme-catalog.ts";
import type { ThemeMode, ThemeName } from "./theme.ts";
import type { WebPushCapability } from "./web-push.ts";

export type { ApplicationGateway, ApplicationGatewaySnapshot } from "./gateway.ts";

export type ApplicationTheme = {
  readonly branding: ThemeBranding;
  readonly catalog?: ThemeCatalogSnapshot;
  retryCatalog?: () => void;
  readonly settings: UiPreferences;
  readonly mode: ThemeMode;
  readonly resolvedMode: "dark" | "light";
  readonly appliedPalette: ApplicationThemePalette | null;
  recordServerSelection: (theme: ThemeName | null, scope: string) => void;
  setMode: (mode: ThemeMode, element?: HTMLElement | null) => void;
  refresh: (options?: { notify?: boolean }) => void;
  subscribe: (listener: () => void) => () => void;
};

export type ApplicationThemePalette = {
  readonly revision: number;
  readonly theme: ThemeName;
  readonly resolvedMode: "dark" | "light";
};

export type ApplicationNavigationPreferencesSnapshot = {
  navCollapsed: boolean;
  navWidth: number;
  sidebarEntries: readonly string[];
  pinnedAgentIds: readonly string[];
};

export type ApplicationNavigationPreferences = {
  readonly snapshot: ApplicationNavigationPreferencesSnapshot;
  update: (patch: Partial<ApplicationNavigationPreferencesSnapshot>) => void;
  subscribe: (listener: (snapshot: ApplicationNavigationPreferencesSnapshot) => void) => () => void;
};

export type ApplicationNavigationOptions = Partial<
  Pick<RouteLocation, "pathname" | "search" | "hash">
>;

export type MountedApplicationShell = {
  readonly element: HTMLElement;
  readonly routeOutlet?: ControlUiReadinessOutlet;
};

type ChatAttachmentHandoffKey = {
  owner: ApplicationGateway["snapshot"]["client"];
  paneId: string;
  scopeKey: string;
};

export type ApplicationChatAttachmentHandoff = {
  prepare(
    handoff: ChatAttachmentHandoffKey & {
      attachments: readonly ChatAttachment[];
      fallbacks: Readonly<Record<string, ChatComposerMemoryFallback>>;
      message?: string;
      draftRevision?: number;
      goalMode?: ChatGoalDraftMode | null;
      replyTarget?: ChatReplyTarget | null;
      mentions?: readonly HumanMention[];
      newSessionDraft?: NewSessionDraftHandoff;
      incognito?: boolean;
      reviewPrivateDraft: typeof reviewPrivateComposerDraft;
    },
  ): void;
  consume(handoff: ChatAttachmentHandoffKey): {
    attachments: ChatAttachment[];
    fallbacks: Record<string, ChatComposerMemoryFallback>;
    message?: string;
    draftRevision?: number;
    goalMode?: ChatGoalDraftMode | null;
    replyTarget?: ChatReplyTarget | null;
    mentions?: readonly HumanMention[];
    newSessionDraft?: NewSessionDraftHandoff;
  } | null;
  retainedAttachmentIds(attachments: readonly ChatAttachment[]): ReadonlySet<string>;
  retireScope(scopeKey: string, beforeRevision: number): void;
  clearPane(paneId: string): void;
  dispose(): void;
};

export type ApplicationContext<TRouteId extends string = RouteId> = {
  readonly basePath: string;
  readonly resourceBasePath: string;
  readonly lifecycleAbortSignal?: AbortSignal;
  readonly routeOutlet?: ControlUiReadinessOutlet;
  readonly router: Pick<
    Router<RouteId, ApplicationContext, unknown, unknown>,
    "getState" | "subscribe" | "navigate"
  >;
  readonly gateway: ApplicationGateway;
  /** App-owned queue for automatic Gateway reconnect bootstrap work. */
  readonly connectionBootstrap: ConnectionBootstrapCoordinator;
  readonly agents: AgentCapability;
  /** Admitted local routing defaults, never a discoverable agent roster. */
  readonly offlineSessionDefaults?: Pick<AgentsListResult, "mainKey" | "scope"> | null;
  readonly agentIdentity: AgentIdentityCapability;
  readonly agentSelection: AgentSelectionCapability;
  /** Configured agent targeted by Settings, independent of chat/session selection. */
  readonly settingsAgentSelection: AgentSelectionCapability;
  /** Lazy routes provide the constructor; the application retains and disposes one owner. */
  readonly acquireChannels: (create: typeof createChannelCapability) => ChannelCapability;
  readonly config: ApplicationConfigCapability;
  readonly scopeUpgrade: ScopeUpgradeCapability;
  readonly sidebarAttention: SidebarAttentionStore;
  readonly runtimeConfig: RuntimeConfigCapability;
  readonly sessions: SessionCapability;
  readonly placementStartup: ApplicationPlacementStartup;
  readonly plugins: ControlUiPluginCapability;
  /** Visitor Access welcome-session setup for invited guests; app router documents only. */
  readonly guestWelcome?: GuestWelcomeHandle;
  readonly assistantDock: AssistantDock;
  readonly overlays: ApplicationOverlays;
  readonly navigation: ApplicationNavigationPreferences;
  readonly theme: ApplicationTheme;
  readonly nativeChatDrafts: NativeChatDrafts;
  readonly nativeConversation?: NativeConversationBridge | null;
  readonly nativeDeviceSettings: NativeDeviceSettingsCapability | null;
  readonly nativeNotifications: NativeNotificationsCapability | null;
  readonly webPush: WebPushCapability;
  readonly chatSubmissions: ApplicationChatSubmissions;
  readonly chatAttachmentHandoff: ApplicationChatAttachmentHandoff;
  readonly navigate: (routeId: TRouteId, options?: ApplicationNavigationOptions) => void;
  /** Navigates and resolves after any route-specific handoff completes. */
  readonly navigateAndWait: (
    routeId: TRouteId,
    options?: ApplicationNavigationOptions,
  ) => Promise<void>;
  readonly replace: (routeId: TRouteId, options?: ApplicationNavigationOptions) => void;
  readonly revalidate: (routeId?: TRouteId) => Promise<void>;
  /** Warms a named route; dynamic locations load as part of navigation. */
  readonly preload: (routeId: TRouteId) => Promise<void>;
};
