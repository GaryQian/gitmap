import type {
  SessionRunStatus,
  SessionsResolveCandidate,
  SessionsResolveResult,
} from "../../../packages/gateway-protocol/src/index.js";
import type {
  SessionVisibility,
  SessionVisibilitySetResult,
} from "../../../packages/gateway-protocol/src/schema/sessions-sharing.js";
import type { ModelCatalogEntry } from "../api/types.ts";

export type ControlUiSessionFixture = {
  key: string;
  sessionId?: string;
  updatedAt?: number;
  contextTokens?: number;
  kind?: string;
  pinned?: boolean;
  pinnedAt?: number;
  archived?: boolean;
  archivedAt?: number;
  spawnedCwd?: string;
  lastMessagePreview?: string;
  [field: string]: unknown;
};

// Also serialized into the page realm; keep these builders free of module captures.
export function createControlUiSessionRow(
  key: string,
  label: string,
  updatedAt: number,
  options?: Partial<ControlUiSessionFixture>,
) {
  const archivedAt = options?.archivedAt ?? (options?.archived ? updatedAt : undefined);
  const pinnedAt =
    archivedAt === undefined
      ? (options?.pinnedAt ?? (options?.pinned ? updatedAt : undefined))
      : undefined;
  return Object.assign(
    {
      displayName: label,
      hasActiveRun: false,
      key,
      sessionId: `session:${key}`,
      label,
      model: "gpt-5.5",
      modelProvider: "openai",
      status: "done",
      totalTokens: 0,
      workspaceReadDisabledReason: null,
      updatedAt,
    },
    options,
    {
      contextTokens: options?.contextTokens,
      kind: options?.kind ?? "direct",
      pinned: pinnedAt !== undefined,
      pinnedAt,
      archived: archivedAt !== undefined,
      archivedAt,
    },
  );
}

export function createControlUiSessionFixtures(
  input: {
    rows: ControlUiSessionFixture[];
    mainKey: string;
    models?: ModelCatalogEntry[];
    hasMessages?: (row: Record<string, unknown>) => boolean | undefined;
  },
  isRecord: (value: unknown) => value is Record<string, unknown>,
) {
  const records = new Map<
    string,
    { row: ControlUiSessionFixture; changed: Set<string>; lastRunEventSequence?: number }
  >();
  const listed = new Set<string>();
  const materialized = new Set<string>();
  let materializedSequence = 0;
  let timestamp = 1_800_000_000_000;
  const canonicalKey = (key: string) => (key === "main" ? input.mainKey : key);
  const record = (inputKey: string) => {
    const key = canonicalKey(inputKey);
    let value = records.get(key);
    if (!value) {
      value = {
        // Unseeded case/sequence rows have identity, but no known metadata.
        row: { key, sessionId: `session:${key}` },
        changed: new Set(),
      };
      records.set(key, value);
    }
    return value;
  };
  for (const fixture of input.rows) {
    const key = canonicalKey(fixture.key);
    const archivedAt =
      fixture.archivedAt ?? (fixture.archived ? (fixture.updatedAt ?? ++timestamp) : undefined);
    const pinnedAt =
      archivedAt === undefined
        ? (fixture.pinnedAt ?? (fixture.pinned ? (fixture.updatedAt ?? ++timestamp) : undefined))
        : undefined;
    records.set(key, {
      row: {
        sessionId: `session:${key}`,
        workspaceReadDisabledReason: null,
        ...fixture,
        key,
        archivedAt,
        archived: archivedAt !== undefined,
        pinnedAt,
        pinned: pinnedAt !== undefined,
      },
      changed: new Set(),
    });
    listed.add(key);
  }
  const read = (key: string) => ({ ...record(key).row });
  // Sample history and projection clocks at read time; explicit row facts override defaults.
  const sample = <T extends Record<string, unknown>>(row: T, now: number) =>
    Object.assign({ hasMessages: input.hasMessages?.(row) }, row, {
      snapshotAt: row.snapshotAt ?? now,
    });
  const patch = (key: string, fields: Record<string, unknown>) => {
    const value = record(key);
    const next = { ...value.row };
    // Validate before touching the owner: rejected or deferred writes must not leak.
    const archived = fields.archived ?? next.archived;
    if (archived && fields.pinned === true) {
      return {
        __mockError: {
          code: "INVALID_REQUEST",
          message: "cannot pin an archived session; restore it first",
        },
      };
    }
    const set = (field: string, fieldValue: unknown) => {
      next[field] = fieldValue;
      value.changed.add(field);
    };
    for (const field of [
      "model",
      "thinkingLevel",
      "fastMode",
      "cyberAccessProgram",
      "permissionMode",
      "label",
      "category",
      "icon",
      "color",
      "boardFace",
      "boardPresentation",
      "unread",
      "toolOverrides",
    ]) {
      if (Object.hasOwn(fields, field)) {
        set(
          field,
          field === "cyberAccessProgram" && fields[field] === null ? undefined : fields[field],
        );
      }
    }
    if (Object.hasOwn(fields, "model")) {
      set("modelOverrideSource", fields.model == null ? null : "user");
    }
    if (fields.agentRuntime !== undefined) {
      const model = input.models?.find(
        (candidate) =>
          `${candidate.provider}/${candidate.id}` === next.model ||
          (candidate.id === next.model && candidate.provider === next.modelProvider),
      );
      const runtime = fields.agentRuntime;
      const selected = model?.runtimeChoices?.find((choice) => choice.agentRuntime.id === runtime);
      set("agentRuntimeOverride", runtime ?? undefined);
      set(
        "agentRuntime",
        runtime === null
          ? (model?.agentRuntime ?? { id: "openclaw", source: "implicit" })
          : { ...selected?.agentRuntime, id: runtime, source: "session" },
      );
    }
    if (Object.hasOwn(fields, "unread")) {
      if (fields.unread === true) {
        set("markedUnreadAt", ++timestamp);
      } else {
        set("lastReadAt", ++timestamp);
        set("markedUnreadAt", undefined);
      }
    }
    if (Object.hasOwn(fields, "archived")) {
      set("archivedAt", fields.archived ? (next.archivedAt ?? ++timestamp) : undefined);
      set("archived", next.archivedAt !== undefined);
      if (!fields.archived) {
        set("archivedBy", undefined);
      }
    }
    if (fields.archived === true || Object.hasOwn(fields, "pinned")) {
      set(
        "pinnedAt",
        fields.archived !== true && fields.pinned ? (next.pinnedAt ?? ++timestamp) : undefined,
      );
      set("pinned", next.pinnedAt !== undefined);
    }
    // Mirror the Gateway: archive and pin clear a snooze; null wakes; a new wake time restamps.
    if (Object.hasOwn(fields, "snoozedUntil")) {
      const snoozedUntil = fields.snoozedUntil;
      if (typeof snoozedUntil === "number" && next.snoozedUntil !== snoozedUntil) {
        set("snoozedUntil", snoozedUntil);
        set("snoozedAt", ++timestamp);
      } else if (snoozedUntil === null) {
        set("snoozedUntil", undefined);
        set("snoozedAt", undefined);
      }
    }
    if (fields.archived === true || fields.pinned === true) {
      set("snoozedUntil", undefined);
      set("snoozedAt", undefined);
    }
    // Advance the fixture's synthetic timeline without making its later events stale.
    const latestUpdatedAt = Math.max(
      0,
      ...[...records.values()].map(({ row }) => row.updatedAt ?? 0),
    );
    set("updatedAt", latestUpdatedAt + 1);
    value.row = next;
    return {
      ok: true,
      key: next.key,
      entry: read(key),
      resolved: fields.agentRuntime !== undefined ? { agentRuntime: next.agentRuntime } : undefined,
    };
  };
  type RunStatus = Extract<SessionRunStatus, "running" | "done" | "failed" | "killed">;
  let runEventSequence = 0;
  const trackedRuns = new Map<
    string,
    Map<
      string,
      { status: RunStatus; acknowledged: boolean; sequence: number; errorMessage?: string }
    >
  >();
  const runsFor = (key: string) => {
    let runs = trackedRuns.get(key);
    if (!runs) {
      runs = new Map();
      trackedRuns.set(key, runs);
    }
    return runs;
  };
  const trackRun = (inputKey: string, runId: string, status: RunStatus, errorMessage?: string) => {
    const key = canonicalKey(inputKey);
    const runs = runsFor(key);
    const previous = runs.get(runId);
    const outcome = status === "running" ? (previous?.status ?? status) : status;
    const diagnostic = status === "running" ? previous?.errorMessage : errorMessage;
    const value = record(inputKey);
    const activeRunIds = Array.isArray(value.row.activeRunIds)
      ? value.row.activeRunIds.filter((id): id is string => typeof id === "string")
      : [];
    let sequence: number;
    if (status === "running") {
      // A send ACK consumes an earlier terminal outcome once; replay cannot revive it.
      if (previous?.acknowledged) {
        return;
      }
      sequence = previous?.sequence ?? ++runEventSequence;
      runs.set(runId, { status: outcome, acknowledged: true, sequence, errorMessage: diagnostic });
      // The first delayed ACK must not replay a terminal event over newer lifecycle state.
      if (outcome !== "running" && sequence < (value.lastRunEventSequence ?? 0)) {
        return;
      }
    } else {
      if (previous && previous.status !== "running") {
        return;
      }
      const acknowledged = previous?.acknowledged || activeRunIds.includes(runId);
      sequence = ++runEventSequence;
      runs.set(runId, { status, acknowledged, sequence, errorMessage: diagnostic });
      // Unrelated terminal events do not mutate a row until its send ACK arrives.
      if (!acknowledged) {
        return;
      }
    }
    const remaining =
      outcome === "running"
        ? [...new Set([...activeRunIds, runId])]
        : activeRunIds.filter((id) => id !== runId);
    const fields = {
      // Like the Gateway projection, a newly started sole run has no execution
      // model until it publishes one; the previous fallback is not evidence.
      ...(outcome === "running" && activeRunIds.length === 0
        ? { activeModel: undefined, activeModelProvider: undefined }
        : {}),
      activeRunIds: remaining,
      hasActiveRun: remaining.length > 0,
      status: remaining.length > 0 ? "running" : outcome,
      abortedLastRun: remaining.length === 0 && outcome === "killed",
      lastRunError: remaining.length === 0 && outcome === "failed" ? diagnostic : undefined,
      updatedAt: Date.now(),
    };
    value.lastRunEventSequence = sequence;
    value.row = { ...value.row, ...fields };
    for (const field of Object.keys(fields)) {
      value.changed.add(field);
    }
  };
  const abortRuns = (
    inputKey: string,
    runId: string | undefined,
    response: Record<string, unknown>,
  ) => {
    const confirmedRunIds = Array.isArray(response.runIds)
      ? response.runIds.filter((id): id is string => typeof id === "string")
      : undefined;
    const key = canonicalKey(inputKey);
    const value = confirmedRunIds?.length ? record(inputKey) : records.get(key);
    if (!value) {
      return { ...response, aborted: false, runIds: [] as string[] };
    }
    const activeRunIds = Array.isArray(value.row.activeRunIds)
      ? value.row.activeRunIds.filter((id): id is string => typeof id === "string")
      : [];
    // Explicit abort receipts can precede the send ACK that lists the run locally.
    const candidates = confirmedRunIds ?? activeRunIds;
    const runIds = runId ? candidates.filter((id) => id === runId) : candidates;
    const aborted = runIds.length > 0 || (!runId && value.row.hasActiveRun === true);
    if (!aborted) {
      return { ...response, aborted: false, runIds };
    }
    const sequence = ++runEventSequence;
    for (const id of runIds) {
      runsFor(key).set(id, { status: "killed", acknowledged: true, sequence });
    }
    const remaining = activeRunIds.filter((id) => !runIds.includes(id));
    const fields = {
      activeRunIds: remaining,
      hasActiveRun: remaining.length > 0,
      status: remaining.length > 0 ? "running" : "killed",
      abortedLastRun: remaining.length === 0,
      lastRunError: undefined,
      updatedAt: Date.now(),
    };
    value.lastRunEventSequence = sequence;
    value.row = { ...value.row, ...fields };
    // Lifecycle writes must override stale wire fixtures like other committed edits.
    for (const field of Object.keys(fields)) {
      value.changed.add(field);
    }
    return { ...response, aborted, runIds };
  };
  // sessions.abort settles the session and its controlled descendants; the Gateway
  // computes activity at read time, so every later describe/list/history read is idle.
  const settleSessionAbort = (inputKey: string, aborted: boolean) => {
    const key = canonicalKey(inputKey);
    const value = records.get(key);
    if (!value) {
      return;
    }
    const activeRunIds = Array.isArray(value.row.activeRunIds)
      ? value.row.activeRunIds.filter((id): id is string => typeof id === "string")
      : [];
    if (
      activeRunIds.length === 0 &&
      value.row.hasActiveRun !== true &&
      value.row.hasActiveSubagentRun !== true
    ) {
      return;
    }
    const sequence = ++runEventSequence;
    for (const id of activeRunIds) {
      runsFor(key).set(id, { status: "killed", acknowledged: true, sequence });
    }
    const fields = {
      activeRunIds: [],
      hasActiveRun: false,
      hasActiveSubagentRun: false,
      status: aborted ? "killed" : value.row.status === "running" ? "done" : value.row.status,
      ...(aborted ? { abortedLastRun: true, lastRunError: undefined } : {}),
      updatedAt: Math.max(Date.now(), (value.row.updatedAt ?? 0) + 1),
    };
    value.lastRunEventSequence = sequence;
    value.row = { ...value.row, ...fields };
    for (const field of Object.keys(fields)) {
      value.changed.add(field);
    }
  };
  // Abort receipts are lifecycle writes; a returned receipt replaces the chat.abort reply.
  const commitAbort = (method: string, params: unknown, response: unknown) => {
    if (!isRecord(params) || !isRecord(response)) {
      return undefined;
    }
    if (
      method === "chat.abort" &&
      typeof params.sessionKey === "string" &&
      response.aborted === true
    ) {
      const runId = typeof params.runId === "string" ? params.runId : undefined;
      return abortRuns(params.sessionKey, runId, response);
    }
    if (
      method === "sessions.abort" &&
      typeof params.key === "string" &&
      (response.status === "aborted" || response.status === "no-active-run")
    ) {
      // Like the Gateway, a run-scoped Stop settles only that run; only a
      // session-wide Stop cascades to every run and controlled descendant.
      if (typeof params.runId !== "string") {
        settleSessionAbort(params.key, response.status === "aborted");
      } else if (response.status === "aborted") {
        abortRuns(params.key, params.runId, {});
      }
    }
    return undefined;
  };
  const materializeResponse = (method: string, params: unknown, response: unknown) => {
    if (
      method !== "sessions.create" &&
      method !== "sessions.catalog.continue" &&
      method !== "beam.owned.continue"
    ) {
      return;
    }
    if (!isRecord(response)) {
      return;
    }
    const key =
      typeof response.key === "string"
        ? response.key
        : typeof response.sessionKey === "string"
          ? response.sessionKey
          : "";
    if (!key.trim()) {
      return;
    }
    const label = isRecord(params) && typeof params.label === "string" ? params.label.trim() : "";
    const runId =
      response.runStarted === true && typeof response.runId === "string"
        ? response.runId
        : undefined;
    const value = record(key);
    value.row = {
      ...value.row,
      ...(isRecord(response.entry) ? response.entry : {}),
      ...(typeof response.sessionId === "string" ? { sessionId: response.sessionId } : {}),
      ...(label ? { displayName: label, label } : {}),
      ...(!runId
        ? {
            hasActiveRun: response.runStarted === true,
            status: response.runStarted === true ? "running" : "done",
          }
        : {}),
      key: canonicalKey(key),
    };
    listed.add(canonicalKey(key));
    materialized.add(canonicalKey(key));
    materializedSequence += 1;
    if (runId) {
      // Creation ACKs share send lifecycle ownership, including terminal-before-ACK ordering.
      trackRun(key, runId, "running");
    }
  };
  const list = (wireRows?: unknown[]) => {
    const rows = wireRows ?? [...listed].map(read);
    const keys = new Set(
      rows.flatMap((row) =>
        row && typeof row === "object" && "key" in row && typeof row.key === "string"
          ? [canonicalKey(row.key)]
          : [],
      ),
    );
    return [
      ...rows.map((row) => {
        if (!row || typeof row !== "object" || !("key" in row) || typeof row.key !== "string") {
          return row;
        }
        const value = record(row.key);
        // Wire rows may deliberately carry stale IDs. Fill ordinary defaults,
        // then replay only committed fields; never learn canonical state from a read.
        const result: Record<string, unknown> = Object.assign({}, value.row, row);
        for (const field of value.changed) {
          result[field] = value.row[field];
        }
        return result;
      }),
      ...[...materialized].filter((key) => !keys.has(key)).map(read),
    ];
  };
  function listResponse(
    response: unknown,
    params: unknown,
    options: {
      renames: readonly { from: string; to: string | null }[];
      archiveFiltering: boolean;
    },
  ): unknown {
    if (!isRecord(response) || !Array.isArray(response.sessions)) {
      return response;
    }
    const archivedFilter =
      isRecord(params) && params.archived === "all"
        ? "all"
        : isRecord(params) && params.archived === true
          ? "archived"
          : "active";
    const now = Date.now();
    const projectedSessions = list(response.sessions).map((row) => {
      if (!isRecord(row)) {
        return row;
      }
      const next = Object.assign({}, row);
      // Replay group renames/deletes over static fixtures: the real gateway
      // rewrites member categories server-side before the next sessions.list.
      let category = typeof next.category === "string" ? next.category : undefined;
      for (const rename of options.renames) {
        if (category === rename.from) {
          category = rename.to ?? undefined;
        }
      }
      if (category === undefined) {
        delete next.category;
      } else {
        next.category = category;
      }
      return sample(next, now);
    });
    const spawnedBy =
      isRecord(params) && typeof params.spawnedBy === "string" ? params.spawnedBy.trim() : "";
    const childSessions = spawnedBy
      ? projectedSessions.filter((row) => {
          if (!isRecord(row) || row.key === spawnedBy) {
            return false;
          }
          const controller =
            typeof row.controlOwnerSessionKey === "string" ? row.controlOwnerSessionKey.trim() : "";
          // Fixtures declare current control and navigation lineage; they do not run a registry.
          return [controller || row.spawnedBy, row.parentSessionKey].some(
            (owner) => typeof owner === "string" && owner.trim() === spawnedBy,
          );
        })
      : projectedSessions;
    // A complete fixture becomes a complete child window after local projection.
    // Partial pages retain their explicit server-owned pagination metadata.
    const completeChildFixture =
      childSessions.length !== projectedSessions.length &&
      typeof response.totalCount === "number" &&
      response.totalCount === response.sessions.length &&
      (response.offset === undefined || response.offset === 0) &&
      (!isRecord(params) || params.offset === undefined || params.offset === 0) &&
      response.hasMore !== true &&
      response.nextOffset == null;
    if (!options.archiveFiltering) {
      return {
        ...response,
        ...(completeChildFixture ? { totalCount: childSessions.length } : {}),
        ...(childSessions.length !== projectedSessions.length || materializedSequence > 0
          ? { count: childSessions.length }
          : {}),
        sessions: childSessions,
      };
    }
    const filteredSessions = childSessions.filter(
      (row) =>
        isRecord(row) &&
        (archivedFilter === "all" || (row.archived === true) === (archivedFilter === "archived")),
    );
    return {
      ...response,
      ...(completeChildFixture ? { totalCount: filteredSessions.length } : {}),
      count: filteredSessions.length,
      sessions: filteredSessions,
    };
  }

  const resolve = (params: {
    reference?: { key: string };
    key?: string;
    shortId?: string;
    agentId?: string;
  }): SessionsResolveResult => {
    const present = (row: ControlUiSessionFixture): SessionsResolveCandidate => ({
      key: row.key,
      agentId:
        typeof row.agentId === "string"
          ? row.agentId
          : (row.key.split(":")[1] ?? params.agentId ?? "main"),
      ...(typeof row.displayName === "string" ? { displayName: row.displayName } : {}),
      ...(row.boardFace === "chat" || row.boardFace === "dashboard"
        ? { boardFace: row.boardFace }
        : {}),
      ...(row.boardPresentation === "split" || row.boardPresentation === "expanded"
        ? { boardPresentation: row.boardPresentation }
        : {}),
    });
    const requestedKey = params.reference?.key ?? params.key;
    if (requestedKey) {
      const key =
        input.mainKey === "global" && /^agent:[^:]+:(?:main|global)$/u.test(requestedKey)
          ? "global"
          : canonicalKey(requestedKey);
      return listed.has(key) ? { ok: true, ...present(read(key)) } : { ok: false };
    }
    // Canonical fixtures provide short-key identity; slug-specific routing scenarios
    // declare explicit wire replies instead of cloning the Gateway's slug matcher.
    const shortId = params.shortId?.toLowerCase();
    const matches = shortId
      ? [...listed]
          .filter((key) => {
            const tail = key.split(":").at(-1)?.replaceAll("-", "").toLowerCase() ?? "";
            return (
              /^[0-9a-f]{32}$/u.test(tail) &&
              tail.startsWith(shortId) &&
              (!params.agentId || present(read(key)).agentId === params.agentId)
            );
          })
          .map((key) => present(read(key)))
      : [];
    const only = matches.length === 1 ? matches[0] : undefined;
    return only
      ? { ok: true, ...only }
      : { ok: false, ...(matches.length ? { candidates: matches.slice(0, 10) } : {}) };
  };
  // History publishes a full row replacement. An unseeded wire-only fixture
  // has no canonical metadata to publish until its caller declares the row.
  const sessionInfo = (key: string) =>
    listed.has(canonicalKey(key)) ? sample(read(key), Date.now()) : undefined;
  return {
    read,
    resolve,
    sessionInfo,
    requireSessionInfo(this: void, key: string) {
      const row = sessionInfo(key);
      if (!row) {
        throw new Error(`Mock Gateway did not return session ${key}`);
      }
      return row;
    },
    readResponse(
      method: string,
      params: unknown,
      scenario: { sessionKey: string; allowedSessionVisibilities: readonly string[] },
    ) {
      if (method === "sessions.resolve") {
        return resolve(isRecord(params) ? params : {});
      }
      if (
        method !== "sessions.describe" &&
        method !== "sessions.dispatch" &&
        method !== "session.members.listEvidence"
      ) {
        return undefined;
      }
      const field = method === "session.members.listEvidence" ? "sessionKey" : "key";
      const requestedKey = isRecord(params) ? params[field] : undefined;
      const key = typeof requestedKey === "string" ? requestedKey : scenario.sessionKey;
      if (method === "sessions.describe") {
        return { session: sessionInfo(key) ?? null };
      }
      const row = read(key);
      if (method === "sessions.dispatch") {
        return {
          ok: true,
          key,
          sessionId: row.sessionId,
          placement: {
            state: "active",
            generation: 1,
            createdAtMs: 1,
            updatedAtMs: 2,
            stateChangedAtMs: 2,
            environmentId: "mock-worker",
            activeOwnerEpoch: 1,
            workerBundleHash: "a".repeat(64),
            workspaceBaseManifestRef: "mock-manifest",
            remoteWorkspaceDir: "/mock/workspace",
          },
        };
      }
      return {
        sessionKey: row.key,
        members: [],
        identities: [],
        role: row.sharingRole ?? "admin",
        allowedVisibilities: scenario.allowedSessionVisibilities,
      };
    },
    patch,
    setVisibility(key: string, expectedSessionId: string, visibility: SessionVisibility) {
      const canonical = canonicalKey(key);
      const value = records.get(canonical);
      if (!listed.has(canonical) || !value || value.row.sessionId !== expectedSessionId) {
        return {
          __mockError: {
            code: "INVALID_REQUEST",
            message: "session identity changed; refresh and retry",
          },
        };
      }
      value.row = { ...value.row, visibility };
      value.changed.add("visibility");
      return { ok: true, sessionKey: canonical, visibility } satisfies SessionVisibilitySetResult;
    },
    commitAbort,
    trackRun,
    materializeResponse,
    list,
    listResponse,
    materializedCount: () => materializedSequence,
    replaceCanonicalRow(this: void, row: ControlUiSessionFixture) {
      const value = record(row.key);
      // Published snapshots and mutation replies share the same canonical row.
      for (const field of [...Object.keys(value.row), ...Object.keys(row)]) {
        value.changed.add(field);
      }
      value.row = { ...row, key: canonicalKey(row.key) };
      listed.add(value.row.key);
    },
    replaceCanonicalList(rows: unknown[]) {
      const replacements: ControlUiSessionFixture[] = [];
      for (const row of rows) {
        if (!row || typeof row !== "object" || !("key" in row) || typeof row.key !== "string") {
          throw new Error("Canonical sessions.list rows require a string key");
        }
        replacements.push({ ...row, key: canonicalKey(row.key) });
      }
      records.clear();
      listed.clear();
      materialized.clear();
      for (const fixture of replacements) {
        records.set(fixture.key, { row: fixture, changed: new Set() });
        listed.add(fixture.key);
      }
    },
  };
}
