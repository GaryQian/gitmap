import {
  asFiniteNumber,
  isRecord,
  truncateUtf16Safe,
} from "openclaw/plugin-sdk/string-coerce-runtime";
import type { sanitizeTerminalText } from "openclaw/plugin-sdk/terminal-safe-text";
import type { CodexThreadTurnsListResponse } from "./app-server/protocol.js";
import {
  CODEX_INTERACTIVE_CUSTOM_THREAD_SOURCES,
  CODEX_INTERACTIVE_THREAD_SOURCE_KINDS,
} from "./app-server/protocol.js";
import { detachCodexCatalogString } from "./session-catalog-limits.js";
import type {
  CodexCatalogNativeThread,
  CodexSessionCatalogError,
  CodexSessionCatalogPage,
  CodexSessionCatalogPageParams,
  CodexSessionCatalogParams,
  CodexSessionCatalogSession,
} from "./session-catalog-types.js";

const DEFAULT_PAGE_LIMIT = 50;
export const CODEX_APP_SERVER_THREADS_CAPABILITY = "codex-app-server-threads";
export const CODEX_APP_SERVER_THREADS_LIST_COMMAND = "codex.appServer.threads.list.v1";
export const CODEX_APP_SERVER_THREAD_TURNS_LIST_COMMAND = "codex.appServer.thread.turns.list.v1";
export const CODEX_CATALOG_TRANSCRIPT_READ_COMMAND = "codex.sessionCatalog.transcript.read.v1";
export const CODEX_LOCAL_SESSION_HOST_ID = "gateway:local";
export const CODEX_SESSION_CATALOG_MAX_PAGE_LIMIT = 100;
// Cold Codex state scans can outlive the Mac node's native 60-second deadline.
export const NODE_INVOKE_TIMEOUT_MS = 65_000;
const MAX_SEARCH_LENGTH = 500;
export const MAX_CURSOR_LENGTH = 4096;
const MAX_CURSOR_COUNT = 100;
export const MAX_HOST_COUNT = 100;
const MAX_HOST_ID_LENGTH = 256;
export const MAX_CWD_LENGTH = 4096;
export const MAX_SESSION_ID_LENGTH = 256;
const MAX_SESSION_NAME_LENGTH = 500;
const MAX_SESSION_PREVIEW_LENGTH = 500;
const SESSION_PREVIEW_PREFIX_LENGTH = 2_048;
const MAX_METADATA_LENGTH = 500;
const MAX_ACTIVE_FLAGS = 16;
export const DEFAULT_TRANSCRIPT_PAGE_LIMIT = 20;
export const MAX_TRANSCRIPT_PAGE_LIMIT = 50;
export const MAX_TRANSCRIPT_PAGE_BYTES = 20 * 1024 * 1024;
export const MAX_TITLE_SEARCH_CATALOG_PAGES = 20;

export class CatalogParamsError extends Error {}

export function readControlCursor(value: unknown, label: string): string | undefined {
  if (value === undefined || value === null) {
    return undefined;
  }
  if (typeof value !== "string" || !value.trim() || value.length > MAX_CURSOR_LENGTH) {
    throw new CatalogParamsError(`invalid Codex session catalog ${label} cursor`);
  }
  return detachCodexCatalogString(value);
}

export function boundedCatalogString(
  value: unknown,
  maxLength: number,
  overflow: "omit" | "truncate" = "omit",
): string | undefined {
  if (typeof value !== "string") {
    return undefined;
  }
  const normalized = value.trim();
  if (!normalized) {
    return undefined;
  }
  if (normalized.length <= maxLength) {
    return detachCodexCatalogString(normalized);
  }
  return overflow === "truncate"
    ? detachCodexCatalogString(truncateUtf16Safe(normalized, maxLength))
    : undefined;
}

/** Detach the small preview from V8's potentially large sliced-string backing store. */
export function truncateCodexCatalogPreview(
  value: string,
  sanitize: typeof sanitizeTerminalText,
): string {
  let normalized: string | undefined;
  if (value.length > SESSION_PREVIEW_PREFIX_LENGTH) {
    const prefix = value.slice(0, SESSION_PREVIEW_PREFIX_LENGTH).replace(/\s+/g, " ").trim();
    // Without controls the canonical sanitizer is identity. This already-trimmed
    // prefix also retains lookahead across the UTF-16 output boundary.
    if (prefix.length > MAX_SESSION_PREVIEW_LENGTH && !/\p{Cc}/u.test(prefix)) {
      normalized = prefix;
    }
  }
  const preview = truncateUtf16Safe(
    normalized ?? sanitize(value.replace(/\s+/g, " ")).trim(),
    MAX_SESSION_PREVIEW_LENGTH,
  );
  return Buffer.from(preview, "utf8").toString("utf8");
}

function normalizeInteractiveThreadSource(source: unknown) {
  return (
    CODEX_INTERACTIVE_THREAD_SOURCE_KINDS.find((kind) => kind === source) ??
    CODEX_INTERACTIVE_CUSTOM_THREAD_SOURCES.find((kind) => kind === source) ??
    (isRecord(source)
      ? CODEX_INTERACTIVE_CUSTOM_THREAD_SOURCES.find((kind) => kind === source.custom)
      : undefined)
  );
}

export function isInteractiveThreadSource(source: unknown): boolean {
  return normalizeInteractiveThreadSource(source) !== undefined;
}

export function codexCatalogThreadName(value: unknown): string | null | undefined {
  return value === null ? null : boundedCatalogString(value, MAX_SESSION_NAME_LENGTH, "truncate");
}

export function codexCatalogThreadStatus(
  status: Record<string, unknown> | null | undefined,
): Pick<CodexSessionCatalogSession, "status" | "activeFlags"> {
  const activeFlags: string[] = [];
  if (status?.type === "active" && Array.isArray(status.activeFlags)) {
    for (const flag of status.activeFlags) {
      const normalized = boundedCatalogString(flag, 128);
      if (normalized) {
        activeFlags.push(normalized);
      }
      if (activeFlags.length === MAX_ACTIVE_FLAGS) {
        break;
      }
    }
  }
  return {
    status: boundedCatalogString(status?.type, 64) ?? "notLoaded",
    ...(activeFlags.length ? { activeFlags } : {}),
  };
}

export function toCatalogSession(
  thread: CodexCatalogNativeThread,
  preparedPreview: string | null | undefined,
): CodexSessionCatalogSession | undefined {
  // Codex models Atlas and ChatGPT as custom sources but includes both in its
  // interactive default. Normalize those objects for the string-only catalog.
  const source = normalizeInteractiveThreadSource(thread.source);
  if (!source) {
    return undefined;
  }
  const { id: threadId, sessionId, name, cwd, modelProvider, cliVersion } = thread;
  const fallbackName = name ? undefined : preparedPreview;
  const gitBranch = thread.gitInfo?.branch;
  const activeFlags = thread.status?.type === "active" ? thread.status.activeFlags : undefined;
  return {
    threadId,
    status: thread.status?.type ?? "notLoaded",
    ...(thread.catalogError ? { catalogError: thread.catalogError } : {}),
    ...(activeFlags?.length ? { activeFlags } : {}),
    archived: false,
    ...(sessionId ? { sessionId } : {}),
    ...(thread.name === null ? { name: null } : name ? { name } : {}),
    ...(fallbackName ? { fallbackName } : {}),
    ...(cwd ? { cwd } : {}),
    ...(thread.createdAt != null ? { createdAt: thread.createdAt } : {}),
    ...(thread.updatedAt != null ? { updatedAt: thread.updatedAt } : {}),
    ...(thread.recencyAt !== undefined ? { recencyAt: thread.recencyAt } : {}),
    source,
    ...(modelProvider ? { modelProvider } : {}),
    ...(cliVersion ? { cliVersion } : {}),
    ...(gitBranch ? { gitBranch } : {}),
  };
}

export function normalizeLimit(
  value: unknown,
  key: string,
  fallback = DEFAULT_PAGE_LIMIT,
  max = CODEX_SESSION_CATALOG_MAX_PAGE_LIMIT,
): number {
  if (value === undefined) {
    return fallback;
  }
  if (typeof value !== "number" || !Number.isInteger(value) || value < 1 || value > max) {
    throw new CatalogParamsError(`${key} must be an integer from 1 to ${max}`);
  }
  return value;
}

export function readBoundedOptionalString(
  params: Record<string, unknown>,
  key: string,
  maxLength: number,
) {
  const value = params[key];
  if (value === undefined) {
    return undefined;
  }
  if (typeof value !== "string") {
    throw new CatalogParamsError(`${key} must be a string`);
  }
  const trimmed = value.trim();
  if (!trimmed) {
    return undefined;
  }
  if (trimmed.length > maxLength) {
    throw new CatalogParamsError(`${key} must be at most ${maxLength} characters`);
  }
  return trimmed;
}

export function requireOnlyKeys(
  params: Record<string, unknown>,
  allowed: ReadonlySet<string>,
): void {
  const unknown = Object.keys(params).find((key) => !allowed.has(key));
  if (unknown) {
    throw new CatalogParamsError(`unknown Codex session catalog parameter: ${unknown}`);
  }
}

export function readPageParams(value: unknown): CodexSessionCatalogPageParams & { limit: number } {
  if (!isRecord(value)) {
    throw new CatalogParamsError("Codex session catalog parameters must be an object");
  }
  const params = value;
  requireOnlyKeys(params, new Set(["cursor", "limit", "searchTerm", "cwd"]));
  const cursor = readBoundedOptionalString(params, "cursor", MAX_CURSOR_LENGTH);
  const searchTerm = readBoundedOptionalString(params, "searchTerm", MAX_SEARCH_LENGTH);
  const cwd = readBoundedOptionalString(params, "cwd", MAX_CWD_LENGTH);
  return {
    limit: normalizeLimit(params.limit, "limit"),
    ...(cursor ? { cursor } : {}),
    ...(searchTerm ? { searchTerm } : {}),
    ...(cwd ? { cwd } : {}),
  };
}

export function readGatewayParams(
  value: unknown,
): CodexSessionCatalogParams & { limitPerHost: number } {
  if (value !== undefined && !isRecord(value)) {
    throw new CatalogParamsError("Codex session catalog parameters must be an object");
  }
  const params = value ?? {};
  requireOnlyKeys(params, new Set(["search", "limitPerHost", "hostIds", "cursors"]));
  const search = readBoundedOptionalString(params, "search", MAX_SEARCH_LENGTH);
  let hostIds: string[] | undefined;
  if (params.hostIds !== undefined) {
    if (!Array.isArray(params.hostIds) || params.hostIds.length > MAX_HOST_COUNT) {
      throw new CatalogParamsError(`hostIds must contain at most ${MAX_HOST_COUNT} host ids`);
    }
    hostIds = [...new Set(params.hostIds.map((hostId) => readHostId(hostId)))];
  }
  let cursors: Record<string, string> | undefined;
  if (params.cursors !== undefined) {
    if (!isRecord(params.cursors)) {
      throw new CatalogParamsError("cursors must be an object");
    }
    const entries = Object.entries(params.cursors);
    if (entries.length > MAX_CURSOR_COUNT) {
      throw new CatalogParamsError(`cursors may contain at most ${MAX_CURSOR_COUNT} hosts`);
    }
    cursors = {};
    for (const [hostId, cursor] of entries) {
      const normalizedHostId = readHostId(hostId);
      if (
        typeof cursor !== "string" ||
        !cursor.trim() ||
        cursor.trim().length > MAX_CURSOR_LENGTH
      ) {
        throw new CatalogParamsError(`invalid cursor for Codex session catalog host: ${hostId}`);
      }
      cursors[normalizedHostId] = cursor.trim();
    }
  }
  return {
    limitPerHost: normalizeLimit(params.limitPerHost, "limitPerHost"),
    ...(search ? { search } : {}),
    ...(hostIds && hostIds.length > 0 ? { hostIds } : {}),
    ...(cursors && Object.keys(cursors).length > 0 ? { cursors } : {}),
  };
}

function readHostId(value: unknown): string {
  if (typeof value !== "string") {
    throw new CatalogParamsError("Codex session catalog host ids must be strings");
  }
  const hostId = value.trim();
  if (
    hostId.length === 0 ||
    hostId.length > MAX_HOST_ID_LENGTH ||
    (!hostId.startsWith("gateway:") && !hostId.startsWith("node:"))
  ) {
    throw new CatalogParamsError(`invalid Codex session catalog host id: ${value}`);
  }
  return hostId;
}

export function parseJsonParams(paramsJSON?: string | null): unknown {
  if (!paramsJSON?.trim()) {
    return {};
  }
  try {
    return JSON.parse(paramsJSON) as unknown;
  } catch (error) {
    throw new Error("Codex session catalog parameters must be valid JSON", { cause: error });
  }
}

function parseOptionalCatalogString(
  value: unknown,
  field: string,
  maxLength: number,
): string | undefined {
  if (value === undefined) {
    return undefined;
  }
  if (typeof value !== "string" || value.length > maxLength) {
    throw new Error(`Codex session catalog returned an invalid ${field}`);
  }
  return detachCodexCatalogString(value);
}

const CATALOG_SESSION_STRINGS = [
  ["sessionId", "session id", MAX_SESSION_ID_LENGTH],
  ["name", "session name", MAX_SESSION_NAME_LENGTH],
  ["fallbackName", "session fallback name", MAX_SESSION_PREVIEW_LENGTH],
  ["cwd", "cwd", MAX_CWD_LENGTH],
  ["source", "source", MAX_METADATA_LENGTH],
  ["modelProvider", "model provider", MAX_METADATA_LENGTH],
  ["cliVersion", "CLI version", MAX_METADATA_LENGTH],
  ["gitBranch", "Git branch", MAX_METADATA_LENGTH],
] as const;

function parseCatalogSession(value: unknown): CodexSessionCatalogSession {
  if (
    !isRecord(value) ||
    typeof value.threadId !== "string" ||
    !value.threadId.trim() ||
    value.threadId.length > MAX_SESSION_ID_LENGTH ||
    value.archived !== false
  ) {
    throw new Error("Codex session catalog returned an invalid session");
  }
  const status = parseOptionalCatalogString(value.status, "status", 64);
  if (!status?.trim()) {
    throw new Error("Codex session catalog returned an invalid status");
  }
  if (value.activeFlags !== undefined && !Array.isArray(value.activeFlags)) {
    throw new Error("Codex session catalog returned invalid active flags");
  }
  if (Array.isArray(value.activeFlags) && value.activeFlags.length > MAX_ACTIVE_FLAGS) {
    throw new Error("Codex session catalog returned too many active flags");
  }
  const activeFlags = Array.isArray(value.activeFlags)
    ? value.activeFlags.map((entry) => {
        const flag = parseOptionalCatalogString(entry, "active flag", 128);
        if (flag === undefined) {
          throw new Error("Codex session catalog returned an invalid active flag");
        }
        return flag;
      })
    : undefined;
  const session: CodexSessionCatalogSession = {
    threadId: detachCodexCatalogString(value.threadId),
    status,
    archived: value.archived,
  };
  for (const [key, label, limit] of CATALOG_SESSION_STRINGS) {
    if (key === "name" && value.name === null) {
      session.name = null;
      continue;
    }
    const parsed = parseOptionalCatalogString(value[key], label, limit);
    if (parsed !== undefined) {
      session[key] = parsed;
    }
  }
  if (value.catalogError !== undefined) {
    if (value.catalogError !== "oversized-thread") {
      throw new Error("Codex session catalog returned an invalid degraded marker");
    }
    session.catalogError = value.catalogError;
  }
  if (activeFlags?.length) {
    session.activeFlags = activeFlags;
  }
  for (const key of ["createdAt", "updatedAt", "recencyAt"] as const) {
    const parsed = asFiniteNumber(value[key]);
    if (parsed !== undefined) {
      session[key] = parsed;
    } else if (key === "recencyAt" && value.recencyAt === null) {
      session.recencyAt = null;
    }
  }
  return session;
}

export function parseCatalogPage(value: unknown): CodexSessionCatalogPage {
  if (
    !isRecord(value) ||
    !Array.isArray(value.sessions) ||
    value.sessions.length > CODEX_SESSION_CATALOG_MAX_PAGE_LIMIT
  ) {
    throw new Error("Codex session catalog returned an invalid page");
  }
  const nextCursor = parseOptionalCatalogString(value.nextCursor, "next cursor", MAX_CURSOR_LENGTH);
  const sourceHomeId = parseOptionalCatalogString(
    value.sourceHomeId,
    "source home id",
    MAX_SESSION_ID_LENGTH,
  );
  const backwardsCursor = parseOptionalCatalogString(
    value.backwardsCursor,
    "backwards cursor",
    MAX_CURSOR_LENGTH,
  );
  return {
    sessions: value.sessions.map(parseCatalogSession),
    ...(sourceHomeId ? { sourceHomeId } : {}),
    ...(typeof value.canContinueCodex === "boolean"
      ? { canContinueCodex: value.canContinueCodex }
      : {}),
    ...(nextCursor ? { nextCursor } : {}),
    ...(backwardsCursor ? { backwardsCursor } : {}),
  };
}

export function filterCatalogPageByTitle(
  page: CodexSessionCatalogPage,
  searchTerm: string | undefined,
): CodexSessionCatalogPage {
  const search = searchTerm?.toLocaleLowerCase().normalize("NFC");
  if (!search) {
    return page;
  }
  return {
    ...page,
    sessions: page.sessions.filter((session) =>
      (session.name ?? session.fallbackName)?.toLocaleLowerCase().normalize("NFC").includes(search),
    ),
  };
}

export function unwrapNodeInvokePayload(
  value: unknown,
  malformedMessage = "Codex node returned malformed session catalog JSON",
): unknown {
  if (!isRecord(value)) {
    return value;
  }
  if (typeof value.payloadJSON === "string" && value.payloadJSON.trim()) {
    try {
      return JSON.parse(value.payloadJSON) as unknown;
    } catch (error) {
      throw new Error(malformedMessage, { cause: error });
    }
  }
  return "payload" in value ? value.payload : value;
}

function catalogErrorDetail(error: unknown): string {
  if (error instanceof Error) {
    return error.message.trim();
  }
  if (typeof error === "string") {
    return error.trim();
  }
  if (error && typeof error === "object" && "message" in error) {
    const message = (error as { message?: unknown }).message;
    return typeof message === "string" ? message.trim() : "";
  }
  return "";
}

export function catalogError(code: string, error: unknown): CodexSessionCatalogError {
  const messages: Record<string, string> = {
    APP_SERVER_UNAVAILABLE: "Codex app-server is unavailable on this host",
    NODE_INVOKE_FAILED: "The paired node could not return its Codex session catalog",
    NODE_LIST_FAILED: "Paired nodes could not be listed",
  };
  const summary = messages[code] ?? "Codex session catalog request failed";
  // Node-list failures are operator diagnostics from the local Gateway. Other
  // catalog errors may cross node/App Server boundaries and keep their bounded summary.
  const detail = code === "NODE_LIST_FAILED" ? catalogErrorDetail(error) : "";
  return { code, message: detail && detail !== summary ? `${summary}: ${detail}` : summary };
}

export function parseTranscriptPage(value: unknown): CodexThreadTurnsListResponse {
  if (
    !isRecord(value) ||
    !Array.isArray(value.data) ||
    value.data.length > MAX_TRANSCRIPT_PAGE_LIMIT ||
    value.data.some(
      (turn) =>
        !isRecord(turn) || !Array.isArray(turn.items) || turn.items.some((item) => !isRecord(item)),
    )
  ) {
    throw new Error("Codex app-server returned an invalid chat history page");
  }
  const nextCursor = readControlCursor(value.nextCursor, "chat history next response");
  const backwardsCursor = readControlCursor(
    value.backwardsCursor,
    "chat history backwards response",
  );
  const page: CodexThreadTurnsListResponse = {
    data: value.data as CodexThreadTurnsListResponse["data"],
    ...(nextCursor ? { nextCursor } : {}),
    ...(backwardsCursor ? { backwardsCursor } : {}),
  };
  // A bounded item count does not bound tool output embedded in one item. Keep
  // the page below node.invoke and Gateway WebSocket payload ceilings.
  if (Buffer.byteLength(JSON.stringify(page), "utf8") > MAX_TRANSCRIPT_PAGE_BYTES) {
    throw new Error("Codex app-server chat history page exceeds the safe response size");
  }
  return page;
}

// Local adoptions always record a bound thread; a missing one means binding
// resolution failed, so fail loud rather than baseline the wrong source thread.
export function requireBoundThread(entry: { boundThreadId?: string }): string {
  if (!entry.boundThreadId) {
    throw new CatalogParamsError("Codex adoption is missing its bound thread. Retry.");
  }
  return entry.boundThreadId;
}
